function [T_tend_overall_term_names,T_tend_detailed_term_names,vardepth_breakdown_term_names,adv_T_tend_vel_temp_reg_term_names,vol_flux_term_names,vert_mean_term_names,T_tend_overall_terms_avg,T_tend_overall_terms_reg_avg,T_tend_overall_terms_noreg_avg,T_tend_detailed_terms_avg,T_tend_detailed_terms_reg_avg,T_tend_detailed_terms_noreg_avg,vardepth_breakdown_terms_avg,vardepth_breakdown_terms_reg_avg,vardepth_breakdown_terms_noreg_avg,adv_T_tend_vel_temp_reg_terms_avg,vol_flux_terms_avg,vol_flux_terms_reg_avg,vol_flux_terms_noreg_avg,vert_mean_terms_avg,vert_mean_terms_reg_avg,vert_mean_terms_noreg_avg] = temp_budget_maps_ML_reg_decomp_fcn(reg_level_option,file_name_base_input,file_name_base_output,i_f,j_f,nc_filenames,file_nums_in_time_range,file_num_vec,time,unique_time_ind,in_file_ind_vec,lon_ind_inrange,lat_ind_inrange,depth_ind_inrange,tarea,hte,htn,dzt,dzt_east_wall,dzt_north_wall,dz,top_depth_bound_array,bottom_depth_bound_array,unique_times,z_w_top,z_w_bot,dxu,dyu,dzu,dxt,dyt,n_subsets_regression,weighting_array_regression,G_reg_array,reg_operator_T_array,ht,ent_compute_option,time_avg_ind_inrange,time_avg_from_unique_reg_ind)

% compute correlations of a time series with with mixed layer temperature budget terms


if reg_level_option > 1
    
    reg_level_option_new = reg_level_option;
    time_new = time;
    unique_time_ind_new = unique_time_ind;
    unique_times_new = unique_times;
    n_subsets_regression_new = n_subsets_regression;
    weighting_array_regression_new = weighting_array_regression;
    G_reg_array_new = G_reg_array;
    reg_operator_T_array_new = reg_operator_T_array;
    ent_compute_option_new = ent_compute_option;
    time_avg_ind_inrange_new = time_avg_ind_inrange;
    time_avg_from_unique_reg_ind_new = time_avg_from_unique_reg_ind;
    
    % load input file of previously-regressed quantities
    
    file_name_input = [file_name_base_input,'_',num2str(i_f),'_',num2str(j_f),'.mat'];
    load(file_name_input,'a*','b*','c*','d*','e*','f*','g*')
    disp('Loaded input file, a-g')
    load(file_name_input,'h*','i*','j*','k*','l*','m*','M*','n*','o*','p*')
    disp('Loaded input file, h-p')
    load(file_name_input,'q*','r*','s*','S*','t*','T*','u*','U*','v*','w*','x*','y*','z*')
    disp('Loaded input file, q-z')
    
    
    time_reg_level1 = time;
    time = time(unique_time_ind);
    
    unique_time_ind_reg_level1 = unique_time_ind;
    
    clear unique_time_ind
    
    
    reg_level_option = reg_level_option_new;
    time = time_new;
    unique_time_ind = unique_time_ind_new;
    unique_times = unique_times_new;
    n_subsets_regression = n_subsets_regression_new;
    weighting_array_regression = weighting_array_regression_new;
    G_reg_array = G_reg_array_new;
    reg_operator_T_array = reg_operator_T_array_new;
    ent_compute_option = ent_compute_option_new;
    time_avg_ind_inrange = time_avg_ind_inrange_new;
    time_avg_from_unique_reg_ind = time_avg_from_unique_reg_ind_new;
    
    
end



if reg_level_option == 1
    
    time_reg_level1 = time;
    unique_time_ind_reg_level1 = unique_time_ind;
    
    % load archived fields
    
    curr_file_start_ind = 1;
    
    SSH = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
    ML_depth = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
    uvel = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
    vvel = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
    wvel = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
    temp = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
    uet = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
    vnt = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
    wtt = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
    hdif_gridx_temp = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
    hdif_gridy_temp = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
    hdif_gridz_temp = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
    diab_imp_vert_T_flux_bottom = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
    kpp_src_temp = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
    sfc_heat_flux = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
    % sfc_freshwater_flux = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
    sw_flux_top = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
    evap_mass_flux = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
    longwave_downward_flux = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
    longwave_upward_flux = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
    sensible_heat_flux = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
    tot_temp_tend = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
    tend_temp_present_vec = [];
    for file_num_ind = 1:length(nc_filenames)
        file_num = file_nums_in_time_range(file_num_ind);
        
        time_curr_source_file = ncread(nc_filenames{file_num},'time');
        
    %     time_ind_infile = find(file_num_vec(time_ind_inrange) == file_num);
    %     curr_time_ind_inrange = in_file_ind_vec(time_ind_inrange(time_ind_infile));
    
        time_ind_infile = find(file_num_vec(unique_time_ind) == file_num);
        if isempty(time_ind_infile) == 1
            continue
        end
        
        curr_time_ind_inrange = in_file_ind_vec(unique_time_ind(time_ind_infile));
        
        
        start_vector_nodepth = [min(lon_ind_inrange) min(lat_ind_inrange) min(curr_time_ind_inrange)];
        size_vector_nodepth = [length(lon_ind_inrange) length(lat_ind_inrange) (max(curr_time_ind_inrange) - min(curr_time_ind_inrange) + 1)];
        
        
        subsetting_in_time_ind = curr_time_ind_inrange - min(curr_time_ind_inrange) + 1;
        
        curr_file_end_ind = curr_file_start_ind - 1 + length(curr_time_ind_inrange);
        
        
        % load SSH
        curr_SSH = ncread(nc_filenames{file_num},'SSH',start_vector_nodepth,size_vector_nodepth,ones(1,3));
        SSH(:,:,curr_file_start_ind:curr_file_end_ind) = curr_SSH(:,:,subsetting_in_time_ind);
        
        
%         % load mixed layer depth
%         curr_ML_depth = ncread(nc_filenames{file_num},'HMXL',start_vector_nodepth,size_vector_nodepth,ones(1,3));
%         ML_depth(:,:,curr_file_start_ind:curr_file_end_ind) = curr_ML_depth(:,:,subsetting_in_time_ind);
        
        
        
        % load velocity and tracer flux variables
        
        start_vector = [min(lon_ind_inrange) min(lat_ind_inrange) min(depth_ind_inrange) min(curr_time_ind_inrange)];
        size_vector = [length(lon_ind_inrange) length(lat_ind_inrange) length(depth_ind_inrange) (max(curr_time_ind_inrange) - min(curr_time_ind_inrange) + 1)];
        
        curr_uvel = ncread(nc_filenames{file_num},'UVEL',start_vector,size_vector,ones(1,4));
        uvel(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_uvel(:,:,:,subsetting_in_time_ind);
        curr_vvel = ncread(nc_filenames{file_num},'VVEL',start_vector,size_vector,ones(1,4));
        vvel(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_vvel(:,:,:,subsetting_in_time_ind);
        curr_wvel = ncread(nc_filenames{file_num},'WVEL',start_vector,size_vector,ones(1,4));
        wvel(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_wvel(:,:,:,subsetting_in_time_ind);
        
        curr_temp = ncread(nc_filenames{file_num},'TEMP',start_vector,size_vector,ones(1,4));
        temp(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_temp(:,:,:,subsetting_in_time_ind);
        
        curr_uet = ncread(nc_filenames{file_num},'UET',start_vector,size_vector,ones(1,4));
        uet(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_uet(:,:,:,subsetting_in_time_ind);
        curr_vnt = ncread(nc_filenames{file_num},'VNT',start_vector,size_vector,ones(1,4));
        vnt(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_vnt(:,:,:,subsetting_in_time_ind);
        curr_wtt = ncread(nc_filenames{file_num},'WTT',start_vector,size_vector,ones(1,4));
        wtt(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_wtt(:,:,:,subsetting_in_time_ind);
        
        
        
        % load horizontal diffusion variables
        
        curr_hdif_gridx_temp = ncread(nc_filenames{file_num},'HDIFE_TEMP',start_vector,size_vector,ones(1,4));
        hdif_gridx_temp(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_hdif_gridx_temp(:,:,:,subsetting_in_time_ind);
        curr_hdif_gridy_temp = ncread(nc_filenames{file_num},'HDIFN_TEMP',start_vector,size_vector,ones(1,4));
        hdif_gridy_temp(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_hdif_gridy_temp(:,:,:,subsetting_in_time_ind);
        curr_hdif_gridz_temp = ncread(nc_filenames{file_num},'HDIFB_TEMP',start_vector,size_vector,ones(1,4));
        curr_hdif_gridz_temp(isnan(curr_hdif_gridz_temp) == 1) = 0;
        hdif_gridz_temp(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_hdif_gridz_temp(:,:,:,subsetting_in_time_ind);
        
        
        
        % load diabatic vertical mixing flux variable
        curr_diab_imp_vert_T_flux_bottom = ncread(nc_filenames{file_num},'DIA_IMPVF_TEMP',start_vector,size_vector,ones(1,4));
        curr_diab_imp_vert_T_flux_bottom(isnan(curr_diab_imp_vert_T_flux_bottom) == 1) = 0;
        diab_imp_vert_T_flux_bottom(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_diab_imp_vert_T_flux_bottom(:,:,:,subsetting_in_time_ind);
        
        
        % load non-local source term variable (boundary layer convection)
        curr_kpp_src_temp = ncread(nc_filenames{file_num},'KPP_SRC_TEMP',start_vector,size_vector,ones(1,4));
        curr_kpp_src_temp(isnan(curr_kpp_src_temp) == 1) = 0;
        kpp_src_temp(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_kpp_src_temp(:,:,:,subsetting_in_time_ind);
        
        % load surface flux, shortwave flux, and other component variables
        curr_sfc_heat_flux = ncread(nc_filenames{file_num},'SHF',start_vector([1 2 4]),size_vector([1 2 4]),ones(1,3));
        curr_sfc_heat_flux(isnan(curr_sfc_heat_flux) == 1) = 0;
        sfc_heat_flux(:,:,curr_file_start_ind:curr_file_end_ind) = curr_sfc_heat_flux(:,:,subsetting_in_time_ind);
    %     curr_sfc_freshwater_flux = ncread(nc_filenames{file_num},'SFWF',start_vector([1 2 4]),size_vector([1 2 4]),ones(1,3));
    %     curr_sfc_freshwater_flux(isnan(curr_sfc_freshwater_flux) == 1) = 0;
    %     sfc_freshwater_flux(:,:,curr_file_start_ind:curr_file_end_ind) = curr_sfc_freshwater_flux(:,:,subsetting_in_time_ind);
        curr_sw_flux_top = ncread(nc_filenames{file_num},'QSW_3D',start_vector,size_vector,ones(1,4));
        curr_sw_flux_top(isnan(curr_sw_flux_top) == 1) = 0;
        sw_flux_top(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_sw_flux_top(:,:,:,subsetting_in_time_ind);
        
        curr_evap_mass_flux = ncread(nc_filenames{file_num},'EVAP_F',start_vector([1 2 4]),size_vector([1 2 4]),ones(1,3));
        curr_evap_mass_flux(isnan(curr_evap_mass_flux) == 1) = 0;
        evap_mass_flux(:,:,curr_file_start_ind:curr_file_end_ind) = curr_evap_mass_flux(:,:,subsetting_in_time_ind);
        curr_longwave_downward_flux = ncread(nc_filenames{file_num},'LWDN_F',start_vector([1 2 4]),size_vector([1 2 4]),ones(1,3));
        curr_longwave_downward_flux(isnan(curr_longwave_downward_flux) == 1) = 0;
        longwave_downward_flux(:,:,curr_file_start_ind:curr_file_end_ind) = curr_longwave_downward_flux(:,:,subsetting_in_time_ind);
        curr_longwave_upward_flux = ncread(nc_filenames{file_num},'LWUP_F',start_vector([1 2 4]),size_vector([1 2 4]),ones(1,3));
        curr_longwave_upward_flux(isnan(curr_longwave_upward_flux) == 1) = 0;
        longwave_upward_flux(:,:,curr_file_start_ind:curr_file_end_ind) = curr_longwave_upward_flux(:,:,subsetting_in_time_ind);
        curr_sensible_heat_flux = ncread(nc_filenames{file_num},'SENH_F',start_vector([1 2 4]),size_vector([1 2 4]),ones(1,3));
        curr_sensible_heat_flux(isnan(curr_sensible_heat_flux) == 1) = 0;
        sensible_heat_flux(:,:,curr_file_start_ind:curr_file_end_ind) = curr_sensible_heat_flux(:,:,subsetting_in_time_ind);
        
        
        % load total temperature tendency variable (if archived)
        try
            curr_tot_temp_tend = ncread(nc_filenames{file_num},'TEND_TEMP',start_vector,size_vector,ones(1,4));
            curr_tot_temp_tend(isnan(curr_tot_temp_tend) == 1) = 0;
            tot_temp_tend(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_tot_temp_tend(:,:,:,subsetting_in_time_ind);
            tend_temp_present_vec = [tend_temp_present_vec; 1];
        catch
            tend_temp_present_vec = [tend_temp_present_vec; 0];
        end
        
        disp(['file_num_ind = ',num2str(file_num_ind),' (out of ',num2str(length(nc_filenames)),')'])
        
        curr_file_start_ind = curr_file_start_ind + length(curr_time_ind_inrange);
        
    end
    
    
    % if archived temperature tendency is missing in any source file, do not include it in calculations
    if isempty(find(tend_temp_present_vec == 0)) == 0
        tend_temp_present = 0;
        clear tot_temp_tend
    else
        tend_temp_present = 1;
    end
    
    
    % load conversion factor for surface heat flux
    hflux_factor = ncread(nc_filenames{1},'hflux_factor');
    
    % load conversion factor for latent heat flux (latent heat of vaporization)
    latent_heat_vapor = ncread(nc_filenames{1},'latent_heat_vapor');
    
    
    
    disp('Completed loading archived terms')
    
    
    
    % recover temp. fluxes in the correct units
    
    uT_east = repmat(tarea./hte,[1 1 size(uet,3) size(uet,4)]).*repmat(dzt(:,:,depth_ind_inrange)./dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 size(uet,4)]).*uet;
    uT_east((isnan(uT_east) == 1) | (isinf(uT_east) == 1)) = 0;
    vT_north = repmat(tarea./htn,[1 1 size(vnt,3) size(vnt,4)]).*repmat(dzt(:,:,depth_ind_inrange)./dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 size(vnt,4)]).*vnt;
    vT_north((isnan(vT_north) == 1) | (isinf(vT_north) == 1)) = 0;
    wT_top = repmat(reshape(dz(depth_ind_inrange),[1 1 length(depth_ind_inrange) 1]),[size(wtt,1) size(wtt,2) 1 size(wtt,4)]).*wtt;
    
    clear uet vnt wtt
    
    
    % recover horizontal diffusive fluxes in the correct units
    
    hdiff_T_flux_east = -repmat(tarea./hte,[1 1 size(hdif_gridx_temp,3) size(hdif_gridx_temp,4)]).*repmat(dzt(:,:,depth_ind_inrange)./dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 size(hdif_gridx_temp,4)]).*hdif_gridx_temp;
    hdiff_T_flux_east((isnan(hdiff_T_flux_east) == 1) | (isinf(hdiff_T_flux_east) == 1)) = 0;
    hdiff_T_flux_north = -repmat(tarea./htn,[1 1 size(hdif_gridy_temp,3) size(hdif_gridy_temp,4)]).*repmat(dzt(:,:,depth_ind_inrange)./dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 size(hdif_gridy_temp,4)]).*hdif_gridy_temp;
    hdiff_T_flux_north((isnan(hdiff_T_flux_north) == 1) | (isinf(hdiff_T_flux_north) == 1)) = 0;
    hdiff_T_flux_bottom = -repmat(reshape(dz(depth_ind_inrange),[1 1 length(depth_ind_inrange)]),[length(lon_ind_inrange) length(lat_ind_inrange) 1 size(hdif_gridz_temp,4)]).*hdif_gridz_temp;
    
    clear hdif_gridx_temp hdif_gridy_temp hdif_gridz_temp
    
    
end



if reg_level_option > 1
    
    % set up arrays from input file
    
%     mean_ML_depth = mean_ML_depth(:,:,unique_time_ind);
    
    top_depth_bound_array = top_depth_bound_array(:,:,unique_time_ind);
    bottom_depth_bound_array = bottom_depth_bound_array(:,:,unique_time_ind);
    
    uvel_prev_reg_east = uvel_east(:,:,:,unique_time_ind) - uvel_noreg_east(:,:,:,unique_time_ind);
    uvel_prev_reg_west = uvel_west(:,:,:,unique_time_ind) - uvel_noreg_west(:,:,:,unique_time_ind);
    vvel_prev_reg_north = vvel_north(:,:,:,unique_time_ind) - vvel_noreg_north(:,:,:,unique_time_ind);
    vvel_prev_reg_south = vvel_south(:,:,:,unique_time_ind) - vvel_noreg_south(:,:,:,unique_time_ind);
    wvel_prev_reg = wvel(:,:,:,unique_time_ind) - wvel_noreg(:,:,:,unique_time_ind);
    T_prev_reg_east = T_east_side_minus_T_vert_avg(:,:,:,unique_time_ind) - T_noreg_east(:,:,:,unique_time_ind);
    T_prev_reg_west = T_west_side_minus_T_vert_avg(:,:,:,unique_time_ind) - T_noreg_west(:,:,:,unique_time_ind);
    T_prev_reg_north = T_north_side_minus_T_vert_avg(:,:,:,unique_time_ind) - T_noreg_north(:,:,:,unique_time_ind);
    T_prev_reg_south = T_south_side_minus_T_vert_avg(:,:,:,unique_time_ind) - T_noreg_south(:,:,:,unique_time_ind);
    T_prev_reg_at_w_level = T_minus_T_vert_mean_at_w_level(:,:,:,unique_time_ind) - T_noreg_at_w_level(:,:,:,unique_time_ind);
    
    SSH = SSH(:,:,unique_time_ind);
    ML_depth = ML_depth(:,:,unique_time_ind);
    uvel_east = uvel_noreg_east(:,:,:,unique_time_ind);
    uvel_west = uvel_noreg_west(:,:,:,unique_time_ind);
    vvel_north = vvel_noreg_north(:,:,:,unique_time_ind);
    vvel_south = vvel_noreg_south(:,:,:,unique_time_ind);
    wvel = wvel_noreg(:,:,:,unique_time_ind);
    
    temp = temp_noreg(:,:,:,unique_time_ind);
    T_east_side_minus_T_vert_avg = T_noreg_east(:,:,:,unique_time_ind);
    T_west_side_minus_T_vert_avg = T_noreg_west(:,:,:,unique_time_ind);
    T_north_side_minus_T_vert_avg = T_noreg_north(:,:,:,unique_time_ind);
    T_south_side_minus_T_vert_avg = T_noreg_south(:,:,:,unique_time_ind);
    T_minus_T_vert_mean_at_w_level = T_noreg_at_w_level(:,:,:,unique_time_ind);
    
    adv_T_tend_E = adv_T_tend_E_noreg(:,:,unique_time_ind);
    adv_T_tend_W = adv_T_tend_W_noreg(:,:,unique_time_ind);
    adv_T_tend_N = adv_T_tend_N_noreg(:,:,unique_time_ind);
    adv_T_tend_S = adv_T_tend_S_noreg(:,:,unique_time_ind);
    adv_T_tend_top = adv_T_tend_top_noreg(:,:,unique_time_ind);
    adv_T_tend_bottom = adv_T_tend_bottom_noreg(:,:,unique_time_ind);
    adv_T_tend_E_sloping_top = adv_T_tend_E_sloping_top_noreg(:,:,unique_time_ind);
    adv_T_tend_W_sloping_top = adv_T_tend_W_sloping_top_noreg(:,:,unique_time_ind);
    adv_T_tend_N_sloping_top = adv_T_tend_N_sloping_top_noreg(:,:,unique_time_ind);
    adv_T_tend_S_sloping_top = adv_T_tend_S_sloping_top_noreg(:,:,unique_time_ind);
    adv_T_tend_E_sloping_bottom = adv_T_tend_E_sloping_bottom_noreg(:,:,unique_time_ind);
    adv_T_tend_W_sloping_bottom = adv_T_tend_W_sloping_bottom_noreg(:,:,unique_time_ind);
    adv_T_tend_N_sloping_bottom = adv_T_tend_N_sloping_bottom_noreg(:,:,unique_time_ind);
    adv_T_tend_S_sloping_bottom = adv_T_tend_S_sloping_bottom_noreg(:,:,unique_time_ind);
    
    hdiff_T_tend_E = hdiff_T_tend_E_noreg(:,:,unique_time_ind);
    hdiff_T_tend_W = hdiff_T_tend_W_noreg(:,:,unique_time_ind);
    hdiff_T_tend_N = hdiff_T_tend_N_noreg(:,:,unique_time_ind);
    hdiff_T_tend_S = hdiff_T_tend_S_noreg(:,:,unique_time_ind);
    hdiff_T_tend_top = hdiff_T_tend_top_noreg(:,:,unique_time_ind);
    hdiff_T_tend_bottom = hdiff_T_tend_bottom_noreg(:,:,unique_time_ind);
    hdiff_T_tend_E_sloping_top = hdiff_T_tend_E_sloping_top_noreg(:,:,unique_time_ind);
    hdiff_T_tend_W_sloping_top = hdiff_T_tend_W_sloping_top_noreg(:,:,unique_time_ind);
    hdiff_T_tend_N_sloping_top = hdiff_T_tend_N_sloping_top_noreg(:,:,unique_time_ind);
    hdiff_T_tend_S_sloping_top = hdiff_T_tend_S_sloping_top_noreg(:,:,unique_time_ind);
    hdiff_T_tend_E_sloping_bottom = hdiff_T_tend_E_sloping_bottom_noreg(:,:,unique_time_ind);
    hdiff_T_tend_W_sloping_bottom = hdiff_T_tend_W_sloping_bottom_noreg(:,:,unique_time_ind);
    hdiff_T_tend_N_sloping_bottom = hdiff_T_tend_N_sloping_bottom_noreg(:,:,unique_time_ind);
    hdiff_T_tend_S_sloping_bottom = hdiff_T_tend_S_sloping_bottom_noreg(:,:,unique_time_ind);
    
    sfc_ent_T_tend_adj = sfc_ent_T_tend_adj_noreg(:,:,unique_time_ind);
    ent_T_tend_top = ent_T_tend_top_noreg(:,:,unique_time_ind);
    ent_T_tend_bottom = ent_T_tend_bottom_noreg(:,:,unique_time_ind);
    ent_T_tend_total = ent_T_tend_total_noreg(:,:,unique_time_ind);
    diab_vert_T_tend_top = diab_vert_T_tend_top_noreg(:,:,unique_time_ind);
    diab_vert_T_tend_bottom = diab_vert_T_tend_bottom_noreg(:,:,unique_time_ind);
    diab_vert_T_tend = diab_vert_T_tend_noreg(:,:,unique_time_ind);
    kpp_src_T_tend = kpp_src_T_tend_noreg(:,:,unique_time_ind);
    sw_top_flux_T_tend = sw_top_flux_T_tend_noreg(:,:,unique_time_ind);
    sw_bottom_flux_T_tend = sw_bottom_flux_T_tend_noreg(:,:,unique_time_ind);
    longwave_downward_flux_T_tend = longwave_downward_flux_T_tend_noreg(:,:,unique_time_ind);
    longwave_upward_flux_T_tend = longwave_upward_flux_T_tend_noreg(:,:,unique_time_ind);
    latent_heat_flux_T_tend = latent_heat_flux_T_tend_noreg(:,:,unique_time_ind);
    sensible_heat_flux_T_tend = sensible_heat_flux_T_tend_noreg(:,:,unique_time_ind);
    sfc_sw_flux_T_tend = sfc_sw_flux_T_tend_noreg(:,:,unique_time_ind);
    
    try
        total_T_tend = total_T_tend(:,:,unique_time_ind);
    end
    
    ent_vol_flux_top = ent_vol_flux_top(:,:,unique_time_ind);
    ent_vol_flux_bottom = ent_vol_flux_bottom(:,:,unique_time_ind);
    
    
    erroneous_array_mask = erroneous_array_mask(:,:,unique_time_ind);
    
end



% compute the boundaries of the box


% create depth integrating array for region

no_thickness_ind = find(bottom_depth_bound_array - top_depth_bound_array <= 0);
    
depth_integrating_array = zeros(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_times));
for curr_depth_ind = 1:length(depth_ind_inrange)
    curr_k_ind = depth_ind_inrange(curr_depth_ind);
    
    at_shallowest_level_ind = find((top_depth_bound_array >= z_w_top(curr_k_ind)) & (top_depth_bound_array < z_w_bot(curr_k_ind)));
    at_deepest_level_ind = find((bottom_depth_bound_array > z_w_top(curr_k_ind)) & (bottom_depth_bound_array <= z_w_bot(curr_k_ind)));
    only_one_in_level_ind = intersect(at_shallowest_level_ind,at_deepest_level_ind);
    not_vert_edge_adj_ind = find((top_depth_bound_array < z_w_top(curr_k_ind)) & (bottom_depth_bound_array > z_w_bot(curr_k_ind)));
    
    depth_integrating_curr_level = zeros(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_times));
    depth_integrating_curr_level(at_shallowest_level_ind) = z_w_bot(curr_k_ind) - top_depth_bound_array(at_shallowest_level_ind);
    depth_integrating_curr_level(at_deepest_level_ind) = bottom_depth_bound_array(at_deepest_level_ind) - z_w_top(curr_k_ind);
    depth_integrating_curr_level(only_one_in_level_ind) = max([(bottom_depth_bound_array(only_one_in_level_ind) - top_depth_bound_array(only_one_in_level_ind)) zeros(length(only_one_in_level_ind),1)],[],2);
    depth_integrating_curr_level(not_vert_edge_adj_ind) = dz(curr_k_ind)*ones(length(not_vert_edge_adj_ind),1);
    
    depth_integrating_curr_level(no_thickness_ind) = 0;
    
    depth_integrating_array(:,:,curr_depth_ind,:) = reshape(depth_integrating_curr_level,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]);
end




if reg_level_option == 1
    % interpolate horizontal velocities to the middle of T-cell walls
    
    dyu_dzu_uvel = repmat(dyu,[1 1 size(uvel,3) size(uvel,4)]).*repmat(dzu(:,:,depth_ind_inrange),[1 1 1 size(uvel,4)]).*uvel;
%     uvel_east = zeros(size(uvel));
%     uvel_east(:,2:size(uvel_east,2),:,:) = repmat(1./hte(:,2:size(dyt,2)),[1 1 size(uvel,3) size(uvel,4)]).*repmat(1./dzt_east_wall(:,2:size(dzt_east_wall,2),depth_ind_inrange),[1 1 1 size(uvel,4)]).*(dyu_dzu_uvel(:,2:size(dyu_dzu_uvel,2),:,:) - (diff(dyu_dzu_uvel,1,2)/2));
%     uvel_east(isnan(uvel_east) == 1) = 0;
    uvel_east = NaN(size(uvel));
    uvel_east_temp = repmat(1./hte(:,2:size(dyt,2)),[1 1 size(uvel,3) size(uvel,4)]).*repmat(1./dzt_east_wall(:,2:size(dzt_east_wall,2),depth_ind_inrange),[1 1 1 size(uvel,4)]).*(dyu_dzu_uvel(:,2:size(dyu_dzu_uvel,2),:,:) - (diff(dyu_dzu_uvel,1,2)/2));
    uvel_east_temp(isnan(uvel_east_temp) == 1) = 0;
    uvel_east(:,2:size(uvel_east,2),:,:) = uvel_east_temp;
    clear dyu_dzu_uvel uvel_east_temp
    
    dxu_dzu_vvel = repmat(dxu,[1 1 size(vvel,3) size(vvel,4)]).*repmat(dzu(:,:,depth_ind_inrange),[1 1 1 size(vvel,4)]).*vvel;
%     vvel_north = zeros(size(vvel));
%     vvel_north(2:size(vvel_north,1),:,:,:) = repmat(1./htn(2:size(dxt,1),:),[1 1 size(vvel,3) size(vvel,4)]).*repmat(1./dzt_north_wall(2:size(dzt_north_wall,1),:,depth_ind_inrange),[1 1 1 size(vvel,4)]).*(dxu_dzu_vvel(2:size(dxu_dzu_vvel,1),:,:,:) - (diff(dxu_dzu_vvel,1,1)/2));
%     vvel_north(isnan(vvel_north) == 1) = 0;
    vvel_north = NaN(size(vvel));
    vvel_north_temp = repmat(1./htn(2:size(dxt,1),:),[1 1 size(vvel,3) size(vvel,4)]).*repmat(1./dzt_north_wall(2:size(dzt_north_wall,1),:,depth_ind_inrange),[1 1 1 size(vvel,4)]).*(dxu_dzu_vvel(2:size(dxu_dzu_vvel,1),:,:,:) - (diff(dxu_dzu_vvel,1,1)/2));
    vvel_north_temp(isnan(vvel_north_temp) == 1) = 0;
    vvel_north(2:size(vvel_north,1),:,:,:) = vvel_north_temp;
    clear dxu_dzu_vvel vvel_north_temp
end





% create depth integrating array that accounts for presence of bathymetry

min_dzt_depth_integrating_array_5D = zeros(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_times),2);
min_dzt_depth_integrating_array_5D(:,:,:,:,1) = depth_integrating_array;
min_dzt_depth_integrating_array_5D(:,:,:,:,2) = repmat(dzt(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]);
min_dzt_depth_integrating_array = squeeze(min(min_dzt_depth_integrating_array_5D,[],5));


% compute the vertically-averaged temperature in the layer

temp(isnan(temp) == 1) = 0;

SSH_depth_integrating_top_layer = zeros(size(SSH));
top_at_sfc_ind = find(top_depth_bound_array <= 0);
SSH_depth_integrating_top_layer(top_at_sfc_ind) = SSH(top_at_sfc_ind);
SSH_depth_integrating_top_layer(isnan(SSH_depth_integrating_top_layer) == 1) = 0;
SSH_depth_integrating_array = zeros(size(min_dzt_depth_integrating_array));
SSH_depth_integrating_array(:,:,1,:) = reshape(SSH_depth_integrating_top_layer,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]);

layer_thickness_array = squeeze(sum(min_dzt_depth_integrating_array + SSH_depth_integrating_array,3));
T_vert_integrated_inlayer = squeeze(sum((min_dzt_depth_integrating_array + SSH_depth_integrating_array).*temp,3));

T_vert_mean_inlayer = T_vert_integrated_inlayer./layer_thickness_array;




% % time array for seasonal harmonic regressions (with 3 harmonics)
% 
% G_reg = [ones(length(unique_times),1) cos((2*pi/365)*unique_times) sin((2*pi/365)*unique_times) cos((2*pi/(365/2))*unique_times) sin((2*pi/(365/2))*unique_times) cos((2*pi/(365/3))*unique_times) sin((2*pi/(365/3))*unique_times) cos((2*pi/(365/4))*unique_times) sin((2*pi/(365/4))*unique_times)];






% compute advective volume and tracer fluxes, diffusive fluxes


size_array = [length(lon_ind_inrange) length(lat_ind_inrange) length(depth_ind_inrange) length(unique_times)];


if reg_level_option == 1
    uvel_west = NaN(size_array);
    uvel_west(2:length(lon_ind_inrange),:,:,:) = uvel_east(1:(length(lon_ind_inrange) - 1),:,:,:);
    uT_west = NaN(size_array);
    uT_west(2:length(lon_ind_inrange),:,:,:) = uT_east(1:(length(lon_ind_inrange) - 1),:,:,:);
    hdiff_T_flux_west = NaN(size_array);
    hdiff_T_flux_west(2:length(lon_ind_inrange),:,:,:) = hdiff_T_flux_east(1:(length(lon_ind_inrange) - 1),:,:,:);
    
    vvel_south = NaN(size_array);
    vvel_south(:,2:length(lat_ind_inrange),:,:) = vvel_north(:,1:(length(lat_ind_inrange) - 1),:,:);
    vT_south = NaN(size_array);
    vT_south(:,2:length(lat_ind_inrange),:,:) = vT_north(:,1:(length(lat_ind_inrange) - 1),:,:);
    hdiff_T_flux_south = NaN(size_array);
    hdiff_T_flux_south(:,2:length(lat_ind_inrange),:,:) = hdiff_T_flux_north(:,1:(length(lat_ind_inrange) - 1),:,:);
end


% compute regressed quantities

uvel_reg_east = zeros(size_array);
T_reg_east = zeros(size_array);
uvel_reg_west = zeros(size_array);
T_reg_west = zeros(size_array);
vvel_reg_north = zeros(size_array);
T_reg_north = zeros(size_array);
vvel_reg_south = zeros(size_array);
T_reg_south = zeros(size_array);
wvel_reg = zeros(size_array);
T_reg_at_w_level = zeros(size_array);
for i_r = 1:n_subsets_regression(1)
    for j_r = 1:n_subsets_regression(2)
        
        curr_weighting_array = weighting_array_regression(:,:,i_r,j_r);
        
        if size(reg_operator_T_array,4) > 1
            curr_G_reg = squeeze(G_reg_array(i_r,j_r,:,:));
            curr_reg_operator_T = squeeze(reg_operator_T_array(i_r,j_r,:,:));
        else
            curr_G_reg = squeeze(G_reg_array(i_r,j_r,:));
            curr_reg_operator_T = squeeze(reg_operator_T_array(i_r,j_r,:));
        end
        
        m_reg_uvel_east = reshape(uvel_east,[prod(size_array(1:3)) size_array(4)])*curr_reg_operator_T;
        uvel_reg_east = uvel_reg_east + (repmat(curr_weighting_array,[1 1 size_array(3:4)]).*reshape(m_reg_uvel_east*(curr_G_reg'),size_array));
        if reg_level_option == 1
            T_east_side_minus_T_vert_avg = NaN(size_array);
            T_east_side_minus_T_vert_avg(1:(length(lon_ind_inrange) - 1),:,:,:) = (temp(2:length(lon_ind_inrange),:,:,:) - (diff(temp,1,1)/2)) - repmat(reshape(T_vert_mean_inlayer(1:(length(lon_ind_inrange) - 1),:,:),[(size_array(1:2) - [1 0]) 1 size_array(4)]),[1 1 size_array(3) 1]);
        end
        m_reg_T_east_at_pos = reshape(T_east_side_minus_T_vert_avg,[prod(size_array(1:3)) size_array(4)])*curr_reg_operator_T;
        T_reg_east = T_reg_east + (repmat(curr_weighting_array,[1 1 size_array(3:4)]).*reshape(m_reg_T_east_at_pos*(curr_G_reg'),size_array));
        m_reg_uvel_west = reshape(uvel_west,[prod(size_array(1:3)) size_array(4)])*curr_reg_operator_T;
        uvel_reg_west = uvel_reg_west + (repmat(curr_weighting_array,[1 1 size_array(3:4)]).*reshape(m_reg_uvel_west*(curr_G_reg'),size_array));
        if reg_level_option == 1
            T_west_side_minus_T_vert_avg = NaN(size_array);
            T_west_side_minus_T_vert_avg(2:length(lon_ind_inrange),:,:,:) = (temp(2:length(lon_ind_inrange),:,:,:) - (diff(temp,1,1)/2)) - repmat(reshape(T_vert_mean_inlayer(2:length(lon_ind_inrange),:,:),[(size_array(1:2) - [1 0]) 1 size_array(4)]),[1 1 size_array(3) 1]);
        end
        m_reg_T_west_at_pos = reshape(T_west_side_minus_T_vert_avg,[prod(size_array(1:3)) size_array(4)])*curr_reg_operator_T;
        T_reg_west = T_reg_west + (repmat(curr_weighting_array,[1 1 size_array(3:4)]).*reshape(m_reg_T_west_at_pos*(curr_G_reg'),size_array));
        m_reg_vvel_north = reshape(vvel_north,[prod(size_array(1:3)) size_array(4)])*curr_reg_operator_T;
        vvel_reg_north = vvel_reg_north + (repmat(curr_weighting_array,[1 1 size_array(3:4)]).*reshape(m_reg_vvel_north*(curr_G_reg'),size_array));
        if reg_level_option == 1
            T_north_side_minus_T_vert_avg = NaN(size_array);
            T_north_side_minus_T_vert_avg(:,1:(length(lat_ind_inrange) - 1),:,:) = (temp(:,2:length(lat_ind_inrange),:,:) - (diff(temp,1,2)/2)) - repmat(reshape(T_vert_mean_inlayer(:,1:(length(lat_ind_inrange) - 1),:,:),[(size_array(1:2) - [0 1]) 1 size_array(4)]),[1 1 size_array(3) 1]);
        end
        m_reg_T_north_at_pos = reshape(T_north_side_minus_T_vert_avg,[prod(size_array(1:3)) size_array(4)])*curr_reg_operator_T;
        T_reg_north = T_reg_north + (repmat(curr_weighting_array,[1 1 size_array(3:4)]).*reshape(m_reg_T_north_at_pos*(curr_G_reg'),size_array));
        m_reg_vvel_south = reshape(vvel_south,[prod(size_array(1:3)) size_array(4)])*curr_reg_operator_T;
        vvel_reg_south = vvel_reg_south + (repmat(curr_weighting_array,[1 1 size_array(3:4)]).*reshape(m_reg_vvel_south*(curr_G_reg'),size_array));
        if reg_level_option == 1
            T_south_side_minus_T_vert_avg = NaN(size_array);
            T_south_side_minus_T_vert_avg(:,2:length(lat_ind_inrange),:,:) = (temp(:,2:length(lat_ind_inrange),:,:) - (diff(temp,1,2)/2)) - repmat(reshape(T_vert_mean_inlayer(:,2:length(lat_ind_inrange),:,:),[(size_array(1:2) - [0 1]) 1 size_array(4)]),[1 1 size_array(3) 1]);
        end
        m_reg_T_south_at_pos = reshape(T_south_side_minus_T_vert_avg,[prod(size_array(1:3)) size_array(4)])*curr_reg_operator_T;
        T_reg_south = T_reg_south + (repmat(curr_weighting_array,[1 1 size_array(3:4)]).*reshape(m_reg_T_south_at_pos*(curr_G_reg'),size_array));
        size_wvel = size(wvel);
        wvel_reshaped = reshape(wvel,[prod(size_wvel(1:3)) size_wvel(4)]);
        m_reg_wvel = wvel_reshaped*curr_reg_operator_T;
        wvel_reg = wvel_reg + (repmat(curr_weighting_array,[1 1 size_array(3:4)]).*reshape(m_reg_wvel*(curr_G_reg'),size_wvel));
        if reg_level_option == 1
            temp_interp_at_w_level = zeros(size(temp));
            temp_interp_at_w_level(:,:,1,:) = temp(:,:,1,:);
            temp_interp_at_w_level(:,:,2:size(temp,3),:) = (0.5*temp(:,:,1:(size(temp,3) - 1),:)) + (0.5*temp(:,:,2:size(temp,3),:));
            T_minus_T_vert_mean_at_w_level = temp_interp_at_w_level - repmat(reshape(T_vert_mean_inlayer,[size_array(1:2) 1 size_array(4)]),[1 1 size_array(3) 1]);
        end
        m_reg_T_at_pos = reshape(T_minus_T_vert_mean_at_w_level,[prod(size_wvel(1:3)) size_wvel(4)])*curr_reg_operator_T;
        T_reg_at_w_level = T_reg_at_w_level + (repmat(curr_weighting_array,[1 1 size_array(3:4)]).*reshape(m_reg_T_at_pos*(curr_G_reg'),size_wvel));
        m_reg_temp = reshape(temp,[prod(size_array(1:3)) size_array(4)])*curr_reg_operator_T;
%         temp_reg = reshape(m_reg_temp*(curr_G_reg'),size_array);
        temp_reg = temp_reg + (repmat(curr_weighting_array,[1 1 size_array(3:4)]).*reshape(m_reg_temp*(curr_G_reg'),size_array));
        
    end
end



% set NaNs in SSH array to zero
SSH(isnan(SSH) == 1) = 0;


% compute advection terms

min_dzt_depth_integrating_array_5D_dx = zeros(length(lon_ind_inrange) - 1,length(lat_ind_inrange),length(depth_ind_inrange),length(unique_times),2);
min_dzt_depth_integrating_array_5D_dx = min(min_dzt_depth_integrating_array,[],1);


reshaped_repmat_dz = reshape(repmat(reshape(dz(depth_ind_inrange),[1 1 length(depth_ind_inrange)]),[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[(length(lon_ind_inrange)*length(lat_ind_inrange)*length(depth_ind_inrange)*length(unique_times)) 1]);

diff_z_w_bot_shallowest_top_bound = repmat(reshape(z_w_bot(depth_ind_inrange),[1 1 length(depth_ind_inrange)]),[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]) - repmat(reshape(top_depth_bound_array,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[1 1 length(depth_ind_inrange) 1]);
diff_z_w_bot_shallowest_top_bound(diff_z_w_bot_shallowest_top_bound < 0) = 0;
reshaped_diff_z_w_bot_shallowest_top_bound = reshape(diff_z_w_bot_shallowest_top_bound,[prod(size(diff_z_w_bot_shallowest_top_bound)) 1]);

at_top_ind = find((reshaped_diff_z_w_bot_shallowest_top_bound > 0) & (reshaped_diff_z_w_bot_shallowest_top_bound - reshaped_repmat_dz < 0));

at_top_ind_add = at_top_ind(mod(at_top_ind,length(lon_ind_inrange)) ~= 1);
at_top_adj_x_ind = unique([(at_top_ind_add - 1); at_top_ind]);
at_top_adj_x_ind = at_top_adj_x_ind((at_top_adj_x_ind >= 1) & (at_top_adj_x_ind <= prod(size(reshaped_repmat_dz))));

at_top_ind_add = at_top_ind(mod(ceil(at_top_ind/length(lon_ind_inrange)),length(lat_ind_inrange)) ~= 1);
at_top_adj_y_ind = unique([(at_top_ind_add - length(lon_ind_inrange)); at_top_ind]);
at_top_adj_y_ind = at_top_adj_y_ind((at_top_adj_y_ind >= 1) & (at_top_adj_y_ind <= prod(size(reshaped_repmat_dz))));


ht = squeeze(sum(dzt,3));
min_ht_bottom_depth = NaN(size(bottom_depth_bound_array));
min_ht_bottom_depth = reshape(min([reshape(repmat(ht,[1 1 length(unique_times)]),[1 (length(lon_ind_inrange)*length(lat_ind_inrange)*length(unique_times))]); reshape(bottom_depth_bound_array,[1 (length(lon_ind_inrange)*length(lat_ind_inrange)*length(unique_times))])],[],1),[length(lon_ind_inrange) length(lat_ind_inrange) length(unique_times)]);
diff_z_w_top_bottom_bound = repmat(reshape(min_ht_bottom_depth,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[1 1 length(depth_ind_inrange) 1]) - repmat(reshape(z_w_top(depth_ind_inrange),[1 1 length(depth_ind_inrange)]),[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]);
reshaped_diff_z_w_top_bottom_bound = reshape(diff_z_w_top_bottom_bound,[prod(size(diff_z_w_top_bottom_bound)) 1]);

at_bottom_ind = find((reshaped_diff_z_w_top_bottom_bound > 0) & (reshaped_diff_z_w_top_bottom_bound - reshaped_repmat_dz < 0));

at_bottom_ind_add = at_bottom_ind(mod(at_bottom_ind,length(lon_ind_inrange)) ~= 1);
at_bottom_adj_x_ind = unique([(at_bottom_ind_add - 1); at_bottom_ind]);
at_bottom_adj_x_ind = at_bottom_adj_x_ind((at_bottom_adj_x_ind >= 1) & (at_bottom_adj_x_ind <= prod(size(reshaped_repmat_dz))));

at_bottom_ind_add = at_bottom_ind(mod(ceil(at_bottom_ind/length(lon_ind_inrange)),length(lat_ind_inrange)) ~= 1);
at_bottom_adj_y_ind = unique([(at_bottom_ind_add - length(lon_ind_inrange)); at_bottom_ind]);
at_bottom_adj_y_ind = at_bottom_adj_y_ind((at_bottom_adj_y_ind >= 1) & (at_bottom_adj_y_ind <= prod(size(reshaped_repmat_dz))));

at_both_top_and_bottom_adj_x_ind = intersect(at_top_adj_x_ind,at_bottom_adj_x_ind);
% size_array = [(length(lon_ind_inrange) - 1) length(lat_ind_inrange) length(depth_ind_inrange) length(unique_times)];
% at_both_top_and_bottom_adj_x_t_ind = ceil(at_both_top_and_bottom_adj_x_ind/prod(size_array(1:3)));
% t_residual = at_both_top_and_bottom_adj_x_ind - (prod(size_array(1:3))*(at_both_top_and_bottom_adj_x_t_ind - 1));
% at_both_top_and_bottom_adj_x_k_ind = ceil(t_residual/prod(size_array(1:2)));
% k_residual = t_residual - (prod(size_array(1:2))*(at_both_top_and_bottom_adj_x_k_ind - 1));
% at_both_top_and_bottom_adj_x_j_ind = ceil(k_residual/size_array(1));
% at_both_top_and_bottom_adj_x_i_ind = k_residual - ((size_array(1))*(at_both_top_and_bottom_adj_x_j_ind - 1));


at_both_top_and_bottom_adj_y_ind = intersect(at_top_adj_y_ind,at_bottom_adj_y_ind);
% size_array = [length(lon_ind_inrange) (length(lat_ind_inrange) - 1) length(depth_ind_inrange) length(unique_times)];
% at_both_top_and_bottom_adj_y_t_ind = ceil(at_both_top_and_bottom_adj_y_ind/prod(size_array(1:3)));
% t_residual = at_both_top_and_bottom_adj_y_ind - (prod(size_array(1:3))*(at_both_top_and_bottom_adj_y_t_ind - 1));
% at_both_top_and_bottom_adj_y_k_ind = ceil(t_residual/prod(size_array(1:2)));
% k_residual = t_residual - (prod(size_array(1:2))*(at_both_top_and_bottom_adj_y_k_ind - 1));
% at_both_top_and_bottom_adj_y_j_ind = ceil(k_residual/size_array(1));
% at_both_top_and_bottom_adj_y_i_ind = k_residual - ((size_array(1))*(at_both_top_and_bottom_adj_y_j_ind - 1));


top_bottom_min_diff_x = min(min_ht_bottom_depth,[],1) - max(top_depth_bound_array,[],1);
top_bottom_min_diff_x(top_bottom_min_diff_x < 0) = 0;

top_bottom_min_diff_y = min(min_ht_bottom_depth,[],2) - max(top_depth_bound_array,[],2);
top_bottom_min_diff_y(top_bottom_min_diff_y < 0) = 0;



min_dzt_depth_integrating_array_adj_x_5D = NaN(length(lon_ind_inrange) - 1,length(lat_ind_inrange),length(depth_ind_inrange),length(unique_times),2);
min_dzt_depth_integrating_array_adj_x_5D(:,:,:,:,1) = min_dzt_depth_integrating_array(1:(length(lon_ind_inrange) - 1),:,:,:);
min_dzt_depth_integrating_array_adj_x_5D(:,:,:,:,2) = min_dzt_depth_integrating_array(2:length(lon_ind_inrange),:,:,:);
min_dzt_depth_integrating_array_adj_x = min(min_dzt_depth_integrating_array_adj_x_5D,[],5);

clear min_dzt_depth_integrating_array_5D_adj_x

min_dzt_depth_integrating_array_adj_y_5D = NaN(length(lon_ind_inrange),length(lat_ind_inrange) - 1,length(depth_ind_inrange),length(unique_times),2);
min_dzt_depth_integrating_array_adj_y_5D(:,:,:,:,1) = min_dzt_depth_integrating_array(:,1:(length(lat_ind_inrange) - 1),:,:);
min_dzt_depth_integrating_array_adj_y_5D(:,:,:,:,2) = min_dzt_depth_integrating_array(:,2:length(lat_ind_inrange),:,:);
min_dzt_depth_integrating_array_adj_y = min(min_dzt_depth_integrating_array_adj_y_5D,[],5);

clear min_dzt_depth_integrating_array_5D_adj_y

min_dzt_depth_integrating_array_adj_x(at_both_top_and_bottom_adj_x_ind) = top_bottom_min_diff_x(at_both_top_and_bottom_adj_x_ind);
min_dzt_depth_integrating_array_adj_y(at_both_top_and_bottom_adj_y_ind) = top_bottom_min_diff_y(at_both_top_and_bottom_adj_y_ind);

clear at_top* at_bottom* reshaped*


size_array = [length(lon_ind_inrange) length(lat_ind_inrange) length(depth_ind_inrange) length(unique_times)];
hte_east_side = hte;
hte_west_side = NaN(size_array(1:2));
hte_west_side(2:length(lon_ind_inrange),:) = hte(1:(length(lon_ind_inrange) - 1),:);
min_dzt_depth_integrating_array_east_side = NaN(size_array);
min_dzt_depth_integrating_array_east_side(1:(length(lon_ind_inrange) - 1),:,:,:) = min_dzt_depth_integrating_array_adj_x;
min_dzt_depth_integrating_array_west_side = NaN(size_array);
min_dzt_depth_integrating_array_west_side(2:length(lon_ind_inrange),:,:,:) = min_dzt_depth_integrating_array_adj_x;

htn_north_side = htn;
htn_south_side = NaN(size_array(1:2));
htn_south_side(:,2:length(lat_ind_inrange)) = htn(:,1:(length(lat_ind_inrange) - 1));
min_dzt_depth_integrating_array_north_side = NaN(size_array);
min_dzt_depth_integrating_array_north_side(:,1:(length(lat_ind_inrange) - 1),:,:,:) = min_dzt_depth_integrating_array_adj_y;
min_dzt_depth_integrating_array_south_side = NaN(size_array);
min_dzt_depth_integrating_array_south_side(:,2:length(lat_ind_inrange),:,:) = min_dzt_depth_integrating_array_adj_y;


temp_noreg = temp - temp_reg;


vol_layer_at_horiz_cell = repmat(tarea,[1 1 length(unique_times)]).*layer_thickness_array;


uvel_vert_mean_inlayer = NaN(size_array([1 2 4]));
adv_vol_flux_E = repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array_east_side.*uvel_east,3));
adv_vol_flux_W = repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array_west_side.*uvel_west,3));
uvel_vert_mean_inlayer = (0.5*(adv_vol_flux_E + adv_vol_flux_W))./(repmat(dyt,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array,3)));

if reg_level_option == 1
    adv_T_flux_E = (repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array_east_side.*uT_east,3))) - (adv_vol_flux_E.*T_vert_mean_inlayer);
    adv_T_flux_W = (repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array_west_side.*uT_west,3))) - (adv_vol_flux_W.*T_vert_mean_inlayer);
    
    adv_T_tend_E = -adv_T_flux_E./vol_layer_at_horiz_cell;
    adv_T_tend_W = adv_T_flux_W./vol_layer_at_horiz_cell;
end


% uvel_east_norm_at_pos = reshape(uvel_east./repmat(reshape(vol_layer_at_horiz_cell,[size_array(1:2) 1 size_array(4)]),[1 1 size_array(3) 1]),[prod(size_array(1:3)) size_array(4)]);


uvel_noreg_east = uvel_east - uvel_reg_east;

T_noreg_east = T_east_side_minus_T_vert_avg - T_reg_east;

if reg_level_option > 1
    uvel_noreg_east = uvel_noreg_east + uvel_prev_reg_east;
    T_noreg_east = T_noreg_east + T_prev_reg_east;
end

adv_uvel_reg_T_reg_tend_E = -repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array_east_side.*uvel_reg_east.*T_reg_east,3))./vol_layer_at_horiz_cell;
adv_uvel_reg_T_noreg_tend_E = -repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array_east_side.*uvel_reg_east.*T_noreg_east,3))./vol_layer_at_horiz_cell;
adv_uvel_noreg_T_reg_tend_E = -repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array_east_side.*uvel_noreg_east.*T_reg_east,3))./vol_layer_at_horiz_cell;
adv_uvel_noreg_T_noreg_tend_E = adv_T_tend_E - (adv_uvel_reg_T_reg_tend_E + adv_uvel_reg_T_noreg_tend_E + adv_uvel_noreg_T_reg_tend_E);

if reg_level_option == 1
    hdiff_T_tend_E = -repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array_east_side.*hdiff_T_flux_east,3))./vol_layer_at_horiz_cell;
end

clear min_dzt_depth_integrating_array_east_side


uvel_noreg_west = uvel_west - uvel_reg_west;

T_noreg_west = T_west_side_minus_T_vert_avg - T_reg_west;

if reg_level_option > 1
    uvel_noreg_west = uvel_noreg_west + uvel_prev_reg_west;
    T_noreg_west = T_noreg_west + T_prev_reg_west;
end

adv_uvel_reg_T_reg_tend_W = repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array_west_side.*uvel_reg_west.*T_reg_west,3))./vol_layer_at_horiz_cell;
adv_uvel_reg_T_noreg_tend_W = repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array_west_side.*uvel_reg_west.*T_noreg_west,3))./vol_layer_at_horiz_cell;
adv_uvel_noreg_T_reg_tend_W = repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array_west_side.*uvel_noreg_west.*T_reg_west,3))./vol_layer_at_horiz_cell;
adv_uvel_noreg_T_noreg_tend_W = adv_T_tend_W - (adv_uvel_reg_T_reg_tend_W + adv_uvel_reg_T_noreg_tend_W + adv_uvel_noreg_T_reg_tend_W);

if reg_level_option == 1
    hdiff_T_tend_W = repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array_west_side.*hdiff_T_flux_west,3))./vol_layer_at_horiz_cell;
end

clear min_dzt_depth_integrating_array_west_side


adv_T_tend_zonal = adv_T_tend_E + adv_T_tend_W;
adv_uvel_reg_T_reg_tend = adv_uvel_reg_T_reg_tend_E + adv_uvel_reg_T_reg_tend_W;
adv_uvel_reg_T_noreg_tend = adv_uvel_reg_T_noreg_tend_E + adv_uvel_reg_T_noreg_tend_W;
adv_uvel_noreg_T_reg_tend = adv_uvel_noreg_T_reg_tend_E + adv_uvel_noreg_T_reg_tend_W;
adv_uvel_noreg_T_noreg_tend = adv_uvel_noreg_T_noreg_tend_E + adv_uvel_noreg_T_noreg_tend_W;
hdiff_T_tend_zonal = hdiff_T_tend_E + hdiff_T_tend_W;



vvel_vert_mean_inlayer = NaN(size_array([1 2 4]));
adv_vol_flux_N = repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array_north_side.*vvel_north,3));
adv_vol_flux_S = repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array_south_side.*vvel_south,3));
vvel_vert_mean_inlayer = (0.5*(adv_vol_flux_N + adv_vol_flux_S))./(repmat(dxt,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array,3)));

if reg_level_option == 1
    adv_T_flux_N = (repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array_north_side.*vT_north,3))) - (adv_vol_flux_N.*T_vert_mean_inlayer);
    adv_T_flux_S = (repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array_south_side.*vT_south,3))) - (adv_vol_flux_S.*T_vert_mean_inlayer);
    
    adv_T_tend_N = -adv_T_flux_N./vol_layer_at_horiz_cell;
    adv_T_tend_S = adv_T_flux_S./vol_layer_at_horiz_cell;
end


% uvel_east_norm_at_pos = reshape(uvel_east./repmat(reshape(vol_layer_at_horiz_cell,[size_array(1:2) 1 size_array(4)]),[1 1 size_array(3) 1]),[prod(size_array(1:3)) size_array(4)]);

vvel_noreg_north = vvel_north - vvel_reg_north;

T_noreg_north = T_north_side_minus_T_vert_avg - T_reg_north;

if reg_level_option > 1
    vvel_noreg_north = vvel_noreg_north + vvel_prev_reg_north;
    T_noreg_north = T_noreg_north + T_prev_reg_north;
end

adv_vvel_reg_T_reg_tend_N = -repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array_north_side.*vvel_reg_north.*T_reg_north,3))./vol_layer_at_horiz_cell;
adv_vvel_reg_T_noreg_tend_N = -repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array_north_side.*vvel_reg_north.*T_noreg_north,3))./vol_layer_at_horiz_cell;
adv_vvel_noreg_T_reg_tend_N = -repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array_north_side.*vvel_noreg_north.*T_reg_north,3))./vol_layer_at_horiz_cell;
adv_vvel_noreg_T_noreg_tend_N = adv_T_tend_N - (adv_vvel_reg_T_reg_tend_N + adv_vvel_reg_T_noreg_tend_N + adv_vvel_noreg_T_reg_tend_N);

if reg_level_option == 1
    hdiff_T_tend_N = -repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array_north_side.*hdiff_T_flux_north,3))./vol_layer_at_horiz_cell;
end

clear min_dzt_depth_integrating_array_north_side


vvel_noreg_south = vvel_south - vvel_reg_south;

T_noreg_south = T_south_side_minus_T_vert_avg - T_reg_south;

if reg_level_option > 1
    vvel_noreg_south = vvel_noreg_south + vvel_prev_reg_south;
    T_noreg_south = T_noreg_south + T_prev_reg_south;
end

adv_vvel_reg_T_reg_tend_S = repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array_south_side.*vvel_reg_south.*T_reg_south,3))./vol_layer_at_horiz_cell;
adv_vvel_reg_T_noreg_tend_S = repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array_south_side.*vvel_reg_south.*T_noreg_south,3))./vol_layer_at_horiz_cell;
adv_vvel_noreg_T_reg_tend_S = repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array_south_side.*vvel_noreg_south.*T_reg_south,3))./vol_layer_at_horiz_cell;
adv_vvel_noreg_T_noreg_tend_S = adv_T_tend_S - (adv_vvel_reg_T_reg_tend_S + adv_vvel_reg_T_noreg_tend_S + adv_vvel_noreg_T_reg_tend_S);

if reg_level_option == 1
    hdiff_T_tend_S = repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array_south_side.*hdiff_T_flux_south,3))./vol_layer_at_horiz_cell;
end

clear min_dzt_depth_integrating_array_south_side


adv_T_tend_merid = adv_T_tend_N + adv_T_tend_S;
adv_vvel_reg_T_reg_tend = adv_vvel_reg_T_reg_tend_N + adv_vvel_reg_T_reg_tend_S;
adv_vvel_reg_T_noreg_tend = adv_vvel_reg_T_noreg_tend_N + adv_vvel_reg_T_noreg_tend_S;
adv_vvel_noreg_T_reg_tend = adv_vvel_noreg_T_reg_tend_N + adv_vvel_noreg_T_reg_tend_S;
adv_vvel_noreg_T_noreg_tend = adv_vvel_noreg_T_noreg_tend_N + adv_vvel_noreg_T_noreg_tend_S;
hdiff_T_tend_merid = hdiff_T_tend_N + hdiff_T_tend_S;





% compute the top and bottom fluxes


% create array to help identify top and bottom bounds of region

nonzero_mask_depth_integrating_dzt_combined = zeros(size(min_dzt_depth_integrating_array));
nonzero_mask_depth_integrating_dzt_combined(min_dzt_depth_integrating_array ~= 0) = 1;

diff_z_nonzero_mask = zeros(length(lon_ind_inrange),length(lat_ind_inrange),(length(depth_ind_inrange) + 1),length(unique_times));
diff_z_nonzero_mask(:,:,1,:) = nonzero_mask_depth_integrating_dzt_combined(:,:,1,:) - 0;
diff_z_nonzero_mask(:,:,2:length(depth_ind_inrange),:) = diff(nonzero_mask_depth_integrating_dzt_combined,1,3);
diff_z_nonzero_mask(:,:,length(depth_ind_inrange) + 1,:) = 0 - nonzero_mask_depth_integrating_dzt_combined(:,:,length(depth_ind_inrange),:);



% identify top and bottom depth cells for each (horizontal point), and create a weighting array for vertical fluxes

top_bound_cell_ind = find(diff_z_nonzero_mask(:,:,1:length(depth_ind_inrange),:) == 1);
top_bound_depth_ind = mod((ceil(top_bound_cell_ind/(length(lon_ind_inrange)*length(lat_ind_inrange)))) - 1,length(depth_ind_inrange)) + 1;

top_cell_k_ind = depth_ind_inrange(top_bound_depth_ind);
repmat_top_depth_bound_array = repmat(reshape(top_depth_bound_array,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[1 1 length(depth_ind_inrange) 1]);
repmat_dzt_in_depth_range = repmat(dzt(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]);
frac_below_top = (repmat_top_depth_bound_array(top_bound_cell_ind) - z_w_top(top_cell_k_ind))./repmat_dzt_in_depth_range(top_bound_cell_ind);
frac_below_top(frac_below_top > 1) = 1;
frac_above_top = 1 - frac_below_top;

top_bound_weighting_array = zeros(size(min_dzt_depth_integrating_array));
top_bound_weighting_array(top_bound_cell_ind) = frac_above_top;
top_bound_weighting_array(top_bound_cell_ind + (length(lon_ind_inrange)*length(lat_ind_inrange))) = frac_below_top;



bottom_bound_cell_ind = find(diff_z_nonzero_mask(:,:,2:(length(depth_ind_inrange) + 1),:) == (-1));
bottom_bound_depth_ind = mod((ceil(bottom_bound_cell_ind/(length(lon_ind_inrange)*length(lat_ind_inrange)))) - 1,length(depth_ind_inrange)) + 1;

bottom_cell_k_ind = depth_ind_inrange(bottom_bound_depth_ind);
repmat_bottom_depth_bound_array = repmat(reshape(bottom_depth_bound_array,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[1 1 length(depth_ind_inrange) 1]);

% account for the possibility that the prescribed bottom depth bounds are deeper than the bathymetry
thickness_at_base_layer_array = zeros(length(bottom_bound_cell_ind),2);
thickness_at_base_layer_array(:,1) = repmat_bottom_depth_bound_array(bottom_bound_cell_ind) - z_w_top(bottom_cell_k_ind);
thickness_at_base_layer_array(:,2) = repmat_dzt_in_depth_range(bottom_bound_cell_ind);

frac_below_bottom = min(thickness_at_base_layer_array,[],2)./repmat_dzt_in_depth_range(bottom_bound_cell_ind);
bottom_bound_bottom_level_ind = find(repmat_bottom_depth_bound_array(bottom_bound_cell_ind) > z_w_top(depth_ind_inrange(size(wvel,3))));
frac_below_bottom(bottom_bound_bottom_level_ind) = 0;
frac_below_bottom(isnan(frac_below_bottom) == 1) = 0;
frac_above_bottom = 1 - frac_below_bottom;


bottom_bound_weighting_array = zeros(size(min_dzt_depth_integrating_array));
bottom_bound_weighting_array(bottom_bound_cell_ind) = frac_above_bottom;
bottom_bound_not_bottom_level_ind = setdiff((1:1:length(bottom_bound_cell_ind))',bottom_bound_bottom_level_ind);
bottom_bound_weighting_array(bottom_bound_cell_ind(bottom_bound_not_bottom_level_ind) + (length(lon_ind_inrange)*length(lat_ind_inrange))) = frac_below_bottom(bottom_bound_not_bottom_level_ind);



% adjustment to the advective tracer flux at z = 0
% Note: though in POP wT = 0 through the surface, this adjustment is to represent the advective flux at z = 0 consistently with other fluxes, and recover the true temp. tendency.  For the surface layer, which varies in thickness, the tendency due to the advective flux through z = 0 is essentially balanced in this formulation by the entrainment tendency at the top surface as the top depth bound changes with time.  (Unless there is freshwater input at the surface, in which case the top advective and entrainment tendencies may not quite balance.)
if reg_level_option == 1
    wT_top(:,:,1,:) = wvel(:,:,1,:).*temp(:,:,1,:);
end

wvel(isnan(wvel) == 1) = 0;
if reg_level_option == 1
    wT_top(isnan(wT_top) == 1) = 0;
end


% volume, advective, and diffusive vertical fluxes are calculated

adv_vol_flux_top = repmat(tarea,[1 1 length(unique_times)]).*squeeze(sum(top_bound_weighting_array.*wvel,3));
if reg_level_option == 1
    adv_T_flux_top = repmat(tarea,[1 1 length(unique_times)]).*squeeze(sum(top_bound_weighting_array.*wT_top,3)) - (adv_vol_flux_top.*T_vert_mean_inlayer);
    adv_T_tend_top = -adv_T_flux_top./vol_layer_at_horiz_cell;
end


wvel_noreg = wvel - wvel_reg;

T_noreg_at_w_level = T_minus_T_vert_mean_at_w_level - T_reg_at_w_level;

if reg_level_option > 1
    wvel_noreg = wvel_noreg + wvel_prev_reg;
    T_noreg_at_w_level = T_noreg_at_w_level + T_prev_reg_at_w_level;
end


adv_wvel_reg_T_reg_tend_top = repmat(tarea,[1 1 length(unique_times)]).*squeeze(sum(top_bound_weighting_array.*wvel_reg.*T_reg_at_w_level,3))./vol_layer_at_horiz_cell;
adv_wvel_reg_T_noreg_tend_top = repmat(tarea,[1 1 length(unique_times)]).*squeeze(sum(top_bound_weighting_array.*wvel_reg.*T_noreg_at_w_level,3))./vol_layer_at_horiz_cell;
adv_wvel_noreg_T_reg_tend_top = repmat(tarea,[1 1 length(unique_times)]).*squeeze(sum(top_bound_weighting_array.*wvel_noreg.*T_reg_at_w_level,3))./vol_layer_at_horiz_cell;
adv_wvel_noreg_T_noreg_tend_top = adv_T_tend_top - adv_wvel_reg_T_reg_tend_top - adv_wvel_reg_T_noreg_tend_top - adv_wvel_noreg_T_reg_tend_top;
% adv_wvel_noreg_T_noreg_tend_top = (-adv_T_flux_top./vol_layer_at_horiz_cell) - adv_wvel_reg_T_reg_tend_top - adv_wvel_reg_T_noreg_tend_top - adv_wvel_noreg_T_reg_tend_top;


if reg_level_option == 1
    hdiff_T_tend_top = -repmat(tarea,[1 1 length(unique_times)]).*squeeze(sum(top_bound_weighting_array(:,:,2:length(depth_ind_inrange),:).*hdiff_T_flux_bottom(:,:,1:(length(depth_ind_inrange) - 1),:),3))./vol_layer_at_horiz_cell;
    diab_vert_T_tend_top = repmat(tarea,[1 1 length(unique_times)]).*squeeze(sum(top_bound_weighting_array(:,:,2:length(depth_ind_inrange),:).*diab_imp_vert_T_flux_bottom(:,:,1:(length(depth_ind_inrange) - 1),:),3))./vol_layer_at_horiz_cell;
end



adv_vol_flux_bottom = repmat(tarea,[1 1 length(unique_times)]).*squeeze(sum(bottom_bound_weighting_array.*wvel,3));
if reg_level_option == 1
    adv_T_flux_bottom = repmat(tarea,[1 1 length(unique_times)]).*squeeze(sum(bottom_bound_weighting_array.*wT_top,3)) - (adv_vol_flux_bottom.*T_vert_mean_inlayer);
    adv_T_tend_bottom = adv_T_flux_bottom./vol_layer_at_horiz_cell;
end



adv_wvel_reg_T_reg_tend_bottom = repmat(tarea,[1 1 length(unique_times)]).*squeeze(sum(bottom_bound_weighting_array.*wvel_reg.*T_reg_at_w_level,3))./vol_layer_at_horiz_cell;
adv_wvel_reg_T_noreg_tend_bottom = repmat(tarea,[1 1 length(unique_times)]).*squeeze(sum(bottom_bound_weighting_array.*wvel_reg.*T_noreg_at_w_level,3))./vol_layer_at_horiz_cell;
adv_wvel_noreg_T_reg_tend_bottom = repmat(tarea,[1 1 length(unique_times)]).*squeeze(sum(bottom_bound_weighting_array.*wvel_noreg.*T_reg_at_w_level,3))./vol_layer_at_horiz_cell;
adv_wvel_noreg_T_noreg_tend_bottom = adv_T_tend_bottom - adv_wvel_reg_T_reg_tend_bottom - adv_wvel_reg_T_noreg_tend_bottom - adv_wvel_noreg_T_reg_tend_bottom;
% adv_wvel_noreg_T_noreg_tend_bottom = (adv_T_flux_bottom./vol_layer_at_horiz_cell) - adv_wvel_reg_T_reg_tend_bottom - adv_wvel_reg_T_noreg_tend_bottom - adv_wvel_noreg_T_reg_tend_bottom;


if reg_level_option == 1
    hdiff_T_tend_bottom = repmat(tarea,[1 1 length(unique_times)]).*squeeze(sum(bottom_bound_weighting_array(:,:,2:length(depth_ind_inrange),:).*hdiff_T_flux_bottom(:,:,1:(length(depth_ind_inrange) - 1),:),3))./vol_layer_at_horiz_cell;
    diab_vert_T_tend_bottom = -repmat(tarea,[1 1 length(unique_times)]).*squeeze(sum(bottom_bound_weighting_array(:,:,2:length(depth_ind_inrange),:).*diab_imp_vert_T_flux_bottom(:,:,1:(length(depth_ind_inrange) - 1),:),3))./vol_layer_at_horiz_cell;
end



% correct vertical fluxes for cells adjacent to bathymetry

dzt_west_wall = NaN([size_array(1:2) size(dzt,3)]);
dzt_west_wall(2:length(lon_ind_inrange),:,:) = dzt_east_wall(1:(length(lon_ind_inrange) - 1),:,:);
dzt_south_wall = NaN([size_array(1:2) size(dzt,3)]);
dzt_south_wall(:,2:length(lat_ind_inrange),:) = dzt_north_wall(:,1:(length(lat_ind_inrange) - 1),:);

diff_z_w_bot_shallowest_top_bound = repmat(reshape(double(z_w_bot(depth_ind_inrange)),[1 1 length(depth_ind_inrange)]),[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]) - repmat(reshape(top_depth_bound_array,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[1 1 length(depth_ind_inrange) 1]);
diff_z_w_bot_shallowest_top_bound(diff_z_w_bot_shallowest_top_bound < 0) = 0;

repmat_dz_in_range_array = repmat(reshape(dz(depth_ind_inrange),[1 1 length(depth_ind_inrange)]),[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]);
repmat_dzt_in_range_array = repmat(dzt(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]);

min_dzt_depth_integrating_top_only = reshape(min([reshape(repmat_dz_in_range_array,[1 prod(size(diff_z_w_bot_shallowest_top_bound))]); reshape(diff_z_w_bot_shallowest_top_bound,[1 prod(size(diff_z_w_bot_shallowest_top_bound))])],[],1),[length(lon_ind_inrange) length(lat_ind_inrange) length(depth_ind_inrange) length(unique_times)]) - (repmat_dz_in_range_array - repmat_dzt_in_range_array);


% adjustment for top vertical fluxes

supposed_frac = min_dzt_depth_integrating_top_only./repmat_dzt_in_range_array;
% supposed_frac(top_bound_cell_ind) = min_dzt_depth_integrating_top_only(top_bound_cell_ind)./repmat_dzt_in_range_array(top_bound_cell_ind);
supposed_frac(isnan(supposed_frac) | isinf(supposed_frac)) = 0;
actual_frac_east_wall = ((min_dzt_depth_integrating_top_only - repmat_dzt_in_range_array)./repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)])) + 1;
actual_frac_east_wall(isnan(actual_frac_east_wall) | isinf(actual_frac_east_wall)) = 0;
actual_frac_east_wall(actual_frac_east_wall < 0) = 0;
correction_factor_E = actual_frac_east_wall - supposed_frac;
actual_frac_west_wall = ((min_dzt_depth_integrating_top_only - repmat_dzt_in_range_array)./repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)])) + 1;
actual_frac_west_wall(isnan(actual_frac_west_wall) | isinf(actual_frac_west_wall)) = 0;
actual_frac_west_wall(actual_frac_west_wall < 0) = 0;
correction_factor_W = actual_frac_west_wall - supposed_frac;
actual_frac_north_wall = ((min_dzt_depth_integrating_top_only - repmat_dzt_in_range_array)./repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)])) + 1;
actual_frac_north_wall(isnan(actual_frac_north_wall) | isinf(actual_frac_north_wall)) = 0;
actual_frac_north_wall(actual_frac_north_wall < 0) = 0;
correction_factor_N = actual_frac_north_wall - supposed_frac;
actual_frac_south_wall = ((min_dzt_depth_integrating_top_only - repmat_dzt_in_range_array)./repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)])) + 1;
actual_frac_south_wall(isnan(actual_frac_south_wall) | isinf(actual_frac_south_wall)) = 0;
actual_frac_south_wall(actual_frac_south_wall < 0) = 0;
correction_factor_S = actual_frac_south_wall - supposed_frac;

top_cell_mask = zeros(size_array);
top_cell_mask(top_bound_cell_ind) = 1;

adv_vol_flux_top_correction_E = -repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_E.*repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_east,3));
adv_vol_flux_top_correction_W = repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_W.*repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_west,3));
adv_vol_flux_top_correction_N = -repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_N.*repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_north,3));
adv_vol_flux_top_correction_S = repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_S.*repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_south,3));
adv_vol_flux_top = adv_vol_flux_top + adv_vol_flux_top_correction_E + adv_vol_flux_top_correction_W + adv_vol_flux_top_correction_N + adv_vol_flux_top_correction_S;

if reg_level_option == 1
    adv_T_flux_top_correction_E = -(repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_E.*repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uT_east,3))) - (adv_vol_flux_top_correction_E.*T_vert_mean_inlayer);
    adv_T_flux_top_correction_W = (repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_W.*repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uT_west,3))) - (adv_vol_flux_top_correction_W.*T_vert_mean_inlayer);
    adv_T_flux_top_correction_N = -(repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_N.*repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vT_north,3))) - (adv_vol_flux_top_correction_N.*T_vert_mean_inlayer);
    adv_T_flux_top_correction_S = (repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_S.*repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vT_south,3))) - (adv_vol_flux_top_correction_S.*T_vert_mean_inlayer);
    adv_T_flux_top = adv_T_flux_top + adv_T_flux_top_correction_E + adv_T_flux_top_correction_W + adv_T_flux_top_correction_N + adv_T_flux_top_correction_S;
    
    adv_T_tend_top = -adv_T_flux_top./vol_layer_at_horiz_cell;
end


adv_wvel_reg_T_reg_tend_top_correction_E = repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_E.*repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_reg_east.*T_reg_east,3))./vol_layer_at_horiz_cell;
adv_wvel_reg_T_noreg_tend_top_correction_E = repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_E.*repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_reg_east.*T_noreg_east,3))./vol_layer_at_horiz_cell;
adv_wvel_noreg_T_reg_tend_top_correction_E = repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_E.*repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_noreg_east.*T_reg_east,3))./vol_layer_at_horiz_cell;
try
    adv_wvel_noreg_T_noreg_tend_top_correction_E = (-adv_T_flux_top_correction_E./vol_layer_at_horiz_cell) - (adv_wvel_reg_T_reg_tend_top_correction_E + adv_wvel_reg_T_noreg_tend_top_correction_E + adv_wvel_noreg_T_reg_tend_top_correction_E);
catch
    adv_wvel_noreg_T_noreg_tend_top_correction_E = repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_E.*repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_noreg_east.*T_noreg_east,3))./vol_layer_at_horiz_cell;
end

adv_wvel_reg_T_reg_tend_top_correction_W = -repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_W.*repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_reg_west.*T_reg_west,3))./vol_layer_at_horiz_cell;
adv_wvel_reg_T_noreg_tend_top_correction_W = -repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_W.*repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_reg_west.*T_noreg_west,3))./vol_layer_at_horiz_cell;
adv_wvel_noreg_T_reg_tend_top_correction_W = -repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_W.*repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_noreg_west.*T_reg_west,3))./vol_layer_at_horiz_cell;
try
    adv_wvel_noreg_T_noreg_tend_top_correction_W = (-adv_T_flux_top_correction_W./vol_layer_at_horiz_cell) - (adv_wvel_reg_T_reg_tend_top_correction_W + adv_wvel_reg_T_noreg_tend_top_correction_W + adv_wvel_noreg_T_reg_tend_top_correction_W);
catch
    adv_wvel_noreg_T_noreg_tend_top_correction_W = -repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_W.*repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_noreg_west.*T_noreg_west,3))./vol_layer_at_horiz_cell;
end

adv_wvel_reg_T_reg_tend_top_correction_N = repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_N.*repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_reg_north.*T_reg_north,3))./vol_layer_at_horiz_cell;
adv_wvel_reg_T_noreg_tend_top_correction_N = repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_N.*repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_reg_north.*T_noreg_north,3))./vol_layer_at_horiz_cell;
adv_wvel_noreg_T_reg_tend_top_correction_N = repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_N.*repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_noreg_north.*T_reg_north,3))./vol_layer_at_horiz_cell;
try
    adv_wvel_noreg_T_noreg_tend_top_correction_N = (-adv_T_flux_top_correction_N./vol_layer_at_horiz_cell) - (adv_wvel_reg_T_reg_tend_top_correction_N + adv_wvel_reg_T_noreg_tend_top_correction_N + adv_wvel_noreg_T_reg_tend_top_correction_N);
catch
    adv_wvel_noreg_T_noreg_tend_top_correction_N = repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_N.*repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_noreg_north.*T_noreg_north,3))./vol_layer_at_horiz_cell;
end

adv_wvel_reg_T_reg_tend_top_correction_S = -repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_S.*repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_reg_south.*T_reg_south,3))./vol_layer_at_horiz_cell;
adv_wvel_reg_T_noreg_tend_top_correction_S = -repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_S.*repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_reg_south.*T_noreg_south,3))./vol_layer_at_horiz_cell;
adv_wvel_noreg_T_reg_tend_top_correction_S = -repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_S.*repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_noreg_south.*T_reg_south,3))./vol_layer_at_horiz_cell;
try
    adv_wvel_noreg_T_noreg_tend_top_correction_S = (-adv_T_flux_top_correction_S./vol_layer_at_horiz_cell) - (adv_wvel_reg_T_reg_tend_top_correction_S + adv_wvel_reg_T_noreg_tend_top_correction_S + adv_wvel_noreg_T_reg_tend_top_correction_S);
catch
    adv_wvel_noreg_T_noreg_tend_top_correction_S = -repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_S.*repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_noreg_south.*T_noreg_south,3))./vol_layer_at_horiz_cell;
end


adv_wvel_reg_T_reg_tend_top = adv_wvel_reg_T_reg_tend_top + adv_wvel_reg_T_reg_tend_top_correction_E + adv_wvel_reg_T_reg_tend_top_correction_W + adv_wvel_reg_T_reg_tend_top_correction_N + adv_wvel_reg_T_reg_tend_top_correction_S;
adv_wvel_reg_T_noreg_tend_top = adv_wvel_reg_T_noreg_tend_top + adv_wvel_reg_T_noreg_tend_top_correction_E + adv_wvel_reg_T_noreg_tend_top_correction_W + adv_wvel_reg_T_noreg_tend_top_correction_N + adv_wvel_reg_T_noreg_tend_top_correction_S;
adv_wvel_noreg_T_reg_tend_top = adv_wvel_noreg_T_reg_tend_top + adv_wvel_noreg_T_reg_tend_top_correction_E + adv_wvel_noreg_T_reg_tend_top_correction_W + adv_wvel_noreg_T_reg_tend_top_correction_N + adv_wvel_noreg_T_reg_tend_top_correction_S;
adv_wvel_noreg_T_noreg_tend_top = adv_wvel_noreg_T_noreg_tend_top + adv_wvel_noreg_T_noreg_tend_top_correction_E + adv_wvel_noreg_T_noreg_tend_top_correction_W + adv_wvel_noreg_T_noreg_tend_top_correction_N + adv_wvel_noreg_T_noreg_tend_top_correction_S;


% adjustment for bottom vertical fluxes

diff_z_w_top_deepest_bottom_bound = repmat(reshape(bottom_depth_bound_array,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[1 1 length(depth_ind_inrange) 1]) - repmat(reshape(double(z_w_top(depth_ind_inrange)),[1 1 length(depth_ind_inrange)]),[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]);
diff_z_w_top_deepest_bottom_bound(diff_z_w_top_deepest_bottom_bound < 0) = 0;

min_dzt_depth_integrating_bottom_only = reshape(min([reshape(repmat(dzt(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]),[1 prod(size(diff_z_w_top_deepest_bottom_bound))]); reshape(diff_z_w_top_deepest_bottom_bound,[1 prod(size(diff_z_w_top_deepest_bottom_bound))])],[],1),[length(lon_ind_inrange) length(lat_ind_inrange) length(depth_ind_inrange) length(unique_times)]);

supposed_frac = min_dzt_depth_integrating_bottom_only./repmat_dzt_in_range_array;
% supposed_frac(bottom_bound_cell_ind) = min_dzt_depth_integrating_bottom_only(bottom_bound_cell_ind)./repmat_dzt_in_range_array(bottom_bound_cell_ind);
supposed_frac(isnan(supposed_frac) | isinf(supposed_frac)) = 0;
actual_frac_east_wall = min_dzt_depth_integrating_bottom_only./repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]);
actual_frac_east_wall(isnan(actual_frac_east_wall) | isinf(actual_frac_east_wall)) = 0;
actual_frac_east_wall(actual_frac_east_wall > 1) = 1;
correction_factor_E = actual_frac_east_wall - supposed_frac;
actual_frac_west_wall = min_dzt_depth_integrating_bottom_only./repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]);
actual_frac_west_wall(isnan(actual_frac_west_wall) | isinf(actual_frac_west_wall)) = 0;
actual_frac_west_wall(actual_frac_west_wall > 1) = 1;
correction_factor_W = actual_frac_west_wall - supposed_frac;
actual_frac_north_wall = min_dzt_depth_integrating_bottom_only./repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]);
actual_frac_north_wall(isnan(actual_frac_north_wall) | isinf(actual_frac_north_wall)) = 0;
actual_frac_north_wall(actual_frac_north_wall > 1) = 1;
correction_factor_N = actual_frac_north_wall - supposed_frac;
actual_frac_south_wall = min_dzt_depth_integrating_bottom_only./repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]);
actual_frac_south_wall(isnan(actual_frac_south_wall) | isinf(actual_frac_south_wall)) = 0;
actual_frac_south_wall(actual_frac_south_wall > 1) = 1;
correction_factor_S = actual_frac_south_wall - supposed_frac;

clear actual_frac*

bottom_cell_mask = zeros(size_array);
bottom_cell_mask(bottom_bound_cell_ind) = 1;

adv_vol_flux_bottom_correction_E = repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_E.*repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_east,3));
adv_vol_flux_bottom_correction_W = -repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_W.*repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_west,3));
adv_vol_flux_bottom_correction_N = repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_N.*repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_north,3));
adv_vol_flux_bottom_correction_S = -repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_S.*repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_south,3));
adv_vol_flux_bottom = adv_vol_flux_bottom + adv_vol_flux_bottom_correction_E + adv_vol_flux_bottom_correction_W + adv_vol_flux_bottom_correction_N + adv_vol_flux_bottom_correction_S;

if reg_level_option == 1
    adv_T_flux_bottom_correction_E = (repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_E.*repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uT_east,3))) - (adv_vol_flux_bottom_correction_E.*T_vert_mean_inlayer);
    adv_T_flux_bottom_correction_W = -(repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_W.*repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uT_west,3))) - (adv_vol_flux_bottom_correction_W.*T_vert_mean_inlayer);
    adv_T_flux_bottom_correction_N = (repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_N.*repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vT_north,3))) - (adv_vol_flux_bottom_correction_N.*T_vert_mean_inlayer);
    adv_T_flux_bottom_correction_S = -(repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_S.*repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vT_south,3))) - (adv_vol_flux_bottom_correction_S.*T_vert_mean_inlayer);
    adv_T_flux_bottom = adv_T_flux_bottom + adv_T_flux_bottom_correction_E + adv_T_flux_bottom_correction_W + adv_T_flux_bottom_correction_N + adv_T_flux_bottom_correction_S;
    
    adv_T_tend_bottom = adv_T_flux_bottom./vol_layer_at_horiz_cell;
end


adv_wvel_reg_T_reg_tend_bottom_correction_E = repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_E.*repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_reg_east.*T_reg_east,3))./vol_layer_at_horiz_cell;
adv_wvel_reg_T_noreg_tend_bottom_correction_E = repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_E.*repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_reg_east.*T_noreg_east,3))./vol_layer_at_horiz_cell;
adv_wvel_noreg_T_reg_tend_bottom_correction_E = repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_E.*repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_noreg_east.*T_reg_east,3))./vol_layer_at_horiz_cell;
try
    adv_wvel_noreg_T_noreg_tend_bottom_correction_E = (adv_T_flux_bottom_correction_E./vol_layer_at_horiz_cell) - (adv_wvel_reg_T_reg_tend_bottom_correction_E + adv_wvel_reg_T_noreg_tend_bottom_correction_E + adv_wvel_noreg_T_reg_tend_bottom_correction_E);
catch
    adv_wvel_noreg_T_noreg_tend_bottom_correction_E = repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_E.*repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_noreg_east.*T_noreg_east,3))./vol_layer_at_horiz_cell;
end

adv_wvel_reg_T_reg_tend_bottom_correction_W = -repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_W.*repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_reg_west.*T_reg_west,3))./vol_layer_at_horiz_cell;
adv_wvel_reg_T_noreg_tend_bottom_correction_W = -repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_W.*repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_reg_west.*T_noreg_west,3))./vol_layer_at_horiz_cell;
adv_wvel_noreg_T_reg_tend_bottom_correction_W = -repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_W.*repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_noreg_west.*T_reg_west,3))./vol_layer_at_horiz_cell;
try
    adv_wvel_noreg_T_noreg_tend_bottom_correction_W = (adv_T_flux_bottom_correction_W./vol_layer_at_horiz_cell) - (adv_wvel_reg_T_reg_tend_bottom_correction_W + adv_wvel_reg_T_noreg_tend_bottom_correction_W + adv_wvel_noreg_T_reg_tend_bottom_correction_W);
catch
    adv_wvel_noreg_T_noreg_tend_bottom_correction_W = -repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_W.*repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_noreg_west.*T_noreg_west,3))./vol_layer_at_horiz_cell;
end

adv_wvel_reg_T_reg_tend_bottom_correction_N = repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_N.*repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_reg_north.*T_reg_north,3))./vol_layer_at_horiz_cell;
adv_wvel_reg_T_noreg_tend_bottom_correction_N = repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_N.*repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_reg_north.*T_noreg_north,3))./vol_layer_at_horiz_cell;
adv_wvel_noreg_T_reg_tend_bottom_correction_N = repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_N.*repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_noreg_north.*T_reg_north,3))./vol_layer_at_horiz_cell;
try
    adv_wvel_noreg_T_noreg_tend_bottom_correction_N = (adv_T_flux_bottom_correction_N./vol_layer_at_horiz_cell) - (adv_wvel_reg_T_reg_tend_bottom_correction_N + adv_wvel_reg_T_noreg_tend_bottom_correction_N + adv_wvel_noreg_T_reg_tend_bottom_correction_N);
catch
    adv_wvel_noreg_T_noreg_tend_bottom_correction_N = repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_N.*repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_noreg_north.*T_noreg_north,3))./vol_layer_at_horiz_cell;
end

adv_wvel_reg_T_reg_tend_bottom_correction_S = -repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_S.*repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_reg_south.*T_reg_south,3))./vol_layer_at_horiz_cell;
adv_wvel_reg_T_noreg_tend_bottom_correction_S = -repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_S.*repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_reg_south.*T_noreg_south,3))./vol_layer_at_horiz_cell;
adv_wvel_noreg_T_reg_tend_bottom_correction_S = -repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_S.*repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_noreg_south.*T_reg_south,3))./vol_layer_at_horiz_cell;
try
    adv_wvel_noreg_T_noreg_tend_bottom_correction_S = (adv_T_flux_bottom_correction_S./vol_layer_at_horiz_cell) - (adv_wvel_reg_T_reg_tend_bottom_correction_S + adv_wvel_reg_T_noreg_tend_bottom_correction_S + adv_wvel_noreg_T_reg_tend_bottom_correction_S);
catch
    adv_wvel_noreg_T_noreg_tend_bottom_correction_S = -repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_S.*repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_noreg_south.*T_noreg_south,3))./vol_layer_at_horiz_cell;
end



adv_wvel_reg_T_reg_tend_bottom = adv_wvel_reg_T_reg_tend_bottom + adv_wvel_reg_T_reg_tend_bottom_correction_E + adv_wvel_reg_T_reg_tend_bottom_correction_W + adv_wvel_reg_T_reg_tend_bottom_correction_N + adv_wvel_reg_T_reg_tend_bottom_correction_S;
adv_wvel_reg_T_noreg_tend_bottom = adv_wvel_reg_T_noreg_tend_bottom + adv_wvel_reg_T_noreg_tend_bottom_correction_E + adv_wvel_reg_T_noreg_tend_bottom_correction_W + adv_wvel_reg_T_noreg_tend_bottom_correction_N + adv_wvel_reg_T_noreg_tend_bottom_correction_S;
adv_wvel_noreg_T_reg_tend_bottom = adv_wvel_noreg_T_reg_tend_bottom + adv_wvel_noreg_T_reg_tend_bottom_correction_E + adv_wvel_noreg_T_reg_tend_bottom_correction_W + adv_wvel_noreg_T_reg_tend_bottom_correction_N + adv_wvel_noreg_T_reg_tend_bottom_correction_S;
adv_wvel_noreg_T_noreg_tend_bottom = adv_wvel_noreg_T_noreg_tend_bottom + adv_wvel_noreg_T_noreg_tend_bottom_correction_E + adv_wvel_noreg_T_noreg_tend_bottom_correction_W + adv_wvel_noreg_T_noreg_tend_bottom_correction_N + adv_wvel_noreg_T_noreg_tend_bottom_correction_S;


clear *correction* correction*


disp('Completed computing non-sloping advective terms')





% compute horizontal advection/diffusion terms through variable depth top bound

min_dz_depth_integrating_top_only = reshape(min([reshape(repmat_dz_in_range_array,[1 prod(size(diff_z_w_bot_shallowest_top_bound))]); reshape(diff_z_w_bot_shallowest_top_bound,[1 prod(size(diff_z_w_bot_shallowest_top_bound))])],[],1),[length(lon_ind_inrange) length(lat_ind_inrange) length(depth_ind_inrange) length(unique_times)]);

diff_x_min_dz_depth_integrating_top_only = diff(min_dz_depth_integrating_top_only,1,1);
diff_x_min_dz_depth_integrating_east_facing_top_only = NaN(size_array);
diff_x_min_dz_depth_integrating_east_facing_top_only(1:(length(lon_ind_inrange) - 1),:,:,:) = diff_x_min_dz_depth_integrating_top_only;
not_east_facing_ind = find(diff_x_min_dz_depth_integrating_east_facing_top_only >= 0);
diff_x_min_dz_depth_integrating_east_facing_top_only(not_east_facing_ind) = 0;

adv_vol_flux_E_sloping_top = repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(-diff_x_min_dz_depth_integrating_east_facing_top_only.*uvel_east,3));
if reg_level_option == 1
    adv_T_flux_E_sloping_top = (repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(-diff_x_min_dz_depth_integrating_east_facing_top_only.*uT_east,3))) - (adv_vol_flux_E_sloping_top.*T_vert_mean_inlayer);
    adv_T_tend_E_sloping_top = -adv_T_flux_E_sloping_top./vol_layer_at_horiz_cell;
end


adv_uvel_reg_T_reg_tend_E_sloping_top = -repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(-diff_x_min_dz_depth_integrating_east_facing_top_only.*uvel_reg_east.*T_reg_east,3))./vol_layer_at_horiz_cell;
adv_uvel_reg_T_noreg_tend_E_sloping_top = -repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(-diff_x_min_dz_depth_integrating_east_facing_top_only.*uvel_reg_east.*T_noreg_east,3))./vol_layer_at_horiz_cell;
adv_uvel_noreg_T_reg_tend_E_sloping_top = -repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(-diff_x_min_dz_depth_integrating_east_facing_top_only.*uvel_noreg_east.*T_reg_east,3))./vol_layer_at_horiz_cell;
adv_uvel_noreg_T_noreg_tend_E_sloping_top = adv_T_tend_E_sloping_top - (adv_uvel_reg_T_reg_tend_E_sloping_top + adv_uvel_reg_T_noreg_tend_E_sloping_top + adv_uvel_noreg_T_reg_tend_E_sloping_top);

if reg_level_option == 1
    hdiff_T_tend_E_sloping_top = -repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(-diff_x_min_dz_depth_integrating_east_facing_top_only.*hdiff_T_flux_east,3))./vol_layer_at_horiz_cell;
end

diff_x_min_dz_depth_integrating_west_facing_top_only = NaN(size_array);
diff_x_min_dz_depth_integrating_west_facing_top_only(2:length(lon_ind_inrange),:,:,:) = diff_x_min_dz_depth_integrating_top_only;
not_west_facing_ind = find(diff_x_min_dz_depth_integrating_west_facing_top_only <= 0);
diff_x_min_dz_depth_integrating_west_facing_top_only(not_west_facing_ind) = 0;

adv_vol_flux_W_sloping_top = repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(diff_x_min_dz_depth_integrating_west_facing_top_only.*uvel_west,3));
if reg_level_option == 1
    adv_T_flux_W_sloping_top = (repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(diff_x_min_dz_depth_integrating_west_facing_top_only.*uT_west,3))) - (adv_vol_flux_W_sloping_top.*T_vert_mean_inlayer);
    adv_T_tend_W_sloping_top = adv_T_flux_W_sloping_top./vol_layer_at_horiz_cell;
end


adv_uvel_reg_T_reg_tend_W_sloping_top = repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(diff_x_min_dz_depth_integrating_west_facing_top_only.*uvel_reg_west.*T_reg_west,3))./vol_layer_at_horiz_cell;
adv_uvel_reg_T_noreg_tend_W_sloping_top = repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(diff_x_min_dz_depth_integrating_west_facing_top_only.*uvel_reg_west.*T_noreg_west,3))./vol_layer_at_horiz_cell;
adv_uvel_noreg_T_reg_tend_W_sloping_top = repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(diff_x_min_dz_depth_integrating_west_facing_top_only.*uvel_noreg_west.*T_reg_west,3))./vol_layer_at_horiz_cell;
adv_uvel_noreg_T_noreg_tend_W_sloping_top = adv_T_tend_W_sloping_top - (adv_uvel_reg_T_reg_tend_W_sloping_top + adv_uvel_reg_T_noreg_tend_W_sloping_top + adv_uvel_noreg_T_reg_tend_W_sloping_top);

if reg_level_option == 1
    hdiff_T_tend_W_sloping_top = repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(diff_x_min_dz_depth_integrating_west_facing_top_only.*hdiff_T_flux_west,3))./vol_layer_at_horiz_cell;
end


diff_y_min_dz_depth_integrating_top_only = diff(min_dz_depth_integrating_top_only,1,2);
diff_y_min_dz_depth_integrating_north_facing_top_only = NaN(size_array);
diff_y_min_dz_depth_integrating_north_facing_top_only(:,1:(length(lat_ind_inrange) - 1),:,:) = diff_y_min_dz_depth_integrating_top_only;
not_north_facing_ind = find(diff_y_min_dz_depth_integrating_north_facing_top_only >= 0);
diff_y_min_dz_depth_integrating_north_facing_top_only(not_north_facing_ind) = 0;

adv_vol_flux_N_sloping_top = repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(-diff_y_min_dz_depth_integrating_north_facing_top_only.*vvel_north,3));
if reg_level_option == 1
    adv_T_flux_N_sloping_top = (repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(-diff_y_min_dz_depth_integrating_north_facing_top_only.*vT_north,3))) - (adv_vol_flux_N_sloping_top.*T_vert_mean_inlayer);
    adv_T_tend_N_sloping_top = -adv_T_flux_N_sloping_top./vol_layer_at_horiz_cell;
end


adv_vvel_reg_T_reg_tend_N_sloping_top = -repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(-diff_y_min_dz_depth_integrating_north_facing_top_only.*vvel_reg_north.*T_reg_north,3))./vol_layer_at_horiz_cell;
adv_vvel_reg_T_noreg_tend_N_sloping_top = -repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(-diff_y_min_dz_depth_integrating_north_facing_top_only.*vvel_reg_north.*T_noreg_north,3))./vol_layer_at_horiz_cell;
adv_vvel_noreg_T_reg_tend_N_sloping_top = -repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(-diff_y_min_dz_depth_integrating_north_facing_top_only.*vvel_noreg_north.*T_reg_north,3))./vol_layer_at_horiz_cell;
adv_vvel_noreg_T_noreg_tend_N_sloping_top = adv_T_tend_N_sloping_top - (adv_vvel_reg_T_reg_tend_N_sloping_top + adv_vvel_reg_T_noreg_tend_N_sloping_top + adv_vvel_noreg_T_reg_tend_N_sloping_top);

if reg_level_option == 1
    hdiff_T_tend_N_sloping_top = -repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(-diff_y_min_dz_depth_integrating_north_facing_top_only.*hdiff_T_flux_north,3))./vol_layer_at_horiz_cell;
end


diff_y_min_dz_depth_integrating_south_facing_top_only = NaN(size_array);
diff_y_min_dz_depth_integrating_south_facing_top_only(:,2:length(lat_ind_inrange),:,:) = diff_y_min_dz_depth_integrating_top_only;
not_south_facing_ind = find(diff_y_min_dz_depth_integrating_top_only <= 0);
diff_y_min_dz_depth_integrating_top_only(not_south_facing_ind) = 0;

adv_vol_flux_S_sloping_top = repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(diff_y_min_dz_depth_integrating_south_facing_top_only.*vvel_south,3));
if reg_level_option == 1
    adv_T_flux_S_sloping_top = (repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(diff_y_min_dz_depth_integrating_south_facing_top_only.*vT_south,3))) - (adv_vol_flux_S_sloping_top.*T_vert_mean_inlayer);
    adv_T_tend_S_sloping_top = adv_T_flux_S_sloping_top./vol_layer_at_horiz_cell;
end


adv_vvel_reg_T_reg_tend_S_sloping_top = repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(diff_y_min_dz_depth_integrating_south_facing_top_only.*vvel_reg_south.*T_reg_south,3))./vol_layer_at_horiz_cell;
adv_vvel_reg_T_noreg_tend_S_sloping_top = repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(diff_y_min_dz_depth_integrating_south_facing_top_only.*vvel_reg_south.*T_noreg_south,3))./vol_layer_at_horiz_cell;
adv_vvel_noreg_T_reg_tend_S_sloping_top = repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(diff_y_min_dz_depth_integrating_south_facing_top_only.*vvel_noreg_south.*T_reg_south,3))./vol_layer_at_horiz_cell;
adv_vvel_noreg_T_noreg_tend_S_sloping_top = adv_T_tend_S_sloping_top - (adv_vvel_reg_T_reg_tend_S_sloping_top + adv_vvel_reg_T_noreg_tend_S_sloping_top + adv_vvel_noreg_T_reg_tend_S_sloping_top);

if reg_level_option == 1
    hdiff_T_tend_S_sloping_top = repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(diff_y_min_dz_depth_integrating_south_facing_top_only.*hdiff_T_flux_south,3))./vol_layer_at_horiz_cell;
end

disp('Completed computing advective terms for variable-depth top bound')



% compute horizontal advection/diffusion terms through variable depth bottom bound

% some of this (e.g., the use of ht_east_wall and ht_north_wall) is different from the computation for the top bound, to account for bathymetry and partial bottom cells
ht_east_wall = squeeze(sum(dzt_east_wall,3));
min_ht_bottom_depth_east_side = NaN(size(bottom_depth_bound_array));
min_ht_bottom_depth_east_side(1:(length(lon_ind_inrange) - 1),:,:) = reshape(min([reshape(repmat(ht_east_wall(1:(size(ht_east_wall,1) - 1),:),[1 1 length(unique_times)]),[1 ((length(lon_ind_inrange) - 1)*length(lat_ind_inrange)*length(unique_times))]); reshape(bottom_depth_bound_array(1:(length(lon_ind_inrange) - 1),:,:),[1 ((length(lon_ind_inrange) - 1)*length(lat_ind_inrange)*length(unique_times))])],[],1),[(length(lon_ind_inrange) - 1) length(lat_ind_inrange) length(unique_times)]);
diff_z_w_top_bottom_bound_east_side = repmat(reshape(min_ht_bottom_depth_east_side,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[1 1 length(depth_ind_inrange) 1]) - repmat(reshape(z_w_top(depth_ind_inrange),[1 1 length(depth_ind_inrange)]),[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]);
min_dzt_depth_integrating_east_side_bottom_only = reshape(min([reshape(min_dzt_depth_integrating_array,[1 prod(size(min_dzt_depth_integrating_array))]); reshape(diff_z_w_top_bottom_bound_east_side,[1 prod(size(diff_z_w_top_bottom_bound_east_side))])],[],1),[length(lon_ind_inrange) length(lat_ind_inrange) length(depth_ind_inrange) length(unique_times)]);
min_dzt_depth_integrating_east_side_bottom_only(min_dzt_depth_integrating_east_side_bottom_only < 0) = 0;

min_ht_bottom_depth_west_side = NaN(size(bottom_depth_bound_array));
min_ht_bottom_depth_west_side(2:length(lon_ind_inrange),:,:) = reshape(min([reshape(repmat(ht_east_wall(1:(size(ht_east_wall,1) - 1),:),[1 1 length(unique_times)]),[1 ((length(lon_ind_inrange) - 1)*length(lat_ind_inrange)*length(unique_times))]); reshape(bottom_depth_bound_array(2:length(lon_ind_inrange),:,:),[1 ((length(lon_ind_inrange) - 1)*length(lat_ind_inrange)*length(unique_times))])],[],1),[(length(lon_ind_inrange) - 1) length(lat_ind_inrange) length(unique_times)]);
diff_z_w_top_bottom_bound_west_side = repmat(reshape(min_ht_bottom_depth_west_side,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[1 1 length(depth_ind_inrange) 1]) - repmat(reshape(z_w_top(depth_ind_inrange),[1 1 length(depth_ind_inrange)]),[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]);
min_dzt_depth_integrating_west_side_bottom_only = reshape(min([reshape(min_dzt_depth_integrating_array,[1 prod(size(min_dzt_depth_integrating_array))]); reshape(diff_z_w_top_bottom_bound_west_side,[1 prod(size(diff_z_w_top_bottom_bound_west_side))])],[],1),[length(lon_ind_inrange) length(lat_ind_inrange) length(depth_ind_inrange) length(unique_times)]);
min_dzt_depth_integrating_west_side_bottom_only(min_dzt_depth_integrating_west_side_bottom_only < 0) = 0;

diff_x_min_dzt_depth_integrating_bottom_only = min_dzt_depth_integrating_west_side_bottom_only(2:length(lon_ind_inrange),:,:,:) - min_dzt_depth_integrating_east_side_bottom_only(1:(length(lon_ind_inrange) - 1),:,:,:);

diff_x_min_dzt_depth_integrating_east_facing_bottom_only = NaN(size_array);
diff_x_min_dzt_depth_integrating_east_facing_bottom_only(1:(length(lon_ind_inrange) - 1),:,:,:) = diff_x_min_dzt_depth_integrating_bottom_only;
not_east_facing_ind = find(diff_x_min_dzt_depth_integrating_east_facing_bottom_only >= 0);
diff_x_min_dzt_depth_integrating_east_facing_bottom_only(not_east_facing_ind) = 0;

adv_vol_flux_E_sloping_bottom = repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(-diff_x_min_dzt_depth_integrating_east_facing_bottom_only.*uvel_east,3));
if reg_level_option == 1
    adv_T_flux_E_sloping_bottom = (repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(-diff_x_min_dzt_depth_integrating_east_facing_bottom_only.*uT_east,3))) - (adv_vol_flux_E_sloping_bottom.*T_vert_mean_inlayer);
    adv_T_tend_E_sloping_bottom = -adv_T_flux_E_sloping_bottom./vol_layer_at_horiz_cell;
end

adv_uvel_reg_T_reg_tend_E_sloping_bottom = -repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(-diff_x_min_dzt_depth_integrating_east_facing_bottom_only.*uvel_reg_east.*T_reg_east,3))./vol_layer_at_horiz_cell;
adv_uvel_reg_T_noreg_tend_E_sloping_bottom = -repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(-diff_x_min_dzt_depth_integrating_east_facing_bottom_only.*uvel_reg_east.*T_noreg_east,3))./vol_layer_at_horiz_cell;
adv_uvel_noreg_T_reg_tend_E_sloping_bottom = -repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(-diff_x_min_dzt_depth_integrating_east_facing_bottom_only.*uvel_noreg_east.*T_reg_east,3))./vol_layer_at_horiz_cell;
adv_uvel_noreg_T_noreg_tend_E_sloping_bottom = adv_T_tend_E_sloping_bottom - (adv_uvel_reg_T_reg_tend_E_sloping_bottom + adv_uvel_reg_T_noreg_tend_E_sloping_bottom + adv_uvel_noreg_T_reg_tend_E_sloping_bottom);

if reg_level_option == 1
    hdiff_T_tend_E_sloping_bottom = -repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(-diff_x_min_dzt_depth_integrating_east_facing_bottom_only.*hdiff_T_flux_east,3))./vol_layer_at_horiz_cell;
end


diff_x_min_dzt_depth_integrating_west_facing_bottom_only = NaN(size_array);
diff_x_min_dzt_depth_integrating_west_facing_bottom_only(2:length(lon_ind_inrange),:,:,:) = diff_x_min_dzt_depth_integrating_bottom_only;
not_west_facing_ind = find(diff_x_min_dzt_depth_integrating_west_facing_bottom_only <= 0);
diff_x_min_dzt_depth_integrating_west_facing_bottom_only(not_west_facing_ind) = 0;

adv_vol_flux_W_sloping_bottom = repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(diff_x_min_dzt_depth_integrating_west_facing_bottom_only.*uvel_west,3));
if reg_level_option == 1
    adv_T_flux_W_sloping_bottom = (repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(diff_x_min_dzt_depth_integrating_west_facing_bottom_only.*uT_west,3))) - (adv_vol_flux_W_sloping_bottom.*T_vert_mean_inlayer);
    adv_T_tend_W_sloping_bottom = adv_T_flux_W_sloping_bottom./vol_layer_at_horiz_cell;
end


adv_uvel_reg_T_reg_tend_W_sloping_bottom = repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(diff_x_min_dzt_depth_integrating_west_facing_bottom_only.*uvel_reg_west.*T_reg_west,3))./vol_layer_at_horiz_cell;
adv_uvel_reg_T_noreg_tend_W_sloping_bottom = repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(diff_x_min_dzt_depth_integrating_west_facing_bottom_only.*uvel_reg_west.*T_noreg_west,3))./vol_layer_at_horiz_cell;
adv_uvel_noreg_T_reg_tend_W_sloping_bottom = repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(diff_x_min_dzt_depth_integrating_west_facing_bottom_only.*uvel_noreg_west.*T_reg_west,3))./vol_layer_at_horiz_cell;
adv_uvel_noreg_T_noreg_tend_W_sloping_bottom = adv_T_tend_W_sloping_bottom - (adv_uvel_reg_T_reg_tend_W_sloping_bottom + adv_uvel_reg_T_noreg_tend_W_sloping_bottom + adv_uvel_noreg_T_reg_tend_W_sloping_bottom);

if reg_level_option == 1
    hdiff_T_tend_W_sloping_bottom = repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(diff_x_min_dzt_depth_integrating_west_facing_bottom_only.*hdiff_T_flux_west,3))./vol_layer_at_horiz_cell;
end



ht_north_wall = squeeze(sum(dzt_north_wall,3));
min_ht_bottom_depth_north_side = NaN(size(bottom_depth_bound_array));
min_ht_bottom_depth_north_side(:,1:(length(lat_ind_inrange) - 1),:) = reshape(min([reshape(repmat(ht_north_wall(:,1:(size(ht_north_wall,2) - 1)),[1 1 length(unique_times)]),[1 (length(lon_ind_inrange)*(length(lat_ind_inrange) - 1)*length(unique_times))]); reshape(bottom_depth_bound_array(:,1:(length(lat_ind_inrange) - 1),:),[1 (length(lon_ind_inrange)*(length(lat_ind_inrange) - 1)*length(unique_times))])],[],1),[length(lon_ind_inrange) (length(lat_ind_inrange) - 1) length(unique_times)]);
diff_z_w_top_bottom_bound_north_side = repmat(reshape(min_ht_bottom_depth_north_side,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[1 1 length(depth_ind_inrange) 1]) - repmat(reshape(z_w_top(depth_ind_inrange),[1 1 length(depth_ind_inrange)]),[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]);
min_dzt_depth_integrating_north_side_bottom_only = reshape(min([reshape(min_dzt_depth_integrating_array,[1 prod(size(min_dzt_depth_integrating_array))]); reshape(diff_z_w_top_bottom_bound_north_side,[1 prod(size(diff_z_w_top_bottom_bound_north_side))])],[],1),[length(lon_ind_inrange) length(lat_ind_inrange) length(depth_ind_inrange) length(unique_times)]);
min_dzt_depth_integrating_north_side_bottom_only(min_dzt_depth_integrating_north_side_bottom_only < 0) = 0;

min_ht_bottom_depth_south_side = NaN(size(bottom_depth_bound_array));
min_ht_bottom_depth_south_side(:,2:length(lat_ind_inrange),:) = reshape(min([reshape(repmat(ht_north_wall(:,1:(size(ht_north_wall,2) - 1)),[1 1 length(unique_times)]),[1 (length(lon_ind_inrange)*(length(lat_ind_inrange) - 1)*length(unique_times))]); reshape(bottom_depth_bound_array(:,2:length(lat_ind_inrange),:),[1 (length(lon_ind_inrange)*(length(lat_ind_inrange) - 1)*length(unique_times))])],[],1),[length(lon_ind_inrange) (length(lat_ind_inrange) - 1) length(unique_times)]);
diff_z_w_top_bottom_bound_south_side = repmat(reshape(min_ht_bottom_depth_south_side,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[1 1 length(depth_ind_inrange) 1]) - repmat(reshape(z_w_top(depth_ind_inrange),[1 1 length(depth_ind_inrange)]),[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]);
min_dzt_depth_integrating_south_side_bottom_only = reshape(min([reshape(min_dzt_depth_integrating_array,[1 prod(size(min_dzt_depth_integrating_array))]); reshape(diff_z_w_top_bottom_bound_south_side,[1 prod(size(diff_z_w_top_bottom_bound_south_side))])],[],1),[length(lon_ind_inrange) length(lat_ind_inrange) length(depth_ind_inrange) length(unique_times)]);
min_dzt_depth_integrating_south_side_bottom_only(min_dzt_depth_integrating_south_side_bottom_only < 0) = 0;

diff_y_min_dzt_depth_integrating_bottom_only = min_dzt_depth_integrating_south_side_bottom_only(:,2:length(lat_ind_inrange),:,:) - min_dzt_depth_integrating_north_side_bottom_only(:,1:(length(lat_ind_inrange) - 1),:,:);



diff_y_min_dzt_depth_integrating_north_facing_bottom_only = NaN(size_array);
diff_y_min_dzt_depth_integrating_north_facing_bottom_only(:,1:(length(lat_ind_inrange) - 1),:,:) = diff_y_min_dzt_depth_integrating_bottom_only;
not_north_facing_ind = find(diff_y_min_dzt_depth_integrating_north_facing_bottom_only >= 0);
diff_y_min_dzt_depth_integrating_north_facing_bottom_only(not_north_facing_ind) = 0;

adv_vol_flux_N_sloping_bottom = repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(-diff_y_min_dzt_depth_integrating_north_facing_bottom_only.*vvel_north,3));
if reg_level_option == 1
    adv_T_flux_N_sloping_bottom = (repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(-diff_y_min_dzt_depth_integrating_north_facing_bottom_only.*vT_north,3))) - (adv_vol_flux_N_sloping_bottom.*T_vert_mean_inlayer);
    adv_T_tend_N_sloping_bottom = -adv_T_flux_N_sloping_bottom./vol_layer_at_horiz_cell;
end


adv_vvel_reg_T_reg_tend_N_sloping_bottom = -repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(-diff_y_min_dzt_depth_integrating_north_facing_bottom_only.*vvel_reg_north.*T_reg_north,3))./vol_layer_at_horiz_cell;
adv_vvel_reg_T_noreg_tend_N_sloping_bottom = -repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(-diff_y_min_dzt_depth_integrating_north_facing_bottom_only.*vvel_reg_north.*T_noreg_north,3))./vol_layer_at_horiz_cell;
adv_vvel_noreg_T_reg_tend_N_sloping_bottom = -repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(-diff_y_min_dzt_depth_integrating_north_facing_bottom_only.*vvel_noreg_north.*T_reg_north,3))./vol_layer_at_horiz_cell;
adv_vvel_noreg_T_noreg_tend_N_sloping_bottom = adv_T_tend_N_sloping_bottom - (adv_vvel_reg_T_reg_tend_N_sloping_bottom + adv_vvel_reg_T_noreg_tend_N_sloping_bottom + adv_vvel_noreg_T_reg_tend_N_sloping_bottom);

if reg_level_option == 1
    hdiff_T_tend_N_sloping_bottom = -repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(-diff_y_min_dzt_depth_integrating_north_facing_bottom_only.*hdiff_T_flux_north,3))./vol_layer_at_horiz_cell;
end


diff_y_min_dzt_depth_integrating_south_facing_bottom_only = NaN(size_array);
diff_y_min_dzt_depth_integrating_south_facing_bottom_only(:,2:length(lat_ind_inrange),:,:) = diff_y_min_dzt_depth_integrating_bottom_only;
not_south_facing_ind = find(diff_y_min_dzt_depth_integrating_south_facing_bottom_only <= 0);
diff_y_min_dzt_depth_integrating_south_facing_bottom_only(not_south_facing_ind) = 0;

adv_vol_flux_S_sloping_bottom = repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(diff_y_min_dzt_depth_integrating_south_facing_bottom_only.*vvel_south,3));
if reg_level_option == 1
    adv_T_flux_S_sloping_bottom = (repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(diff_y_min_dzt_depth_integrating_south_facing_bottom_only.*vT_south,3))) - (adv_vol_flux_S_sloping_bottom.*T_vert_mean_inlayer);
    adv_T_tend_S_sloping_bottom = adv_T_flux_S_sloping_bottom./vol_layer_at_horiz_cell;
end


adv_vvel_reg_T_reg_tend_S_sloping_bottom = repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(diff_y_min_dzt_depth_integrating_south_facing_bottom_only.*vvel_reg_south.*T_reg_south,3))./vol_layer_at_horiz_cell;
adv_vvel_reg_T_noreg_tend_S_sloping_bottom = repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(diff_y_min_dzt_depth_integrating_south_facing_bottom_only.*vvel_reg_south.*T_noreg_south,3))./vol_layer_at_horiz_cell;
adv_vvel_noreg_T_reg_tend_S_sloping_bottom = repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(diff_y_min_dzt_depth_integrating_south_facing_bottom_only.*vvel_noreg_south.*T_reg_south,3))./vol_layer_at_horiz_cell;
adv_vvel_noreg_T_noreg_tend_S_sloping_bottom = adv_T_tend_S_sloping_bottom - (adv_vvel_reg_T_reg_tend_S_sloping_bottom + adv_vvel_reg_T_noreg_tend_S_sloping_bottom + adv_vvel_noreg_T_reg_tend_S_sloping_bottom);

if reg_level_option == 1
    hdiff_T_tend_S_sloping_bottom = repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(diff_y_min_dzt_depth_integrating_south_facing_bottom_only.*hdiff_T_flux_south,3))./vol_layer_at_horiz_cell;
end

clear uT_east uT_west vT_north vT_south wT_top diff_x* diff_y* diff_z* frac_above* frac_below* hdiff_T_flux_west hdiff_T_flux_south thickness_at_base_layer_array


disp('Completed computing advective terms for variable-depth bottom bound')



if reg_level_option == 1
    
    % adjustment to shift the top advective and entrainment term balance at the surface
    
    top_at_sfc_mask = zeros(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_times));
    top_cell_top_level_ind = find(top_depth_bound_array < z_w_bot(1));
    min_dzt_depth_integrating_array_top_layer = squeeze(min_dzt_depth_integrating_array(:,:,1,:));
    repmat_dzt_inrange = repmat(dzt(:,:,1),[1 1 length(unique_times)]);
    if isempty(top_cell_top_level_ind) == 0
        top_at_sfc_mask(top_cell_top_level_ind) = min_dzt_depth_integrating_array_top_layer(top_cell_top_level_ind)./repmat_dzt_inrange(top_cell_top_level_ind);
    end
    top_at_sfc_mask(isnan(top_at_sfc_mask) == 1) = 0;
    top_at_sfc_mask(isinf(top_at_sfc_mask) == 1) = 0;
    
    adv_vol_flux_top_at_sfc = repmat(tarea,[1 1 length(unique_times)]).*top_at_sfc_mask.*squeeze(wvel(:,:,1,:));
    adv_T_flux_top_at_sfc = repmat(tarea,[1 1 length(unique_times)]).*top_at_sfc_mask.*squeeze(wvel(:,:,1,:).*temp(:,:,1,:));
    
    sfc_ent_T_tend_adj = (adv_T_flux_top_at_sfc - (adv_vol_flux_top_at_sfc.*T_vert_mean_inlayer))./vol_layer_at_horiz_cell;
    sfc_total_T_tend_adj = adv_T_flux_top_at_sfc./vol_layer_at_horiz_cell;   % may need to be solved for based on entrainment instead
    
    
    
    
    % compute contributions from diabatic implicit vertical mixing
    
    diab_vert_T_tend = diab_vert_T_tend_top + diab_vert_T_tend_bottom;
    
    
    
    % compute contributions from the non-local mixing term
    
    kpp_src_T_tend = repmat(tarea,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array.*kpp_src_temp,3))./vol_layer_at_horiz_cell;
    
    
    
    
    % compute contributions from the surface heat flux and the shortwave energy input
    
    sfc_flux_T_tend = repmat(tarea,[1 1 length(unique_times)]).*top_at_sfc_mask.*sfc_heat_flux*hflux_factor./vol_layer_at_horiz_cell;
    
    % compute contributions from constituents of surface heat flux (other than shortwave)
    longwave_downward_flux_T_tend = repmat(tarea,[1 1 length(unique_times)]).*top_at_sfc_mask.*longwave_downward_flux*hflux_factor./vol_layer_at_horiz_cell;
    longwave_upward_flux_T_tend = repmat(tarea,[1 1 length(unique_times)]).*top_at_sfc_mask.*longwave_upward_flux*hflux_factor./vol_layer_at_horiz_cell;
    latent_heat_flux_T_tend = repmat(tarea,[1 1 length(unique_times)]).*top_at_sfc_mask.*evap_mass_flux*latent_heat_vapor*hflux_factor./vol_layer_at_horiz_cell;
    sensible_heat_flux_T_tend = repmat(tarea,[1 1 length(unique_times)]).*top_at_sfc_mask.*sensible_heat_flux*hflux_factor./vol_layer_at_horiz_cell;
    
    
    sw_flux_top_bound_top_level_mask = ones(size(top_at_sfc_mask));
    sw_flux_top_bound_top_level_mask(top_cell_top_level_ind) = 1 - top_at_sfc_mask(top_cell_top_level_ind);
    sw_flux_top_bound_weighting_array = top_bound_weighting_array;
    sw_flux_top_bound_weighting_array_sfc = top_bound_weighting_array(:,:,1,:);
    sw_flux_top_bound_weighting_array_sfc(top_cell_top_level_ind) = 0;
    sw_flux_top_bound_weighting_array(:,:,1,:) = sw_flux_top_bound_weighting_array_sfc;
    sw_flux_top_bound_weighting_array_just_under_sfc = top_bound_weighting_array(:,:,2,:);
    sw_flux_top_bound_weighting_array_just_under_sfc(top_cell_top_level_ind) = 1;
    sw_flux_top_bound_weighting_array(:,:,2,:) = sw_flux_top_bound_weighting_array_just_under_sfc;
    
    % shortwave flux + other surface fluxes (if applicable)
    sw_inc_sfc_flux_top_bound_T_tend = repmat(tarea,[1 1 length(unique_times)]).*squeeze(sum(repmat(reshape(sw_flux_top_bound_top_level_mask,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[1 1 length(depth_ind_inrange) 1]).*sw_flux_top_bound_weighting_array.*sw_flux_top*hflux_factor,3))./vol_layer_at_horiz_cell;
    
    % shortwave flux only
    sw_top_flux_T_tend = repmat(tarea,[1 1 length(unique_times)]).*squeeze(sum(top_bound_weighting_array.*sw_flux_top*hflux_factor,3))./vol_layer_at_horiz_cell;
    
    
    sw_flux_bottom_bound_top_level_mask = ones(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_times));
    bottom_at_sfc_ind = find(bottom_depth_bound_array <= 0);
    bottom_cell_top_level_ind = find(bottom_depth_bound_array < z_w_bot(1));
    bottom_cell_top_level_not_sfc_ind = setdiff(bottom_cell_top_level_ind,bottom_at_sfc_ind);
    sw_flux_bottom_bound_top_level_mask(bottom_at_sfc_ind) = 0;
    if isempty(bottom_cell_top_level_not_sfc_ind) == 0
        sw_flux_bottom_bound_top_level_mask(bottom_cell_top_level_not_sfc_ind) = (bottom_depth_bound_array(bottom_cell_top_level_not_sfc_ind) + SSH(bottom_cell_top_level_not_sfc_ind))./(repmat_dzt_inrange(bottom_cell_top_level_not_sfc_ind) + SSH(bottom_cell_top_level_not_sfc_ind));
    end
    sw_flux_bottom_bound_top_level_mask(isnan(sw_flux_bottom_bound_top_level_mask) == 1) = 0;
    sw_flux_bottom_bound_top_level_mask(isinf(sw_flux_bottom_bound_top_level_mask) == 1) = 0;
    
    
    sw_flux_bottom_bound_weighting_array = bottom_bound_weighting_array;
    sw_flux_bottom_bound_weighting_array_sfc = bottom_bound_weighting_array(:,:,1,:);
    sw_flux_bottom_bound_weighting_array_sfc(bottom_cell_top_level_ind) = 0;
    sw_flux_bottom_bound_weighting_array(:,:,1,:) = sw_flux_bottom_bound_weighting_array_sfc;
    sw_flux_bottom_bound_weighting_array_just_under_sfc = bottom_bound_weighting_array(:,:,2,:);
    sw_flux_bottom_bound_weighting_array_just_under_sfc(bottom_cell_top_level_ind) = 1;
    sw_flux_bottom_bound_weighting_array(:,:,2,:) = sw_flux_bottom_bound_weighting_array_just_under_sfc;
    
    % shortwave flux + other surface fluxes (if applicable)
    sw_inc_sfc_flux_bottom_bound_T_tend = -repmat(tarea,[1 1 length(unique_times)]).*squeeze(sum(repmat(reshape(sw_flux_bottom_bound_top_level_mask,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[1 1 length(depth_ind_inrange) 1]).*sw_flux_bottom_bound_weighting_array.*sw_flux_top*hflux_factor,3))./vol_layer_at_horiz_cell;
    
    % shortwave flux only
    sw_bottom_flux_T_tend = -repmat(tarea,[1 1 length(unique_times)]).*squeeze(sum(bottom_bound_weighting_array.*sw_flux_top*hflux_factor,3))./vol_layer_at_horiz_cell;
    
    
    % separate shortwave and other surface tendencies
    
    sfc_flux_minus_sw_T_tend = sfc_flux_T_tend - (sw_top_flux_T_tend + sw_bottom_flux_T_tend) + (sw_inc_sfc_flux_top_bound_T_tend + sw_inc_sfc_flux_bottom_bound_T_tend);
    
    
    % total (surface + shortwave) tendency
    sfc_sw_flux_T_tend = sfc_flux_minus_sw_T_tend + sw_top_flux_T_tend + sw_bottom_flux_T_tend;
    
end

clear bottom_bound* bottom_cell* sw_flux_top_bound* sw_flux_bottom_bound* top_bound* top_cell*


% collective contribution from variable depth bound-related terms

var_depth_adv_T_tend_top = adv_T_tend_N_sloping_top + adv_T_tend_W_sloping_top + adv_T_tend_S_sloping_top + adv_T_tend_E_sloping_top;
var_depth_hdiff_T_tend_top = hdiff_T_tend_N_sloping_top + hdiff_T_tend_W_sloping_top + hdiff_T_tend_S_sloping_top + hdiff_T_tend_E_sloping_top;
var_depth_T_tend_top = var_depth_adv_T_tend_top + var_depth_hdiff_T_tend_top + sfc_ent_T_tend_adj;
var_depth_adv_T_tend_bottom = adv_T_tend_N_sloping_bottom + adv_T_tend_W_sloping_bottom + adv_T_tend_S_sloping_bottom + adv_T_tend_E_sloping_bottom;
var_depth_hdiff_T_tend_bottom = hdiff_T_tend_N_sloping_bottom + hdiff_T_tend_W_sloping_bottom + hdiff_T_tend_S_sloping_bottom + hdiff_T_tend_E_sloping_bottom;
var_depth_T_tend_bottom = var_depth_adv_T_tend_bottom + var_depth_hdiff_T_tend_bottom;


% sum of velocity-temperature regressed advective contributions from each direction

adv_T_tend_uvel_reg_T_reg_all = adv_uvel_reg_T_reg_tend_E + adv_uvel_reg_T_reg_tend_W + adv_uvel_reg_T_reg_tend_E_sloping_top + adv_uvel_reg_T_reg_tend_W_sloping_top + adv_uvel_reg_T_reg_tend_E_sloping_bottom + adv_uvel_reg_T_reg_tend_W_sloping_bottom;
adv_T_tend_uvel_reg_T_noreg_all = adv_uvel_reg_T_noreg_tend_E + adv_uvel_reg_T_noreg_tend_W + adv_uvel_reg_T_noreg_tend_E_sloping_top + adv_uvel_reg_T_noreg_tend_W_sloping_top + adv_uvel_reg_T_noreg_tend_E_sloping_bottom + adv_uvel_reg_T_noreg_tend_W_sloping_bottom;
adv_T_tend_uvel_noreg_T_reg_all = adv_uvel_noreg_T_reg_tend_E + adv_uvel_noreg_T_reg_tend_W + adv_uvel_noreg_T_reg_tend_E_sloping_top + adv_uvel_noreg_T_reg_tend_W_sloping_top + adv_uvel_noreg_T_reg_tend_E_sloping_bottom + adv_uvel_noreg_T_reg_tend_W_sloping_bottom;
adv_T_tend_uvel_noreg_T_noreg_all = adv_uvel_noreg_T_noreg_tend_E + adv_uvel_noreg_T_noreg_tend_W + adv_uvel_noreg_T_noreg_tend_E_sloping_top + adv_uvel_noreg_T_noreg_tend_W_sloping_top + adv_uvel_noreg_T_noreg_tend_E_sloping_bottom + adv_uvel_noreg_T_noreg_tend_W_sloping_bottom;
adv_T_tend_vvel_reg_T_reg_all = adv_vvel_reg_T_reg_tend_N + adv_vvel_reg_T_reg_tend_S + adv_vvel_reg_T_reg_tend_N_sloping_top + adv_vvel_reg_T_reg_tend_S_sloping_top + adv_vvel_reg_T_reg_tend_N_sloping_bottom + adv_vvel_reg_T_reg_tend_S_sloping_bottom;
adv_T_tend_vvel_reg_T_noreg_all = adv_vvel_reg_T_noreg_tend_N + adv_vvel_reg_T_noreg_tend_S + adv_vvel_reg_T_noreg_tend_N_sloping_top + adv_vvel_reg_T_noreg_tend_S_sloping_top + adv_vvel_reg_T_noreg_tend_N_sloping_bottom + adv_vvel_reg_T_noreg_tend_S_sloping_bottom;
adv_T_tend_vvel_noreg_T_reg_all = adv_vvel_noreg_T_reg_tend_N + adv_vvel_noreg_T_reg_tend_S + adv_vvel_noreg_T_reg_tend_N_sloping_top + adv_vvel_noreg_T_reg_tend_S_sloping_top + adv_vvel_noreg_T_reg_tend_N_sloping_bottom + adv_vvel_noreg_T_reg_tend_S_sloping_bottom;
adv_T_tend_vvel_noreg_T_noreg_all = adv_vvel_noreg_T_noreg_tend_N + adv_vvel_noreg_T_noreg_tend_S + adv_vvel_noreg_T_noreg_tend_N_sloping_top + adv_vvel_noreg_T_noreg_tend_S_sloping_top + adv_vvel_noreg_T_noreg_tend_N_sloping_bottom + adv_vvel_noreg_T_noreg_tend_S_sloping_bottom;
adv_T_tend_wvel_reg_T_reg_all = adv_wvel_reg_T_reg_tend_top + adv_wvel_reg_T_reg_tend_bottom;
adv_T_tend_wvel_reg_T_noreg_all = adv_wvel_reg_T_noreg_tend_top + adv_wvel_reg_T_noreg_tend_bottom;
adv_T_tend_wvel_noreg_T_reg_all = adv_wvel_noreg_T_reg_tend_top + adv_wvel_noreg_T_reg_tend_bottom;
adv_T_tend_wvel_noreg_T_noreg_all = adv_wvel_noreg_T_noreg_tend_top + adv_wvel_noreg_T_noreg_tend_bottom;



% sum of the advective/entrainment contributions to temp. tendency

adv_T_tend_total = adv_T_tend_zonal + adv_T_tend_merid + adv_T_tend_top + adv_T_tend_bottom + var_depth_adv_T_tend_top + var_depth_adv_T_tend_bottom;

% sum of the diffusive contributions to temp. tendency
hdiff_T_tend_total = hdiff_T_tend_zonal + hdiff_T_tend_merid + hdiff_T_tend_top + hdiff_T_tend_bottom + var_depth_hdiff_T_tend_top + var_depth_hdiff_T_tend_bottom;





% sum of the temperature tendency terms, prior to the entrainment calculation
T_tend_sum_terms = adv_T_tend_total + hdiff_T_tend_total + sfc_ent_T_tend_adj + diab_vert_T_tend + kpp_src_T_tend + sfc_sw_flux_T_tend;



if reg_level_option == 1
    
    % compute temperature tendency from archived field, and find indices where there is a disagreement
    
    if tend_temp_present == 1
        total_T_tend = repmat(tarea,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array.*tot_temp_tend,3))./vol_layer_at_horiz_cell;
        
        % adjustment of temp. tendency to account for variable-thickness surface layer
        total_T_tend = total_T_tend - sfc_total_T_tend_adj;
        
        T_tend_error = T_tend_sum_terms - total_T_tend;
        
        T_tend_error_smoothed = filter((1/6)*[0.5; ones(5,1); 0.5],[1; zeros(6,1)],T_tend_error,[],3);
        
        try
    %         erroneous_ind = find(abs(T_tend_error) > ((1e-3)/86400));
%             erroneous_smoothed_ind = find(abs(T_tend_error_smoothed) > ((5e-3)/86400));
            erroneous_smoothed_ind = find((abs(T_tend_error_smoothed) > ((5e-3)/86400)) | (isnan(T_tend_error_smoothed) == 1));
            
            in_smoothed_range_ind_ind = find(erroneous_smoothed_ind > 6*prod(size_array(1:2)));
            at_first_full_time_ind_ind = find((erroneous_smoothed_ind > 6*prod(size_array(1:2))) & (erroneous_smoothed_ind <= 7*prod(size_array(1:2))));
            at_last_full_time_ind_ind = find(erroneous_smoothed_ind > (size_array(4) - 1)*prod(size_array(1:2)));
            
            erroneous_ind = reshape(repmat((0:1:2),[length(at_first_full_time_ind_ind) 1]).*prod(size_array(1:2)),[(3*length(at_first_full_time_ind_ind)) 1]) + repmat(erroneous_smoothed_ind(at_first_full_time_ind_ind) - (6*prod(size_array(1:2))),[3 1]);
            erroneous_to_add_ind = erroneous_smoothed_ind(in_smoothed_range_ind_ind) - (3*prod(size_array(1:2)));
            erroneous_ind = unique([erroneous_ind; erroneous_to_add_ind]);
            erroneous_to_add_ind = reshape(repmat(size_array(4) + ((-3):1:(-1)),[length(at_last_full_time_ind_ind) 1]).*prod(size_array(1:2)),[(3*length(at_last_full_time_ind_ind)) 1]) + repmat(erroneous_smoothed_ind(at_last_full_time_ind_ind) - ((size_array(4) - 1)*prod(size_array(1:2))),[3 1]);
            erroneous_ind = unique([erroneous_ind; erroneous_to_add_ind]);
            
            erroneous_array_mask = zeros(size_array([1 2 4]));
            erroneous_array_mask(erroneous_ind) = 1;
        
            erroneous_spatial_ind = find(sum(erroneous_array_mask(:,:,time_avg_from_unique_reg_ind),3) >= (0.1*length(time_avg_from_unique_reg_ind)));
            
            good_spatial_ind = find(sum(erroneous_array_mask,3) < (0.1*size_array(4)));
            
            erroneous_nan_mask_2D = NaN(size_array(1:2));
            erroneous_nan_mask_2D(good_spatial_ind) = 0;
            erroneous_nan_mask_3D = repmat(erroneous_nan_mask_2D,[1 1 size_array(4)]);
            good_spatial_ind_with_timedim = find(isnan(erroneous_nan_mask_3D) == 0);
            
%             save('T_tend_error_for_testing.mat','T_tend_sum_terms','total_T_tend','T_tend_error','erroneous_ind','-v7.3')
        catch err
            save('T_tend_error_for_testing_error.mat','T_tend_sum_terms','total_T_tend','T_tend_error','err','-v7.3')
        end
    end    
    
    
    
    % compute entrainment term, as the residual of the temperature change unexplained by other terms
    
    % compute time midpoints (i.e., endpoints of tavg periods)
    time_midpts = unique_times(2:length(unique_times)) - (diff(unique_times)/2);
    
    
    if ent_compute_option == 1
        diff_t_SSH_array = diff(SSH_depth_integrating_array,1,4);
        ent_vol_flux_top_time_midpt = repmat(tarea,[1 1 (length(unique_times) - 1)]).*(-squeeze(diff_t_SSH_array(:,:,1,:)))./(86400*diff(unique_times));
        ent_vol_flux_top = [(0.5*ent_vol_flux_top_time_midpt(1)); (((diff(unique_times(2:length(unique_times))).*ent_vol_flux_top_time_midpt(2:length(ent_vol_flux_top_time_midpt))) - (diff(diff(unique_times).*ent_vol_flux_top_time_midpt)/2))./diff(time_midpts)); (0.5*ent_vol_flux_top_time_midpt(length(ent_vol_flux_top_time_midpt)))];
        ent_vol_flux_top = NaN(size_array([1 2 4]));
        ent_vol_flux_top(:,:,1) = 0.5*ent_vol_flux_top_time_midpt(:,:,1);
        ent_vol_flux_top(:,:,2:(length(unique_times) - 1)) = ((repmat(reshape(diff(unique_times(2:length(unique_times))),[1 1 size_array(4)]),[size_array(1:2) 1]).*ent_vol_flux_top_time_midpt(:,:,2:length(ent_vol_flux_top_time_midpt))) - (diff(repmat(reshape(diff(unique_times),[1 1 size_array(4)]),[size_array(1:2) 1]).*ent_vol_flux_top_time_midpt,1,3)/2))./repmat(reshape(diff(time_midpts),[1 1 size_array(4)]),[size_array(1:2) 1]);
        ent_vol_flux_top(:,:,length(unique_times)) = 0.5*ent_vol_flux_top_time_midpt(:,:,size(ent_vol_flux_top_time_midpt,3));
        ent_vol_flux_bottom = zeros(size_array([1 2 4]));
        
        ent_T_tend_total = sfc_ent_T_tend_adj;
        ent_T_tend_top = sfc_ent_T_tend_adj;
        ent_T_tend_bottom = zeros(size_array([1 2 4]));
    elseif ent_compute_option == 2
        
        T_vert_mean_inlayer_midpts = NaN(size_array([1 2 4]) + [0 0 1]);
        T_vert_mean_inlayer_midpts(:,:,1) = (1.5*T_vert_mean_inlayer(:,:,1)) + ((-0.5)*T_vert_mean_inlayer(:,:,2));
        T_vert_mean_inlayer_midpts(:,:,2:(size(T_vert_mean_inlayer_midpts,3) - 1)) = T_vert_mean_inlayer(:,:,2:size(T_vert_mean_inlayer,3)) - (diff(T_vert_mean_inlayer,1,3)/2);
        T_vert_mean_inlayer_midpts(:,:,size(T_vert_mean_inlayer_midpts,3)) = ((-0.5)*T_vert_mean_inlayer(:,:,size(T_vert_mean_inlayer,3) - 1)) + (1.5*T_vert_mean_inlayer(:,:,size(T_vert_mean_inlayer,3)));
        
        actual_dT_dt_vert_mean_inlayer = diff(T_vert_mean_inlayer_midpts,1,3)./(86400*repmat(reshape([diff(time_midpts(1:2)); diff(time_midpts); diff(time_midpts((length(time_midpts) - 1):length(time_midpts)))],[1 1 size_array(4)]),[size_array(1:2) 1]));
        
        % total entrainment tendency (computed from residual of temperature change)
        ent_T_tend_total = actual_dT_dt_vert_mean_inlayer - T_tend_sum_terms;
        
        
        % divide up the total entrainment-related tendency into parts associated with the top and bottom surfaces
        
        % adjust top entrainment term to include changes in SSH
        SSH_depth_integrating_top_layer = zeros(size(SSH));
        top_at_sfc_ind = find(top_depth_bound_array <= 0);
        SSH_depth_integrating_top_layer(top_at_sfc_ind) = SSH(top_at_sfc_ind);
        SSH_depth_integrating_array = zeros(size(min_dzt_depth_integrating_array));
        SSH_depth_integrating_array(:,:,1,:) = reshape(SSH_depth_integrating_top_layer,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]);
        
        
        % compute approximation to T*dh/dt for top bound
        
        diff_t_min_dzt_depth_integrating_top_only = diff(min_dzt_depth_integrating_top_only + SSH_depth_integrating_array,1,4);
        
        ent_vol_flux_top_time_midpt = repmat(tarea,[1 1 (length(unique_times) - 1)]).*squeeze(sum(-diff_t_min_dzt_depth_integrating_top_only,3))./(86400*repmat(reshape(diff(unique_times),[1 1 (size_array(4) - 1)]),[size_array(1:2) 1]));
        
        temp_time_midpt = temp(:,:,:,2:length(unique_times)) - (diff(temp,1,4)/2);
        
        ent_T_dh_top_time_midpt = diff_t_min_dzt_depth_integrating_top_only.*temp_time_midpt;
        
        temp_time_midpt_no_nans = temp_time_midpt;
        temp_time_midpt_no_nans(isnan(temp_time_midpt) == 1) = 0;
        
        
        % depth integrating arrays for time midpoints
        
        top_depth_bound_array_with_SSH = top_depth_bound_array - squeeze(SSH_depth_integrating_array(:,:,1,:));
        top_depth_bound_array_with_SSH_midpts = top_depth_bound_array_with_SSH(:,:,2:length(unique_times)) - (diff(top_depth_bound_array_with_SSH,1,3)/2);
        
        bottom_depth_bound_array_midpts = bottom_depth_bound_array(:,:,2:length(unique_times)) - squeeze(diff(bottom_depth_bound_array,1,3)/2);
        
        
        depth_integrating_array_midpts = zeros(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_times) - 1);
        for curr_depth_ind = 1:length(depth_ind_inrange)
            curr_k_ind = depth_ind_inrange(curr_depth_ind);
            
            if curr_k_ind == 1
                at_shallowest_level_ind = find(top_depth_bound_array_with_SSH_midpts < z_w_bot(curr_k_ind));
                not_vert_edge_adj_ind = [];
            else
                at_shallowest_level_ind = find((top_depth_bound_array_with_SSH_midpts >= z_w_top(curr_k_ind)) & (top_depth_bound_array_with_SSH_midpts < z_w_bot(curr_k_ind)));
                not_vert_edge_adj_ind = find((top_depth_bound_array_with_SSH_midpts < z_w_top(curr_k_ind)) & (bottom_depth_bound_array_midpts > z_w_bot(curr_k_ind)));
            end
            at_deepest_level_ind = find((bottom_depth_bound_array_midpts > z_w_top(curr_k_ind)) & (bottom_depth_bound_array_midpts <= z_w_bot(curr_k_ind)));
            only_one_in_level_ind = intersect(at_shallowest_level_ind,at_deepest_level_ind);
            
            depth_integrating_curr_level = zeros(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_times) - 1);
            depth_integrating_curr_level(at_shallowest_level_ind) = z_w_bot(curr_k_ind) - top_depth_bound_array_with_SSH_midpts(at_shallowest_level_ind);
            depth_integrating_curr_level(at_deepest_level_ind) = bottom_depth_bound_array_midpts(at_deepest_level_ind) - z_w_top(curr_k_ind);
            depth_integrating_curr_level(only_one_in_level_ind) = bottom_depth_bound_array_midpts(only_one_in_level_ind) - top_depth_bound_array_with_SSH_midpts(only_one_in_level_ind);
            depth_integrating_curr_level(not_vert_edge_adj_ind) = dz(curr_k_ind)*ones(length(not_vert_edge_adj_ind),1);
            
            depth_integrating_array_midpts(:,:,curr_depth_ind,:) = reshape(depth_integrating_curr_level,[length(lon_ind_inrange) length(lat_ind_inrange) 1 (length(unique_times) - 1)]);
        end
        
        min_dzt_depth_integrating_array_with_SSH_midpts_5D = zeros(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_times) - 1,2);
        min_dzt_depth_integrating_array_with_SSH_midpts_5D(:,:,:,:,1) = depth_integrating_array_midpts;
        if depth_ind_inrange(1) == 1
            min_dzt_depth_integrating_array_with_SSH_midpts_5D(:,:,:,:,2) = repmat(dzt(:,:,depth_ind_inrange),[1 1 1 (length(unique_times) - 1)]);
            min_dzt_depth_integrating_array_with_SSH_midpts_5D(:,:,1,:,2) = min_dzt_depth_integrating_array_with_SSH_midpts_5D(:,:,1,:,2) - reshape(top_depth_bound_array_with_SSH_midpts,[length(lon_ind_inrange) length(lat_ind_inrange) 1 (length(unique_times) - 1)]);
        else
            min_dzt_depth_integrating_array_with_SSH_midpts_5D(:,:,:,:,2) = repmat(dzt(:,:,depth_ind_inrange),[1 1 1 (length(unique_times) - 1)]);
        end
        min_dzt_depth_integrating_array_with_SSH_midpts = squeeze(min(min_dzt_depth_integrating_array_with_SSH_midpts_5D,[],5));
        
        
    %     vol_layer_at_horiz_cell = repmat(tarea,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array + SSH_depth_integrating_array,3));
        vol_layer_at_horiz_cell_midpts = repmat(tarea,[1 1 (length(unique_times) - 1)]).*squeeze(sum(min_dzt_depth_integrating_array_with_SSH_midpts,3));
        
        
        
        % approximate the temperature change due specifically to entrainment (from top and bottom bounds combined), based on (dh/dt)*T_midpt
        
        % estimate of entrainment contribution from top bound
        
        T_integrated_inlayer_midpts = repmat(tarea,[1 1 (length(unique_times) - 1)]).*squeeze(sum(min_dzt_depth_integrating_array_with_SSH_midpts.*temp_time_midpt_no_nans,3));
        
        T_time_midpt_vert_mean_inlayer = T_integrated_inlayer_midpts./vol_layer_at_horiz_cell_midpts;
        
        diff_t_min_dzt_depth_integrating_only_top_change = diff_t_min_dzt_depth_integrating_top_only;
        diff_t_min_dzt_depth_integrating_only_top_change(ent_T_dh_top_time_midpt == 0) = 0;
        
        ent_T_minus_Tmean_dh_top_time_midpt = ent_T_dh_top_time_midpt - (diff_t_min_dzt_depth_integrating_only_top_change.*repmat(reshape(T_time_midpt_vert_mean_inlayer,[size_array(1:2) 1 size(T_time_midpt_vert_mean_inlayer,3)]),[1 1 size(temp_time_midpt,3) 1]));
        
        
        % estimate of entrainment contribution from bottom bound
        
        diff_t_min_dzt_depth_integrating_bottom_only = diff(min_dzt_depth_integrating_array + SSH_depth_integrating_array,1,4) - diff_t_min_dzt_depth_integrating_top_only;
        
        ent_vol_flux_bottom_time_midpt = repmat(tarea,[1 1 (length(unique_times) - 1)]).*squeeze(sum(-diff_t_min_dzt_depth_integrating_bottom_only,3))./(86400*repmat(reshape(diff(unique_times),[1 1 (size_array(4) - 1)]),[size_array(1:2) 1]));
        
        ent_T_dh_bottom_time_midpt = diff_t_min_dzt_depth_integrating_bottom_only.*temp_time_midpt;
        
        
        diff_t_min_dzt_depth_integrating_only_bottom_change = diff_t_min_dzt_depth_integrating_bottom_only;
        diff_t_min_dzt_depth_integrating_only_bottom_change(ent_T_dh_bottom_time_midpt == 0) = 0;
        
        ent_T_minus_Tmean_dh_bottom_time_midpt = ent_T_dh_bottom_time_midpt - (diff_t_min_dzt_depth_integrating_only_bottom_change.*repmat(reshape(T_time_midpt_vert_mean_inlayer,[size_array(1:2) 1 size(T_time_midpt_vert_mean_inlayer,3)]),[1 1 size(temp_time_midpt,3) 1]));
        
        
        
        % separate out entrainment volume fluxes and temperature tendencies from top and bottom surfaces
        
        ent_T_minus_Tmean_dh_top_time_midpt_integrated = repmat(tarea,[1 1 (length(unique_times) - 1)]).*squeeze(sum(ent_T_minus_Tmean_dh_top_time_midpt,3));
        ent_T_minus_Tmean_dh_bottom_time_midpt_integrated = repmat(tarea,[1 1 (length(unique_times) - 1)]).*squeeze(sum(ent_T_minus_Tmean_dh_bottom_time_midpt,3));
        
        
        % interpolate estimated entrainment fluxes at top and bottom, to the same time points as the other budget terms
        
        ent_vol_flux_top = NaN(size_array([1 2 4]));
        ent_vol_flux_top(:,:,1) = 0.5*ent_vol_flux_top_time_midpt(:,:,1);
        ent_vol_flux_top(:,:,2:(size(ent_vol_flux_top,3) - 1)) = ((repmat(reshape(diff(unique_times(2:length(unique_times))),[1 1 (length(unique_times) - 2)]),[size_array(1:2) 1]).*ent_vol_flux_top_time_midpt(:,:,2:size(ent_vol_flux_top_time_midpt,3))) - (diff(repmat(reshape(diff(unique_times),[1 1 (length(unique_times) - 1)]),[size_array(1:2) 1]).*ent_vol_flux_top_time_midpt,1,3)/2))./repmat(reshape(diff(time_midpts),[1 1 (length(time_midpts) - 1)]),[size_array(1:2) 1]);
        ent_vol_flux_top(:,:,size(ent_vol_flux_top,3)) = 0.5*ent_vol_flux_top_time_midpt(:,:,size(ent_vol_flux_top_time_midpt,3));
        ent_vol_flux_bottom = NaN(size_array([1 2 4]));
        ent_vol_flux_bottom(:,:,1) = 0.5*ent_vol_flux_bottom_time_midpt(:,:,1);
        ent_vol_flux_bottom(:,:,2:(size(ent_vol_flux_bottom,3) - 1)) = ((repmat(reshape(diff(unique_times(2:length(unique_times))),[1 1 (length(unique_times) - 2)]),[size_array(1:2) 1]).*ent_vol_flux_bottom_time_midpt(:,:,2:size(ent_vol_flux_bottom_time_midpt,3))) - (diff(repmat(reshape(diff(unique_times),[1 1 (length(unique_times) - 1)]),[size_array(1:2) 1]).*ent_vol_flux_bottom_time_midpt,1,3)/2))./repmat(reshape(diff(time_midpts),[1 1 (length(time_midpts) - 1)]),[size_array(1:2) 1]);
        ent_vol_flux_bottom(:,:,size(ent_vol_flux_bottom,3)) = 0.5*ent_vol_flux_bottom_time_midpt(:,:,size(ent_vol_flux_bottom_time_midpt,3));
        
        ent_T_minus_Tmean_dh_top_integrated = NaN(size_array([1 2 4]));
        ent_T_minus_Tmean_dh_top_integrated(:,:,1) = 0.5*ent_T_minus_Tmean_dh_top_time_midpt_integrated(:,:,1);
        ent_T_minus_Tmean_dh_top_integrated(:,:,2:(size(ent_T_minus_Tmean_dh_top_integrated,3) - 1)) = ((repmat(reshape(diff(unique_times(2:length(unique_times))),[1 1 (length(unique_times) - 2)]),[size_array(1:2) 1]).*ent_T_minus_Tmean_dh_top_time_midpt_integrated(:,:,2:size(ent_T_minus_Tmean_dh_top_time_midpt_integrated,3))) - (diff(repmat(reshape(diff(unique_times),[1 1 (length(unique_times) - 1)]),[size_array(1:2) 1]).*ent_T_minus_Tmean_dh_top_time_midpt_integrated,1,3)/2))./repmat(reshape(diff(time_midpts),[1 1 (length(time_midpts) - 1)]),[size_array(1:2) 1]);
        ent_T_minus_Tmean_dh_top_integrated(:,:,size(ent_T_minus_Tmean_dh_top_integrated,3)) = 0.5*ent_T_minus_Tmean_dh_top_time_midpt_integrated(:,:,size(ent_T_minus_Tmean_dh_top_time_midpt_integrated,3));
        ent_T_minus_Tmean_dh_bottom_integrated = NaN(size_array([1 2 4]));
        ent_T_minus_Tmean_dh_bottom_integrated(:,:,1) = 0.5*ent_T_minus_Tmean_dh_bottom_time_midpt_integrated(:,:,1);
        ent_T_minus_Tmean_dh_bottom_integrated(:,:,2:(size(ent_T_minus_Tmean_dh_bottom_integrated,3) - 1)) = ((repmat(reshape(diff(unique_times(2:length(unique_times))),[1 1 (length(unique_times) - 2)]),[size_array(1:2) 1]).*ent_T_minus_Tmean_dh_bottom_time_midpt_integrated(:,:,2:size(ent_T_minus_Tmean_dh_bottom_time_midpt_integrated,3))) - (diff(repmat(reshape(diff(unique_times),[1 1 (length(unique_times) - 1)]),[size_array(1:2) 1]).*ent_T_minus_Tmean_dh_bottom_time_midpt_integrated,1,3)/2))./repmat(reshape(diff(time_midpts),[1 1 (length(time_midpts) - 1)]),[size_array(1:2) 1]);
        ent_T_minus_Tmean_dh_bottom_integrated(:,:,size(ent_T_minus_Tmean_dh_bottom_integrated,3)) = 0.5*ent_T_minus_Tmean_dh_bottom_time_midpt_integrated(:,:,size(ent_T_minus_Tmean_dh_bottom_time_midpt_integrated,3));
        
        
        % implement scheme for separating top and bottom entrainment tendencies
        ent_T_tend_top = sfc_ent_T_tend_adj + ((ent_T_minus_Tmean_dh_top_integrated./(ent_T_minus_Tmean_dh_top_integrated + ent_T_minus_Tmean_dh_bottom_integrated)).*ent_T_tend_total);
        ent_T_tend_bottom = ent_T_tend_total - ent_T_tend_top;
        
        
        % use different separation for times when the total entrainment tendency is very small
        too_small_total_ind = find((isnan(ent_T_tend_total) == 1) | (abs(ent_T_tend_total) < (1e-8)) | ((abs(ent_T_tend_total))./(abs(ent_T_tend_top) + abs(ent_T_tend_bottom)) < 0.01));
        
        ent_T_minus_Tmean_tend_top_integrated = ent_T_minus_Tmean_dh_top_integrated./(86400*repmat(reshape([diff(time_midpts(1:2)); diff(time_midpts); diff(time_midpts((length(time_midpts) - 1):length(time_midpts)))],[1 1 size_array(4)]),[size_array(1:2) 1]));
        ent_T_tend_top(too_small_total_ind) = ent_T_minus_Tmean_tend_top_integrated(too_small_total_ind)./vol_layer_at_horiz_cell(too_small_total_ind);
        ent_T_tend_bottom(too_small_total_ind) = ent_T_tend_total(too_small_total_ind) - ent_T_tend_top(too_small_total_ind);
        
        
        
        % adjust variable depth-related tendencies computed earlier
        
        var_depth_T_tend_top = var_depth_T_tend_top - sfc_ent_T_tend_adj + ent_T_tend_top;
        var_depth_T_tend_bottom = var_depth_T_tend_bottom + ent_T_tend_bottom;
        
        
    end
    
    
    
    % adjust archived temperature tendency for entrainment
    
    if tend_temp_present == 1
%         total_T_tend = repmat(tarea,[1 1 length(unique_times)]).*squeeze(sum(min_dzt_depth_integrating_array.*tot_temp_tend,3))./vol_layer_at_horiz_cell;
        
        % add entrainment terms
        total_T_tend = total_T_tend + ent_T_tend_total;
        
%         % adjustment of temp. tendency to account for variable-thickness surface layer
%         total_T_tend = total_T_tend - sfc_total_T_tend_adj;
    end
    
else
    
    erroneous_spatial_ind = find(sum(erroneous_array_mask(:,:,time_avg_from_unique_reg_ind),3) >= (0.1*length(time_avg_from_unique_reg_ind)));
    
    good_spatial_ind = find(sum(erroneous_array_mask,3) < (0.1*size_array(4)));
    
    erroneous_nan_mask_2D = NaN(size_array(1:2));
    erroneous_nan_mask_2D(good_spatial_ind) = 0;
    erroneous_nan_mask_3D = repmat(erroneous_nan_mask_2D,[1 1 size_array(4)]);
    good_spatial_ind_with_timedim = find(isnan(erroneous_nan_mask_3D) == 0);
    
end


clear diff_t* ent_T_dh* ent_T_minus* kpp_src_temp depth_integrating_array min_dz_* min_dz* min_ht_bottom* not*facing_ind tot_temp_tend temp_time* top_at_sfc* vol_layer*



% output names


T_tend_overall_term_names = {'adv_T_tend_total' 'hdiff_T_tend_total' 'ent_T_tend_total' 'diab_vert_T_tend' 'kpp_src_T_tend' 'sfc_sw_flux_T_tend'};

T_tend_detailed_term_names = {'adv_T_tend_E' 'adv_T_tend_W' 'adv_T_tend_zonal' 'adv_T_tend_N' 'adv_T_tend_S' 'adv_T_tend_merid' 'adv_T_tend_top' 'adv_T_tend_bottom' 'var_depth_adv_T_tend_top' 'var_depth_adv_T_tend_bottom' 'hdiff_T_tend_E' 'hdiff_T_tend_W' 'hdiff_T_tend_N' 'hdiff_T_tend_S' 'hdiff_T_tend_top' 'hdiff_T_tend_bottom' 'var_depth_hdiff_T_tend_top' 'var_depth_hdiff_T_tend_bottom' 'ent_T_tend_top' 'ent_T_tend_bottom' 'sfc_ent_T_tend_adj' 'diab_vert_T_tend_top' 'diab_vert_T_tend_bottom' 'kpp_src_T_tend' 'sw_top_flux_T_tend' 'sw_bottom_flux_T_tend' 'longwave_downward_flux_T_tend' 'longwave_upward_flux_T_tend' 'latent_heat_flux_T_tend' 'sensible_heat_flux_T_tend'};

vardepth_breakdown_term_names = {'adv_T_tend_E_sloping_top' 'adv_T_tend_W_sloping_top' 'adv_T_tend_N_sloping_top' 'adv_T_tend_S_sloping_top' 'hdiff_T_tend_E_sloping_top' 'hdiff_T_tend_W_sloping_top' 'hdiff_T_tend_N_sloping_top' 'hdiff_T_tend_S_sloping_top' 'ent_T_tend_top' 'adv_T_tend_E_sloping_bottom' 'adv_T_tend_W_sloping_bottom' 'adv_T_tend_N_sloping_bottom' 'adv_T_tend_S_sloping_bottom' 'hdiff_T_tend_E_sloping_bottom' 'hdiff_T_tend_W_sloping_bottom' 'hdiff_T_tend_N_sloping_bottom' 'hdiff_T_tend_S_sloping_bottom' 'ent_T_tend_bottom'};

adv_T_tend_vel_temp_reg_term_names = {'adv_T_tend_uvel_reg_T_reg_all','adv_T_tend_uvel_reg_T_noreg_all','adv_T_tend_uvel_noreg_T_reg_all','adv_T_tend_uvel_noreg_T_noreg_all','adv_T_tend_vvel_reg_T_reg_all','adv_T_tend_vvel_reg_T_noreg_all','adv_T_tend_vvel_noreg_T_reg_all','adv_T_tend_vvel_noreg_T_noreg_all','adv_T_tend_wvel_reg_T_reg_all','adv_T_tend_wvel_reg_T_noreg_all','adv_T_tend_wvel_noreg_T_reg_all','adv_T_tend_wvel_noreg_T_noreg_all'};

vol_flux_term_names = {'adv_vol_flux_E' 'adv_vol_flux_W' 'adv_vol_flux_N' 'adv_vol_flux_S' 'adv_vol_flux_top' 'adv_vol_flux_bottom' 'adv_vol_flux_E_sloping_top' 'adv_vol_flux_W_sloping_top' 'adv_vol_flux_N_sloping_top' 'adv_vol_flux_S_sloping_top' 'adv_vol_flux_E_sloping_bottom' 'adv_vol_flux_W_sloping_bottom' 'adv_vol_flux_N_sloping_bottom' 'adv_vol_flux_S_sloping_bottom' 'ent_vol_flux_top' 'ent_vol_flux_bottom'};


if tend_temp_present == 1
    T_tend_overall_term_names = {T_tend_overall_term_names{:} 'total_T_tend'};
    T_tend_detailed_term_names = {T_tend_detailed_term_names{:} 'total_T_tend'};
end



% compute regressions for tendency terms

for num_term = 1:length(T_tend_overall_term_names)
    curr_term_name = T_tend_overall_term_names{num_term};
    curr_term_array = eval(curr_term_name);
    
    curr_term_reg = zeros(size_array([1 2 4]));
    eval([curr_term_name,'_reg = NaN(size_array([1 2 4]));'])
    for i_r = 1:n_subsets_regression(1)
        for j_r = 1:n_subsets_regression(2)
            
            curr_weighting_array = weighting_array_regression(:,:,i_r,j_r);
            
            if size(reg_operator_T_array,4) > 1
                curr_G_reg = squeeze(G_reg_array(i_r,j_r,:,:));
                curr_reg_operator_T = squeeze(reg_operator_T_array(i_r,j_r,:,:));
            else
                curr_G_reg = squeeze(G_reg_array(i_r,j_r,:));
                curr_reg_operator_T = squeeze(reg_operator_T_array(i_r,j_r,:));
            end
            
            m_reg_curr_term_array = reshape(curr_term_array,[prod(size_array(1:2)) size_array(4)])*curr_reg_operator_T;
            curr_term_reg = curr_term_reg + (repmat(curr_weighting_array,[1 1 size_array(4)]).*reshape(m_reg_curr_term_array*(curr_G_reg'),size_array([1 2 4])));
        end
    end
    eval([curr_term_name,'_reg(good_spatial_ind_with_timedim) = curr_term_reg(good_spatial_ind_with_timedim);'])
    eval([curr_term_name,'_noreg = curr_term_array - ',curr_term_name,'_reg;'])
end

for num_term = 1:length(T_tend_detailed_term_names)
    curr_term_name = T_tend_detailed_term_names{num_term};
    curr_term_array = eval(curr_term_name);
    
    curr_term_reg = zeros(size_array([1 2 4]));
    eval([curr_term_name,'_reg = NaN(size_array([1 2 4]));'])
    for i_r = 1:n_subsets_regression(1)
        for j_r = 1:n_subsets_regression(2)
            
            curr_weighting_array = weighting_array_regression(:,:,i_r,j_r);
            
            if size(reg_operator_T_array,4) > 1
                curr_G_reg = squeeze(G_reg_array(i_r,j_r,:,:));
                curr_reg_operator_T = squeeze(reg_operator_T_array(i_r,j_r,:,:));
            else
                curr_G_reg = squeeze(G_reg_array(i_r,j_r,:));
                curr_reg_operator_T = squeeze(reg_operator_T_array(i_r,j_r,:));
            end
            
            m_reg_curr_term_array = reshape(curr_term_array,[prod(size_array(1:2)) size_array(4)])*curr_reg_operator_T;
            curr_term_reg = curr_term_reg + (repmat(curr_weighting_array,[1 1 size_array(4)]).*reshape(m_reg_curr_term_array*(curr_G_reg'),size_array([1 2 4])));
        end
    end
    eval([curr_term_name,'_reg(good_spatial_ind_with_timedim) = curr_term_reg(good_spatial_ind_with_timedim);'])
    eval([curr_term_name,'_noreg = curr_term_array - ',curr_term_name,'_reg;'])
end

for num_term = 1:length(vardepth_breakdown_term_names)
    curr_term_name = vardepth_breakdown_term_names{num_term};
    curr_term_array = eval(curr_term_name);
    
    curr_term_reg = zeros(size_array([1 2 4]));
    eval([curr_term_name,'_reg = NaN(size_array([1 2 4]));'])
    for i_r = 1:n_subsets_regression(1)
        for j_r = 1:n_subsets_regression(2)
            
            curr_weighting_array = weighting_array_regression(:,:,i_r,j_r);
            
            if size(reg_operator_T_array,4) > 1
                curr_G_reg = squeeze(G_reg_array(i_r,j_r,:,:));
                curr_reg_operator_T = squeeze(reg_operator_T_array(i_r,j_r,:,:));
            else
                curr_G_reg = squeeze(G_reg_array(i_r,j_r,:));
                curr_reg_operator_T = squeeze(reg_operator_T_array(i_r,j_r,:));
            end
            
            m_reg_curr_term_array = reshape(curr_term_array,[prod(size_array(1:2)) size_array(4)])*curr_reg_operator_T;
            curr_term_reg = curr_term_reg + (repmat(curr_weighting_array,[1 1 size_array(4)]).*reshape(m_reg_curr_term_array*(curr_G_reg'),size_array([1 2 4])));
        end
    end
    eval([curr_term_name,'_reg(good_spatial_ind_with_timedim) = curr_term_reg(good_spatial_ind_with_timedim);'])
    eval([curr_term_name,'_noreg = curr_term_array - ',curr_term_name,'_reg;'])
end

for num_term = 1:length(vol_flux_term_names)
    curr_term_name = vol_flux_term_names{num_term};
    curr_term_array = eval(curr_term_name);
    
    curr_term_reg = zeros(size_array([1 2 4]));
    eval([curr_term_name,'_reg = NaN(size_array([1 2 4]));'])
    for i_r = 1:n_subsets_regression(1)
        for j_r = 1:n_subsets_regression(2)
            
            curr_weighting_array = weighting_array_regression(:,:,i_r,j_r);
            
            if size(reg_operator_T_array,4) > 1
                curr_G_reg = squeeze(G_reg_array(i_r,j_r,:,:));
                curr_reg_operator_T = squeeze(reg_operator_T_array(i_r,j_r,:,:));
            else
                curr_G_reg = squeeze(G_reg_array(i_r,j_r,:));
                curr_reg_operator_T = squeeze(reg_operator_T_array(i_r,j_r,:));
            end
            
            m_reg_curr_term_array = reshape(curr_term_array,[prod(size_array(1:2)) size_array(4)])*curr_reg_operator_T;
            curr_term_reg = curr_term_reg + (repmat(curr_weighting_array,[1 1 size_array(4)]).*reshape(m_reg_curr_term_array*(curr_G_reg'),size_array([1 2 4])));
        end
    end
    eval([curr_term_name,'_reg(good_spatial_ind_with_timedim) = curr_term_reg(good_spatial_ind_with_timedim);'])
    eval([curr_term_name,'_noreg = curr_term_array - ',curr_term_name,'_reg;'])
end



% compute regressions for vertically-averaged u, v, T, and w at base of layer (approx. proportional to vertical average of dw/dz)

wvel_bottom = adv_vol_flux_bottom./repmat(tarea,[1 1 size_array(4)]);

vert_mean_term_names = {'uvel_vert_mean_inlayer' 'vvel_vert_mean_inlayer' 'wvel_bottom' 'T_vert_mean_inlayer'};

for num_term = 1:length(vert_mean_term_names)
    curr_term_name = vert_mean_term_names{num_term};
    curr_term_array = eval(curr_term_name);
    
    curr_term_reg = zeros(size_array([1 2 4]));
    eval([curr_term_name,'_reg = NaN(size_array([1 2 4]));'])
    for i_r = 1:n_subsets_regression(1)
        for j_r = 1:n_subsets_regression(2)
            
            curr_weighting_array = weighting_array_regression(:,:,i_r,j_r);
            
            if size(reg_operator_T_array,4) > 1
                curr_G_reg = squeeze(G_reg_array(i_r,j_r,:,:));
                curr_reg_operator_T = squeeze(reg_operator_T_array(i_r,j_r,:,:));
            else
                curr_G_reg = squeeze(G_reg_array(i_r,j_r,:));
                curr_reg_operator_T = squeeze(reg_operator_T_array(i_r,j_r,:));
            end
            
            m_reg_curr_term_array = reshape(curr_term_array,[prod(size_array(1:2)) size_array(4)])*curr_reg_operator_T;
            curr_term_reg = curr_term_reg + (repmat(curr_weighting_array,[1 1 size_array(4)]).*reshape(m_reg_curr_term_array*(curr_G_reg'),size_array([1 2 4])));
        end
    end
%     eval([curr_term_name,'_reg(good_spatial_ind_with_timedim) = curr_term_reg(good_spatial_ind_with_timedim);'])
    eval([curr_term_name,'_reg = curr_term_reg;'])
    eval([curr_term_name,'_noreg = curr_term_array - ',curr_term_name,'_reg;'])
end

clear curr*





T_tend_overall_terms_avg = cell(length(T_tend_overall_term_names),1);
T_tend_overall_terms_reg_avg = cell(length(T_tend_overall_term_names),1);
T_tend_overall_terms_noreg_avg = cell(length(T_tend_overall_term_names),1);
for num_term = 1:length(T_tend_overall_term_names)
    curr_term_name = T_tend_overall_term_names{num_term};
    curr_term_array = eval(curr_term_name);
    
%     m_reg_curr_term_array = reshape(curr_term_array,[prod(size_array(1:2)) size_array(4)])*reg_operator_T;
%     curr_term_array_reg = reshape(m_reg_curr_term_array*(G_reg'),size_array([1 2 4]));
%     curr_term_array_noreg = curr_term_array - curr_term_array_reg;
    curr_term_array_reg = eval([curr_term_name,'_reg']);
    curr_term_array_noreg = eval([curr_term_name,'_noreg']);
    
%     disp([size(curr_term_array) min(erroneous_ind) max(erroneous_ind)])
    
    
    % mask out erroneous points
    
%     curr_term_array(erroneous_ind) = NaN;
%     curr_term_array_reg(erroneous_ind) = NaN;
%     curr_term_array_noreg(erroneous_ind) = NaN;
    curr_term_array(erroneous_spatial_ind) = NaN;
    curr_term_array_reg(erroneous_spatial_ind) = NaN;
    curr_term_array_noreg(erroneous_spatial_ind) = NaN;
    
    
    
    T_tend_overall_terms_avg{num_term} = mean(curr_term_array(:,:,time_avg_from_unique_reg_ind),3);
    T_tend_overall_terms_reg_avg{num_term} = mean(curr_term_array_reg(:,:,time_avg_from_unique_reg_ind),3);
    T_tend_overall_terms_noreg_avg{num_term} = mean(curr_term_array_noreg(:,:,time_avg_from_unique_reg_ind),3);
    
end


T_tend_detailed_terms_avg = cell(length(T_tend_detailed_term_names),1);
T_tend_detailed_terms_reg_avg = cell(length(T_tend_detailed_term_names),1);
T_tend_detailed_terms_noreg_avg = cell(length(T_tend_detailed_term_names),1);
for num_term = 1:length(T_tend_detailed_term_names)
    curr_term_name = T_tend_detailed_term_names{num_term};
    curr_term_array = eval(curr_term_name);
    
    curr_term_array_reg = eval([curr_term_name,'_reg']);
    curr_term_array_noreg = eval([curr_term_name,'_noreg']);
    
    
    % mask out erroneous points
    curr_term_array(erroneous_spatial_ind) = NaN;
    curr_term_array_reg(erroneous_spatial_ind) = NaN;
    curr_term_array_noreg(erroneous_spatial_ind) = NaN;
    
    
    T_tend_detailed_terms_avg{num_term} = mean(curr_term_array(:,:,time_avg_from_unique_reg_ind),3);
    T_tend_detailed_terms_reg_avg{num_term} = mean(curr_term_array_reg(:,:,time_avg_from_unique_reg_ind),3);
    T_tend_detailed_terms_noreg_avg{num_term} = mean(curr_term_array_noreg(:,:,time_avg_from_unique_reg_ind),3);
    
end


vardepth_breakdown_terms_avg = cell(length(vardepth_breakdown_term_names),1);
vardepth_breakdown_terms_reg_avg = cell(length(vardepth_breakdown_term_names),1);
vardepth_breakdown_terms_noreg_avg = cell(length(vardepth_breakdown_term_names),1);
for num_term = 1:length(vardepth_breakdown_term_names)
    curr_term_name = vardepth_breakdown_term_names{num_term};
    curr_term_array = eval(curr_term_name);
    
    curr_term_array_reg = eval([curr_term_name,'_reg']);
    curr_term_array_noreg = eval([curr_term_name,'_noreg']);
    
    
    % mask out erroneous points
    curr_term_array(erroneous_spatial_ind) = NaN;
    curr_term_array_reg(erroneous_spatial_ind) = NaN;
    curr_term_array_noreg(erroneous_spatial_ind) = NaN;
    
    
    vardepth_breakdown_terms_avg{num_term} = mean(curr_term_array(:,:,time_avg_from_unique_reg_ind),3);
    vardepth_breakdown_terms_reg_avg{num_term} = mean(curr_term_array_reg(:,:,time_avg_from_unique_reg_ind),3);
    vardepth_breakdown_terms_noreg_avg{num_term} = mean(curr_term_array_noreg(:,:,time_avg_from_unique_reg_ind),3);
    
end


adv_T_tend_vel_temp_reg_terms_avg = cell(length(adv_T_tend_vel_temp_reg_term_names),1);
for num_term = 1:length(adv_T_tend_vel_temp_reg_term_names)
    curr_term_name = adv_T_tend_vel_temp_reg_term_names{num_term};
    curr_term_array = eval(curr_term_name);
    
    
    % mask out erroneous points
    curr_term_array(erroneous_spatial_ind) = NaN;
    
    % remove seasonal means of these terms
    season_unique_times = mod(unique_times,365);
    season_times_to_avg = unique(season_unique_times);
    for season_time_ind = 1:length(season_times_to_avg)
        curr_season_time = season_times_to_avg(season_time_ind);
        at_curr_season_time_ind = find(abs(season_unique_times - curr_season_time) < 0.5);
        
        curr_term_array(:,:,at_curr_season_time_ind) = curr_term_array(:,:,at_curr_season_time_ind) - repmat(mean(curr_term_array(:,:,at_curr_season_time_ind),3),[1 1 length(at_curr_season_time_ind)]);
    end
    
    adv_T_tend_vel_temp_reg_terms_avg{num_term} = mean(curr_term_array(:,:,time_avg_from_unique_reg_ind),3);
    
%     try
%         eval(['save(''adv_vel_T_tend_arrays.mat'',''',curr_term_name,''',''-append'',''-v7.3'')'])
%     catch
%         eval(['save(''adv_vel_T_tend_arrays.mat'',''',curr_term_name,''',''-v7.3'')'])
%     end
    
end


% save('adv_vel_T_tend_arrays.mat','adv_T_tend_vel_temp_reg_terms_avg','-append','-v7.3')



vol_flux_terms_avg = cell(length(vol_flux_term_names),1);
vol_flux_terms_reg_avg = cell(length(vol_flux_term_names),1);
vol_flux_terms_noreg_avg = cell(length(vol_flux_term_names),1);
for num_term = 1:length(vol_flux_term_names)
    curr_term_name = vol_flux_term_names{num_term};
    curr_term_array = eval(curr_term_name);
    
    curr_term_array_reg = eval([curr_term_name,'_reg']);
    curr_term_array_noreg = eval([curr_term_name,'_noreg']);
    
    
    % mask out erroneous points
    curr_term_array(erroneous_spatial_ind) = NaN;
    curr_term_array_reg(erroneous_spatial_ind) = NaN;
    curr_term_array_noreg(erroneous_spatial_ind) = NaN;
    
    
    vol_flux_terms_avg{num_term} = mean(curr_term_array(:,:,time_avg_from_unique_reg_ind),3);
    vol_flux_terms_reg_avg{num_term} = mean(curr_term_array_reg(:,:,time_avg_from_unique_reg_ind),3);
    vol_flux_terms_noreg_avg{num_term} = mean(curr_term_array_noreg(:,:,time_avg_from_unique_reg_ind),3);
    
end


vol_flux_terms_avg = cell(length(vol_flux_term_names),1);
vol_flux_terms_reg_avg = cell(length(vol_flux_term_names),1);
vol_flux_terms_noreg_avg = cell(length(vol_flux_term_names),1);
for num_term = 1:length(vol_flux_term_names)
    curr_term_name = vol_flux_term_names{num_term};
    curr_term_array = eval(curr_term_name);
    
    curr_term_array_reg = eval([curr_term_name,'_reg']);
    curr_term_array_noreg = eval([curr_term_name,'_noreg']);
    
    
    % mask out erroneous points
    curr_term_array(erroneous_spatial_ind) = NaN;
    curr_term_array_reg(erroneous_spatial_ind) = NaN;
    curr_term_array_noreg(erroneous_spatial_ind) = NaN;
    
    
    vol_flux_terms_avg{num_term} = mean(curr_term_array(:,:,time_avg_from_unique_reg_ind),3);
    vol_flux_terms_reg_avg{num_term} = mean(curr_term_array_reg(:,:,time_avg_from_unique_reg_ind),3);
    vol_flux_terms_noreg_avg{num_term} = mean(curr_term_array_noreg(:,:,time_avg_from_unique_reg_ind),3);
    
end


vert_mean_terms_avg = cell(length(vert_mean_term_names),1);
vert_mean_terms_reg_avg = cell(length(vert_mean_term_names),1);
vert_mean_terms_noreg_avg = cell(length(vert_mean_term_names),1);
for num_term = 1:length(vert_mean_term_names)
    curr_term_name = vert_mean_term_names{num_term};
    curr_term_array = eval(curr_term_name);
    
    curr_term_array_reg = eval([curr_term_name,'_reg']);
    curr_term_array_noreg = eval([curr_term_name,'_noreg']);
    
    
%     % mask out erroneous points
%     curr_term_array(erroneous_ind) = NaN;
%     curr_term_array_reg(erroneous_ind) = NaN;
%     curr_term_array_noreg(erroneous_ind) = NaN;
    
    
    vert_mean_terms_avg{num_term} = mean(curr_term_array(:,:,time_avg_from_unique_reg_ind),3);
    vert_mean_terms_reg_avg{num_term} = mean(curr_term_array_reg(:,:,time_avg_from_unique_reg_ind),3);
    vert_mean_terms_noreg_avg{num_term} = mean(curr_term_array_noreg(:,:,time_avg_from_unique_reg_ind),3);
    
end



if reg_level_option == 1
    % save output .mat file
    save([file_name_base_output,'_',num2str(i_f),'_',num2str(j_f),'.mat'],'-v7.3')
end
