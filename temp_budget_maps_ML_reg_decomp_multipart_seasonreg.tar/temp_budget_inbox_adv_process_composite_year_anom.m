% compute composite anomalies of temperature budget terms, from .mat file


path(path,'~/Budget_calculations/')
path(path,'~/plotting_scripts/')
cd('/glade/scratch/adelman/POP_1977_start_JC/')


% % load('Java_budget_1979_2009_seasonal_decomp.mat')
% % load('temp_budget_Java_map_Kelvin_diff_20_lp_1979_to_2009_ML_seasonreg.mat')
% load('temp_budget_Java_map_Kelvin_diff_85_95_1979_to_2009_ML_seasonreg.mat')
% % load('temp_budget_Java_map_Kelvin_diff_85_95_rem_reg_wstr_SE_cent_Sumatra_1979_to_2009_ML_seasonreg.mat')
% time_inrange = unique_times;
% % load('temp_budget_Java_wstr_local_1979_to_2009_ML_seasonreg.mat')
% % load('temp_budget_Java_mesoscale_vvel_1979_to_2009_ML_seasonreg.mat')
% % load('temp_budget_Java_Lombok_vvel_10lead_1979_to_2009_ML_seasonreg.mat')
% % load('temp_budget_Java_wstr_local_allderivs_1979_to_2009_ML_seasonreg.mat')
% % load('temp_budget_Java_mesoscale_vvel_withderiv_20_lp_1979_to_2009_ML_seasonreg.mat')
% % load('temp_budget_Java_Lombok_vvel_10lead_rem_reg_Kelvin_wstr_Sumatra_Java_20_lp_1979_to_2009_ML_seasonreg.mat')
% % load('temp_budget_Java_wstr_Sumatra_allderivs_10lead_rem_reg_wstr_local_20_lp_1979_to_2009_ML_seasonreg.mat')
% % load('temp_budget_Java_map_wstr_SE_Sumatra_allderivs_5lead_rem_reg_Kelvin_wstr_cent_Sumatra_1979_to_2009_ML_seasonreg.mat')
% load('temp_budget_Java_map_wstr_SE_Sumatra_allderivs_5lead_1979_to_2009_ML_seasonreg.mat')
% % load('temp_budget_Java_map_wstr_Sumatra_allderivs_10lead_rem_reg_Kelvin_1979_to_2009_ML_seasonreg.mat')
% % load('temp_budget_Java_map_wstr_local_allderivs_rem_reg_Kelvin_wstr_cent_SE_Sumatra_1979_to_2009_ML_seasonreg.mat')
% load('temp_budget_Java_map_wstr_local_allderivs_1979_to_2009_ML_seasonreg.mat')
% % load('temp_budget_Java_map_Lombok_vvel_5lead_rem_reg_Kelvin_wstr_cent_SE_Sumatra_local_1979_to_2009_ML_seasonreg.mat')
% load('temp_budget_Java_map_Lombok_vvel_5lead_1979_to_2009_ML_seasonreg.mat')
% load('temp_budget_Java_map_mesoscale_vvel_withderiv_1979_to_2009_ML_seasonreg.mat')
% % load('temp_budget_Java_map_wstr_cent_Sumatra_allderivs_10lead_rem_reg_Kelvin_1979_to_2009_ML_seasonreg.mat')
% load('temp_budget_Java_map_wstr_cent_Sumatra_allderivs_10lead_1979_to_2009_ML_seasonreg.mat')
% % load('temp_budget_Java_map_wstr_cent_Sumatra_allderivs_10lead_rem_reg_wstr_SE_Sumatra_1979_to_2009_ML_seasonreg.mat')
% 
% 
% 
% % years to use to construct composite
% 
% % year_nums_to_composite = [6; 7; 11; 18; 21; 27; 30; 31; 32];
% year_nums_to_composite = [6; 7; 18; 21; 27; 30; 31; 32];
% % year_nums_to_composite = [6; 7; 18; 21; 27; 30; 31];
% 
% % years to use as samples in bootstrap calculations
% 
% year_nums_for_bootstrap = (3:1:33)';
% % year_nums_for_bootstrap = [(3:1:19)'; (21:1:33)'];
% 
% tavg_days = 5;
% t_plot_smooth_days = 30;
% 
% process_var_names = {'Kelvin'; 'wstr_local'; 'mesoscale'; 'Lombok'; 'wstr_cent_Sumatra'; 'wstr_SE_Sumatra'};
% 
% 
% 
% % remove any remaining seasonal cycle
% 
% for process_ind = 1:length(process_var_names)
%     curr_process_var_name = process_var_names{process_ind};
%     
%     G_seasonal = [ones(length(unique_times),1) cos((2*pi/365)*unique_times) sin((2*pi/365)*unique_times) cos((2*pi/(365/2))*unique_times) sin((2*pi/(365/2))*unique_times) cos((2*pi/(365/3))*unique_times) sin((2*pi/(365/3))*unique_times) cos((2*pi/(365/4))*unique_times) sin((2*pi/(365/4))*unique_times)];
%     
%     seasonal_reg_operator_T = ((((G_seasonal')*G_seasonal)^(-1))*(G_seasonal'))';
%     
%     eval(['T_tend_adv_along_E_edge_',curr_process_var_name,' = T_tend_adv_along_E_edge_',curr_process_var_name,' - (G_seasonal*((permute(seasonal_reg_operator_T,[2 1]))*T_tend_adv_along_E_edge_',curr_process_var_name,'));'])
%     eval(['T_tend_adv_along_W_edge_',curr_process_var_name,' = T_tend_adv_along_W_edge_',curr_process_var_name,' - (G_seasonal*((permute(seasonal_reg_operator_T,[2 1]))*T_tend_adv_along_W_edge_',curr_process_var_name,'));'])
%     eval(['T_tend_adv_along_N_edge_',curr_process_var_name,' = T_tend_adv_along_N_edge_',curr_process_var_name,' - (G_seasonal*((permute(seasonal_reg_operator_T,[2 1]))*T_tend_adv_along_N_edge_',curr_process_var_name,'));'])
%     eval(['T_tend_adv_along_S_edge_',curr_process_var_name,' = T_tend_adv_along_S_edge_',curr_process_var_name,' - (G_seasonal*((permute(seasonal_reg_operator_T,[2 1]))*T_tend_adv_along_S_edge_',curr_process_var_name,'));'])
%     eval(['T_tend_adv_along_top_edge_',curr_process_var_name,' = T_tend_adv_along_top_edge_',curr_process_var_name,' - (G_seasonal*((permute(seasonal_reg_operator_T,[2 1]))*T_tend_adv_along_top_edge_',curr_process_var_name,'));'])
%     eval(['T_tend_adv_along_bottom_edge_',curr_process_var_name,' = T_tend_adv_along_bottom_edge_',curr_process_var_name,' - (G_seasonal*((permute(seasonal_reg_operator_T,[2 1]))*T_tend_adv_along_bottom_edge_',curr_process_var_name,'));'])
%     eval(['T_tend_adv_total_inbox_',curr_process_var_name,' = T_tend_adv_total_inbox_',curr_process_var_name,' - (G_seasonal*((permute(seasonal_reg_operator_T,[2 1]))*T_tend_adv_total_inbox_',curr_process_var_name,'));'])
%     eval(['T_tend_ent_along_top_edge_',curr_process_var_name,' = T_tend_ent_along_top_edge_',curr_process_var_name,' - (G_seasonal*((permute(seasonal_reg_operator_T,[2 1]))*T_tend_ent_along_top_edge_',curr_process_var_name,'));'])
%     eval(['T_tend_ent_along_bottom_edge_',curr_process_var_name,' = T_tend_ent_along_bottom_edge_',curr_process_var_name,' - (G_seasonal*((permute(seasonal_reg_operator_T,[2 1]))*T_tend_ent_along_bottom_edge_',curr_process_var_name,'));'])
%     
%     eval(['adv_vol_flux_along_E_edge_',curr_process_var_name,' = adv_vol_flux_along_E_edge_',curr_process_var_name,' - (G_seasonal*((permute(seasonal_reg_operator_T,[2 1]))*adv_vol_flux_along_E_edge_',curr_process_var_name,'));'])
%     eval(['adv_vol_flux_along_W_edge_',curr_process_var_name,' = adv_vol_flux_along_W_edge_',curr_process_var_name,' - (G_seasonal*((permute(seasonal_reg_operator_T,[2 1]))*adv_vol_flux_along_W_edge_',curr_process_var_name,'));'])
%     eval(['adv_vol_flux_along_N_edge_',curr_process_var_name,' = adv_vol_flux_along_N_edge_',curr_process_var_name,' - (G_seasonal*((permute(seasonal_reg_operator_T,[2 1]))*adv_vol_flux_along_N_edge_',curr_process_var_name,'));'])
%     eval(['adv_vol_flux_along_S_edge_',curr_process_var_name,' = adv_vol_flux_along_S_edge_',curr_process_var_name,' - (G_seasonal*((permute(seasonal_reg_operator_T,[2 1]))*adv_vol_flux_along_S_edge_',curr_process_var_name,'));'])
%     eval(['adv_vol_flux_along_top_edge_',curr_process_var_name,' = adv_vol_flux_along_top_edge_',curr_process_var_name,' - (G_seasonal*((permute(seasonal_reg_operator_T,[2 1]))*adv_vol_flux_along_top_edge_',curr_process_var_name,'));'])
%     eval(['adv_vol_flux_along_bottom_edge_',curr_process_var_name,' = adv_vol_flux_along_bottom_edge_',curr_process_var_name,' - (G_seasonal*((permute(seasonal_reg_operator_T,[2 1]))*adv_vol_flux_along_bottom_edge_',curr_process_var_name,'));'])
%     eval(['adv_vol_flux_net_reg_inbox_',curr_process_var_name,' = adv_vol_flux_net_reg_inbox_',curr_process_var_name,' - (G_seasonal*((permute(seasonal_reg_operator_T,[2 1]))*adv_vol_flux_net_reg_inbox_',curr_process_var_name,'));'])
%     eval(['ent_vol_flux_along_top_edge_',curr_process_var_name,' = ent_vol_flux_along_top_edge_',curr_process_var_name,' - (G_seasonal*((permute(seasonal_reg_operator_T,[2 1]))*ent_vol_flux_along_top_edge_',curr_process_var_name,'));'])
%     eval(['ent_vol_flux_along_bottom_edge_',curr_process_var_name,' = ent_vol_flux_along_bottom_edge_',curr_process_var_name,' - (G_seasonal*((permute(seasonal_reg_operator_T,[2 1]))*ent_vol_flux_along_bottom_edge_',curr_process_var_name,'));'])
% end
% 
% T_tend_adv_all = T_tend_adv_all - (G_seasonal*((permute(seasonal_reg_operator_T,[2 1]))*T_tend_adv_all));
% 
% 
% 
% T_tend_adv_along_edges_for_composite_anom_Kelvin = NaN((365/5) + 8,7,length(year_nums_to_composite));
% T_tend_adv_along_edges_for_composite_anom_wstr_local = NaN((365/5) + 8,7,length(year_nums_to_composite));
% T_tend_adv_along_edges_for_composite_anom_mesoscale = NaN((365/5) + 8,7,length(year_nums_to_composite));
% T_tend_adv_along_edges_for_composite_anom_Lombok = NaN((365/5) + 8,7,length(year_nums_to_composite));
% T_tend_adv_along_edges_for_composite_anom_wstr_cent_Sumatra = NaN((365/5) + 8,7,length(year_nums_to_composite));
% T_tend_adv_along_edges_for_composite_anom_wstr_SE_Sumatra = NaN((365/5) + 8,7,length(year_nums_to_composite));
% T_tend_ent_for_composite_anom_Kelvin = NaN((365/5) + 8,2,length(year_nums_to_composite));
% T_tend_ent_for_composite_anom_wstr_local = NaN((365/5) + 8,2,length(year_nums_to_composite));
% T_tend_ent_for_composite_anom_mesoscale = NaN((365/5) + 8,2,length(year_nums_to_composite));
% T_tend_ent_for_composite_anom_Lombok = NaN((365/5) + 8,2,length(year_nums_to_composite));
% T_tend_ent_for_composite_anom_wstr_cent_Sumatra = NaN((365/5) + 8,2,length(year_nums_to_composite));
% T_tend_ent_for_composite_anom_wstr_SE_Sumatra = NaN((365/5) + 8,2,length(year_nums_to_composite));
% vol_flux_along_edges_for_composite_anom_Kelvin = NaN((365/5) + 8,7,length(year_nums_to_composite));
% vol_flux_along_edges_for_composite_anom_wstr_local = NaN((365/5) + 8,7,length(year_nums_to_composite));
% vol_flux_along_edges_for_composite_anom_mesoscale = NaN((365/5) + 8,7,length(year_nums_to_composite));
% vol_flux_along_edges_for_composite_anom_Lombok = NaN((365/5) + 8,7,length(year_nums_to_composite));
% vol_flux_along_edges_for_composite_anom_wstr_cent_Sumatra = NaN((365/5) + 8,7,length(year_nums_to_composite));
% vol_flux_along_edges_for_composite_anom_wstr_SE_Sumatra = NaN((365/5) + 8,7,length(year_nums_to_composite));
% vol_flux_ent_for_composite_anom_Kelvin = NaN((365/5) + 8,2,length(year_nums_to_composite));
% vol_flux_ent_for_composite_anom_wstr_local = NaN((365/5) + 8,2,length(year_nums_to_composite));
% vol_flux_ent_for_composite_anom_mesoscale = NaN((365/5) + 8,2,length(year_nums_to_composite));
% vol_flux_ent_for_composite_anom_Lombok = NaN((365/5) + 8,2,length(year_nums_to_composite));
% vol_flux_ent_for_composite_anom_wstr_cent_Sumatra = NaN((365/5) + 8,2,length(year_nums_to_composite));
% vol_flux_ent_for_composite_anom_wstr_SE_Sumatra = NaN((365/5) + 8,2,length(year_nums_to_composite));
% T_tend_adv_for_composite_anom_all = NaN((365/5) + 8,1,length(year_nums_to_composite));
% for year_ind = 1:length(year_nums_to_composite)
%     in_curr_year_ind = find((time_inrange >= ((365*(year_nums_to_composite(year_ind))) - 20)) & (time_inrange <= ((365*(year_nums_to_composite(year_ind) + 1)) + 20)));
%     
%     for process_ind = 1:length(process_var_names)
%         curr_process_var_name = process_var_names{process_ind};
%         
%         eval(['T_tend_adv_along_edges_for_composite_anom_',curr_process_var_name,'(ceil((time_inrange(in_curr_year_ind) - (365*year_nums_to_composite(year_ind)) + 20)/5),1,year_ind) = T_tend_adv_along_E_edge_',curr_process_var_name,'(in_curr_year_ind);'])
%         eval(['T_tend_adv_along_edges_for_composite_anom_',curr_process_var_name,'(ceil((time_inrange(in_curr_year_ind) - (365*year_nums_to_composite(year_ind)) + 20)/5),2,year_ind) = T_tend_adv_along_W_edge_',curr_process_var_name,'(in_curr_year_ind);'])
%         eval(['T_tend_adv_along_edges_for_composite_anom_',curr_process_var_name,'(ceil((time_inrange(in_curr_year_ind) - (365*year_nums_to_composite(year_ind)) + 20)/5),3,year_ind) = T_tend_adv_along_N_edge_',curr_process_var_name,'(in_curr_year_ind);'])
%         eval(['T_tend_adv_along_edges_for_composite_anom_',curr_process_var_name,'(ceil((time_inrange(in_curr_year_ind) - (365*year_nums_to_composite(year_ind)) + 20)/5),4,year_ind) = T_tend_adv_along_S_edge_',curr_process_var_name,'(in_curr_year_ind);'])
%         eval(['T_tend_adv_along_edges_for_composite_anom_',curr_process_var_name,'(ceil((time_inrange(in_curr_year_ind) - (365*year_nums_to_composite(year_ind)) + 20)/5),5,year_ind) = T_tend_adv_along_top_edge_',curr_process_var_name,'(in_curr_year_ind);'])
%         eval(['T_tend_adv_along_edges_for_composite_anom_',curr_process_var_name,'(ceil((time_inrange(in_curr_year_ind) - (365*year_nums_to_composite(year_ind)) + 20)/5),6,year_ind) = T_tend_adv_along_bottom_edge_',curr_process_var_name,'(in_curr_year_ind);'])
%         eval(['T_tend_adv_along_edges_for_composite_anom_',curr_process_var_name,'(ceil((time_inrange(in_curr_year_ind) - (365*year_nums_to_composite(year_ind)) + 20)/5),7,year_ind) = T_tend_adv_total_inbox_',curr_process_var_name,'(in_curr_year_ind);'])
% %         curr_nan_ind = eval(['find(isnan(T_tend_adv_along_edges_for_composite_anom_',curr_process_var_name,'(4,:,year_ind)) == 1)']);
% %         eval(['T_tend_adv_along_edges_for_composite_anom_',curr_process_var_name,'(1:4,curr_nan_ind,year_ind) = repmat(T_tend_adv_along_edges_for_composite_anom_',curr_process_var_name,'(5,curr_nan_ind,year_ind),[4 1 1]);'])
% %         curr_nan_ind = eval(['find(isnan(T_tend_adv_along_edges_for_composite_anom_',curr_process_var_name,'(78,:,year_ind)) == 1)']);
% %         eval(['T_tend_adv_along_edges_for_composite_anom_',curr_process_var_name,'(78:81,curr_nan_ind,year_ind) = repmat(T_tend_adv_along_edges_for_composite_anom_',curr_process_var_name,'(77,curr_nan_ind,year_ind),[4 1 1]);'])
%         eval(['T_tend_ent_for_composite_anom_',curr_process_var_name,'(ceil((time_inrange(in_curr_year_ind) - (365*year_nums_to_composite(year_ind)) + 20)/5),1,year_ind) = T_tend_ent_along_top_edge_',curr_process_var_name,'(in_curr_year_ind);'])
%         eval(['T_tend_ent_for_composite_anom_',curr_process_var_name,'(ceil((time_inrange(in_curr_year_ind) - (365*year_nums_to_composite(year_ind)) + 20)/5),2,year_ind) = T_tend_ent_along_bottom_edge_',curr_process_var_name,'(in_curr_year_ind);'])
% %         curr_nan_ind = eval(['find(isnan(T_tend_ent_for_composite_anom_',curr_process_var_name,'(4,:,year_ind)) == 1)']);
% %         eval(['T_tend_ent_for_composite_anom_',curr_process_var_name,'(1:4,curr_nan_ind,year_ind) = repmat(T_tend_ent_for_composite_anom_',curr_process_var_name,'(5,curr_nan_ind,year_ind),[4 1 1]);'])
% %         curr_nan_ind = eval(['find(isnan(T_tend_ent_for_composite_anom_',curr_process_var_name,'(78,:,year_ind)) == 1)']);
% %         eval(['T_tend_ent_for_composite_anom_',curr_process_var_name,'(78:81,curr_nan_ind,year_ind) = repmat(T_tend_ent_for_composite_anom_',curr_process_var_name,'(77,curr_nan_ind,year_ind),[4 1 1]);'])
%         
%         eval(['vol_flux_along_edges_for_composite_anom_',curr_process_var_name,'(ceil((time_inrange(in_curr_year_ind) - (365*year_nums_to_composite(year_ind)) + 20)/5),1,year_ind) = adv_vol_flux_along_E_edge_',curr_process_var_name,'(in_curr_year_ind);'])
%         eval(['vol_flux_along_edges_for_composite_anom_',curr_process_var_name,'(ceil((time_inrange(in_curr_year_ind) - (365*year_nums_to_composite(year_ind)) + 20)/5),2,year_ind) = adv_vol_flux_along_W_edge_',curr_process_var_name,'(in_curr_year_ind);'])
%         eval(['vol_flux_along_edges_for_composite_anom_',curr_process_var_name,'(ceil((time_inrange(in_curr_year_ind) - (365*year_nums_to_composite(year_ind)) + 20)/5),3,year_ind) = adv_vol_flux_along_N_edge_',curr_process_var_name,'(in_curr_year_ind);'])
%         eval(['vol_flux_along_edges_for_composite_anom_',curr_process_var_name,'(ceil((time_inrange(in_curr_year_ind) - (365*year_nums_to_composite(year_ind)) + 20)/5),4,year_ind) = adv_vol_flux_along_S_edge_',curr_process_var_name,'(in_curr_year_ind);'])
%         eval(['vol_flux_along_edges_for_composite_anom_',curr_process_var_name,'(ceil((time_inrange(in_curr_year_ind) - (365*year_nums_to_composite(year_ind)) + 20)/5),5,year_ind) = adv_vol_flux_along_top_edge_',curr_process_var_name,'(in_curr_year_ind);'])
%         eval(['vol_flux_along_edges_for_composite_anom_',curr_process_var_name,'(ceil((time_inrange(in_curr_year_ind) - (365*year_nums_to_composite(year_ind)) + 20)/5),6,year_ind) = adv_vol_flux_along_bottom_edge_',curr_process_var_name,'(in_curr_year_ind);'])
%         eval(['vol_flux_along_edges_for_composite_anom_',curr_process_var_name,'(ceil((time_inrange(in_curr_year_ind) - (365*year_nums_to_composite(year_ind)) + 20)/5),7,year_ind) = adv_vol_flux_net_reg_inbox_',curr_process_var_name,'(in_curr_year_ind);'])
% %         curr_nan_ind = eval(['find(isnan(vol_flux_along_edges_for_composite_anom_',curr_process_var_name,'(4,:,year_ind)) == 1)']);
% %         eval(['vol_flux_along_edges_for_composite_anom_',curr_process_var_name,'(1:4,curr_nan_ind,year_ind) = repmat(vol_flux_along_edges_for_composite_anom_',curr_process_var_name,'(5,curr_nan_ind,year_ind),[4 1 1]);'])
% %         curr_nan_ind = eval(['find(isnan(vol_flux_along_edges_for_composite_anom_',curr_process_var_name,'(78,:,year_ind)) == 1)']);
% %         eval(['vol_flux_along_edges_for_composite_anom_',curr_process_var_name,'(78:81,curr_nan_ind,year_ind) = repmat(vol_flux_along_edges_for_composite_anom_',curr_process_var_name,'(77,curr_nan_ind,year_ind),[4 1 1]);'])
%         eval(['vol_flux_ent_for_composite_anom_',curr_process_var_name,'(ceil((time_inrange(in_curr_year_ind) - (365*year_nums_to_composite(year_ind)) + 20)/5),1,year_ind) = ent_vol_flux_along_top_edge_',curr_process_var_name,'(in_curr_year_ind);'])
%         eval(['vol_flux_ent_for_composite_anom_',curr_process_var_name,'(ceil((time_inrange(in_curr_year_ind) - (365*year_nums_to_composite(year_ind)) + 20)/5),2,year_ind) = ent_vol_flux_along_bottom_edge_',curr_process_var_name,'(in_curr_year_ind);'])
% %         curr_nan_ind = eval(['find(isnan(vol_flux_ent_for_composite_anom_',curr_process_var_name,'(4,:,year_ind)) == 1)']);
% %         eval(['vol_flux_ent_for_composite_anom_',curr_process_var_name,'(1:4,curr_nan_ind,year_ind) = repmat(vol_flux_ent_for_composite_anom_',curr_process_var_name,'(5,curr_nan_ind,year_ind),[4 1 1]);'])
% %         curr_nan_ind = eval(['find(isnan(vol_flux_ent_for_composite_anom_',curr_process_var_name,'(78,:,year_ind)) == 1)']);
% %         eval(['vol_flux_ent_for_composite_anom_',curr_process_var_name,'(78:81,curr_nan_ind,year_ind) = repmat(vol_flux_ent_for_composite_anom_',curr_process_var_name,'(77,curr_nan_ind,year_ind),[4 1 1]);'])
%         
%     end
%     
%     T_tend_adv_for_composite_anom_all(ceil((time_inrange(in_curr_year_ind) - (365*year_nums_to_composite(year_ind)) + 20)/5),1,year_ind) = T_tend_adv_all(in_curr_year_ind);
%     
% end
% 
% 
% 
% T_tend_adv_along_edges_composite_anom_Kelvin = mean(T_tend_adv_along_edges_for_composite_anom_Kelvin,3);
% T_tend_adv_along_edges_composite_anom_wstr_local = mean(T_tend_adv_along_edges_for_composite_anom_wstr_local,3);
% T_tend_adv_along_edges_composite_anom_mesoscale = mean(T_tend_adv_along_edges_for_composite_anom_mesoscale,3);
% T_tend_adv_along_edges_composite_anom_Lombok = mean(T_tend_adv_along_edges_for_composite_anom_Lombok,3);
% T_tend_adv_along_edges_composite_anom_wstr_cent_Sumatra = mean(T_tend_adv_along_edges_for_composite_anom_wstr_cent_Sumatra,3);
% T_tend_adv_along_edges_composite_anom_wstr_SE_Sumatra = mean(T_tend_adv_along_edges_for_composite_anom_wstr_SE_Sumatra,3);
% T_tend_ent_composite_anom_Kelvin = mean(T_tend_ent_for_composite_anom_Kelvin,3);
% T_tend_ent_composite_anom_wstr_local = mean(T_tend_ent_for_composite_anom_wstr_local,3);
% T_tend_ent_composite_anom_mesoscale = mean(T_tend_ent_for_composite_anom_mesoscale,3);
% T_tend_ent_composite_anom_Lombok = mean(T_tend_ent_for_composite_anom_Lombok,3);
% T_tend_ent_composite_anom_wstr_cent_Sumatra = mean(T_tend_ent_for_composite_anom_wstr_cent_Sumatra,3);
% T_tend_ent_composite_anom_wstr_SE_Sumatra = mean(T_tend_ent_for_composite_anom_wstr_SE_Sumatra,3);
% vol_flux_along_edges_composite_anom_Kelvin = mean(vol_flux_along_edges_for_composite_anom_Kelvin,3);
% vol_flux_along_edges_composite_anom_wstr_local = mean(vol_flux_along_edges_for_composite_anom_wstr_local,3);
% vol_flux_along_edges_composite_anom_mesoscale = mean(vol_flux_along_edges_for_composite_anom_mesoscale,3);
% vol_flux_along_edges_composite_anom_Lombok = mean(vol_flux_along_edges_for_composite_anom_Lombok,3);
% vol_flux_along_edges_composite_anom_wstr_cent_Sumatra = mean(vol_flux_along_edges_for_composite_anom_wstr_cent_Sumatra,3);
% vol_flux_along_edges_composite_anom_wstr_SE_Sumatra = mean(vol_flux_along_edges_for_composite_anom_wstr_SE_Sumatra,3);
% vol_flux_ent_composite_anom_Kelvin = mean(vol_flux_ent_for_composite_anom_Kelvin,3);
% vol_flux_ent_composite_anom_wstr_local = mean(vol_flux_ent_for_composite_anom_wstr_local,3);
% vol_flux_ent_composite_anom_mesoscale = mean(vol_flux_ent_for_composite_anom_mesoscale,3);
% vol_flux_ent_composite_anom_Lombok = mean(vol_flux_ent_for_composite_anom_Lombok,3);
% vol_flux_ent_composite_anom_wstr_cent_Sumatra = mean(vol_flux_ent_for_composite_anom_wstr_cent_Sumatra,3);
% vol_flux_ent_composite_anom_wstr_SE_Sumatra = mean(vol_flux_ent_for_composite_anom_wstr_SE_Sumatra,3);
% T_tend_adv_composite_anom_all = mean(T_tend_adv_for_composite_anom_all,3);
% 
% 
% 
% % span for smoothing in plots
% span = t_plot_smooth_days/tavg_days;
% 
% 
% 
% 
% 
% % T_tend_adv_along_edges_for_bootstrap_Kelvin = NaN((365/5) + 8,7,length(year_nums_for_bootstrap));
% % T_tend_adv_along_edges_for_bootstrap_wstr_local = NaN((365/5) + 8,7,length(year_nums_for_bootstrap));
% % T_tend_adv_along_edges_for_bootstrap_mesoscale = NaN((365/5) + 8,7,length(year_nums_for_bootstrap));
% % vol_flux_along_edges_for_bootstrap_Kelvin = NaN((365/5) + 8,7,length(year_nums_for_bootstrap));
% % vol_flux_along_edges_for_bootstrap_wstr_local = NaN((365/5) + 8,7,length(year_nums_for_bootstrap));
% % vol_flux_along_edges_for_bootstrap_mesoscale = NaN((365/5) + 8,7,length(year_nums_for_bootstrap));
% % for year_ind = 1:length(year_nums_for_bootstrap)
% %     in_curr_year_ind = find((time_inrange >= ((365*(year_nums_for_bootstrap(year_ind))) + (tavg_days/2) - 20)) & (time_inrange <= ((365*(year_nums_for_bootstrap(year_ind) + 1)) + (tavg_days/2) + 20)));
% %     
% %     for process_ind = 1:length(process_var_names)
% %         curr_process_var_name = process_var_names(process_ind);
% %         
% %         eval(['T_tend_adv_along_edges_for_bootstrap_',curr_process_var_name,'(:,1,year_ind) = T_tend_adv_along_E_edge_',curr_process_var_name,'(in_curr_year_ind);'])
% %         eval(['T_tend_adv_along_edges_for_bootstrap_',curr_process_var_name,'(:,2,year_ind) = T_tend_adv_along_W_edge_',curr_process_var_name,'(in_curr_year_ind);'])
% %         eval(['T_tend_adv_along_edges_for_bootstrap_',curr_process_var_name,'(:,3,year_ind) = T_tend_adv_along_N_edge_',curr_process_var_name,'(in_curr_year_ind);'])
% %         eval(['T_tend_adv_along_edges_for_bootstrap_',curr_process_var_name,'(:,4,year_ind) = T_tend_adv_along_S_edge_',curr_process_var_name,'(in_curr_year_ind);'])
% %         eval(['T_tend_adv_along_edges_for_bootstrap_',curr_process_var_name,'(:,5,year_ind) = T_tend_adv_along_top_edge_',curr_process_var_name,'(in_curr_year_ind);'])
% %         eval(['T_tend_adv_along_edges_for_bootstrap_',curr_process_var_name,'(:,6,year_ind) = T_tend_adv_along_bottom_edge_',curr_process_var_name,'(in_curr_year_ind);'])
% %         eval(['T_tend_adv_along_edges_for_bootstrap_',curr_process_var_name,'(:,7,year_ind) = T_tend_adv_total_inbox_',curr_process_var_name,'(in_curr_year_ind);'])
% %         
% %         eval(['vol_flux_along_edges_for_bootstrap_',curr_process_var_name,'(:,1,year_ind) = adv_vol_flux_along_E_edge_',curr_process_var_name,'(in_curr_year_ind);'])
% %         eval(['vol_flux_along_edges_for_bootstrap_',curr_process_var_name,'(:,2,year_ind) = adv_vol_flux_along_W_edge_',curr_process_var_name,'(in_curr_year_ind);'])
% %         eval(['vol_flux_along_edges_for_bootstrap_',curr_process_var_name,'(:,3,year_ind) = adv_vol_flux_along_N_edge_',curr_process_var_name,'(in_curr_year_ind);'])
% %         eval(['vol_flux_along_edges_for_bootstrap_',curr_process_var_name,'(:,4,year_ind) = adv_vol_flux_along_S_edge_',curr_process_var_name,'(in_curr_year_ind);'])
% %         eval(['vol_flux_along_edges_for_bootstrap_',curr_process_var_name,'(:,5,year_ind) = adv_vol_flux_along_top_edge_',curr_process_var_name,'(in_curr_year_ind);'])
% %         eval(['vol_flux_along_edges_for_bootstrap_',curr_process_var_name,'(:,6,year_ind) = adv_vol_flux_along_bottom_edge_',curr_process_var_name,'(in_curr_year_ind);'])
% %         eval(['vol_flux_along_edges_for_bootstrap_',curr_process_var_name,'(:,7,year_ind) = adv_vol_flux_total_inbox_',curr_process_var_name,'(in_curr_year_ind);'])
% %         
% %     end
% %     
% % end
% 
% 
% 
% % n_bootstrap = 1000;   % number of combinations to average for bootstrap calculation
% n_bootstrap = 10000;   % number of combinations to average for bootstrap calculation
% 
% bootstrap_random_year_ind = randi(length(year_nums_for_bootstrap),[length(year_nums_to_composite),n_bootstrap]);
% 
% 
% % T_tend_adv_along_edges_anom_bootstrap_avg_Kelvin = NaN((365/5) + 3,7,length(year_nums_for_bootstrap));
% % T_tend_adv_along_edges_anom_bootstrap_avg_wstr_local = NaN((365/5) + 3,7,length(year_nums_for_bootstrap));
% % T_tend_adv_along_edges_anom_bootstrap_avg_mesoscale = NaN((365/5) + 3,7,length(year_nums_for_bootstrap));
% % vol_flux_along_edges_anom_bootstrap_avg_Kelvin = NaN((365/5) + 3,7,length(year_nums_for_bootstrap));
% % vol_flux_along_edges_anom_bootstrap_avg_wstr_local = NaN((365/5) + 3,7,length(year_nums_for_bootstrap));
% % vol_flux_along_edges_anom_bootstrap_avg_mesoscale = NaN((365/5) + 3,7,length(year_nums_for_bootstrap));
% % for n_bstrap = 1:n_bootstrap
% %     curr_bstrap_year_ind = bootstrap_random_year_ind(:,n_bstrap);
% %     
% %     T_tend_adv_along_edges_anom_bootstrap_avg_Kelvin(:,:,n_bstrap) = mean(T_tend_adv_along_edges_for_bootstrap_Kelvin(:,:,curr_bstrap_year_ind),3);
% %     T_tend_adv_along_edges_anom_bootstrap_avg_wstr_local(:,:,n_bstrap) = mean(T_tend_adv_along_edges_for_bootstrap_wstr_local(:,:,curr_bstrap_year_ind),3);
% %     T_tend_adv_along_edges_anom_bootstrap_avg_mesoscale(:,:,n_bstrap) = mean(T_tend_adv_along_edges_for_bootstrap_mesoscale(:,:,curr_bstrap_year_ind),3);
% %     vol_flux_along_edges_anom_bootstrap_avg_Kelvin(:,:,n_bstrap) = mean(vol_flux_along_edges_for_bootstrap_Kelvin(:,:,curr_bstrap_year_ind),3);
% %     vol_flux_along_edges_anom_bootstrap_avg_wstr_local(:,:,n_bstrap) = mean(vol_flux_along_edges_for_bootstrap_wstr_local(:,:,curr_bstrap_year_ind),3);
% %     vol_flux_along_edges_anom_bootstrap_avg_mesoscale(:,:,n_bstrap) = mean(vol_flux_along_edges_for_bootstrap_mesoscale(:,:,curr_bstrap_year_ind),3);
% % end
% % 
% % 
% % T_tend_adv_along_edges_anom_bootstrap_sorted_Kelvin = sort(T_tend_adv_along_edges_anom_bootstrap_avg_Kelvin,3,'ascend');
% % T_tend_adv_along_edges_anom_bootstrap_sorted_wstr_local = sort(T_tend_adv_along_edges_anom_bootstrap_avg_wstr_local,3,'ascend');
% % T_tend_adv_along_edges_anom_bootstrap_sorted_mesoscale = sort(T_tend_adv_along_edges_anom_bootstrap_avg_mesoscale,3,'ascend');
% % vol_flux_along_edges_anom_bootstrap_sorted_Kelvin = sort(vol_flux_along_edges_anom_bootstrap_avg_Kelvin,3,'ascend');
% % vol_flux_along_edges_anom_bootstrap_sorted_wstr_local = sort(vol_flux_along_edges_anom_bootstrap_avg_wstr_local,3,'ascend');
% % vol_flux_along_edges_anom_bootstrap_sorted_mesoscale = sort(vol_flux_along_edges_anom_bootstrap_avg_mesoscale,3,'ascend');
% 
% 
% cdf_vec = ((1:1:n_bootstrap)' - 0.5)/n_bootstrap;
% 
% 
% % T_tend_adv_along_edges_anom_bootstrap_2p5_97p5_bounds_Kelvin = permute(interp1(cdf_vec,permute(T_tend_adv_along_edges_anom_bootstrap_sorted_Kelvin,[3 1 2]),[0.025; 0.975]),[2 3 1]);
% % T_tend_adv_along_edges_anom_bootstrap_2p5_97p5_bounds_wstr_local = permute(interp1(cdf_vec,permute(T_tend_adv_along_edges_anom_bootstrap_sorted_wstr_local,[3 1 2]),[0.025; 0.975]),[2 3 1]);
% % T_tend_adv_along_edges_anom_bootstrap_2p5_97p5_bounds_mesoscale = permute(interp1(cdf_vec,permute(T_tend_adv_along_edges_anom_bootstrap_sorted_mesoscale,[3 1 2]),[0.025; 0.975]),[2 3 1]);
% % vol_flux_along_edges_anom_bootstrap_2p5_97p5_bounds_Kelvin = permute(interp1(cdf_vec,permute(vol_flux_along_edges_anom_bootstrap_sorted_Kelvin,[3 1 2]),[0.025; 0.975]),[2 3 1]);
% % vol_flux_along_edges_anom_bootstrap_2p5_97p5_bounds_wstr_local = permute(interp1(cdf_vec,permute(vol_flux_along_edges_anom_bootstrap_sorted_wstr_local,[3 1 2]),[0.025; 0.975]),[2 3 1]);
% % vol_flux_along_edges_anom_bootstrap_2p5_97p5_bounds_mesoscale = permute(interp1(cdf_vec,permute(vol_flux_along_edges_anom_bootstrap_sorted_mesoscale,[3 1 2]),[0.025; 0.975]),[2 3 1]);
% 
% 
% 
% 
% % date labels
% 
% month_start_vec = [0; 31; 59; 90; 120; 151; 181; 212; 243; 273; 304; 334];
% time_date_label = month_start_vec;
% % date_label = {'Jan-01'; ''; 'Mar-01'; ''; 'May-01'; ''; 'Jul-01'; ''; 'Sep-01'; ''; 'Nov-01'; ''};
% date_label = {'Jan-01'; ''; ''; 'Apr-01'; ''; ''; 'Jul-01'; ''; ''; 'Oct-01'; ''; ''};
% 
% 
% % time vector (in year)
% time_inyear = ((2.5 - 20):5:(362.5 + 20))';
% 
% % smoothed time vector
% time_inyear_smoothed = smooth_endclip(time_inyear,span);
% 
% 
% 
% 
% % % create figures
% % 
% % for process_var_ind = 1:length(process_var_names)
% %     process_specifier = process_var_names{process_var_ind};
% %     
% %     fig17 = figure(17);
% %     fig17_paper_pos = get(fig17,'PaperPosition');
% %     fig17_paper_pos(3) = 1.8*fig17_paper_pos(4);
% %     fig17_paper_pos(3:4) = 0.8*fig17_paper_pos(3:4);
% %     set(fig17,'PaperPosition',fig17_paper_pos)
% %     eval(['h = plot(time_inyear_smoothed,(1e-12)*smooth_endclip(vol_flux_along_edges_composite_anom_',process_specifier,'(:,3),span),time_inyear_smoothed,(1e-12)*smooth_endclip(vol_flux_along_edges_composite_anom_',process_specifier,'(:,4),span),time_inyear_smoothed,(1e-12)*smooth_endclip(vol_flux_along_edges_composite_anom_',process_specifier,'(:,1),span),time_inyear_smoothed,(1e-12)*smooth_endclip(vol_flux_along_edges_composite_anom_',process_specifier,'(:,2),span),time_inyear_smoothed,(1e-12)*smooth_endclip(vol_flux_along_edges_composite_anom_',process_specifier,'(:,5),span),time_inyear_smoothed,(1e-12)*smooth_endclip(vol_flux_along_edges_composite_anom_',process_specifier,'(:,6),span),time_inyear_smoothed,(1e-12)*smooth_endclip(sum(vol_flux_ent_composite_anom_',process_specifier,'(:,1:2),2),span));'])
% %     set(h(1),'Color',[0 0.8 0.5],'LineStyle','-','LineWidth',1)
% %     set(h(2),'Color',[0.5 0 0.5],'LineStyle','-','LineWidth',1)
% %     set(h(3),'Color',[0.7 0 0],'LineStyle','--','LineWidth',1)
% %     set(h(4),'Color',[0 0.4 0.2],'LineStyle','--','LineWidth',1)
% %     set(h(5),'LineStyle','-.','LineWidth',1)
% %     set(h(6),'Color',[0 0 0.4],'LineStyle','-.','LineWidth',1)
% %     set(h(7),'Color','k','LineWidth',1.5)
% %     weight_white = 0.7;     % proportion of color adjustment towards white
% %     for h_ind = 1:length(h)
% %         full_color_vec = get(h(h_ind),'Color');
% %         set(h(h_ind),'Color',(weight_white*[1 1 1]) + (1 - weight_white)*full_color_vec)
% %     end
% %     plot_series_specifiers_allyears = {['adv_vol_flux_along_N_edge_',process_specifier]; ['adv_vol_flux_along_S_edge_',process_specifier]; ['adv_vol_flux_along_E_edge_',process_specifier]; ['adv_vol_flux_along_W_edge_',process_specifier]; ['adv_vol_flux_along_top_edge_',process_specifier]; ['adv_vol_flux_along_bottom_edge_',process_specifier]; ['ent_vol_flux_along_top_edge_',process_specifier,' + ent_vol_flux_along_bottom_edge_',process_specifier,]};
% %     plot_series_specifiers_composite = {['vol_flux_along_edges_composite_anom_',process_specifier,'(:,3)']; ['vol_flux_along_edges_composite_anom_',process_specifier,'(:,4)']; ['vol_flux_along_edges_composite_anom_',process_specifier,'(:,1)']; ['vol_flux_along_edges_composite_anom_',process_specifier,'(:,2)']; ['vol_flux_along_edges_composite_anom_',process_specifier,'(:,5)']; ['vol_flux_along_edges_composite_anom_',process_specifier,'(:,6)']; ['sum(vol_flux_ent_composite_anom_',process_specifier,'(:,1:2),2)']};
% %     hold on
% %     h_b = NaN(length(plot_series_specifiers_composite),1);
% %     for n_series = 1:length(plot_series_specifiers_allyears)
% %         curr_series_for_bootstrap = NaN((365/5) + 3,length(year_nums_for_bootstrap));
% %         
% %         curr_series = eval(plot_series_specifiers_allyears{n_series});
% %         for year_ind = 1:length(year_nums_for_bootstrap)
% %             in_curr_year_ind = find((time_inrange >= ((365*(year_nums_for_bootstrap(year_ind))) - 20)) & (time_inrange <= ((365*(year_nums_for_bootstrap(year_ind) + 1)) + 20)));
% %             
% % %             if year_ind == 1
% %             if ((year_ind == 1) || (year_ind == 18))
% %                 begin_ind = size(curr_series_for_bootstrap,1) - length(in_curr_year_ind) + span;
% %                 curr_series_for_bootstrap(begin_ind:size(curr_series_for_bootstrap,1),year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
% %                 curr_series_for_bootstrap(1:(begin_ind - 1),year_ind) = curr_series_for_bootstrap(begin_ind,year_ind);
% % %             elseif year_ind == length(year_nums_for_bootstrap))
% %             elseif ((year_ind == length(year_nums_for_bootstrap)) || (year_ind == 17))
% %                 end_ind = length(in_curr_year_ind) - span + 1;
% %                 curr_series_for_bootstrap(1:end_ind,year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
% %                 curr_series_for_bootstrap((end_ind + 1):size(curr_series_for_bootstrap,1),year_ind) = curr_series_for_bootstrap(end_ind,year_ind);
% %             else
% %                 curr_series_for_bootstrap(:,year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
% %             end
% %         end
% %         
% %         curr_series_bootstrap_avg = NaN((365/5) + 3,n_bootstrap);
% %         for n_bstrap = 1:n_bootstrap
% %             curr_bstrap_year_ind = bootstrap_random_year_ind(:,n_bstrap);
% %             
% %             curr_series_bootstrap_avg(:,n_bstrap) = mean(curr_series_for_bootstrap(:,curr_bstrap_year_ind),2);
% %         end
% %         
% %         curr_series_bootstrap_sorted = sort(curr_series_bootstrap_avg,2,'ascend');
% %         
% %         curr_series_bootstrap_2p5_97p5_bounds = (interp1(cdf_vec,curr_series_bootstrap_sorted',[0.025; 0.975]))';
% %         curr_series_bootstrap_5_95_bounds = (interp1(cdf_vec,curr_series_bootstrap_sorted',[0.05; 0.95]))';
% %         
% %         curr_color_vec = get(h(n_series),'Color');
% %         curr_linestyle = get(h(n_series),'LineStyle');
% %         curr_linewidth = get(h(n_series),'LineWidth');
% %         curr_ydata = get(h(n_series),'YData');
% %         
% %     %     h_e = errorbar(time_inyear_smoothed,curr_ydata,(1e-12)*curr_series_bootstrap_2p5_97p5_bounds(:,2),(1e-12)*curr_series_bootstrap_2p5_97p5_bounds(:,1));
% %     %     set(h_e,'Color',curr_color,'LineWidth',curr_linewidth)
% %         
% %         weight_white_reverse = -weight_white/(1 - weight_white);
% %         full_color_vec = (weight_white_reverse*[1 1 1]) + (1 - weight_white_reverse)*curr_color_vec;
% %         curr_series_bootstrap_test = eval(['smooth_endclip(',plot_series_specifiers_composite{n_series},',span)']);
% %         
% %         curr_h_ydata = get(h(n_series),'YData');
% %         outside_range_ind = find((curr_series_bootstrap_test < curr_series_bootstrap_5_95_bounds(:,1)) | (curr_series_bootstrap_test > curr_series_bootstrap_5_95_bounds(:,2)));
% %         outside_range_no_transition_ind = intersect(intersect(outside_range_ind - 1,outside_range_ind),outside_range_ind + 1);
% %         curr_h_ydata(outside_range_no_transition_ind) = NaN;
% %         set(h(n_series),'YData',curr_h_ydata)
% %         
% %         curr_series_bootstrap_test((curr_series_bootstrap_test >= curr_series_bootstrap_5_95_bounds(:,1)) & (curr_series_bootstrap_test <= curr_series_bootstrap_5_95_bounds(:,2))) = NaN;
% %         h_b(n_series) = line(time_inyear_smoothed,(1e-12)*curr_series_bootstrap_test,'Color',full_color_vec,'LineStyle',curr_linestyle,'LineWidth',curr_linewidth + 1);
% %         
% %     end
% %     
% %     % xlim_bounds = [(min(time_inrange) - (tavg_days/2)) (max(time_inrange) + (tavg_days/2))];
% %     xlim_bounds = [0 365];
% %     set(gca,'xlim',xlim_bounds,'xtick',time_date_label,'xticklabel',date_label,'FontSize',14)
% %     set(gca,'ylim',[-4 4],'ytick',(-4):1:4)
% %     hold on
% %     line(xlim_bounds,[0 0],[0 0],'Color','k','LineStyle','-','LineWidth',0.5)
% %     hold off
% %     ylabel('Volume flux anomaly (Sv)')
% %     % legend('North flux','West flux','South flux','East flux','Top flux','Bottom flux','Net vol. change','Location','southwest')
% %     legend(h_b,'North flux','South flux','East flux','West flux','Top flux','Bottom flux','Vol. change anom.','Location','eastoutside')
% %     % legend(h,'North flux','South flux','East flux','West flux','Top flux','Bottom flux','Vol. change ','Location','eastoutside')
% %     % title(['Composite volume flux into each side of the region: ',region_desc])
% %     title(['Composite volume flux anomaly into each side of the region associated with ',process_specifier],'FontSize',10)
% %     
% %     saveas(fig17,['Java_temp_budget_vol_fluxes_anom_pIOD_composite_',process_specifier,'.pdf'])
% %     close(fig17)
% %     
% %     
% %     
% %     % plot the directional advective tendency components - seasonal cycle & anomalies
% %     
% %     fig19 = figure(19);
% %     fig19_paper_pos = get(fig19,'PaperPosition');
% %     fig19_paper_pos(3) = 1.8*fig19_paper_pos(4);
% %     fig19_paper_pos(3:4) = 0.8*fig19_paper_pos(3:4);
% %     set(fig19,'PaperPosition',fig19_paper_pos)
% %     eval(['h = plot(time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_',process_specifier,'(:,3),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_',process_specifier,'(:,4),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_',process_specifier,'(:,1),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_',process_specifier,'(:,2),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_',process_specifier,'(:,5),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_',process_specifier,'(:,6),span),time_inyear_smoothed,86400*smooth_endclip(sum(T_tend_ent_composite_anom_',process_specifier,'(:,1:2),2),span));'])
% %     set(h(1),'Color',[0 0.8 0.5],'LineStyle','-','LineWidth',1)
% %     set(h(2),'Color',[0.5 0 0.5],'LineStyle','-','LineWidth',1)
% %     set(h(3),'Color',[0.7 0 0],'LineStyle','--','LineWidth',1)
% %     set(h(4),'Color',[0 0.4 0.2],'LineStyle','--','LineWidth',1)
% %     set(h(5),'LineStyle','-.','LineWidth',1)
% %     set(h(6),'Color',[0 0 0.4],'LineStyle','-.','LineWidth',1)
% %     set(h(7),'Color',[0 0.5 0],'LineWidth',1.5)
% %     weight_white = 0.7;     % proportion of color adjustment towards white
% %     for h_ind = 1:length(h)
% %         full_color_vec = get(h(h_ind),'Color');
% %         set(h(h_ind),'Color',(weight_white*[1 1 1]) + (1 - weight_white)*full_color_vec)
% %     end
% %     plot_series_specifiers_allyears = {['T_tend_adv_along_N_edge_',process_specifier]; ['T_tend_adv_along_S_edge_',process_specifier]; ['T_tend_adv_along_E_edge_',process_specifier]; ['T_tend_adv_along_W_edge_',process_specifier]; ['T_tend_adv_along_top_edge_',process_specifier]; ['T_tend_adv_along_bottom_edge_',process_specifier]; ['T_tend_ent_along_top_edge_',process_specifier,' + T_tend_ent_along_bottom_edge_',process_specifier]};
% %     plot_series_specifiers_composite = {['T_tend_adv_along_edges_composite_anom_',process_specifier,'(:,3)']; ['T_tend_adv_along_edges_composite_anom_',process_specifier,'(:,4)']; ['T_tend_adv_along_edges_composite_anom_',process_specifier,'(:,1)']; ['T_tend_adv_along_edges_composite_anom_',process_specifier,'(:,2)']; ['T_tend_adv_along_edges_composite_anom_',process_specifier,'(:,5)']; ['T_tend_adv_along_edges_composite_anom_',process_specifier,'(:,6)']; ['sum(T_tend_ent_composite_anom_',process_specifier,'(:,1:2),2)']};
% %     hold on
% %     h_b = NaN(length(plot_series_specifiers_composite),1);
% %     for n_series = 1:length(plot_series_specifiers_allyears)
% %         curr_series_for_bootstrap = NaN((365/5) + 3,length(year_nums_for_bootstrap));
% %         
% %         curr_series = eval(plot_series_specifiers_allyears{n_series});
% %         for year_ind = 1:length(year_nums_for_bootstrap)
% %             in_curr_year_ind = find((time_inrange >= ((365*(year_nums_for_bootstrap(year_ind))) - 20)) & (time_inrange <= ((365*(year_nums_for_bootstrap(year_ind) + 1)) + 20)));
% %             
% % %             if year_ind == 1
% %             if ((year_ind == 1) || (year_ind == 18) || (year_ind == 29))
% %                 begin_ind = size(curr_series_for_bootstrap,1) - length(in_curr_year_ind) + span;
% %                 curr_series_for_bootstrap(begin_ind:size(curr_series_for_bootstrap,1),year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
% %                 curr_series_for_bootstrap(1:(begin_ind - 1),year_ind) = curr_series_for_bootstrap(begin_ind,year_ind);
% % %             elseif year_ind == length(year_nums_for_bootstrap))
% %             elseif ((year_ind == length(year_nums_for_bootstrap)) || (year_ind == 17))
% %                 end_ind = length(in_curr_year_ind) - span + 1;
% %                 curr_series_for_bootstrap(1:end_ind,year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
% %                 curr_series_for_bootstrap((end_ind + 1):size(curr_series_for_bootstrap,1),year_ind) = curr_series_for_bootstrap(end_ind,year_ind);
% %             else
% %                 curr_series_for_bootstrap(:,year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
% %             end
% %         end
% %         
% %         curr_series_bootstrap_avg = NaN((365/5) + 3,n_bootstrap);
% %         for n_bstrap = 1:n_bootstrap
% %             curr_bstrap_year_ind = bootstrap_random_year_ind(:,n_bstrap);
% %             
% %             curr_series_bootstrap_avg(:,n_bstrap) = mean(curr_series_for_bootstrap(:,curr_bstrap_year_ind),2);
% %         end
% %         
% %         curr_series_bootstrap_sorted = sort(curr_series_bootstrap_avg,2,'ascend');
% %         
% %         curr_series_bootstrap_2p5_97p5_bounds = (interp1(cdf_vec,curr_series_bootstrap_sorted',[0.025; 0.975]))';
% %         curr_series_bootstrap_5_95_bounds = (interp1(cdf_vec,curr_series_bootstrap_sorted',[0.05; 0.95]))';
% %         
% %         curr_color_vec = get(h(n_series),'Color');
% %         curr_linestyle = get(h(n_series),'LineStyle');
% %         curr_linewidth = get(h(n_series),'LineWidth');
% %         curr_ydata = get(h(n_series),'YData');
% %         
% %     %     h_e = errorbar(time_inyear_smoothed,curr_ydata,86400*curr_series_bootstrap_2p5_97p5_bounds(:,2),86400*curr_series_bootstrap_2p5_97p5_bounds(:,1));
% %     %     set(h_e,'Color',curr_color,'LineWidth',curr_linewidth)
% %         
% %         weight_white_reverse = -weight_white/(1 - weight_white);
% %         full_color_vec = (weight_white_reverse*[1 1 1]) + (1 - weight_white_reverse)*curr_color_vec;
% %         curr_series_bootstrap_test = eval(['smooth_endclip(',plot_series_specifiers_composite{n_series},',span)']);
% %         
% %         curr_h_ydata = get(h(n_series),'YData');
% %         outside_range_ind = find((curr_series_bootstrap_test < curr_series_bootstrap_5_95_bounds(:,1)) | (curr_series_bootstrap_test > curr_series_bootstrap_5_95_bounds(:,2)));
% %         outside_range_no_transition_ind = intersect(intersect(outside_range_ind - 1,outside_range_ind),outside_range_ind + 1);
% %         curr_h_ydata(outside_range_no_transition_ind) = NaN;
% %         set(h(n_series),'YData',curr_h_ydata)
% %         
% %         curr_series_bootstrap_test((curr_series_bootstrap_test >= curr_series_bootstrap_5_95_bounds(:,1)) & (curr_series_bootstrap_test <= curr_series_bootstrap_5_95_bounds(:,2))) = NaN;
% %         h_b(n_series) = line(time_inyear_smoothed,86400*curr_series_bootstrap_test,'Color',full_color_vec,'LineStyle',curr_linestyle,'LineWidth',curr_linewidth + 1);
% %         
% %     end
% %     
% %     xlim_bounds = [0 365];
% %     set(gca,'xlim',xlim_bounds,'xtick',time_date_label,'xticklabel',date_label,'FontSize',14)
% %     set(gca,'ylim',[-0.02 0.02],'ytick',(-0.02):0.005:0.02)
% %     hold on
% %     line(xlim_bounds,[0 0],[0 0],'Color','k','LineStyle','-','LineWidth',0.5)
% %     hold off
% %     ylabel('Temp. tendency anomaly ( ^{o}C day^{-1})')
% %     % legend('North edge','West edge','South edge','East edge','Top edge','Bottom edge','Total adv. tend. anom.','location','eastoutside')
% %     legend(h_b,'North edge','South edge','East edge','West edge','Top edge','Bottom edge','Volume change','location','eastoutside')
% %     % legend(h,'North edge','South edge','East edge','West edge','Top edge','Bottom edge','Total adv. tend. anom.','location','eastoutside')
% %     title({'Contributions to the composite advective temp. anomaly from each side of the region'; ['associated with ',process_specifier]},'FontSize',10)
% %     
% %     saveas(fig19,['Java_temp_budget_T_tend_anom_pIOD_composite_from_fluxes_',process_specifier,'.pdf'])
% %     close(fig19)
% %     
% % end
% 
% 
% 
% % plot the tendencies associated with each process
% 
% T_tend_adv_total_inbox_sum_processes = T_tend_adv_total_inbox_Kelvin + T_tend_adv_total_inbox_wstr_local + T_tend_adv_total_inbox_mesoscale + T_tend_adv_total_inbox_Lombok + T_tend_adv_total_inbox_wstr_cent_Sumatra + T_tend_adv_total_inbox_wstr_SE_Sumatra;
% T_tend_adv_along_edges_composite_anom_sum_processes = T_tend_adv_along_edges_composite_anom_Kelvin + T_tend_adv_along_edges_composite_anom_wstr_local + T_tend_adv_along_edges_composite_anom_mesoscale + T_tend_adv_along_edges_composite_anom_Lombok + T_tend_adv_along_edges_composite_anom_wstr_cent_Sumatra + T_tend_adv_along_edges_composite_anom_wstr_SE_Sumatra;


fig21 = figure(21);
fig21_paper_pos = get(fig21,'PaperPosition');
fig21_paper_pos(3) = 1.8*fig21_paper_pos(4);
fig21_paper_pos(3:4) = 0.8*fig21_paper_pos(3:4);
set(fig21,'PaperPosition',fig21_paper_pos)
% % h = plot(time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_Kelvin(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_wstr_local(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_mesoscale(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_wstr_Sumatra(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_Lombok(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_sum_processes(:,7),span));
% % set(h(1),'Color',[0 0.4 0.4],'LineStyle','-','LineWidth',1)
% % set(h(2),'Color',[0.2 1 0.2],'LineStyle','-','LineWidth',1)
% % set(h(3),'Color',[0.5 0.5 0],'LineStyle','-','LineWidth',1)
% % set(h(4),'Color',[0.7 0 0.7],'LineStyle','-','LineWidth',1)
% % set(h(5),'Color',[0.3 0 0],'LineStyle','-','LineWidth',1)
% % set(h(6),'Color',[0 0 1],'LineStyle','-','LineWidth',1.5)
% % h = plot(time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_Kelvin(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_wstr_cent_Sumatra(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_wstr_SE_Sumatra(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_wstr_local(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_Lombok(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_mesoscale(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_sum_processes(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_composite_anom_all,span));
h = plot(time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_Kelvin(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_wstr_cent_Sumatra(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_wstr_SE_Sumatra(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_wstr_local(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_Lombok(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_mesoscale(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_sum_processes(:,7),span));
% h = plot(time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_Kelvin(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_wstr_cent_Sumatra(:,7) + T_tend_adv_along_edges_composite_anom_wstr_SE_Sumatra(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_wstr_local(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_Lombok(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_mesoscale(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_sum_processes(:,7),span));
% % h = plot(time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_wstr_cent_Sumatra(:,7) + T_tend_adv_along_edges_composite_anom_wstr_SE_Sumatra(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_Kelvin(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_wstr_local(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_Lombok(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_mesoscale(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_sum_processes(:,7),span));
% set(h(1),'Color',[0.6 0 0.85],'LineStyle','-','LineWidth',1)
set(h(1),'Color',[0 0.4 0.4],'LineStyle','-','LineWidth',1)
% set(h(2),'Color',[0 0.4 0.4],'LineStyle','-','LineWidth',1)
% % set(h(2),'Color',[0.5 0 1],'LineStyle','-','LineWidth',1)
% % set(h(3),'Color',[0.7 0 0.7],'LineStyle','-','LineWidth',1)
set(h(2),'Color',[0.3 0 0.8],'LineStyle','-','LineWidth',1)
set(h(3),'Color',[1 0 1],'LineStyle','-','LineWidth',1)
% set(h(2),'Color',[0.6 0 0.85],'LineStyle','-','LineWidth',1)
set(h(4),'Color',[0.2 1 0.2],'LineStyle','-','LineWidth',1)
set(h(5),'Color',[0.5 0 0],'LineStyle','-','LineWidth',1)
set(h(6),'Color',[0.5 0.5 0],'LineStyle','-','LineWidth',1)
set(h(7),'Color',[0 0 0],'LineStyle','-','LineWidth',1.5)
% set(h(8),'Color',[0 0 1],'LineStyle','-','LineWidth',0.5)
weight_white = 0.7;     % proportion of color adjustment towards white
for h_ind = 1:length(h)
    full_color_vec = get(h(h_ind),'Color');
    set(h(h_ind),'Color',(weight_white*[1 1 1]) + (1 - weight_white)*full_color_vec)
end
plot_series_specifiers_allyears = {'T_tend_adv_total_inbox_Kelvin'; 'T_tend_adv_total_inbox_wstr_cent_Sumatra'; 'T_tend_adv_total_inbox_wstr_SE_Sumatra'; 'T_tend_adv_total_inbox_wstr_local'; 'T_tend_adv_total_inbox_Lombok'; 'T_tend_adv_total_inbox_mesoscale'; 'T_tend_adv_total_inbox_sum_processes'};
plot_series_specifiers_composite = {'T_tend_adv_along_edges_composite_anom_Kelvin(:,7)'; 'T_tend_adv_along_edges_composite_anom_wstr_cent_Sumatra(:,7)'; 'T_tend_adv_along_edges_composite_anom_wstr_SE_Sumatra(:,7)'; 'T_tend_adv_along_edges_composite_anom_wstr_local(:,7)'; 'T_tend_adv_along_edges_composite_anom_Lombok(:,7)'; 'T_tend_adv_along_edges_composite_anom_mesoscale(:,7)'; 'T_tend_adv_along_edges_composite_anom_sum_processes(:,7)'};
% plot_series_specifiers_allyears = {'T_tend_adv_total_inbox_Kelvin'; 'T_tend_adv_total_inbox_wstr_cent_Sumatra + T_tend_adv_total_inbox_wstr_SE_Sumatra'; 'T_tend_adv_total_inbox_wstr_local'; 'T_tend_adv_total_inbox_Lombok'; 'T_tend_adv_total_inbox_mesoscale'; 'T_tend_adv_total_inbox_sum_processes'};
% plot_series_specifiers_composite = {'T_tend_adv_along_edges_composite_anom_Kelvin(:,7)'; 'T_tend_adv_along_edges_composite_anom_wstr_cent_Sumatra(:,7) + T_tend_adv_along_edges_composite_anom_wstr_SE_Sumatra(:,7)'; 'T_tend_adv_along_edges_composite_anom_wstr_local(:,7)'; 'T_tend_adv_along_edges_composite_anom_Lombok(:,7)'; 'T_tend_adv_along_edges_composite_anom_mesoscale(:,7)'; 'T_tend_adv_along_edges_composite_anom_sum_processes(:,7)'};
% % plot_series_specifiers_allyears = {'T_tend_adv_total_inbox_wstr_cent_Sumatra + T_tend_adv_total_inbox_wstr_SE_Sumatra'; 'T_tend_adv_total_inbox_Kelvin'; 'T_tend_adv_total_inbox_wstr_local'; 'T_tend_adv_total_inbox_Lombok'; 'T_tend_adv_total_inbox_mesoscale'; 'T_tend_adv_total_inbox_sum_processes'};
% % plot_series_specifiers_composite = {'T_tend_adv_along_edges_composite_anom_wstr_cent_Sumatra(:,7) + T_tend_adv_along_edges_composite_anom_wstr_SE_Sumatra(:,7)'; 'T_tend_adv_along_edges_composite_anom_Kelvin(:,7)'; 'T_tend_adv_along_edges_composite_anom_wstr_local(:,7)'; 'T_tend_adv_along_edges_composite_anom_Lombok(:,7)'; 'T_tend_adv_along_edges_composite_anom_mesoscale(:,7)'; 'T_tend_adv_along_edges_composite_anom_sum_processes(:,7)'};
hold on
h_b = NaN(length(plot_series_specifiers_composite),1);
for n_series = 1:length(plot_series_specifiers_allyears)
    curr_series_for_bootstrap = NaN((365/5) + 3,length(year_nums_for_bootstrap));
    
    curr_series = eval(plot_series_specifiers_allyears{n_series});
    for year_ind = 1:length(year_nums_for_bootstrap)
        in_curr_year_ind = find((time_inrange >= ((365*(year_nums_for_bootstrap(year_ind))) - 20)) & (time_inrange <= ((365*(year_nums_for_bootstrap(year_ind) + 1)) + 20)));
        
        if year_ind == 1
%         if ((year_ind == 1) || (year_ind == 18) || (year_ind == 29))
            begin_ind = size(curr_series_for_bootstrap,1) - length(in_curr_year_ind) + span;
            curr_series_for_bootstrap(begin_ind:size(curr_series_for_bootstrap,1),year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
            curr_series_for_bootstrap(1:(begin_ind - 1),year_ind) = curr_series_for_bootstrap(begin_ind,year_ind);
        elseif year_ind == length(year_nums_for_bootstrap)
%         elseif ((year_ind == length(year_nums_for_bootstrap)) || (year_ind == 17))
            end_ind = length(in_curr_year_ind) - span + 1;
            curr_series_for_bootstrap(1:end_ind,year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
            curr_series_for_bootstrap((end_ind + 1):size(curr_series_for_bootstrap,1),year_ind) = curr_series_for_bootstrap(end_ind,year_ind);
        else
            curr_series_for_bootstrap(:,year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
        end
    end
    
    curr_series_bootstrap_avg = NaN((365/5) + 3,n_bootstrap);
    for n_bstrap = 1:n_bootstrap
        curr_bstrap_year_ind = bootstrap_random_year_ind(:,n_bstrap);
        
        curr_series_bootstrap_avg(:,n_bstrap) = mean(curr_series_for_bootstrap(:,curr_bstrap_year_ind),2);
    end
    
    curr_series_bootstrap_sorted = sort(curr_series_bootstrap_avg,2,'ascend');
    
    curr_series_bootstrap_2p5_97p5_bounds = (interp1(cdf_vec,curr_series_bootstrap_sorted',[0.025; 0.975]))';
    curr_series_bootstrap_5_95_bounds = (interp1(cdf_vec,curr_series_bootstrap_sorted',[0.05; 0.95]))';
    
    curr_color_vec = get(h(n_series),'Color');
    curr_linestyle = get(h(n_series),'LineStyle');
    curr_linewidth = get(h(n_series),'LineWidth');
    curr_ydata = get(h(n_series),'YData');
    
%     h_e = errorbar(time_inyear_smoothed,curr_ydata,86400*curr_series_bootstrap_2p5_97p5_bounds(:,2),86400*curr_series_bootstrap_2p5_97p5_bounds(:,1));
%     set(h_e,'Color',curr_color,'LineWidth',curr_linewidth)
    
    weight_white_reverse = -weight_white/(1 - weight_white);
    full_color_vec = (weight_white_reverse*[1 1 1]) + (1 - weight_white_reverse)*curr_color_vec;
    curr_series_bootstrap_test = eval(['smooth_endclip(',plot_series_specifiers_composite{n_series},',span)']);
    
    curr_h_ydata = get(h(n_series),'YData');
    outside_range_ind = find((curr_series_bootstrap_test < curr_series_bootstrap_5_95_bounds(:,1)) | (curr_series_bootstrap_test > curr_series_bootstrap_5_95_bounds(:,2)));
    outside_range_no_transition_ind = intersect(intersect(outside_range_ind - 1,outside_range_ind),outside_range_ind + 1);
    curr_h_ydata(outside_range_no_transition_ind) = NaN;
    set(h(n_series),'YData',curr_h_ydata)
    
    curr_series_bootstrap_test((curr_series_bootstrap_test >= curr_series_bootstrap_5_95_bounds(:,1)) & (curr_series_bootstrap_test <= curr_series_bootstrap_5_95_bounds(:,2))) = NaN;
    h_b(n_series) = line(time_inyear_smoothed,86400*curr_series_bootstrap_test,'Color',full_color_vec,'LineStyle',curr_linestyle,'LineWidth',curr_linewidth + 1);
    
end

xlim_bounds = [0 365];
set(gca,'xlim',xlim_bounds,'xtick',time_date_label,'xticklabel',date_label,'FontSize',14)
% set(gca,'ylim',[-0.02 0.02],'ytick',(-0.02):0.005:0.02,'DataAspectRatio',[30 0.004 1])
set(gca,'ylim',[-0.04 0.01],'ytick',(-0.04):0.005:0.02,'DataAspectRatio',[30 0.004 1])
hold on
line(xlim_bounds,[0 0],[0 0],'Color','k','LineStyle','-','LineWidth',0.5)
hold off
ylabel('Temp. tendency anomaly ( ^{o}C day^{-1})')
% % leg = legend(h_b,'Equatorial Kelvin waves','Central Sumatra wind stress (minus EqKW)','SE Sumatra wind stress (minus EqKW & CentSWstr)','Local Java wind stress (minus EqKW, CentSWstr, & SESWstr)','Lombok Strait (minus EqKW, CentSWstr, SESWStr, & LJWstr)','Mesoscale eddies','Sum of processes','location','eastoutside');
% % leg = legend(h_b,'Equatorial Kelvin waves (adjusted)','Central Sumatra wind stress (adjusted)','S Sumatra wind stress','Local Java wind stress (adjusted)','Lombok Strait (adjusted)','Mesoscale eddies','Sum of processes','location','eastoutside');
leg = legend(h_b,'Equatorial Kelvin waves','Central Sumatra wind stress','S Sumatra wind stress','Local Java wind stress','Lombok Strait','Mesoscale eddies','Sum of processes','location','eastoutside');
% leg = legend(h,'Equatorial Kelvin waves (adjusted)','Sumatra combined wind stress','Local Java wind stress (adjusted)','Lombok Strait (adjusted)','Mesoscale eddies','Sum of processes','location','eastoutside');
% % leg = legend(h,'Sumatra combined wind stress','Equatorial Kelvin waves (adjusted)','Local Java wind stress (adjusted)','Lombok Strait (adjusted)','Mesoscale eddies','Sum of processes','location','eastoutside');
set(leg,'FontSize',10)
title('Contributions to the composite advective temp. anomaly from each process','FontSize',8)

% saveas(fig21,['Java_temp_budget_T_tend_anom_pIOD_composite_from_fluxes_all_processes.pdf'])
saveas(fig21,['Java_temp_budget_T_tend_anom_pIOD_composite_from_fluxes_all_processes_no_rem_reg.pdf'])
close(fig21)


T_tend_adv_total_unexplained_resid = T_tend_adv_all - T_tend_adv_total_inbox_sum_processes;
T_tend_adv_composite_anom_unexplained_resid = T_tend_adv_composite_anom_all - T_tend_adv_along_edges_composite_anom_sum_processes(:,7);

fig22 = figure(22);
fig22_paper_pos = get(fig22,'PaperPosition');
fig22_paper_pos(3) = 1.8*fig22_paper_pos(4);
fig22_paper_pos(3:4) = 0.8*fig22_paper_pos(3:4);
set(fig22,'PaperPosition',fig22_paper_pos)
h = plot(time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_along_edges_composite_anom_sum_processes(:,7),span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_composite_anom_all,span),time_inyear_smoothed,86400*smooth_endclip(T_tend_adv_composite_anom_unexplained_resid,span));
set(h(1),'Color',[0 0 0],'LineStyle','-','LineWidth',1.5)
set(h(2),'Color',[0 0 1],'LineStyle','-','LineWidth',1.5)
set(h(3),'Color',[0 0 0.7],'LineStyle','-.','LineWidth',1.5)
weight_white = 0.7;     % proportion of color adjustment towards white
for h_ind = 1:length(h)
    full_color_vec = get(h(h_ind),'Color');
    set(h(h_ind),'Color',(weight_white*[1 1 1]) + (1 - weight_white)*full_color_vec)
end
plot_series_specifiers_allyears = {'T_tend_adv_total_inbox_sum_processes'; 'T_tend_adv_all'; 'T_tend_adv_total_unexplained_resid'};
plot_series_specifiers_composite = {'T_tend_adv_along_edges_composite_anom_sum_processes(:,7)'; 'T_tend_adv_composite_anom_all'; 'T_tend_adv_composite_anom_unexplained_resid'};
hold on
h_b = NaN(length(plot_series_specifiers_composite),1);
for n_series = 1:length(plot_series_specifiers_allyears)
    curr_series_for_bootstrap = NaN((365/5) + 3,length(year_nums_for_bootstrap));
    
    curr_series = eval(plot_series_specifiers_allyears{n_series});
    for year_ind = 1:length(year_nums_for_bootstrap)
        in_curr_year_ind = find((time_inrange >= ((365*(year_nums_for_bootstrap(year_ind))) - 20)) & (time_inrange <= ((365*(year_nums_for_bootstrap(year_ind) + 1)) + 20)));
        
        if year_ind == 1
%         if ((year_ind == 1) || (year_ind == 18) || (year_ind == 29))
            begin_ind = size(curr_series_for_bootstrap,1) - length(in_curr_year_ind) + span;
            curr_series_for_bootstrap(begin_ind:size(curr_series_for_bootstrap,1),year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
            curr_series_for_bootstrap(1:(begin_ind - 1),year_ind) = curr_series_for_bootstrap(begin_ind,year_ind);
        elseif year_ind == length(year_nums_for_bootstrap)
%         elseif ((year_ind == length(year_nums_for_bootstrap)) || (year_ind == 17))
            end_ind = length(in_curr_year_ind) - span + 1;
            curr_series_for_bootstrap(1:end_ind,year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
            curr_series_for_bootstrap((end_ind + 1):size(curr_series_for_bootstrap,1),year_ind) = curr_series_for_bootstrap(end_ind,year_ind);
        else
            curr_series_for_bootstrap(:,year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
        end
    end
    
    curr_series_bootstrap_avg = NaN((365/5) + 3,n_bootstrap);
    for n_bstrap = 1:n_bootstrap
        curr_bstrap_year_ind = bootstrap_random_year_ind(:,n_bstrap);
        
        curr_series_bootstrap_avg(:,n_bstrap) = mean(curr_series_for_bootstrap(:,curr_bstrap_year_ind),2);
    end
    
    curr_series_bootstrap_sorted = sort(curr_series_bootstrap_avg,2,'ascend');
    
    curr_series_bootstrap_2p5_97p5_bounds = (interp1(cdf_vec,curr_series_bootstrap_sorted',[0.025; 0.975]))';
    curr_series_bootstrap_5_95_bounds = (interp1(cdf_vec,curr_series_bootstrap_sorted',[0.05; 0.95]))';
    
    curr_color_vec = get(h(n_series),'Color');
    curr_linestyle = get(h(n_series),'LineStyle');
    curr_linewidth = get(h(n_series),'LineWidth');
    curr_ydata = get(h(n_series),'YData');
    
%     h_e = errorbar(time_inyear_smoothed,curr_ydata,86400*curr_series_bootstrap_2p5_97p5_bounds(:,2),86400*curr_series_bootstrap_2p5_97p5_bounds(:,1));
%     set(h_e,'Color',curr_color,'LineWidth',curr_linewidth)
    
    weight_white_reverse = -weight_white/(1 - weight_white);
    full_color_vec = (weight_white_reverse*[1 1 1]) + (1 - weight_white_reverse)*curr_color_vec;
    curr_series_bootstrap_test = eval(['smooth_endclip(',plot_series_specifiers_composite{n_series},',span)']);
    
    curr_h_ydata = get(h(n_series),'YData');
    outside_range_ind = find((curr_series_bootstrap_test < curr_series_bootstrap_5_95_bounds(:,1)) | (curr_series_bootstrap_test > curr_series_bootstrap_5_95_bounds(:,2)));
    outside_range_no_transition_ind = intersect(intersect(outside_range_ind - 1,outside_range_ind),outside_range_ind + 1);
    curr_h_ydata(outside_range_no_transition_ind) = NaN;
    set(h(n_series),'YData',curr_h_ydata)
    
    curr_series_bootstrap_test((curr_series_bootstrap_test >= curr_series_bootstrap_5_95_bounds(:,1)) & (curr_series_bootstrap_test <= curr_series_bootstrap_5_95_bounds(:,2))) = NaN;
    h_b(n_series) = line(time_inyear_smoothed,86400*curr_series_bootstrap_test,'Color',full_color_vec,'LineStyle',curr_linestyle,'LineWidth',curr_linewidth + 1);
    
end

xlim_bounds = [0 365];
set(gca,'xlim',xlim_bounds,'xtick',time_date_label,'xticklabel',date_label,'FontSize',14)
set(gca,'ylim',[-0.03 0.02],'ytick',(-0.03):0.005:0.02,'DataAspectRatio',[30 0.004 1])
hold on
line(xlim_bounds,[0 0],[0 0],'Color','k','LineStyle','-','LineWidth',0.5)
hold off
ylabel('Temp. tendency anomaly ( ^{o}C day^{-1})')
leg = legend(h_b,'Sum of processes','Total advection','Unexplained residual','location','eastoutside');
set(leg,'FontSize',10)
title('Sum of advective processes, total advective tendency, and unexplained residual','FontSize',8)

saveas(fig22,['Java_temp_budget_T_tend_anom_pIOD_composite_from_fluxes_adv_residual.pdf'])
close(fig22)
