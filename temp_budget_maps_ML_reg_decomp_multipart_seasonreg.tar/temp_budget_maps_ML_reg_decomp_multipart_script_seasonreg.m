% show maps of mixed layer temperature budget terms, with a decomposition based on regression with a process index (defined based on SSH, wind stress, currents,etc.).  The process index may be defined differently for different regions in the domain; the spatial boundaries of each individual box-averaged index are given in the arrays longwest_reg_qty, longeast_reg_qty, latsouth_reg_qty, and latnorth_reg_qty.

path(path,'~/Budget_calculations/')
path(path,'~/plotting_scripts/')
cd('/glade/scratch/adelman/POP_1977_start_JC/')


% define boundaries to carry out computations for

longwest = 103.0;
longeast = 118.0;
latsouth = -15.0;
latnorth = -5.0;


% define [lat lon] of 4 corners of averaging region

NE_corner = [-8.65 115.2];
NW_corner = [-6.65 105.2];
SW_corner = [-10.0 105.2];
SE_corner = [-10.0 114.5];


% define dates to use in regressions (must include all averaging dates)

% start_dates_reg = [(1994:1:2008)' (4*ones(15,1)) (1*ones(15,1))];
% end_dates_reg = [(1994:1:2008)' (7*ones(15,1)) (29*ones(15,1))];
% start_dates_reg = [1994 1 31];
% end_dates_reg = [2009 1 1];
% start_dates_reg = [1977 1 31];
% end_dates_reg = [2010 1 1];
% start_dates_reg = [(1977:1:2009)' (4*ones(33,1)) (30*ones(33,1))];
% end_dates_reg = [(1977:1:2009)' (8*ones(33,1)) (3*ones(33,1))];
% start_dates_reg = [(1977:1:2009)' (8*ones(33,1)) (3*ones(33,1))];
% end_dates_reg = [(1977:1:2009)' (11*ones(33,1)) (1*ones(33,1))];
% start_dates_reg = [(1979:1:2009)' (4*ones(31,1)) (30*ones(31,1))];
% end_dates_reg = [(1979:1:2009)' (8*ones(31,1)) (3*ones(31,1))];
% start_dates_reg = [(1979:1:2009)' (6*ones(31,1)) (29*ones(31,1))];
% end_dates_reg = [(1979:1:2009)' (9*ones(31,1)) (2*ones(31,1))];
start_dates_reg = [1979 1 1];
end_dates_reg = [2010 1 1];

% define dates to average

% start_dates_avg = [2006 05 15];
% end_dates_avg = [2006 06 14];
% start_dates_avg = [2006 05 30; 2007 06 29; 2008 05 30];
% end_dates_avg = [2006 07 04; 2007 08 03; 2008 07 04];
% start_dates_avg = [1994 04 10; 1997 08 08; 2003 06 04; 2006 05 30; 2007 06 24; 2008 05 05];
% end_dates_avg = [1994 05 30; 1997 09 27; 2003 07 24; 2006 07 19; 2007 08 13; 2008 06 24];
% start_dates_avg = [1994 04 30; 1997 04 30; 2003 04 30; 2006 04 30; 2007 04 30; 2008 04 30];
% end_dates_avg = [1994 09 02; 1997 09 02; 2003 09 02; 2006 09 02; 2007 09 02; 2008 09 02];
% start_dates_avg = [2006 04 30; 2007 04 30; 2008 04 30];
% end_dates_avg = [2006 09 02; 2007 09 02; 2008 09 02];
% start_dates_avg = [2003 04 30; 2006 04 30; 2007 04 30; 2008 04 30];
% end_dates_avg = [2003 08 03; 2006 08 03; 2007 08 03; 2008 08 03];
% start_dates_avg = [1982 04 30; 1983 04 30; 1987 04 30; 1994 04 30; 1997 04 30; 2003 04 30; 2006 04 30; 2007 04 30; 2008 04 30];
% end_dates_avg = [1982 08 03; 1983 08 03; 1987 08 03; 1994 08 03; 1997 08 03; 2003 08 03; 2006 08 03; 2007 08 03; 2008 08 03];
% start_dates_avg = [1982 08 03; 1983 08 03; 1987 08 03; 1994 08 03; 1997 08 03; 2003 08 03; 2006 08 03; 2007 08 03; 2008 08 03];
% end_dates_avg = [1982 11 01; 1983 11 01; 1987 11 01; 1994 11 01; 1997 11 01; 2003 11 01; 2006 11 01; 2007 11 01; 2008 11 01];
start_dates_avg = [1982 04 30; 1983 04 30; 1994 04 30; 1997 04 30; 2003 04 30; 2006 04 30; 2007 04 30; 2008 04 30];
end_dates_avg = [1982 08 03; 1983 08 03; 1994 08 03; 1997 08 03; 2003 08 03; 2006 08 03; 2007 08 03; 2008 08 03];
time_avg_specifier = 'pIOD_MayJul';
% start_dates_avg = [1982 06 29; 1983 06 29; 1994 06 29; 1997 06 29; 2003 06 29; 2006 06 29; 2007 06 29; 2008 06 29];
% end_dates_avg = [1982 09 02; 1983 09 02; 1994 09 02; 1997 09 02; 2003 09 02; 2006 09 02; 2007 09 02; 2008 09 02];
% time_avg_specifier = 'pIOD_JulAug';



% ent_compute_option = 1: no flux or tendency computed due to changing volume of the surface layer (except for the part due to changes at the surface)
% ent_compute_option = 2: entrainment tendencies are computed based on the residual between the sum of the already-computed budget terms and the actual temperature change
ent_compute_option = 2;


% reg_level_option = 1: first regression applied to raw output (e.g., regression of annual cycle and harmonics)
% reg_level_option = 2: carry out regression with another regressed quantity (e.g., seasonal cycle) already removed
reg_level_option = 2;


% splitting parameters
% ADJUSTABLE SETTING (search "ADJUSTABLE SETTING" all caps to find settings throughout script that may need to be changed for each different regression.)

% number of boxes in x- and y-directions to split for file loading and computation purposes
n_subsets_file_computation = [2 2];

% number of boxes in x- and y-directions to split for regression purposes
% ADJUSTABLE SETTING
n_subsets_regression = [4 4];
% n_subsets_regression = [14 9];
% n_subsets_regression = [14 2];


% file name base to save output of regressed budget
% ADJUSTABLE SETTING
if reg_level_option == 1
%     file_name_output = 'seasonal_Java_upwelling_ML_reg.mat';
%     file_name_output = 'seasonal_Java_upwelling_ML_v2_reg.mat';
%     file_name_base_output = 'seasonal_Java_ML_94_08_reg';
%     file_name_base_output = 'seasonal_Java_ML_06_08_reg_smalltest';
%     file_name_base_output = 'seasonal_Java_ML_77_09_reg';
%     file_name_base_output = 'seasonal_Java_ML_77_09_reg_v2';
    file_name_base_output = 'seasonal_Java_ML_79_09_reg';
%     file_name_base_output = 'seasonal_JulAug_Java_ML_79_09_reg';
end

% file name base containing previously regressed quantities
% ADJUSTABLE SETTING
if reg_level_option > 1
%     file_name_input = 'seasonal_Java_upwelling_ML_reg.mat';
%     file_name_input = 'seasonal_Java_upwelling_ML_v2_2_reg.mat';
%     file_name_base_input = 'seasonal_Java_ML_94_08_reg';
%     file_name_base_input = 'seasonal_Java_ML_06_08_reg_smalltest';
%     file_name_base_input = 'seasonal_Java_ML_77_09_reg';
    file_name_base_input = 'seasonal_Java_map_ML_79_09_reg';
%     file_name_base_input = 'seasonal_JulAug_Java_ML_79_09_reg';
end
    

% specify source file(s)

% nc_filenames = {'pop.h.nday5.JC.00300105-00301231.nc'};
nc_cell_array = struct2cell(dir('pop.h.nday5.JC.*0105-*1231.nc'));
nc_filenames = (nc_cell_array(1,:))';


% model year offset
year_offset = 1976;

% tavg for archived output (in days)
tavg_days = 5;



% specifiers for the regression and averaging range
% ADJUSTABLE SETTINGS

% reg_avg_text_specifier = 'seasonal decomposition, 2006-2008 Java upwelling onset composite';
% reg_avg_text_specifier = 'seasonal decomposition, 1994-2008 Java upwelling onset composite';
% reg_avg_text_specifier = 'Kelvin wave decomposition, 1994-2008 Java upwelling onset composite';
% reg_avg_text_specifier = 'Kelvin wave decomposition, 1994-2008 pIOD May-August composite';
% reg_avg_text_specifier = 'seasonal decomposition, 1994-2008 pIOD May-July composite';
% reg_avg_text_specifier = 'seasonal decomposition, 1977-2009 pIOD May-July composite';
% reg_avg_text_specifier = 'Kelvin wave decomposition, 1977-2009 pIOD May-July composite';
% reg_avg_text_specifier = 'Kelvin wave decomposition, 2002-2008 pIOD May-August composite';
% reg_avg_text_specifier = 'Kelvin SSH diff. wave decomposition, 1977-2009 pIOD May-July composite';
% % reg_avg_text_specifier = 'Wind forcing decomposition, zonal wind stress, 1977-2009 pIOD May-July composite';
% reg_avg_text_specifier = 'Wind forcing decomposition, 1977-2009 pIOD May-July composite';
% % reg_avg_text_specifier = 'Mesoscale merid. vel. decomposition, zonal wind stress, 1977-2009 pIOD May-July composite';
% reg_avg_text_specifier = 'Mesoscale merid. vel. decomposition, 1977-2009 pIOD May-July composite';
% reg_avg_text_specifier = 'Mesoscale merid. vel. decomposition, 1977-2009 pIOD August-October composite';
% reg_avg_text_specifier = 'Mesoscale merid. vel. decomposition, 1977-2009 pIOD May-July 5-day lag composite';
% reg_avg_text_specifier = 'seasonal decomposition, 1979-2009 pIOD May-July composite';
% reg_avg_text_specifier = 'Kelvin SSH diff. wave decomposition, 1979-2009 pIOD May-July composite';
% reg_avg_text_specifier = 'Local wind forcing decomposition, w/ Kelvin, cent. and SE Sumatra wstr removed, 1979-2009 pIOD May-July composite';
% reg_avg_text_specifier = 'Mesoscale merid. vel. decomposition, 1979-2009 pIOD May-July composite';
% reg_avg_text_specifier = 'seasonal decomposition, 1979-2009 pIOD July-August composite';
% reg_avg_text_specifier = 'Zonal wind forcing decomposition, 1979-2009 pIOD May-July composite';
% reg_avg_text_specifier = 'Merid. wind forcing decomposition, 1979-2009 pIOD May-July composite';
% reg_avg_text_specifier = 'Wind stress curl decomposition, 1979-2009 pIOD May-July composite';
% reg_avg_text_specifier = 'Kelvin SSH diff. wave decomposition, 1979-2009';
% reg_avg_text_specifier = 'Local wind forcing decomposition, 1979-2009';
% reg_avg_text_specifier = 'Mesoscale merid. vel. decomposition, 1979-2009';
% reg_avg_text_specifier = 'Lombok Strait merid. vel. decomposition, 1979-2009';
% reg_avg_text_specifier = 'Lombok Strait merid. vel. decomposition, w/ Kelvin removed, 1979-2009';
% reg_avg_text_specifier = 'Lombok Strait merid. vel. decomposition, w/ Kelvin, Sumatra wstr, and local wstr removed, 1979-2009';
% reg_avg_text_specifier = 'Sumatra wind forcing decomposition, w/ Kelvin removed, 1979-2009';
% reg_avg_text_specifier = 'SE Sumatra wind forcing decomposition, 1979-2009';
% reg_avg_text_specifier = 'Central Sumatra wind forcing decomposition, w/ Kelvin removed, 1979-2009';
reg_avg_text_specifier = 'Central Sumatra wind forcing decomposition, w/ SE Sumatra wstr removed, 1979-2009';
% reg_avg_text_specifier = 'Kelvin SSH diff. wave decomposition, w/ SE and cent. Sumatra wstr removed, 1979-2009';
% reg_avg_text_specifier = 'Sumatra combined wind forcing decomposition';
% reg_avg_file_specifier = 'seasonal_2006_Java_upwelling_onset_fixed_ML_nosurf_test';
% reg_avg_file_specifier = 'seasonal_2006_to_2008_Java_upwelling_onset_ML';
% reg_avg_file_specifier = 'seasonal_1994_to_2008_Java_upwelling_onset_ML';
% reg_avg_file_specifier = 'Kelvin_1994_to_2008_Java_upwelling_onset_ML';
% reg_avg_file_specifier = 'Kelvin_1994_to_2008_pIOD_MayAug_ML';
% reg_avg_file_specifier = 'seasonal_1994_to_2008_pIOD_MayJul_ML';
% reg_avg_file_specifier = 'Kelvin_2002_to_2008_pIOD_MayAug_ML';
% reg_avg_file_specifier = 'seasonal_1977_to_2009_pIOD_MayJul_ML';
% reg_avg_file_specifier = 'Kelvin_1977_to_2009_pIOD_MayJul_ML';
% reg_avg_file_specifier = 'Kelvin_diff_1977_to_2009_pIOD_MayJul_ML';
% reg_avg_file_specifier = 'wstr_local_1977_to_2009_pIOD_MayJul_ML';
% reg_avg_file_specifier = 'mesoscale_vvel_1977_to_2009_pIOD_MayJul_ML';
% reg_avg_file_specifier = 'mesoscale_vvel_1977_to_2009_pIOD_AugOct_ML';
% reg_avg_file_specifier = 'mesoscale_vvel_5lag_1977_to_2009_pIOD_MayJul_ML';
% reg_avg_file_specifier = 'seasonal_1979_to_2009_pIOD_MayJul_ML';
% reg_avg_file_specifier = 'Kelvin_diff_1979_to_2009_pIOD_MayJul_ML';
% reg_avg_file_specifier = 'wstr_local_1979_to_2009_pIOD_MayJul_ML';
% reg_avg_file_specifier = 'mesoscale_vvel_1979_to_2009_pIOD_MayJul_ML';
% reg_avg_file_specifier = 'seasonal_1979_to_2009_pIOD_JulAug_ML';
% reg_avg_file_specifier = 'wstr_zonal_local_1979_to_2009_pIOD_MayJul_ML';
% reg_avg_file_specifier = 'wstr_merid_local_1979_to_2009_pIOD_MayJul_ML';
% reg_avg_file_specifier = 'wstr_curl_local_1979_to_2009_pIOD_MayJul_ML';
% reg_avg_file_specifier = 'Java_Kelvin_diff_1979_to_2009_ML';
% reg_avg_file_specifier = 'Java_wstr_local_1979_to_2009_ML';
% reg_avg_file_specifier = 'Java_mesoscale_vvel_1979_to_2009_ML';
% reg_avg_file_specifier = 'Java_Lombok_vvel_10lead_1979_to_2009_ML';
% reg_avg_file_specifier = 'Java_map_Lombok_vvel_5lead_1979_to_2009_ML';
% reg_avg_file_specifier = 'Java_map_wstr_local_allderivs_1979_to_2009_ML';
% reg_avg_file_specifier = 'Java_map_mesoscale_vvel_withderiv_1979_to_2009_ML';
% reg_avg_file_specifier = 'Java_Lombok_vvel_10lead_rem_reg_Kelvin_1979_to_2009_ML';
% reg_avg_file_specifier = 'Java_map_wstr_Sumatra_allderivs_10lead_rem_reg_Kelvin_wstr_local_1979_to_2009_ML';
% reg_avg_file_specifier = 'Java_Kelvin_diff_20_lp_1979_to_2009_pIOD_MayJul_ML';
% reg_avg_file_specifier = 'Java_mesoscale_vvel_withderiv_20_lp_1979_to_2009_ML';
% reg_avg_file_specifier = 'Java_Lombok_vvel_10lead_rem_reg_Kelvin_wstr_Sumatra_Java_20_lp_1979_to_2009_ML';
% reg_avg_file_specifier = 'Java_wstr_Sumatra_allderivs_10lead_rem_reg_wstr_local_20_lp_1979_to_2009_ML';
% reg_avg_file_specifier = 'Java_map_Kelvin_diff_85_95_1979_to_2009_ML';
% reg_avg_file_specifier = 'Java_map_Lombok_vvel_5lead_rem_reg_Kelvin_wstr_Sumatra_Java_1979_to_2009_ML';
% reg_avg_file_specifier = 'Java_map_wstr_Sumatra_allderivs_10lead_rem_reg_Kelvin_1979_to_2009_ML';
% reg_avg_file_specifier = 'Java_map_wstr_local_allderivs_rem_reg_Kelvin_wstr_cent_SE_Sumatra_1979_to_2009_ML';
% reg_avg_file_specifier = 'Java_map_Lombok_vvel_5lead_rem_reg_Kelvin_wstr_Sumatra_local_1979_to_2009_ML';
% reg_avg_file_specifier = 'Java_map_wstr_SE_Sumatra_allderivs_5lead_1979_to_2009_ML';
% reg_avg_file_specifier = 'Java_map_wstr_cent_Sumatra_allderivs_10lead_1979_to_2009_ML';
% reg_avg_file_specifier = 'Java_map_Lombok_vvel_5lead_rem_reg_Kelvin_wstr_cent_SE_Sumatra_local_1979_to_2009_ML';
reg_avg_file_specifier = 'Java_map_wstr_cent_Sumatra_allderivs_10lead_rem_reg_wstr_SE_Sumatra_1979_to_2009_ML';
% reg_avg_file_specifier = 'Java_map_Kelvin_diff_85_95_rem_reg_wstr_SE_cent_Sumatra_1979_to_2009_ML';


% reg_var_specifier = 'Kelvin';
% reg_var_specifier = 'wstr_local';
% reg_var_specifier = 'mesoscale';
% reg_var_specifier = 'Lombok';
% reg_var_specifier = 'wstr_Sumatra';
% reg_var_specifier = 'wstr_SE_Sumatra';
reg_var_specifier = 'wstr_cent_Sumatra';


reg_avg_text_specifier_new = reg_avg_text_specifier;




if reg_level_option > 1
    reg_avg_text_specifier_new = reg_avg_text_specifier;
    reg_avg_file_specifier_new = reg_avg_file_specifier;
end


grid_res = 0.1;


% convert dates to model form
month_start_vec = [0; 31; 59; 90; 120; 151; 181; 212; 243; 273; 304; 334];

start_datenums_reg = (365*(start_dates_reg(:,1) - year_offset)) + month_start_vec(start_dates_reg(:,2)) + start_dates_reg(:,3);
end_datenums_reg = (365*(end_dates_reg(:,1) - year_offset)) + month_start_vec(end_dates_reg(:,2)) + end_dates_reg(:,3);
start_datenums_avg = (365*(start_dates_avg(:,1) - year_offset)) + month_start_vec(start_dates_avg(:,2)) + start_dates_avg(:,3);
end_datenums_avg = (365*(end_dates_avg(:,1) - year_offset)) + month_start_vec(end_dates_avg(:,2)) + end_dates_avg(:,3);


% if reg_level_option == 1

% model output source file(s)

TLAT = ncread(nc_filenames{1},'TLAT');
TLON = ncread(nc_filenames{1},'TLONG');
ULAT = ncread(nc_filenames{1},'ULAT');
ULON = ncread(nc_filenames{1},'ULONG');

z_t = ncread(nc_filenames{1},'z_t');
z_t = double(z_t);
z_w_top = ncread(nc_filenames{1},'z_w_top');
z_w_top = double(z_w_top);
z_w_bot = ncread(nc_filenames{1},'z_w_bot');
z_w_bot = double(z_w_bot);
dz = ncread(nc_filenames{1},'dz');


if reg_level_option == 1
    
    time = [];
    file_num_vec = [];
    in_file_ind_vec = [];
    for file_num = 1:length(nc_filenames)
        time_curr_source_file = ncread(nc_filenames{file_num},'time');
        
        time = [time; time_curr_source_file];
        
        file_num_vec = [file_num_vec; (file_num*ones(length(time_curr_source_file),1))];
        in_file_ind_vec = [in_file_ind_vec; ((1:1:length(time_curr_source_file))')];
    end
    
    
    % adjust time points to lie in centers of 5-day periods
    time = time - 2.5;
    
end


ind_inrange = find((TLON >= (longwest - (2*grid_res))) & (TLON <= (longeast + (2*grid_res))) & (TLAT >= (latsouth - (2*grid_res))) & (TLAT <= (latnorth + (2*grid_res))));
[lat_ind_mesh,lon_ind_mesh] = meshgrid((1:1:size(TLAT,2)),(1:1:size(TLON,1)));


lon_ind_min_inrange = min(lon_ind_mesh(ind_inrange));
lon_ind_max_inrange = max(lon_ind_mesh(ind_inrange));
lat_ind_min_inrange = min(lat_ind_mesh(ind_inrange));
lat_ind_max_inrange = max(lat_ind_mesh(ind_inrange));

lon_ind_inrange = (lon_ind_min_inrange:1:lon_ind_max_inrange)';
lat_ind_inrange = (lat_ind_min_inrange:1:lat_ind_max_inrange);


tlon = TLON(lon_ind_inrange,lat_ind_inrange);
tlat = TLAT(lon_ind_inrange,lat_ind_inrange);
ulon = ULON(lon_ind_inrange,lat_ind_inrange);
ulat = ULAT(lon_ind_inrange,lat_ind_inrange);



% compute size of subset boxes

subset_x_file_dim_size = ceil((length(lon_ind_inrange) - 3)./n_subsets_file_computation(1)) + 3;
subset_y_file_dim_size = ceil((length(lat_ind_inrange) - 3)./n_subsets_file_computation(2)) + 3;

subset_x_file_start_ind = 1 + ((subset_x_file_dim_size - 3)*(0:1:(n_subsets_file_computation(1) - 1)))';
subset_x_file_end_ind = [(subset_x_file_start_ind(1:(n_subsets_file_computation(1) - 1)) + (subset_x_file_dim_size - 1)); length(lon_ind_inrange)];
subset_y_file_start_ind = 1 + ((subset_y_file_dim_size - 3)*(0:1:(n_subsets_file_computation(2) - 1)));
subset_y_file_end_ind = [(subset_y_file_start_ind(1:(n_subsets_file_computation(2) - 1)) + (subset_y_file_dim_size - 1)); length(lat_ind_inrange)];


    
if reg_level_option > 1
    
    % load time variables for subsequent calculations
    load([file_name_base_input,'_1_1.mat'],'time','unique_time_ind','file_nums_in_time_range','file_num_vec','in_file_ind_vec')
    
    
    time_reg_level1 = time;
    time = time(unique_time_ind);
    
    unique_time_ind_reg_level1 = unique_time_ind;
    
    clear unique_time_ind
    
    reg_avg_text_specifier = reg_avg_text_specifier_new;
    reg_avg_file_specifier = reg_avg_file_specifier_new;
    
end




% find times in specified ranges
time_reg_ind_inrange = [];
for seg_ind = 1:size(start_dates_reg,1)
    curr_seg_time_reg_ind_inrange = find((time >= start_datenums_reg(seg_ind)) & (time < end_datenums_reg(seg_ind)));
    time_reg_ind_inrange = [time_reg_ind_inrange; curr_seg_time_reg_ind_inrange];
end

time_avg_ind_inrange = [];
for seg_ind = 1:size(start_dates_avg,1)
    curr_seg_time_avg_ind_inrange = find((time >= start_datenums_avg(seg_ind)) & (time < end_datenums_avg(seg_ind)));
    time_avg_ind_inrange = [time_avg_ind_inrange; curr_seg_time_avg_ind_inrange];
end



% remove possible duplication of times across files
[unique_times,unique_time_from_reg_ind,unique_time_rev_ind] = unique(time(time_reg_ind_inrange));
unique_time_ind = time_reg_ind_inrange(unique_time_from_reg_ind);

[time_avg_ind_inrange,~,time_avg_from_unique_reg_ind] = intersect(time_avg_ind_inrange,unique_time_ind);



% % COMMENT OUT STARTING HERE IF RECOVERING FROM ALREADY-SAVED .MAT FILE
% 
% if reg_level_option == 1
%     
%     % % use only files that contain times within specified time range
%     % file_nums_in_time_range = unique(file_num_vec(time_ind_inrange));
%     
%     % use all files in source_nc_filenames
%     file_nums_in_time_range = unique(file_num_vec);
%     
%     
%     curr_file_start_ind = 1;
%     
%     mean_ML_depth = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_times));
%     for file_num_ind = 1:length(file_nums_in_time_range)
%         file_num = file_nums_in_time_range(file_num_ind);
%         
%         time_curr_source_file = ncread(nc_filenames{file_num},'time');
%         
%     %     time_ind_infile = find(file_num_vec(time_ind_inrange) == file_num);
%     %     curr_time_ind_inrange = in_file_ind_vec(time_ind_inrange(time_ind_infile));
%     
%         time_ind_infile = find(file_num_vec(unique_time_ind) == file_num);
%         if isempty(time_ind_infile) == 1
%             continue
%         end
%         
%         curr_time_ind_inrange = in_file_ind_vec(unique_time_ind(time_ind_infile));
%     
%     
%         start_vector_nodepth = [lon_ind_min_inrange lat_ind_min_inrange min(curr_time_ind_inrange)];
%         size_vector_nodepth = [length(lon_ind_inrange) length(lat_ind_inrange) (max(curr_time_ind_inrange) - min(curr_time_ind_inrange) + 1)];
%         
%         
%         subsetting_in_time_ind = curr_time_ind_inrange - min(curr_time_ind_inrange) + 1;
%         
%         curr_file_end_ind = curr_file_start_ind - 1 + length(curr_time_ind_inrange);
%         
%         % load mixed layer depth
%         curr_mean_ML_depth = ncread(nc_filenames{file_num},'HMXL',start_vector_nodepth,size_vector_nodepth,ones(1,3));
%         mean_ML_depth(:,:,curr_file_start_ind:curr_file_end_ind) = curr_mean_ML_depth(:,:,subsetting_in_time_ind);
%         
%         curr_file_start_ind = curr_file_start_ind + length(curr_time_ind_inrange);
%         
%     end
%     
%     
%     % adjust for problems with the ML depth field
%     
%     problem_mask = zeros(size(mean_ML_depth));
%     
%     problem_mask((isnan(mean_ML_depth) == 1) | (mean_ML_depth == 0)) = 1;
%     
%     sum_problem_mask = squeeze(sum(sum(problem_mask,2),1));
%     problem_times_ind = find(sum_problem_mask > (2*min(sum_problem_mask)));
%     
%     for n_problem_ind = 1:length(problem_times_ind)
%         curr_problem_ind = problem_times_ind(n_problem_ind);
%         
%         if curr_problem_ind == 1
%             mean_ML_depth(:,:,1) = mean_ML_depth(:,:,2);
%         elseif curr_problem_ind == size(mean_ML_depth,3)
%             mean_ML_depth(:,:,size(mean_ML_depth,3)) = mean_ML_depth(:,:,size(mean_ML_depth,3) - 1);
%         else
%             mean_ML_depth(:,:,curr_problem_ind) = 0.5*(mean_ML_depth(:,:,curr_problem_ind - 1) + mean_ML_depth(:,:,curr_problem_ind + 1));
%         end
%     end
%     
%     
%     
%     z_w_top = ncread(nc_filenames{1},'z_w_top');
%     z_w_bot = ncread(nc_filenames{1},'z_w_bot');
%     
%     
%     
%     % create depth bound arrays
%     
%     top_depth_bound_array = 0*ones(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
%     % top_depth_bound_array = (double(z_w_top(2)))*ones(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
%     % bottom_depth_bound_array = repmat(mean_ML_depth(:,:,1),[1 1 length(unique_time_ind)]);    % this sets bottom depth bound to the mixed layer base
%     bottom_depth_bound_array = mean_ML_depth;    % this sets bottom depth bound to the mixed layer base
%     % bottom_depth_bound_array = (z_w_bot(7))*ones(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));;    % this sets bottom depth bound to the mixed layer base
%     
%     
%     % load remaining grid variables
%     
%     start_vector_i_j_only = [min(lon_ind_inrange) min(lat_ind_inrange)];
%     size_vector_i_j_only = [length(lon_ind_inrange) length(lat_ind_inrange)];
%     
%     hte = ncread(nc_filenames{1},'HTE',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
%     htn = ncread(nc_filenames{1},'HTN',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
%     dxt = ncread(nc_filenames{1},'DXT',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
%     dyt = ncread(nc_filenames{1},'DYT',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
%     dxu = ncread(nc_filenames{1},'DXU',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
%     dyu = ncread(nc_filenames{1},'DYU',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
%     tarea = ncread(nc_filenames{1},'TAREA',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
%     anglet = ncread(nc_filenames{1},'ANGLET',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
%     
%     
%     
%     % compute all depth indices needed for the mixed layer
%     
%     outside_depth_bounds = [min(min(min(top_depth_bound_array))) max(max(max(bottom_depth_bound_array)))];     % in cm
%     z_t_ind_inrange = find((z_t >= outside_depth_bounds(1)) & (z_t <= outside_depth_bounds(2)));
%     depth_ind_inrange = (max([1 (min(z_t_ind_inrange) - 1)]):1:min([length(z_t) (max(z_t_ind_inrange) + 1)]))';
%     
%     
%     
%     % load partial bottom cell grid variables
%     
%     KMT = ncread(nc_filenames{1},'KMT');
%     kmt = KMT(lon_ind_inrange,lat_ind_inrange);
%     clear KMT
%     
%     HT = ncread(nc_filenames{1},'HT');
%     ht = HT(lon_ind_inrange,lat_ind_inrange);
%     clear HT
%     
%     kmt_reshaped = reshape(kmt,[prod(size(kmt)) 1]);
%     ht_reshaped = reshape(ht,[prod(size(ht)) 1]);
%     
%     dzbc_vec = zeros(size(ht_reshaped));
%     not_land_ind = find(kmt_reshaped > 0);
%     dzbc_vec(not_land_ind) = ht(not_land_ind) - z_w_top(kmt_reshaped(not_land_ind));
%     dzbc = reshape(dzbc_vec,[length(lon_ind_inrange) length(lat_ind_inrange)]);
%     
%     
%     
%     % compute thickness of cells
%     
%     dzt = zeros(size(tlon,1),size(tlat,2),length(z_t));
%     for curr_k_ind = 1:length(z_t)
%         at_deepest_level_ind = find(kmt == curr_k_ind);
%         not_at_deepest_level_ind = find(kmt > curr_k_ind);
%         
%         dzt_curr_level = zeros(size(dzt,1),size(dzt,2));
%         dzt_curr_level(at_deepest_level_ind) = dzbc(at_deepest_level_ind);
%         dzt_curr_level(not_at_deepest_level_ind) = dz(curr_k_ind)*ones(length(not_at_deepest_level_ind),1);
%         
%         dzt(:,:,curr_k_ind) = dzt_curr_level;
%     end
%     
%     dzt_corner_ucells = NaN(size(dzt,1),size(dzt,2),size(dzt,3),4);
%     dzt_corner_ucells(1:(size(dzt,1) - 1),1:(size(dzt,2) - 1),:,1) = dzt(1:(size(dzt,1) - 1),1:(size(dzt,2) - 1),:);
%     dzt_corner_ucells(1:(size(dzt,1) - 1),1:(size(dzt,2) - 1),:,2) = dzt(2:size(dzt,1),1:(size(dzt,2) - 1),:);
%     dzt_corner_ucells(1:(size(dzt,1) - 1),1:(size(dzt,2) - 1),:,3) = dzt(1:(size(dzt,1) - 1),2:size(dzt,2),:);
%     dzt_corner_ucells(1:(size(dzt,1) - 1),1:(size(dzt,2) - 1),:,4) = dzt(2:size(dzt,1),2:size(dzt,2),:);
%     
%     dzt_east_wall = squeeze(min(dzt_corner_ucells(:,:,:,[1 2]),[],4));
%     dzt_north_wall = squeeze(min(dzt_corner_ucells(:,:,:,[1 3]),[],4));
%     dzu = squeeze(min(dzt_corner_ucells,[],4));
%     
%     
% end
% 
% 
% 
% 
% % regression from input time series
% 
% subset_x_reg_dim_size = (2*ceil((length(lon_ind_inrange) + 1)./(n_subsets_regression(1) + 1))) - 1;
% subset_y_reg_dim_size = (2*ceil((length(lat_ind_inrange) + 1)./(n_subsets_regression(2) + 1))) - 1;
% 
% subset_x_reg_start_ind = 1 + (((subset_x_reg_dim_size + 1)/2)*(0:1:(n_subsets_regression(1) - 1)))';
% subset_x_reg_end_ind = [(subset_x_reg_start_ind(1:(n_subsets_regression(1) - 1)) + (subset_x_reg_dim_size - 1)); length(lon_ind_inrange)];
% subset_y_reg_start_ind = 1 + (((subset_y_reg_dim_size + 1)/2)*(0:1:(n_subsets_regression(2) - 1)));
% subset_y_reg_end_ind = [(subset_y_reg_start_ind(1:(n_subsets_regression(2) - 1)) + (subset_y_reg_dim_size - 1)) length(lat_ind_inrange)];
% 
% 
% % weighting of regressions in spatial domain
% 
% standard_weighting_x = repmat((1/((subset_x_reg_dim_size + 1)/2))*[(1:1:((subset_x_reg_dim_size + 1)/2))'; (((subset_x_reg_dim_size - 1)/2):(-1):1)'],[1 subset_y_reg_dim_size]);
% standard_weighting_y = repmat((1/((subset_y_reg_dim_size + 1)/2))*[(1:1:((subset_y_reg_dim_size + 1)/2)) (((subset_y_reg_dim_size - 1)/2):(-1):1)],[subset_x_reg_dim_size 1]);
% standard_weighting = standard_weighting_x.*standard_weighting_y;
% 
% weighting_array_regression = zeros([length(lon_ind_inrange) length(lat_ind_inrange) n_subsets_regression]);
% for i_r = 1:n_subsets_regression(1)
%     curr_x_start_ind = subset_x_reg_start_ind(i_r);
%     curr_x_end_ind = subset_x_reg_end_ind(i_r);
%     curr_x_ind = (curr_x_start_ind:1:curr_x_end_ind)';
%     for j_r = 1:n_subsets_regression(2)
%         curr_y_start_ind = subset_y_reg_start_ind(j_r);
%         curr_y_end_ind = subset_y_reg_end_ind(j_r);
%         curr_y_ind = (curr_y_start_ind:1:curr_y_end_ind);
%         
%         weighting_array_regression(curr_x_ind,curr_y_ind,i_r,j_r) = standard_weighting(1:length(curr_x_ind),1:length(curr_y_ind));
%     end
% end
% 
% sum_weighting_array_regression_repmat = repmat(sum(sum(weighting_array_regression,4),3),[1 1 n_subsets_regression]);
% weighting_array_regression = weighting_array_regression./sum_weighting_array_regression_repmat;
% 
% 
% 
% 
% % % time array for seasonal harmonic regressions (with 3 harmonics)
% % % USE THIS AND COMMENT OUT THE ~250 LINES OF CODE AFTER REG_OPERATOR_T_ARRAY IF ONLY USING SEASONAL REGRESSIONS (WITH HARMONICS)
% % 
% % G_reg = [ones(length(unique_times),1) cos((2*pi/365)*unique_times) sin((2*pi/365)*unique_times) cos((2*pi/(365/2))*unique_times) sin((2*pi/(365/2))*unique_times) cos((2*pi/(365/3))*unique_times) sin((2*pi/(365/3))*unique_times) cos((2*pi/(365/4))*unique_times) sin((2*pi/(365/4))*unique_times)];
% % 
% % G_reg_array = repmat(reshape(G_reg,[1 1 size(G_reg)]),[n_subsets_regression 1 1]);
% % reg_operator_T_array = repmat(reshape(((((G_reg')*G_reg)^(-1))*((G_reg')))',[1 1 size(G_reg)]),[n_subsets_regression 1 1]);
% 
% 
% 
% 
% % % define boundaries of averaging for regression input time series in each subset region
% 
% % % ADJUSTABLE SETTING
% 
% 
% % % longwest_reg_qty = 90.0*ones(n_subsets_regression);
% % longwest_reg_qty = 85.0*ones(n_subsets_regression);
% % longeast_reg_qty = 95.0*ones(n_subsets_regression);
% % latsouth_reg_qty = -2.0*ones(n_subsets_regression);
% % latnorth_reg_qty = 2.0*ones(n_subsets_regression);
% % 
% % time_offset = -10;    % in days
% 
% 
% % longwest_reg_qty = tlon(subset_x_reg_start_ind,subset_y_reg_start_ind) - (grid_res/2);
% % longeast_reg_qty = tlon(subset_x_reg_end_ind,subset_y_reg_end_ind) + (grid_res/2);
% % latsouth_reg_qty = tlat(subset_x_reg_start_ind,subset_y_reg_start_ind) - (grid_res/2);
% % latnorth_reg_qty = tlat(subset_x_reg_end_ind,subset_y_reg_end_ind) + (grid_res/2);
% % 
% % time_offset = 0;    % in days
% 
% 
% % longwest_reg_qty = tlon(subset_x_reg_start_ind,subset_y_reg_start_ind) - (grid_res/2);
% % longeast_reg_qty = tlon(subset_x_reg_end_ind,subset_y_reg_start_ind) + (grid_res/2);
% % % latsouth_reg_qty = -12.5*ones(n_subsets_regression);
% % % latnorth_reg_qty = -11.5*ones(n_subsets_regression);
% % latsouth_reg_qty = -13*ones(n_subsets_regression);
% % latnorth_reg_qty = -11*ones(n_subsets_regression);
% % 
% % time_offset = 0;    % in days
% % % time_offset = -5;    % in days
% 
% 
% % longwest_reg_qty = 115.5*ones(n_subsets_regression);
% % longeast_reg_qty = 116.2*ones(n_subsets_regression);
% % latsouth_reg_qty = -8.5*ones(n_subsets_regression);
% % latnorth_reg_qty = -8.3*ones(n_subsets_regression);
% % 
% % % time_offset = -10;    % in days
% % time_offset = -5;    % in days
% 
% 
% % longwest_reg_qty = 95*ones(n_subsets_regression);
% % longeast_reg_qty = 103*ones(n_subsets_regression);
% % latsouth_reg_qty = -6*ones(n_subsets_regression);
% % latnorth_reg_qty = 0*ones(n_subsets_regression);
% % 
% % time_offset = -10;    % in days
% 
% 
% % longwest_reg_qty = 99*ones(n_subsets_regression);
% % longeast_reg_qty = 105*ones(n_subsets_regression);
% % latsouth_reg_qty = -6*ones(n_subsets_regression);
% % latnorth_reg_qty = -3*ones(n_subsets_regression);
% % 
% % time_offset = -5;    % in days
% 
% 
% longwest_reg_qty = 95*ones(n_subsets_regression);
% longeast_reg_qty = 100*ones(n_subsets_regression);
% latsouth_reg_qty = -3*ones(n_subsets_regression);
% latnorth_reg_qty = 0*ones(n_subsets_regression);
% 
% time_offset = -10;    % in days
% 
% 
% 
% 
% TLAT = ncread(nc_filenames{1},'TLAT');
% TLON = ncread(nc_filenames{1},'TLONG');
% 
% ind_inrange = find((TLON >= (min(min(longwest_reg_qty)) - (2*grid_res))) & (TLON <= (max(max(longeast_reg_qty)) + (2*grid_res))) & (TLAT >= (min(min(latsouth_reg_qty)) - (2*grid_res))) & (TLAT <= (max(max(latnorth_reg_qty)) + (2*grid_res))));
% [lat_ind_mesh,lon_ind_mesh] = meshgrid((1:1:size(TLAT,2)),(1:1:size(TLON,1)));
% 
% 
% lon_ind_min_inrange = min(lon_ind_mesh(ind_inrange));
% lon_ind_max_inrange = max(lon_ind_mesh(ind_inrange));
% lat_ind_min_inrange = min(lat_ind_mesh(ind_inrange));
% lat_ind_max_inrange = max(lat_ind_mesh(ind_inrange));
% 
% lon_ind_inrange_reg_qty = (lon_ind_min_inrange:1:lon_ind_max_inrange)';
% lat_ind_inrange_reg_qty = (lat_ind_min_inrange:1:lat_ind_max_inrange);
% 
% tlon_reg_qty = TLON(lon_ind_inrange_reg_qty,lat_ind_inrange_reg_qty);
% tlat_reg_qty = TLAT(lon_ind_inrange_reg_qty,lat_ind_inrange_reg_qty);
% ulon_reg_qty = ULON(lon_ind_inrange_reg_qty,lat_ind_inrange_reg_qty);
% ulat_reg_qty = ULAT(lon_ind_inrange_reg_qty,lat_ind_inrange_reg_qty);
% 
% 
% if reg_level_option == 1
%     unique_time_ind_reg_level1 = unique_time_ind;
%     time_reg_level1 = time;
% end
% 
% time_ind_offset = round(time_offset/tavg_days);
% % unique_time_ind_reg_qty = unique_time_ind + time_ind_offset;
% if reg_level_option == 1
%     unique_time_ind_reg_qty = unique_time_ind + time_ind_offset;
%     unique_times_reg_qty = time(unique_time_ind_reg_qty);
% else
%     unique_time_ind_reg_qty = unique_time_ind_reg_level1(unique_time_ind) + time_ind_offset;
%     unique_times_reg_qty = time_reg_level1(unique_time_ind_reg_qty);
% end
% 
% 
% curr_file_start_ind = 1;
% 
% SSH_reg_qty = NaN(length(lon_ind_inrange_reg_qty),length(lat_ind_inrange_reg_qty),length(unique_time_ind_reg_qty));
% % SSH_south_reg_qty = NaN(length(lon_ind_inrange_reg_qty),round(0.5*length(lat_ind_inrange_reg_qty)),length(unique_time_ind_reg_qty));
% % SSH_north_reg_qty = NaN(length(lon_ind_inrange_reg_qty),round(0.5*length(lat_ind_inrange_reg_qty)),length(unique_time_ind_reg_qty));
% tau_x_reg_qty = NaN(length(lon_ind_inrange_reg_qty),length(lat_ind_inrange_reg_qty),length(unique_time_ind_reg_qty));
% tau_y_reg_qty = NaN(length(lon_ind_inrange_reg_qty),length(lat_ind_inrange_reg_qty),length(unique_time_ind_reg_qty));
% uvel_surf_reg_qty = NaN(length(lon_ind_inrange_reg_qty),length(lat_ind_inrange_reg_qty),length(unique_time_ind_reg_qty));
% vvel_surf_reg_qty = NaN(length(lon_ind_inrange_reg_qty),length(lat_ind_inrange_reg_qty),length(unique_time_ind_reg_qty));
% for file_num = 1:length(nc_filenames)
%     time_curr_source_file = ncread(nc_filenames{file_num},'time');
%     
%     time_ind_infile = find(file_num_vec(unique_time_ind_reg_qty) == file_num);
%     if isempty(time_ind_infile) == 1
%         continue
%     end
%     
%     curr_time_ind_inrange = in_file_ind_vec(unique_time_ind_reg_qty(time_ind_infile));
%     
%     
%     start_vector_nodepth_reg_qty = [min(lon_ind_inrange_reg_qty) min(lat_ind_inrange_reg_qty) min(curr_time_ind_inrange)];
%     size_vector_nodepth_reg_qty = [length(lon_ind_inrange_reg_qty) length(lat_ind_inrange_reg_qty) (max(curr_time_ind_inrange) - min(curr_time_ind_inrange) + 1)];
%     start_vector_surf_only_reg_qty = [min(lon_ind_inrange_reg_qty) min(lat_ind_inrange_reg_qty) 1 min(curr_time_ind_inrange)];
%     size_vector_surf_only_reg_qty = [length(lon_ind_inrange_reg_qty) length(lat_ind_inrange_reg_qty) 1 (max(curr_time_ind_inrange) - min(curr_time_ind_inrange) + 1)];
%     
% 
% %     if file_num == 1
%     if curr_file_start_ind == 1
%         dxt = ncread(nc_filenames{1},'DXT',start_vector_nodepth_reg_qty(1:2),size_vector_nodepth_reg_qty(1:2),ones(1,2));
%         dyt = ncread(nc_filenames{1},'DYT',start_vector_nodepth_reg_qty(1:2),size_vector_nodepth_reg_qty(1:2),ones(1,2));
%         dxu = ncread(nc_filenames{1},'DXU',start_vector_nodepth_reg_qty(1:2),size_vector_nodepth_reg_qty(1:2),ones(1,2));
%         dyu = ncread(nc_filenames{1},'DYU',start_vector_nodepth_reg_qty(1:2),size_vector_nodepth_reg_qty(1:2),ones(1,2));
%         tarea = ncread(nc_filenames{1},'TAREA',start_vector_nodepth_reg_qty(1:2),size_vector_nodepth_reg_qty(1:2),ones(1,2));
%     end
%     
%     
%     subsetting_in_time_ind = curr_time_ind_inrange - min(curr_time_ind_inrange) + 1;
%     
%     curr_file_end_ind = curr_file_start_ind - 1 + length(curr_time_ind_inrange);
%     
%     
%     curr_SSH = ncread(nc_filenames{file_num},'SSH',start_vector_nodepth_reg_qty,size_vector_nodepth_reg_qty,ones(1,3));
%     SSH_reg_qty(:,:,curr_file_start_ind:curr_file_end_ind) = curr_SSH(:,:,subsetting_in_time_ind);
% %     curr_SSH_south = ncread(nc_filenames{file_num},'SSH',start_vector_nodepth_reg_qty - [0 30 0],round([1 0.5 1].*size_vector_nodepth_reg_qty),ones(1,3));
% % %     curr_SSH_south = ncread(nc_filenames{file_num},'SSH',start_vector_nodepth_reg_qty - [0 50 0],round([1 0.5 1].*size_vector_nodepth_reg_qty),ones(1,3));
% %     SSH_south_reg_qty(:,:,curr_file_start_ind:curr_file_end_ind) = curr_SSH_south(:,:,subsetting_in_time_ind);
% %     curr_SSH_north = ncread(nc_filenames{file_num},'SSH',start_vector_nodepth_reg_qty + [0 50 0],round([1 0.5 1].*size_vector_nodepth_reg_qty),ones(1,3));
% %     SSH_north_reg_qty(:,:,curr_file_start_ind:curr_file_end_ind) = curr_SSH_north(:,:,subsetting_in_time_ind);
%     curr_tau_x = ncread(nc_filenames{file_num},'TAUX',start_vector_nodepth_reg_qty,size_vector_nodepth_reg_qty,ones(1,3));
%     tau_x_reg_qty(:,:,curr_file_start_ind:curr_file_end_ind) = curr_tau_x(:,:,subsetting_in_time_ind);
%     curr_tau_y = ncread(nc_filenames{file_num},'TAUY',start_vector_nodepth_reg_qty,size_vector_nodepth_reg_qty,ones(1,3));
%     tau_y_reg_qty(:,:,curr_file_start_ind:curr_file_end_ind) = curr_tau_y(:,:,subsetting_in_time_ind);
%     curr_uvel_surf = squeeze(ncread(nc_filenames{file_num},'UVEL',start_vector_surf_only_reg_qty,size_vector_surf_only_reg_qty,ones(1,4)));
%     uvel_surf_reg_qty(:,:,curr_file_start_ind:curr_file_end_ind) = curr_uvel_surf(:,:,subsetting_in_time_ind);
%     curr_vvel_surf = squeeze(ncread(nc_filenames{file_num},'VVEL',start_vector_surf_only_reg_qty,size_vector_surf_only_reg_qty,ones(1,4)));
%     vvel_surf_reg_qty(:,:,curr_file_start_ind:curr_file_end_ind) = curr_vvel_surf(:,:,subsetting_in_time_ind);
%     
%     curr_file_start_ind = curr_file_start_ind + length(curr_time_ind_inrange);
%     
% end
% 
% 
% % SSH_Kelvin_diff_reg_qty = NaN(size(SSH_reg_qty));
% % SSH_Kelvin_diff_reg_qty(:,1:size(SSH_south_reg_qty,2),:) = SSH_reg_qty(:,1:size(SSH_south_reg_qty,2),:) - SSH_south_reg_qty;
% % SSH_Kelvin_diff_reg_qty(:,(size(SSH_south_reg_qty,2) + 1):size(SSH_reg_qty,2),:) = SSH_reg_qty(:,(size(SSH_south_reg_qty,2) + 1):size(SSH_reg_qty,2),:) - SSH_north_reg_qty;
% % % SSH_Kelvin_diff_reg_qty(:,1:size(SSH_south_reg_qty,2),:) = SSH_reg_qty(:,1:size(SSH_south_reg_qty,2),:) - (2*SSH_south_reg_qty);
% 
% 
% 
% % compute wind stress curl
% 
% d_tau_y_dx = NaN(size(tau_y_reg_qty));
% dyu_tau_y = repmat(dyu,[1 1 size(tau_y_reg_qty,3)]).*tau_y_reg_qty;
% dyu_tau_y_midlat = dyu_tau_y(:,2:size(tau_y_reg_qty,2),:) - (diff(dyu_tau_y,1,2)/2);
% d_tau_y_dx(2:size(d_tau_y_dx,1),2:size(d_tau_y_dx,2),:) = repmat(1./tarea(2:size(tarea,1),2:size(tarea,2)),[1 1 size(d_tau_y_dx,3)]).*diff(dyu_tau_y_midlat,1,1);
% d_tau_x_dy = NaN(size(tau_x_reg_qty));
% dxu_tau_x = repmat(dxu,[1 1 size(tau_x_reg_qty,3)]).*tau_x_reg_qty;
% dxu_tau_x_midlon = dxu_tau_x(2:size(tau_x_reg_qty,1),:,:) - (diff(dxu_tau_x,1,1)/2);
% d_tau_x_dy(2:size(d_tau_x_dy,1),2:size(d_tau_x_dy,2),:) = repmat(1./tarea(2:size(tarea,1),2:size(tarea,2)),[1 1 size(d_tau_x_dy,3)]).*diff(dxu_tau_x_midlon,1,2);
% 
% tau_curl_reg_qty = d_tau_y_dx - d_tau_x_dy;
% 
% d_tau_y_dx_reg_qty = d_tau_y_dx;
% d_tau_x_dy_reg_qty = d_tau_x_dy;
% 
% clear dyu_tau_* dxu_tau_* d_tau_y_dx d_tau_x_dy
% 
% 
% d_tau_x_dx = NaN(size(tau_x_reg_qty));
% dyu_tau_x = repmat(dyu,[1 1 size(tau_x_reg_qty,3)]).*tau_x_reg_qty;
% dyu_tau_x_midlat = dyu_tau_x(:,2:size(tau_x_reg_qty,2),:) - (diff(dyu_tau_x,1,2)/2);
% d_tau_x_dx(2:size(d_tau_x_dx,1),2:size(d_tau_x_dx,2),:) = repmat(1./tarea(2:size(tarea,1),2:size(tarea,2)),[1 1 size(d_tau_x_dx,3)]).*diff(dyu_tau_x_midlat,1,1);
% d_tau_y_dy = NaN(size(tau_y_reg_qty));
% dxu_tau_y = repmat(dxu,[1 1 size(tau_y_reg_qty,3)]).*tau_y_reg_qty;
% dxu_tau_y_midlon = dxu_tau_y(2:size(tau_y_reg_qty,1),:,:) - (diff(dxu_tau_y,1,1)/2);
% d_tau_y_dy(2:size(d_tau_y_dy,1),2:size(d_tau_y_dy,2),:) = repmat(1./tarea(2:size(tarea,1),2:size(tarea,2)),[1 1 size(d_tau_y_dy,3)]).*diff(dxu_tau_y_midlon,1,2);
% 
% d_tau_x_dx_reg_qty = d_tau_x_dx;
% d_tau_y_dy_reg_qty = d_tau_y_dy;
% 
% clear d_tau_x_dx d_tau_y_dy
% 
% 
% % band-passing current velocities for mesoscale frequencies (20- to 180-day periods)
% 
% df = 1/(5*length(unique_time_ind_reg_qty));
% f_vec = df*(mod((0:1:(length(unique_time_ind_reg_qty) - 1))' + floor(length(unique_time_ind)/2),length(unique_time_ind)) - floor(length(unique_time_ind)/2));
% % erf_filter = 0.5*(erf(3600*(abs(f_vec) - (1/180))) - erf(400*(abs(f_vec) - (1/20))));
% erf_filter = 0.5*(erf(900*(abs(f_vec) - (1/180))) - erf(100*(abs(f_vec) - (1/20))));
% 
% % screen for occasional NaNs
% uvel_surf_reg_qty_zeronans = uvel_surf_reg_qty;
% nan_uvel_surf_ind = find(isnan(uvel_surf_reg_qty_zeronans) == 1);
% uvel_surf_reg_qty_zeronans(nan_uvel_surf_ind) = 0;
% vvel_surf_reg_qty_zeronans = vvel_surf_reg_qty;
% nan_vvel_surf_ind = find(isnan(vvel_surf_reg_qty_zeronans) == 1);
% vvel_surf_reg_qty_zeronans(nan_vvel_surf_ind) = 0;
% 
% fft_uvel_surf_reg_qty = fft(uvel_surf_reg_qty,[],3);
% fft_vvel_surf_reg_qty = fft(vvel_surf_reg_qty,[],3);
% 
% uvel_surf_bandpassed_reg_qty = ifft(repmat(reshape(erf_filter,[1 1 length(f_vec)]),[size(uvel_surf_reg_qty,1) size(uvel_surf_reg_qty,2) 1]).*fft_uvel_surf_reg_qty,[],3);
% vvel_surf_bandpassed_reg_qty = ifft(repmat(reshape(erf_filter,[1 1 length(f_vec)]),[size(vvel_surf_reg_qty,1) size(vvel_surf_reg_qty,2) 1]).*fft_vvel_surf_reg_qty,[],3);
% 
% uvel_surf_bandpassed_reg_qty(nan_uvel_surf_ind) = NaN;
% vvel_surf_bandpassed_reg_qty(nan_vvel_surf_ind) = NaN;
% 
% 
% d_vvel_surf_bandpassed_dx_reg_qty = NaN(size(vvel_surf_bandpassed_reg_qty));
% dyu_vvel_surf_bandpassed = repmat(dyu,[1 1 size(tau_y_reg_qty,3)]).*vvel_surf_bandpassed_reg_qty;
% dyu_vvel_surf_bandpassed_midlat = dyu_vvel_surf_bandpassed(:,2:size(vvel_surf_bandpassed_reg_qty,2),:) - (diff(dyu_vvel_surf_bandpassed,1,2)/2);
% d_vvel_surf_bandpassed_dx_reg_qty(2:size(d_vvel_surf_bandpassed_dx_reg_qty,1),2:size(d_vvel_surf_bandpassed_dx_reg_qty,2),:) = repmat(1./tarea(2:size(tarea,1),2:size(tarea,2)),[1 1 size(d_vvel_surf_bandpassed_dx_reg_qty,3)]).*diff(dyu_vvel_surf_bandpassed_midlat,1,1);
% 
% 
% 
% 
% 
% % % input field(s) -- Adjust this based on field being used (e.g., SSH, wind stress, velocity) for regression.  Also specify grid(s) for input fields, i.e. 'tgrid' or 'ugrid'.
% 
% % % ADJUSTABLE SETTING
% 
% % input_reg_qty = {SSH_Kelvin_diff_reg_qty};
% % grid_input_reg_qty = {'tgrid'};
% 
% % input_reg_qty = {tau_x_reg_qty tau_y_reg_qty tau_curl_reg_qty};
% % grid_input_reg_qty = {'ugrid' 'ugrid' 'tgrid'};
% 
% % input_reg_qty = {vvel_surf_bandpassed_reg_qty};
% % grid_input_reg_qty = {'ugrid'};
% 
% % input_reg_qty = {tau_x_reg_qty};
% % grid_input_reg_qty = {'ugrid'};
% % input_reg_qty = {tau_y_reg_qty};
% % grid_input_reg_qty = {'ugrid'};
% % input_reg_qty = {tau_curl_reg_qty};
% % grid_input_reg_qty = {'tgrid'};
% 
% % input_reg_qty = {vvel_surf_reg_qty};
% % grid_input_reg_qty = {'ugrid'};
% 
% input_reg_qty = {tau_x_reg_qty tau_y_reg_qty d_tau_x_dx_reg_qty d_tau_x_dy_reg_qty d_tau_y_dx_reg_qty d_tau_y_dy_reg_qty};
% grid_input_reg_qty = {'ugrid' 'ugrid' 'tgrid' 'tgrid' 'tgrid' 'tgrid'};
% 
% % input_reg_qty = {vvel_surf_bandpassed_reg_qty d_vvel_surf_bandpassed_dx_reg_qty};
% % grid_input_reg_qty = {'ugrid' 'tgrid'};
% 
% 
% 
% 
% n_input_timeseries = length(grid_input_reg_qty);
% 
% input_timeseries_array = NaN([n_subsets_regression length(unique_time_ind_reg_qty) n_input_timeseries]);
% for n_input = 1:n_input_timeseries
%     curr_input_timeseries = input_reg_qty{n_input};
%     curr_grid_input = grid_input_reg_qty{n_input};
%     
%     nan_ind = find((isnan(curr_input_timeseries) == 1) | (curr_input_timeseries == 0));
%     curr_input_timeseries_zeronans = curr_input_timeseries;
%     curr_input_timeseries_zeronans(nan_ind) = 0;
%     
%     for i_r = 1:n_subsets_regression(1)
%         for j_r = 1:n_subsets_regression(2)
%             
%             if strcmp(curr_grid_input,'tgrid') == 1
%                 spatial_ind_reg_qty = find((tlon_reg_qty >= longwest_reg_qty(i_r,j_r)) & (tlon_reg_qty <= longeast_reg_qty(i_r,j_r)) & (tlat_reg_qty >= latsouth_reg_qty(i_r,j_r)) & (tlat_reg_qty <= latnorth_reg_qty(i_r,j_r)));
%             else
%                 spatial_ind_reg_qty = find((ulon_reg_qty >= longwest_reg_qty(i_r,j_r)) & (ulon_reg_qty <= longeast_reg_qty(i_r,j_r)) & (ulat_reg_qty >= latsouth_reg_qty(i_r,j_r)) & (ulat_reg_qty <= latnorth_reg_qty(i_r,j_r)));
%             end
%             
%             in_box_reg_qty_avg_mask = zeros(size_vector_nodepth_reg_qty([1 2]));
%             in_box_reg_qty_avg_mask(spatial_ind_reg_qty) = 1;
%             in_box_reg_qty_mask = repmat(in_box_reg_qty_avg_mask,[1 1 length(unique_time_ind_reg_qty)]);
%             in_box_reg_qty_mask(nan_ind) = 0;
%             
%             input_timeseries_array(i_r,j_r,:,n_input) = sum(sum(in_box_reg_qty_mask.*curr_input_timeseries_zeronans,2),1)./sum(sum(in_box_reg_qty_mask,2),1);
%             % normalize by standard deviation (for more stable multivariate regressions)
%             input_timeseries_array(i_r,j_r,:,n_input) = input_timeseries_array(i_r,j_r,:,n_input)/(std(input_timeseries_array(i_r,j_r,:,n_input)));
%             
%         end
%     end
%     
%     
%     % remove annual cycle and harmonics
%     
%     G_seasonal_reg = [ones(length(unique_times_reg_qty),1) cos((2*pi/365)*unique_times_reg_qty) sin((2*pi/365)*unique_times_reg_qty) cos((2*pi/(365/2))*unique_times_reg_qty) sin((2*pi/(365/2))*unique_times_reg_qty) cos((2*pi/(365/3))*unique_times_reg_qty) sin((2*pi/(365/3))*unique_times_reg_qty) cos((2*pi/(365/4))*unique_times_reg_qty) sin((2*pi/(365/4))*unique_times_reg_qty)];
%     
%     m_seasonal_reg_qty = (((G_seasonal_reg')*G_seasonal_reg)^(-1))*((G_seasonal_reg')*(reshape(input_timeseries_array(:,:,:,n_input),[prod(n_subsets_regression) length(unique_time_ind_reg_qty)])'));
%     
%     curr_input_timeseries_array_noreg = input_timeseries_array(:,:,:,n_input) - reshape((G_seasonal_reg*m_seasonal_reg_qty),[n_subsets_regression length(unique_time_ind_reg_qty)]);
%     
%     input_timeseries_array(:,:,:,n_input) = curr_input_timeseries_array_noreg;
%     
% end
% 
% 
% 
% % % ADJUSTABLE SETTING (comment out if undesired)
% % 
% % % low-pass index or indices
% % 
% % lp_threshold = 1/20;    % low-pass cutoff frequency
% % steepness_factor = 5;
% % [input_timeseries_array_lp,~,~] = bandpass_err_fcn(input_timeseries_array,3,tavg_days,(2/3)/(tavg_days*size(input_timeseries_array,3)),lp_threshold,5,1,1,0,0);
% 
% 
% 
% % ADJUSTABLE SETTING (comment out if undesired)
% 
% % remove influence of another index
% 
% % primary_input_timeseries_array = input_timeseries_array;
% % % % load('temp_budget_Java_map_Kelvin_diff_85_95_1979_to_2009_ML_seasonreg.mat','input_timeseries_array')
% % % % input_timeseries_Kelvin = repmat(input_timeseries_array(1,1,:,:),[14 9 1 1]);
% % % % input_timeseries_array_to_rem_reg(:,:,:,1) = input_timeseries_Kelvin;
% % % % load('temp_budget_Java_map_wstr_local_allderivs_1979_to_2009_ML_seasonreg.mat','input_timeseries_array')
% % % % input_timeseries_wstr_local = input_timeseries_array;
% % % % input_timeseries_array_to_rem_reg(:,:,:,1) = input_timeseries_Kelvin;
% % % % input_timeseries_array_to_rem_reg(:,:,:,2:7) = input_timeseries_wstr_local;
% % % % input_timeseries_array_to_rem_reg = input_timeseries_array;
% % % % load('temp_budget_Java_Kelvin_diff_20_lp_1979_to_2009_ML_seasonreg.mat','input_timeseries_array')
% % % % input_timeseries_Kelvin = repmat(input_timeseries_array(1,1,:,:),[12 4]);
% % % % load('temp_budget_Java_map_wstr_Sumatra_allderivs_10lead_rem_reg_Kelvin_wstr_local_1979_to_2009_ML_seasonreg.mat','input_timeseries_array')
% % % % load('temp_budget_Java_map_wstr_Sumatra_allderivs_10lead_rem_reg_Kelvin_1979_to_2009_ML_seasonreg.mat','input_timeseries_array')
% % % % input_timeseries_wstr_Sumatra = repmat(input_timeseries_array(1,1,:,:),[14 9 1 1]);
% % % % load('temp_budget_Java_map_wstr_cent_Sumatra_allderivs_10lead_rem_reg_Kelvin_1979_to_2009_ML_seasonreg.mat','input_timeseries_array')
% % % % input_timeseries_wstr_cent_Sumatra = repmat(input_timeseries_array(1,1,:,:),[14 9 1 1]);
% % % % load('temp_budget_Java_map_wstr_SE_Sumatra_allderivs_5lead_rem_reg_Kelvin_wstr_cent_Sumatra_1979_to_2009_ML_seasonreg.mat','input_timeseries_array')
% % % % input_timeseries_wstr_SE_Sumatra = repmat(input_timeseries_array(1,1,:,:),[14 9 1 1]);
% % load('temp_budget_Java_map_wstr_SE_Sumatra_allderivs_5lead_1979_to_2009_ML_seasonreg.mat','input_timeseries_array')
% % input_timeseries_wstr_SE_Sumatra = repmat(input_timeseries_array(1,1,:,:),[4 4 1 1]);
% % load('temp_budget_Java_map_wstr_cent_Sumatra_allderivs_10lead_rem_reg_wstr_SE_Sumatra_1979_to_2009_ML_seasonreg.mat','input_timeseries_array')
% % input_timeseries_wstr_cent_Sumatra = repmat(input_timeseries_array(1,1,:,:),[4 4 1 1]);
% % % load('temp_budget_Java_map_Kelvin_diff_85_95_rem_reg_wstr_SE_cent_Sumatra_1979_to_2009_ML_seasonreg.mat','input_timeseries_array')
% % % input_timeseries_Kelvin = repmat(input_timeseries_array(1,1,:,:),[14 9 1 1]);
% % % load('temp_budget_Java_map_wstr_local_allderivs_rem_reg_Kelvin_wstr_cent_SE_Sumatra_1979_to_2009_ML_seasonreg.mat','input_timeseries_array')
% % % input_timeseries_wstr_local = input_timeseries_array;
% % % % input_timeseries_array_to_rem_reg(:,:,:,1) = input_timeseries_Kelvin;
% % % % input_timeseries_array_to_rem_reg(:,:,:,2:7) = input_timeseries_wstr_cent_Sumatra;
% % % % input_timeseries_array_to_rem_reg(:,:,:,8:13) = input_timeseries_wstr_SE_Sumatra;
% % % % input_timeseries_array_to_rem_reg(:,:,:,14:19) = input_timeseries_wstr_local;
% % input_timeseries_array_to_rem_reg(:,:,:,1:6) = input_timeseries_wstr_SE_Sumatra;
% % input_timeseries_array_to_rem_reg(:,:,:,7:12) = input_timeseries_wstr_cent_Sumatra;
% % % input_timeseries_array_to_rem_reg(:,:,:,13) = input_timeseries_Kelvin;
% % % input_timeseries_array_to_rem_reg(:,:,:,14:19) = input_timeseries_wstr_local;
% % % 
% % % % clear input_timeseries_array
% % % % % rem_reg_input_timeseries = squeeze(input_timeseries_array_to_rem_reg(1,1,:));
% % 
% % input_timeseries_array = NaN(size(primary_input_timeseries_array));
% % for i_r = 1:size(primary_input_timeseries_array,1)
% %     for j_r = 1:size(primary_input_timeseries_array,2)
% %         rem_reg_input_timeseries = squeeze(input_timeseries_array_to_rem_reg(i_r,j_r,:,:));
% %         curr_rem_reg_timeseries = (rem_reg_input_timeseries*(((rem_reg_input_timeseries')*rem_reg_input_timeseries)^(-1))*(rem_reg_input_timeseries'))*(squeeze(primary_input_timeseries_array(i_r,j_r,:,:)));
% %         
% %         input_timeseries_array(i_r,j_r,:,:) = reshape(squeeze(primary_input_timeseries_array(i_r,j_r,:,:)) - curr_rem_reg_timeseries,[1 1 size(input_timeseries_array,3) size(input_timeseries_array,4)]);
% %     end
% % end
% 
% 
% save(['temp_budget_',reg_avg_file_specifier,'_seasonreg.mat'],'input_timeseries_array','-v7.3')
% 
% 
% 
% % subset times for regressions (in seasonal cycle)
% 
% t_start_reg = [1 1; 1 31; 3 2; 4 1; 5 1; 5 31; 6 30; 8 4; 9 3; 10 3; 11 2; 12 2];
% % t_end_reg = [4 1; 5 1; 5 31; 6 30; 7 30; 8 29; 9 28; 11 2; 12 2; 1 1; 1 31; 3 2];
% t_reg_seg_length_days = 90;
% t_start_daynums = mod(datenum([(1990*ones(size(t_start_reg,1),1)) t_start_reg]) - datenum([1990 1 1]),365);
% % t_end_daynum = mod(datenum([(1990*ones(size(t_start_reg,1),1)) t_start_reg]) - datenum([1990 1 1]),365);
% t_end_daynums = mod(t_start_daynums + t_reg_seg_length_days,365);
% t_centers = mod(t_start_daynums + ((mod(t_end_daynums - t_start_daynums + 182.5,365) - 182.5)/2),365);
% 
% time_daynums = mod(time(unique_time_ind),365);
% time_ind_subset_reg_cellarray = cell(size(t_start_reg,1),1);
% time_weighting_subset_reg_cellarray = cell(size(t_start_reg,1),1);
% G_reg_cellarray = cell(size(t_start_reg,1),1);
% reg_operator_T_cellarray = cell(size(t_start_reg,1),1);
% for t_r = 1:length(time_ind_subset_reg_cellarray)
%     curr_start_daynum = t_start_daynums(t_r);
%     curr_end_daynum = t_end_daynums(t_r);
%     curr_center = t_centers(t_r);
%     curr_center_before = t_centers(mod(t_r - 1 - 1,size(t_start_reg,1)) + 1);
%     curr_center_after = t_centers(mod(t_r + 1 - 1,size(t_start_reg,1)) + 1);
%     
%     curr_time_ind_subset_reg = find((mod(time_daynums - curr_start_daynum + 182.5,365) - 182.5 >= 0) & (mod(time_daynums - curr_end_daynum + 182.5,365) - 182.5 < 0));
%     
%     curr_weighting_before_center = (mod(time_daynums(curr_time_ind_subset_reg) - curr_center_before + 182.5,365) - 182.5)/(mod(curr_center - curr_center_before + 182.5,365) - 182.5);
%     curr_weighting_after_center = (mod(-time_daynums(curr_time_ind_subset_reg) + curr_center_after + 182.5,365) - 182.5)/(mod(-curr_center + curr_center_after + 182.5,365) - 182.5);
%     curr_weighting_subset_reg = zeros(length(curr_time_ind_subset_reg),1);
%     curr_weighting_before_ind = find((curr_weighting_before_center > 0) & (curr_weighting_before_center <= 1));
%     curr_weighting_after_ind = find((curr_weighting_after_center > 0) & (curr_weighting_after_center <= 1));
%     curr_weighting_subset_reg(curr_weighting_before_ind) = curr_weighting_before_center(curr_weighting_before_ind);
%     curr_weighting_subset_reg(curr_weighting_after_ind) = curr_weighting_after_center(curr_weighting_after_ind);
%     
%     time_ind_subset_reg_cellarray{t_r} = curr_time_ind_subset_reg;
%     time_weighting_subset_reg_cellarray{t_r} = curr_weighting_subset_reg;
%     
%     
%     
%     G_reg_array = NaN([n_subsets_regression length(curr_time_ind_subset_reg) n_input_timeseries]);
%     reg_operator_T_array = NaN([n_subsets_regression length(curr_time_ind_subset_reg) n_input_timeseries]);
%     for i_r = 1:n_subsets_regression(1)
%         for j_r = 1:n_subsets_regression(2)
%             % G_reg = [ones(length(unique_times_reg_qty),1) squeeze(input_timeseries_array(i_r,j_r,:))];
%             curr_G_reg = squeeze(input_timeseries_array(i_r,j_r,curr_time_ind_subset_reg,:));
%             
%             G_reg_array(i_r,j_r,:,:) = reshape(curr_G_reg,[1 1 size(curr_G_reg)]);
%             
%             
%             % regression operator
%             
%     %         reg_operator_T_array(i_r,j_r,:) = reshape(((((G_reg')*G_reg)^(-1))*(G_reg'))',[1 1 length(unique_times_reg_qty)]);
%             reg_operator_T_array(i_r,j_r,:,:) = reshape(((((curr_G_reg')*curr_G_reg)^(-1))*(curr_G_reg'))',[1 1 size(curr_G_reg)]);
%             
%         end
%     end
%     
%     G_reg_cellarray{t_r} = G_reg_array;
%     reg_operator_T_cellarray{t_r} = reg_operator_T_array;
%     
% end
% 
% 
% 
% 
% 
% % compute horizontal edges of the region
% 
% m_N = (NE_corner(1) - NW_corner(1))/(NE_corner(2) - NW_corner(2));
% n_W = (NW_corner(2) - SW_corner(2))/(NW_corner(1) - SW_corner(1));
% m_S = (SW_corner(1) - SE_corner(1))/(SW_corner(2) - SE_corner(2));
% n_E = (SE_corner(2) - NE_corner(2))/(SE_corner(1) - NE_corner(1));
% 
% b_N = NE_corner(1) - (m_N*NE_corner(2));
% c_W = NW_corner(2) - (n_W*NW_corner(1));
% b_S = SW_corner(1) - (m_S*SW_corner(2));
% c_E = SE_corner(2) - (n_E*SE_corner(1));
% 
% 
% pos_rel_to_N_edge = tlat - (m_N*tlon) - b_N;
% pos_rel_to_W_edge = tlon - (n_W*tlat) - c_W;
% pos_rel_to_S_edge = tlat - (m_S*tlon) - b_S;
% pos_rel_to_E_edge = tlon - (n_E*tlat) - c_E;
% 
% 
% in_box_ind = find((pos_rel_to_N_edge < 0) & (pos_rel_to_W_edge >= 0) & (pos_rel_to_S_edge >= 0) & (pos_rel_to_E_edge < 0));
% 
% 
% start_vector_i_j_only = [min(lon_ind_inrange) min(lat_ind_inrange)];
% size_vector_i_j_only = [length(lon_ind_inrange) length(lat_ind_inrange)];
% tarea = ncread(nc_filenames{1},'TAREA',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
% 
% 
% 
% % create mask of points in region, for horizontal integration
% in_box_mask = zeros(size(tarea));
% in_box_mask(in_box_ind) = 1;
% 
% 
% 
% at_N_edge_ind_ind = find((pos_rel_to_N_edge(in_box_ind) >= -grid_res));
% at_N_edge_ind = in_box_ind(at_N_edge_ind_ind);
% at_W_edge_ind_ind = find((pos_rel_to_W_edge(in_box_ind) < grid_res));
% at_W_edge_ind = in_box_ind(at_W_edge_ind_ind);
% at_S_edge_ind_ind = find((pos_rel_to_S_edge(in_box_ind) < grid_res));
% at_S_edge_ind = in_box_ind(at_S_edge_ind_ind);
% at_E_edge_ind_ind = find((pos_rel_to_E_edge(in_box_ind) >= -grid_res));
% at_E_edge_ind = in_box_ind(at_E_edge_ind_ind);
% 
% 
% 
% at_N_edge_i_ind = mod(at_N_edge_ind - 1, size(tlat,1)) + 1;
% at_N_edge_j_ind = ceil(at_N_edge_ind/size(tlat,1));
% 
% at_NE_corner_ind = intersect(at_N_edge_ind,at_E_edge_ind);
% at_NW_corner_ind = intersect(at_W_edge_ind,at_N_edge_ind);
% at_SW_corner_ind = intersect(at_S_edge_ind,at_W_edge_ind);
% at_SE_corner_ind = intersect(at_E_edge_ind,at_S_edge_ind);
% 
% at_all_corners_ind = union(at_NE_corner_ind,at_NW_corner_ind);
% at_all_corners_ind = union(at_all_corners_ind,at_SW_corner_ind);
% at_all_corners_ind = union(at_all_corners_ind,at_SE_corner_ind);
% 
% no_corners_N_edge_ind = setdiff(at_N_edge_ind,at_all_corners_ind);
% no_corners_W_edge_ind = setdiff(at_W_edge_ind,at_all_corners_ind);
% no_corners_S_edge_ind = setdiff(at_S_edge_ind,at_all_corners_ind);
% no_corners_E_edge_ind = setdiff(at_E_edge_ind,at_all_corners_ind);
% 
% 
% 
% % load partial bottom cell grid variables
% 
% KMT = ncread(nc_filenames{1},'KMT');
% kmt = KMT(lon_ind_inrange,lat_ind_inrange);
% clear KMT
% 
% HT = ncread(nc_filenames{1},'HT');
% ht = HT(lon_ind_inrange,lat_ind_inrange);
% clear HT
% 
% kmt_reshaped = reshape(kmt,[prod(size(kmt)) 1]);
% ht_reshaped = reshape(ht,[prod(size(ht)) 1]);
% 
% dzbc_vec = zeros(size(ht_reshaped));
% not_land_ind = find(kmt_reshaped > 0);
% dzbc_vec(not_land_ind) = ht(not_land_ind) - z_w_top(kmt_reshaped(not_land_ind));
% dzbc = reshape(dzbc_vec,[length(lon_ind_inrange) length(lat_ind_inrange)]);
% 
% 
% 
% % compute thickness of cells
% 
% dzt = zeros(size(tlon,1),size(tlat,2),length(z_t));
% for curr_k_ind = 1:length(z_t)
%     at_deepest_level_ind = find(kmt == curr_k_ind);
%     not_at_deepest_level_ind = find(kmt > curr_k_ind);
%     
%     dzt_curr_level = zeros(size(dzt,1),size(dzt,2));
%     dzt_curr_level(at_deepest_level_ind) = dzbc(at_deepest_level_ind);
%     dzt_curr_level(not_at_deepest_level_ind) = dz(curr_k_ind)*ones(length(not_at_deepest_level_ind),1);
%     
%     dzt(:,:,curr_k_ind) = dzt_curr_level;
% end
% 
% 
% 
% curr_file_start_ind = 1;
% 
% SSH = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
% mean_ML_depth = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
% for file_num_ind = 1:length(nc_filenames)
%     file_num = file_nums_in_time_range(file_num_ind);
%     
%     time_curr_source_file = ncread(nc_filenames{file_num},'time');
%     
%     time_ind_infile = find(file_num_vec(unique_time_ind_reg_level1(unique_time_ind)) == file_num);
%     if isempty(time_ind_infile) == 1
%         continue
%     end
%     
%     curr_time_ind_inrange = in_file_ind_vec(unique_time_ind_reg_level1(unique_time_ind(time_ind_infile)));
%     
%     
%     start_vector_nodepth = [min(lon_ind_inrange) min(lat_ind_inrange) min(curr_time_ind_inrange)];
%     size_vector_nodepth = [length(lon_ind_inrange) length(lat_ind_inrange) (max(curr_time_ind_inrange) - min(curr_time_ind_inrange) + 1)];
%     
%     
%     subsetting_in_time_ind = curr_time_ind_inrange - min(curr_time_ind_inrange) + 1;
%     
%     curr_file_end_ind = curr_file_start_ind - 1 + length(curr_time_ind_inrange);
%     
%     
%     % load SSH
%     curr_SSH = ncread(nc_filenames{file_num},'SSH',start_vector_nodepth,size_vector_nodepth,ones(1,3));
%     SSH(:,:,curr_file_start_ind:curr_file_end_ind) = curr_SSH(:,:,subsetting_in_time_ind);
%     
%     % load mixed layer depth
%     curr_mean_ML_depth = ncread(nc_filenames{file_num},'HMXL',start_vector_nodepth,size_vector_nodepth,ones(1,3));
%     mean_ML_depth(:,:,curr_file_start_ind:curr_file_end_ind) = curr_mean_ML_depth(:,:,subsetting_in_time_ind);
%     
%     curr_file_start_ind = curr_file_start_ind + length(curr_time_ind_inrange);
% 
% end
% 
% 
% 
% % top and bottom depth bound arrays
% top_depth_bound_array = 0*ones(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
% bottom_depth_bound_array = mean_ML_depth;
% 
% 
% 
% % compute all depth indices needed for the mixed layer
% 
% outside_depth_bounds = [min(min(min(top_depth_bound_array))) max(max(max(bottom_depth_bound_array)))];     % in cm
% z_t_ind_inrange = find((z_t >= outside_depth_bounds(1)) & (z_t <= outside_depth_bounds(2)));
% depth_ind_inrange = (max([1 (min(z_t_ind_inrange) - 1)]):1:min([length(z_t) (max(z_t_ind_inrange) + 1)]))';
%     
% 
% 
% curr_file_start_ind = 1;
% 
% temp = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
% for file_num_ind = 1:length(nc_filenames)
%     file_num = file_nums_in_time_range(file_num_ind);
%     
%     time_curr_source_file = ncread(nc_filenames{file_num},'time');
%     
%     time_ind_infile = find(file_num_vec(unique_time_ind_reg_level1(unique_time_ind)) == file_num);
%     if isempty(time_ind_infile) == 1
%         continue
%     end
%     
%     curr_time_ind_inrange = in_file_ind_vec(unique_time_ind_reg_level1(unique_time_ind(time_ind_infile)));
%     
%     
%     start_vector_nodepth = [min(lon_ind_inrange) min(lat_ind_inrange) min(curr_time_ind_inrange)];
%     size_vector_nodepth = [length(lon_ind_inrange) length(lat_ind_inrange) (max(curr_time_ind_inrange) - min(curr_time_ind_inrange) + 1)];
%     
%     
%     subsetting_in_time_ind = curr_time_ind_inrange - min(curr_time_ind_inrange) + 1;
%     
%     curr_file_end_ind = curr_file_start_ind - 1 + length(curr_time_ind_inrange);
%     
%     
%     % load velocity and tracer flux variables
%     
%     start_vector = [min(lon_ind_inrange) min(lat_ind_inrange) min(depth_ind_inrange) min(curr_time_ind_inrange)];
%     size_vector = [length(lon_ind_inrange) length(lat_ind_inrange) length(depth_ind_inrange) (max(curr_time_ind_inrange) - min(curr_time_ind_inrange) + 1)];
%     
%     curr_temp = ncread(nc_filenames{file_num},'TEMP',start_vector,size_vector,ones(1,4));
%     temp(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_temp(:,:,:,subsetting_in_time_ind);
%     
%     curr_file_start_ind = curr_file_start_ind + length(curr_time_ind_inrange);
% 
% end
% 
% 
% 
% 
% % compute the boundaries of the box
% 
% 
% % create depth integrating array for region
% 
% no_thickness_ind = find(bottom_depth_bound_array - top_depth_bound_array <= 0);
%     
% depth_integrating_array = zeros(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_times));
% for curr_depth_ind = 1:length(depth_ind_inrange)
%     curr_k_ind = depth_ind_inrange(curr_depth_ind);
%     
%     at_shallowest_level_ind = find((top_depth_bound_array >= z_w_top(curr_k_ind)) & (top_depth_bound_array < z_w_bot(curr_k_ind)));
%     at_deepest_level_ind = find((bottom_depth_bound_array > z_w_top(curr_k_ind)) & (bottom_depth_bound_array <= z_w_bot(curr_k_ind)));
%     only_one_in_level_ind = intersect(at_shallowest_level_ind,at_deepest_level_ind);
%     not_vert_edge_adj_ind = find((top_depth_bound_array < z_w_top(curr_k_ind)) & (bottom_depth_bound_array > z_w_bot(curr_k_ind)));
%     
%     depth_integrating_curr_level = zeros(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_times));
%     depth_integrating_curr_level(at_shallowest_level_ind) = z_w_bot(curr_k_ind) - top_depth_bound_array(at_shallowest_level_ind);
%     depth_integrating_curr_level(at_deepest_level_ind) = bottom_depth_bound_array(at_deepest_level_ind) - z_w_top(curr_k_ind);
%     depth_integrating_curr_level(only_one_in_level_ind) = max([(bottom_depth_bound_array(only_one_in_level_ind) - top_depth_bound_array(only_one_in_level_ind)) zeros(length(only_one_in_level_ind),1)],[],2);
%     depth_integrating_curr_level(not_vert_edge_adj_ind) = dz(curr_k_ind)*ones(length(not_vert_edge_adj_ind),1);
%     
%     depth_integrating_curr_level(no_thickness_ind) = 0;
%     
%     depth_integrating_array(:,:,curr_depth_ind,:) = reshape(depth_integrating_curr_level,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]);
% end
% 
% 
% 
% % create depth integrating array that accounts for presence of bathymetry
% 
% min_dzt_depth_integrating_array_5D = zeros(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_times),2);
% min_dzt_depth_integrating_array_5D(:,:,:,:,1) = depth_integrating_array;
% min_dzt_depth_integrating_array_5D(:,:,:,:,2) = repmat(dzt(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]);
% min_dzt_depth_integrating_array = squeeze(min(min_dzt_depth_integrating_array_5D,[],5));
% 
% 
% % compute the vertically-averaged temperature in the layer
% 
% temp(isnan(temp) == 1) = 0;
% 
% SSH_depth_integrating_top_layer = zeros(size(SSH));
% top_at_sfc_ind = find(top_depth_bound_array <= 0);
% SSH_depth_integrating_top_layer(top_at_sfc_ind) = SSH(top_at_sfc_ind);
% SSH_depth_integrating_top_layer(isnan(SSH_depth_integrating_top_layer) == 1) = 0;
% SSH_depth_integrating_array = zeros(size(min_dzt_depth_integrating_array));
% SSH_depth_integrating_array(:,:,1,:) = reshape(SSH_depth_integrating_top_layer,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]);
% 
% layer_thickness_array = squeeze(sum(min_dzt_depth_integrating_array + SSH_depth_integrating_array,3));
% 
% 
% temp_vert_integrated_inlayer = squeeze(sum((min_dzt_depth_integrating_array + SSH_depth_integrating_array).*temp,3));
% 
% vol_integrated_inbox = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 size(min_dzt_depth_integrating_array,4)]).*layer_thickness_array,2),1));
% T_integrated_inbox = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 size(min_dzt_depth_integrating_array,4)]).*temp_vert_integrated_inlayer,2),1));
% 
% T_mean_inbox = T_integrated_inbox./vol_integrated_inbox;
% 
% G_seasonal_reg = [ones(length(unique_times),1) cos((2*pi/365)*unique_times) sin((2*pi/365)*unique_times) cos((2*pi/(365/2))*unique_times) sin((2*pi/(365/2))*unique_times) cos((2*pi/(365/3))*unique_times) sin((2*pi/(365/3))*unique_times) cos((2*pi/(365/4))*unique_times) sin((2*pi/(365/4))*unique_times)];
% m_seasonal_T_mean_inbox = (((G_seasonal_reg')*G_seasonal_reg)^(-1))*((G_seasonal_reg')*T_mean_inbox);
% T_mean_inbox_seasonal = G_seasonal_reg*m_seasonal_T_mean_inbox;
% T_mean_inbox_anom = T_mean_inbox - T_mean_inbox_seasonal;
% 
% % save(['temp_budget_',reg_avg_file_specifier,'_seasonreg.mat'],'in_box_mask','layer_thickness_array','tarea','-append','-v7.3')
% 
% 
% 
% 
% % compute regressed-quantity budget for subset regions
% 
% 
% size_array_ij = [length(lon_ind_inrange) length(lat_ind_inrange)];
% 
% 
% if reg_level_option == 1
%     file_name_base_input = NaN;
% else
%     file_name_base_output = NaN;
% %     file_nums_in_time_range = NaN;
% %     file_num_vec = NaN;
% %     in_file_ind_vec = NaN;
%     depth_ind_inrange = NaN;
%     tarea = NaN(size_array_ij);
%     hte = NaN(size_array_ij);
%     htn = NaN(size_array_ij);
%     dzt = NaN([size_array_ij 1]);
%     dzt_east_wall = NaN([size_array_ij 1]);
%     dzt_north_wall = NaN([size_array_ij 1]);
%     top_depth_bound_array = NaN([size_array_ij 1]);
%     bottom_depth_bound_array = NaN([size_array_ij 1]);
%     dxu = NaN(size_array_ij);
%     dyu = NaN(size_array_ij);
%     dzu = NaN([size_array_ij 1]);
%     dxt = NaN(size_array_ij);
%     dyt = NaN(size_array_ij);
%     ht = NaN(size_array_ij);
% end
% 
% for i_f = 1:n_subsets_file_computation(1)
%     curr_x_start_ind = subset_x_file_start_ind(i_f);
%     curr_x_end_ind = subset_x_file_end_ind(i_f);
%     curr_x_ind = (curr_x_start_ind:1:curr_x_end_ind)';
%     for j_f = 1:n_subsets_file_computation(2)
%         curr_y_start_ind = subset_y_file_start_ind(j_f);
%         curr_y_end_ind = subset_y_file_end_ind(j_f);
%         curr_y_ind = (curr_y_start_ind:1:curr_y_end_ind)';
%         
%         
%         [adv_T_tend_vel_temp_reg_term_names,vol_flux_term_names,curr_adv_T_tend_vel_temp_reg_terms_vert_avg,curr_vol_flux_terms_vert_avg,curr_vol_flux_terms_reg_vert_avg,curr_vol_flux_terms_noreg_vert_avg] = temp_budget_maps_ML_reg_decomp_fcn_seasonreg(reg_level_option,file_name_base_input,file_name_base_output,i_f,j_f,nc_filenames,file_nums_in_time_range,file_num_vec,time,unique_time_ind,in_file_ind_vec,NE_corner,NW_corner,SW_corner,SE_corner,lon_ind_inrange(curr_x_ind),lat_ind_inrange(curr_y_ind),depth_ind_inrange,tarea(curr_x_ind,curr_y_ind),hte(curr_x_ind,curr_y_ind),htn(curr_x_ind,curr_y_ind),dzt(curr_x_ind,curr_y_ind,:),dzt_east_wall(curr_x_ind,curr_y_ind,:),dzt_north_wall(curr_x_ind,curr_y_ind,:),dz,top_depth_bound_array(curr_x_ind,curr_y_ind,:),bottom_depth_bound_array(curr_x_ind,curr_y_ind,:),unique_times,z_w_top,z_w_bot,dxu(curr_x_ind,curr_y_ind),dyu(curr_x_ind,curr_y_ind),dzu(curr_x_ind,curr_y_ind,:),dxt(curr_x_ind,curr_y_ind),dyt(curr_x_ind,curr_y_ind),n_subsets_regression,weighting_array_regression(curr_x_ind,curr_y_ind,:,:),time_ind_subset_reg_cellarray,time_weighting_subset_reg_cellarray,G_reg_cellarray,reg_operator_T_cellarray,ht(curr_x_ind,curr_y_ind),ent_compute_option,T_mean_inbox,T_mean_inbox_anom,time_avg_from_unique_reg_ind);
%         
%         
%         if ((i_f == 1) && (j_f == 1))
%             
%             
% %             for num_term = 1:length(T_tend_overall_term_names)
% %                 eval([T_tend_overall_term_names{num_term},'_avg = NaN(size_array_ij);'])
% %                 eval([T_tend_overall_term_names{num_term},'_reg_avg = NaN(size_array_ij);'])
% %                 eval([T_tend_overall_term_names{num_term},'_noreg_avg = NaN(size_array_ij);'])
% %             end
% %             
% %             for num_term = 1:length(T_tend_detailed_term_names)
% %                 eval([T_tend_detailed_term_names{num_term},'_avg = NaN(size_array_ij);'])
% %                 eval([T_tend_detailed_term_names{num_term},'_reg_avg = NaN(size_array_ij);'])
% %                 eval([T_tend_detailed_term_names{num_term},'_noreg_avg = NaN(size_array_ij);'])
% %             end
% %             
% %             for num_term = 1:length(vardepth_breakdown_term_names)
% %                 eval([vardepth_breakdown_term_names{num_term},'_avg = NaN(size_array_ij);'])
% %                 eval([vardepth_breakdown_term_names{num_term},'_reg_avg = NaN(size_array_ij);'])
% %                 eval([vardepth_breakdown_term_names{num_term},'_noreg_avg = NaN(size_array_ij);'])
% %             end
%             
%             for num_term = 1:length(adv_T_tend_vel_temp_reg_term_names)
% %                 if num_term <= 12
% %                     eval([adv_T_tend_vel_temp_reg_term_names{num_term},'_avg = NaN(size_array_ij);'])
% %                 else
%                     eval([adv_T_tend_vel_temp_reg_term_names{num_term},' = NaN([size_array_ij length(unique_time_ind)]);'])
% %                 end
%             end
%             
%             for num_term = 1:length(vol_flux_term_names)
%                 eval([vol_flux_term_names{num_term},'_vert_avg = NaN([size_array_ij length(unique_time_ind)]);'])
%                 eval([vol_flux_term_names{num_term},'_reg_vert_avg = NaN([size_array_ij length(unique_time_ind)]);'])
%                 eval([vol_flux_term_names{num_term},'_noreg_vert_avg = NaN([size_array_ij length(unique_time_ind)]);'])
%             end
%             
% %             for num_term = 1:length(vert_mean_term_names)
% %                 eval([vert_mean_term_names{num_term},'_avg = NaN(size_array_ij);'])
% %                 eval([vert_mean_term_names{num_term},'_reg_avg = NaN(size_array_ij);'])
% %                 eval([vert_mean_term_names{num_term},'_noreg_avg = NaN(size_array_ij);'])
% %             end
%             
%         end
%         
%         
% %         for num_term = 1:length(T_tend_overall_term_names)
% %             
% %             curr_term_name = [T_tend_overall_term_names{num_term},'_avg'];
% %             curr_term_subset = curr_T_tend_overall_terms_avg{num_term};
% %             curr_term_zeronans = NaN(size_array_ij);
% %             curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
% %             curr_term_zero_ind = find(curr_term_zeronans == 0);
% %             nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
% %             curr_term_zeronans(nan_ind) = 0;
% %             curr_term_old = eval(curr_term_name);
% %             curr_term_old_zero_ind = find(curr_term_old == 0);
% %             nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
% %             curr_term_old_zeronans = curr_term_old;
% %             curr_term_old_zeronans(nan_old_domain_ind) = 0;
% %             currdomain_mask = zeros(size_array_ij);
% %             currdomain_mask(nan_old_domain_ind) = 1;
% %             currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
% %             currdomain_mask(nan_ind) = 0;
% %             curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
% %             curr_term(curr_term == 0) = NaN;
% %             curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
% %             eval([curr_term_name,' = curr_term;'])
% %             
% %             curr_term_name = [T_tend_overall_term_names{num_term},'_reg_avg'];
% %             curr_term_subset = curr_T_tend_overall_terms_reg_avg{num_term};
% %             curr_term_zeronans = NaN(size_array_ij);
% %             curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
% %             curr_term_zero_ind = find(curr_term_zeronans == 0);
% %             nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
% %             curr_term_zeronans(nan_ind) = 0;
% %             curr_term_old = eval(curr_term_name);
% %             curr_term_old_zero_ind = find(curr_term_old == 0);
% %             nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
% %             curr_term_old_zeronans = curr_term_old;
% %             curr_term_old_zeronans(nan_old_domain_ind) = 0;
% %             currdomain_mask = zeros(size_array_ij);
% %             currdomain_mask(nan_old_domain_ind) = 1;
% %             currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
% %             currdomain_mask(nan_ind) = 0;
% %             curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
% %             curr_term(curr_term == 0) = NaN;
% %             curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
% %             eval([curr_term_name,' = curr_term;'])
% %             
% %             curr_term_name = [T_tend_overall_term_names{num_term},'_noreg_avg'];
% %             curr_term_subset = curr_T_tend_overall_terms_noreg_avg{num_term};
% %             curr_term_zeronans = NaN(size_array_ij);
% %             curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
% %             curr_term_zero_ind = find(curr_term_zeronans == 0);
% %             nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
% %             curr_term_zeronans(nan_ind) = 0;
% %             curr_term_old = eval(curr_term_name);
% %             curr_term_old_zero_ind = find(curr_term_old == 0);
% %             nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
% %             curr_term_old_zeronans = curr_term_old;
% %             curr_term_old_zeronans(nan_old_domain_ind) = 0;
% %             currdomain_mask = zeros(size_array_ij);
% %             currdomain_mask(nan_old_domain_ind) = 1;
% %             currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
% %             currdomain_mask(nan_ind) = 0;
% %             curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
% %             curr_term(curr_term == 0) = NaN;
% %             curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
% %             eval([curr_term_name,' = curr_term;'])
% %             
% %         end
% %         
% %         for num_term = 1:length(T_tend_detailed_term_names)
% %             
% %             curr_term_name = [T_tend_detailed_term_names{num_term},'_avg'];
% %             curr_term_subset = curr_T_tend_detailed_terms_avg{num_term};
% %             curr_term_zeronans = NaN(size_array_ij);
% %             curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
% %             curr_term_zero_ind = find(curr_term_zeronans == 0);
% %             nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
% %             curr_term_zeronans(nan_ind) = 0;
% %             curr_term_old = eval(curr_term_name);
% %             curr_term_old_zero_ind = find(curr_term_old == 0);
% %             nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
% %             curr_term_old_zeronans = curr_term_old;
% %             curr_term_old_zeronans(nan_old_domain_ind) = 0;
% %             currdomain_mask = zeros(size_array_ij);
% %             currdomain_mask(nan_old_domain_ind) = 1;
% %             currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
% %             currdomain_mask(nan_ind) = 0;
% %             curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
% %             curr_term(curr_term == 0) = NaN;
% %             curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
% %             eval([curr_term_name,' = curr_term;'])
% %             
% %             curr_term_name = [T_tend_detailed_term_names{num_term},'_reg_avg'];
% %             curr_term_subset = curr_T_tend_detailed_terms_reg_avg{num_term};
% %             curr_term_zeronans = NaN(size_array_ij);
% %             curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
% %             curr_term_zero_ind = find(curr_term_zeronans == 0);
% %             nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
% %             curr_term_zeronans(nan_ind) = 0;
% %             curr_term_old = eval(curr_term_name);
% %             curr_term_old_zero_ind = find(curr_term_old == 0);
% %             nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
% %             curr_term_old_zeronans = curr_term_old;
% %             curr_term_old_zeronans(nan_old_domain_ind) = 0;
% %             currdomain_mask = zeros(size_array_ij);
% %             currdomain_mask(nan_old_domain_ind) = 1;
% %             currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
% %             currdomain_mask(nan_ind) = 0;
% %             curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
% %             curr_term(curr_term == 0) = NaN;
% %             curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
% %             eval([curr_term_name,' = curr_term;'])
% %             
% %             curr_term_name = [T_tend_detailed_term_names{num_term},'_noreg_avg'];
% %             curr_term_subset = curr_T_tend_detailed_terms_noreg_avg{num_term};
% %             curr_term_zeronans = NaN(size_array_ij);
% %             curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
% %             curr_term_zero_ind = find(curr_term_zeronans == 0);
% %             nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
% %             curr_term_zeronans(nan_ind) = 0;
% %             curr_term_old = eval(curr_term_name);
% %             curr_term_old_zero_ind = find(curr_term_old == 0);
% %             nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
% %             curr_term_old_zeronans = curr_term_old;
% %             curr_term_old_zeronans(nan_old_domain_ind) = 0;
% %             currdomain_mask = zeros(size_array_ij);
% %             currdomain_mask(nan_old_domain_ind) = 1;
% %             currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
% %             currdomain_mask(nan_ind) = 0;
% %             curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
% %             curr_term(curr_term == 0) = NaN;
% %             curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
% %             eval([curr_term_name,' = curr_term;'])
% %             
% %         end
% %         
% %         for num_term = 1:length(vardepth_breakdown_term_names)
% %             
% %             curr_term_name = [vardepth_breakdown_term_names{num_term},'_avg'];
% %             curr_term_subset = curr_vardepth_breakdown_terms_avg{num_term};
% %             curr_term_zeronans = NaN(size_array_ij);
% %             curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
% %             curr_term_zero_ind = find(curr_term_zeronans == 0);
% %             nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
% %             curr_term_zeronans(nan_ind) = 0;
% %             curr_term_old = eval(curr_term_name);
% %             curr_term_old_zero_ind = find(curr_term_old == 0);
% %             nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
% %             curr_term_old_zeronans = curr_term_old;
% %             curr_term_old_zeronans(nan_old_domain_ind) = 0;
% %             currdomain_mask = zeros(size_array_ij);
% %             currdomain_mask(nan_old_domain_ind) = 1;
% %             currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
% %             currdomain_mask(nan_ind) = 0;
% %             curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
% %             curr_term(curr_term == 0) = NaN;
% %             curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
% %             eval([curr_term_name,' = curr_term;'])
% %             
% %             curr_term_name = [vardepth_breakdown_term_names{num_term},'_reg_avg'];
% %             curr_term_subset = curr_vardepth_breakdown_terms_reg_avg{num_term};
% %             curr_term_zeronans = NaN(size_array_ij);
% %             curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
% %             curr_term_zero_ind = find(curr_term_zeronans == 0);
% %             nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
% %             curr_term_zeronans(nan_ind) = 0;
% %             curr_term_old = eval(curr_term_name);
% %             curr_term_old_zero_ind = find(curr_term_old == 0);
% %             nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
% %             curr_term_old_zeronans = curr_term_old;
% %             curr_term_old_zeronans(nan_old_domain_ind) = 0;
% %             currdomain_mask = zeros(size_array_ij);
% %             currdomain_mask(nan_old_domain_ind) = 1;
% %             currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
% %             currdomain_mask(nan_ind) = 0;
% %             curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
% %             curr_term(curr_term == 0) = NaN;
% %             curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
% %             eval([curr_term_name,' = curr_term;'])
% %             
% %             curr_term_name = [vardepth_breakdown_term_names{num_term},'_noreg_avg'];
% %             curr_term_subset = curr_vardepth_breakdown_terms_noreg_avg{num_term};
% %             curr_term_zeronans = NaN(size_array_ij);
% %             curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
% %             curr_term_zero_ind = find(curr_term_zeronans == 0);
% %             nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
% %             curr_term_zeronans(nan_ind) = 0;
% %             curr_term_old = eval(curr_term_name);
% %             curr_term_old_zero_ind = find(curr_term_old == 0);
% %             nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
% %             curr_term_old_zeronans = curr_term_old;
% %             curr_term_old_zeronans(nan_old_domain_ind) = 0;
% %             currdomain_mask = zeros(size_array_ij);
% %             currdomain_mask(nan_old_domain_ind) = 1;
% %             currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
% %             currdomain_mask(nan_ind) = 0;
% %             curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
% %             curr_term(curr_term == 0) = NaN;
% %             curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
% %             eval([curr_term_name,' = curr_term;'])
% %             
% %         end
%         
%         for num_term = 1:length(adv_T_tend_vel_temp_reg_term_names)
%             
%             curr_term_subset = curr_adv_T_tend_vel_temp_reg_terms_vert_avg{num_term};
%             
%             if size(curr_term_subset,3) == 1
%                 curr_term_name = [adv_T_tend_vel_temp_reg_term_names{num_term},'_avg'];
%                 curr_term_subset = curr_adv_T_tend_vel_temp_reg_terms_avg{num_term};
%                 curr_term_zeronans = NaN(size_array_ij);
%                 curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
%                 curr_term_zero_ind = find(curr_term_zeronans == 0);
%                 nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
%                 curr_term_zeronans(nan_ind) = 0;
%                 curr_term_old = eval(curr_term_name);
%                 curr_term_old_zero_ind = find(curr_term_old == 0);
%                 nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
%                 curr_term_old_zeronans = curr_term_old;
%                 curr_term_old_zeronans(nan_old_domain_ind) = 0;
%                 currdomain_mask = zeros(size_array_ij);
%                 currdomain_mask(nan_old_domain_ind) = 1;
%                 currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
%                 currdomain_mask(nan_ind) = 0;
%                 curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
%                 curr_term(curr_term == 0) = NaN;
%                 curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
%                 eval([curr_term_name,' = curr_term;'])
%             else
%                 curr_term_name = adv_T_tend_vel_temp_reg_term_names{num_term};
%                 curr_term_subset = curr_adv_T_tend_vel_temp_reg_terms_vert_avg{num_term};
%                 curr_term_zeronans = NaN([size_array_ij size(curr_term_subset,3)]);
%                 curr_term_zeronans(curr_x_ind,curr_y_ind,:) = curr_term_subset;
%                 curr_term_zero_ind = find(curr_term_zeronans == 0);
%                 nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
%                 curr_term_zeronans(nan_ind) = 0;
%                 curr_term_old = eval(curr_term_name);
%                 curr_term_old_zero_ind = find(curr_term_old == 0);
%                 nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
%                 curr_term_old_zeronans = curr_term_old;
%                 curr_term_old_zeronans(nan_old_domain_ind) = 0;
%                 currdomain_mask = zeros([size_array_ij size(curr_term_subset,3)]);
%                 currdomain_mask(nan_old_domain_ind) = 1;
%                 currdomain_mask(curr_x_ind,curr_y_ind,:) = ones(length(curr_x_ind),length(curr_y_ind),size(curr_term_subset,3));
%                 currdomain_mask(nan_ind) = 0;
%                 curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
%                 curr_term(curr_term == 0) = NaN;
%                 curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
%                 eval([curr_term_name,' = curr_term;'])
%             end
%             
%         end
%         
%         for num_term = 1:length(vol_flux_term_names)
%             
%             curr_term_name = [vol_flux_term_names{num_term},'_vert_avg'];
%             curr_term_subset = curr_vol_flux_terms_vert_avg{num_term};
%             curr_term_zeronans = NaN([size_array_ij size(curr_term_subset,3)]);
%             curr_term_zeronans(curr_x_ind,curr_y_ind,:) = curr_term_subset;
%             curr_term_zero_ind = find(curr_term_zeronans == 0);
%             nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
%             curr_term_zeronans(nan_ind) = 0;
%             curr_term_old = eval(curr_term_name);
%             curr_term_old_zero_ind = find(curr_term_old == 0);
%             nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
%             curr_term_old_zeronans = curr_term_old;
%             curr_term_old_zeronans(nan_old_domain_ind) = 0;
%             currdomain_mask = zeros([size_array_ij size(curr_term_subset,3)]);
%             currdomain_mask(nan_old_domain_ind) = 1;
%             currdomain_mask(curr_x_ind,curr_y_ind,:) = ones(length(curr_x_ind),length(curr_y_ind),size(curr_term_subset,3));
%             currdomain_mask(nan_ind) = 0;
%             curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
%             curr_term(curr_term == 0) = NaN;
%             curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
%             eval([curr_term_name,' = curr_term;'])
%             
%             curr_term_name = [vol_flux_term_names{num_term},'_reg_vert_avg'];
%             curr_term_subset = curr_vol_flux_terms_reg_vert_avg{num_term};
%             curr_term_zeronans = NaN([size_array_ij size(curr_term_subset,3)]);
%             curr_term_zeronans(curr_x_ind,curr_y_ind,:) = curr_term_subset;
%             curr_term_zero_ind = find(curr_term_zeronans == 0);
%             nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
%             curr_term_zeronans(nan_ind) = 0;
%             curr_term_old = eval(curr_term_name);
%             curr_term_old_zero_ind = find(curr_term_old == 0);
%             nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
%             curr_term_old_zeronans = curr_term_old;
%             curr_term_old_zeronans(nan_old_domain_ind) = 0;
%             currdomain_mask = zeros([size_array_ij size(curr_term_subset,3)]);
%             currdomain_mask(nan_old_domain_ind) = 1;
%             currdomain_mask(curr_x_ind,curr_y_ind,:) = ones(length(curr_x_ind),length(curr_y_ind),size(curr_term_subset,3));
%             currdomain_mask(nan_ind) = 0;
%             curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
%             curr_term(curr_term == 0) = NaN;
%             curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
%             eval([curr_term_name,' = curr_term;'])
%             
%             curr_term_name = [vol_flux_term_names{num_term},'_noreg_vert_avg'];
%             curr_term_subset = curr_vol_flux_terms_noreg_vert_avg{num_term};
%             curr_term_zeronans = NaN([size_array_ij size(curr_term_subset,3)]);
%             curr_term_zeronans(curr_x_ind,curr_y_ind,:) = curr_term_subset;
%             curr_term_zero_ind = find(curr_term_zeronans == 0);
%             nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
%             curr_term_zeronans(nan_ind) = 0;
%             curr_term_old = eval(curr_term_name);
%             curr_term_old_zero_ind = find(curr_term_old == 0);
%             nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
%             curr_term_old_zeronans = curr_term_old;
%             curr_term_old_zeronans(nan_old_domain_ind) = 0;
%             currdomain_mask = zeros([size_array_ij size(curr_term_subset,3)]);
%             currdomain_mask(nan_old_domain_ind) = 1;
%             currdomain_mask(curr_x_ind,curr_y_ind,:) = ones(length(curr_x_ind),length(curr_y_ind),size(curr_term_subset,3));
%             currdomain_mask(nan_ind) = 0;
%             curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
%             curr_term(curr_term == 0) = NaN;
%             curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
%             eval([curr_term_name,' = curr_term;'])
%             
%         end
%         
% %         for num_term = 1:length(vert_mean_term_names)
% %             
% %             curr_term_name = [vert_mean_term_names{num_term},'_avg'];
% %             curr_term_subset = curr_vert_mean_terms_avg{num_term};
% %             curr_term_zeronans = NaN(size_array_ij);
% %             curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
% %             curr_term_zero_ind = find(curr_term_zeronans == 0);
% %             nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
% %             curr_term_zeronans(nan_ind) = 0;
% %             curr_term_old = eval(curr_term_name);
% %             curr_term_old_zero_ind = find(curr_term_old == 0);
% %             nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
% %             curr_term_old_zeronans = curr_term_old;
% %             curr_term_old_zeronans(nan_old_domain_ind) = 0;
% %             currdomain_mask = zeros(size_array_ij);
% %             currdomain_mask(nan_old_domain_ind) = 1;
% %             currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
% %             currdomain_mask(nan_ind) = 0;
% %             curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
% %             curr_term(curr_term == 0) = NaN;
% %             curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
% %             eval([curr_term_name,' = curr_term;'])
% %             
% %             curr_term_name = [vert_mean_term_names{num_term},'_reg_avg'];
% %             curr_term_subset = curr_vert_mean_terms_reg_avg{num_term};
% %             curr_term_zeronans = NaN(size_array_ij);
% %             curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
% %             curr_term_zero_ind = find(curr_term_zeronans == 0);
% %             nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
% %             curr_term_zeronans(nan_ind) = 0;
% %             curr_term_old = eval(curr_term_name);
% %             curr_term_old_zero_ind = find(curr_term_old == 0);
% %             nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
% %             curr_term_old_zeronans = curr_term_old;
% %             curr_term_old_zeronans(nan_old_domain_ind) = 0;
% %             currdomain_mask = zeros(size_array_ij);
% %             currdomain_mask(nan_old_domain_ind) = 1;
% %             currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
% %             currdomain_mask(nan_ind) = 0;
% %             curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
% %             curr_term(curr_term == 0) = NaN;
% %             curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
% %             eval([curr_term_name,' = curr_term;'])
% %             
% %             curr_term_name = [vert_mean_term_names{num_term},'_noreg_avg'];
% %             curr_term_subset = curr_vert_mean_terms_noreg_avg{num_term};
% %             curr_term_zeronans = NaN(size_array_ij);
% %             curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
% %             curr_term_zero_ind = find(curr_term_zeronans == 0);
% %             nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
% %             curr_term_zeronans(nan_ind) = 0;
% %             curr_term_old = eval(curr_term_name);
% %             curr_term_old_zero_ind = find(curr_term_old == 0);
% %             nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
% %             curr_term_old_zeronans = curr_term_old;
% %             curr_term_old_zeronans(nan_old_domain_ind) = 0;
% %             currdomain_mask = zeros(size_array_ij);
% %             currdomain_mask(nan_old_domain_ind) = 1;
% %             currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
% %             currdomain_mask(nan_ind) = 0;
% %             curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
% %             curr_term(curr_term == 0) = NaN;
% %             curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
% %             eval([curr_term_name,' = curr_term;'])
% %             
% %         end
%         
%         
%         disp(['Finished computations: i_f = ',num2str(i_f),', j_f = ',num2str(j_f)])
%         
%     end
%     
%     save([reg_avg_file_specifier,'_fcn_outputs.mat'],'adv_T_tend*_only','adv_T_tend*_top','adv_T_tend*_bottom','adv_T_tend_total','ent_T_tend_top','ent_T_tend_bottom','adv_vol_flux*','ent_vol_flux*','*_vert_avg','-v7.3')
%     
%     
% end
% 
% 
% try
% 
% % clear reg_avg_text_specifer_new
% 
% 
% tarea = ncread(nc_filenames{1},'TAREA',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
% 
% % advective tendency contributions from process-related terms along edges
% 
% T_tend_adv_reg_terms_along_edges = zeros(7,1);
% 
% uvel_E_edge_mask = zeros(size(in_box_mask));
% uvel_E_edge_mask(1:(size(in_box_mask,1) - 1),:) = in_box_mask(1:(size(in_box_mask,1) - 1),:) - in_box_mask(2:size(in_box_mask,1),:);
% uvel_E_edge_ind = find(abs(uvel_E_edge_mask - 1) < 1e-5);
% uvel_W_edge_mask = zeros(size(in_box_mask));
% uvel_W_edge_mask(2:size(in_box_mask,1),:) = in_box_mask(2:size(in_box_mask,1),:) - in_box_mask(1:(size(in_box_mask,1) - 1),:);
% uvel_W_edge_ind = find(abs(uvel_W_edge_mask - 1) < 1e-5);
% vvel_N_edge_mask = zeros(size(in_box_mask));
% vvel_N_edge_mask(:,1:(size(in_box_mask,2) - 1)) = in_box_mask(:,1:(size(in_box_mask,2) - 1)) - in_box_mask(:,2:size(in_box_mask,2));
% vvel_N_edge_ind = find(abs(vvel_N_edge_mask - 1) < 1e-5);
% vvel_S_edge_mask = zeros(size(in_box_mask));
% vvel_S_edge_mask(:,2:size(in_box_mask,2)) = in_box_mask(:,2:size(in_box_mask,2)) - in_box_mask(:,1:(size(in_box_mask,2) - 1));
% vvel_S_edge_ind = find(abs(vvel_S_edge_mask - 1) < 1e-5);
% 
% 
% adv_T_tend_uvel_T_reg_all_E_side_only(isnan(adv_T_tend_uvel_T_reg_all_E_side_only) == 1) = 0;
% adv_T_tend_uvel_T_reg_all_W_side_only(isnan(adv_T_tend_uvel_T_reg_all_W_side_only) == 1) = 0;
% adv_T_tend_vvel_T_reg_all_N_side_only(isnan(adv_T_tend_vvel_T_reg_all_N_side_only) == 1) = 0;
% adv_T_tend_vvel_T_reg_all_S_side_only(isnan(adv_T_tend_vvel_T_reg_all_S_side_only) == 1) = 0;
% adv_T_tend_vel_T_reg_all_top(isnan(adv_T_tend_vel_T_reg_all_top) == 1) = 0;
% adv_T_tend_vel_T_reg_all_bottom(isnan(adv_T_tend_vel_T_reg_all_bottom) == 1) = 0;
% adv_T_tend_total(isnan(adv_T_tend_total) == 1) = 0;
% 
% adv_vol_flux_E_vert_avg(isnan(adv_vol_flux_E_vert_avg) == 1) = 0;
% adv_vol_flux_W_vert_avg(isnan(adv_vol_flux_W_vert_avg) == 1) = 0;
% adv_vol_flux_N_vert_avg(isnan(adv_vol_flux_N_vert_avg) == 1) = 0;
% adv_vol_flux_S_vert_avg(isnan(adv_vol_flux_S_vert_avg) == 1) = 0;
% adv_vol_flux_top_vert_avg(isnan(adv_vol_flux_top_vert_avg) == 1) = 0;
% adv_vol_flux_E_sloping_top_vert_avg(isnan(adv_vol_flux_E_sloping_top_vert_avg) == 1) = 0;
% adv_vol_flux_W_sloping_top_vert_avg(isnan(adv_vol_flux_W_sloping_top_vert_avg) == 1) = 0;
% adv_vol_flux_N_sloping_top_vert_avg(isnan(adv_vol_flux_N_sloping_top_vert_avg) == 1) = 0;
% adv_vol_flux_S_sloping_top_vert_avg(isnan(adv_vol_flux_S_sloping_top_vert_avg) == 1) = 0;
% adv_vol_flux_bottom_vert_avg(isnan(adv_vol_flux_bottom_vert_avg) == 1) = 0;
% adv_vol_flux_E_sloping_bottom_vert_avg(isnan(adv_vol_flux_E_sloping_bottom_vert_avg) == 1) = 0;
% adv_vol_flux_W_sloping_bottom_vert_avg(isnan(adv_vol_flux_W_sloping_bottom_vert_avg) == 1) = 0;
% adv_vol_flux_N_sloping_bottom_vert_avg(isnan(adv_vol_flux_N_sloping_bottom_vert_avg) == 1) = 0;
% adv_vol_flux_S_sloping_bottom_vert_avg(isnan(adv_vol_flux_S_sloping_bottom_vert_avg) == 1) = 0;
% 
% adv_vol_flux_E_reg_vert_avg(isnan(adv_vol_flux_E_reg_vert_avg) == 1) = 0;
% adv_vol_flux_W_reg_vert_avg(isnan(adv_vol_flux_W_reg_vert_avg) == 1) = 0;
% adv_vol_flux_N_reg_vert_avg(isnan(adv_vol_flux_N_reg_vert_avg) == 1) = 0;
% adv_vol_flux_S_reg_vert_avg(isnan(adv_vol_flux_S_reg_vert_avg) == 1) = 0;
% adv_vol_flux_top_reg_vert_avg(isnan(adv_vol_flux_top_reg_vert_avg) == 1) = 0;
% adv_vol_flux_E_sloping_top_reg_vert_avg(isnan(adv_vol_flux_E_sloping_top_reg_vert_avg) == 1) = 0;
% adv_vol_flux_W_sloping_top_reg_vert_avg(isnan(adv_vol_flux_W_sloping_top_reg_vert_avg) == 1) = 0;
% adv_vol_flux_N_sloping_top_reg_vert_avg(isnan(adv_vol_flux_N_sloping_top_reg_vert_avg) == 1) = 0;
% adv_vol_flux_S_sloping_top_reg_vert_avg(isnan(adv_vol_flux_S_sloping_top_reg_vert_avg) == 1) = 0;
% adv_vol_flux_bottom_reg_vert_avg(isnan(adv_vol_flux_bottom_reg_vert_avg) == 1) = 0;
% adv_vol_flux_E_sloping_bottom_reg_vert_avg(isnan(adv_vol_flux_E_sloping_bottom_reg_vert_avg) == 1) = 0;
% adv_vol_flux_W_sloping_bottom_reg_vert_avg(isnan(adv_vol_flux_W_sloping_bottom_reg_vert_avg) == 1) = 0;
% adv_vol_flux_N_sloping_bottom_reg_vert_avg(isnan(adv_vol_flux_N_sloping_bottom_reg_vert_avg) == 1) = 0;
% adv_vol_flux_S_sloping_bottom_reg_vert_avg(isnan(adv_vol_flux_S_sloping_bottom_reg_vert_avg) == 1) = 0;
% 
% adv_vol_flux_E_noreg_vert_avg(isnan(adv_vol_flux_E_noreg_vert_avg) == 1) = 0;
% adv_vol_flux_W_noreg_vert_avg(isnan(adv_vol_flux_W_noreg_vert_avg) == 1) = 0;
% adv_vol_flux_N_noreg_vert_avg(isnan(adv_vol_flux_N_noreg_vert_avg) == 1) = 0;
% adv_vol_flux_S_noreg_vert_avg(isnan(adv_vol_flux_S_noreg_vert_avg) == 1) = 0;
% adv_vol_flux_top_noreg_vert_avg(isnan(adv_vol_flux_top_noreg_vert_avg) == 1) = 0;
% adv_vol_flux_E_sloping_top_noreg_vert_avg(isnan(adv_vol_flux_E_sloping_top_noreg_vert_avg) == 1) = 0;
% adv_vol_flux_W_sloping_top_noreg_vert_avg(isnan(adv_vol_flux_W_sloping_top_noreg_vert_avg) == 1) = 0;
% adv_vol_flux_N_sloping_top_noreg_vert_avg(isnan(adv_vol_flux_N_sloping_top_noreg_vert_avg) == 1) = 0;
% adv_vol_flux_S_sloping_top_noreg_vert_avg(isnan(adv_vol_flux_S_sloping_top_noreg_vert_avg) == 1) = 0;
% adv_vol_flux_bottom_noreg_vert_avg(isnan(adv_vol_flux_bottom_noreg_vert_avg) == 1) = 0;
% adv_vol_flux_E_sloping_bottom_noreg_vert_avg(isnan(adv_vol_flux_E_sloping_bottom_noreg_vert_avg) == 1) = 0;
% adv_vol_flux_W_sloping_bottom_noreg_vert_avg(isnan(adv_vol_flux_W_sloping_bottom_noreg_vert_avg) == 1) = 0;
% adv_vol_flux_N_sloping_bottom_noreg_vert_avg(isnan(adv_vol_flux_N_sloping_bottom_noreg_vert_avg) == 1) = 0;
% adv_vol_flux_S_sloping_bottom_noreg_vert_avg(isnan(adv_vol_flux_S_sloping_bottom_noreg_vert_avg) == 1) = 0;
% 
% ent_vol_flux_top_reg_vert_avg(isnan(ent_vol_flux_top_reg_vert_avg) == 1) = 0;
% ent_vol_flux_bottom_reg_vert_avg(isnan(ent_vol_flux_bottom_reg_vert_avg) == 1) = 0;
% ent_vol_flux_top_noreg_vert_avg(isnan(ent_vol_flux_top_noreg_vert_avg) == 1) = 0;
% ent_vol_flux_bottom_noreg_vert_avg(isnan(ent_vol_flux_bottom_noreg_vert_avg) == 1) = 0;
% 
% 
% 
% curr_uvel_E_mask = zeros(size(in_box_mask));
% curr_uvel_E_mask(intersect([(no_corners_E_edge_ind'); at_NE_corner_ind; at_SE_corner_ind],uvel_E_edge_ind)) = 1; 
% curr_uvel_W_mask = zeros(size(in_box_mask));
% curr_vvel_N_mask = zeros(size(in_box_mask));
% curr_vvel_N_mask(intersect(no_corners_E_edge_ind',vvel_N_edge_ind)) = 1; 
% curr_vvel_S_mask = zeros(size(in_box_mask));
% curr_vvel_S_mask(intersect(no_corners_E_edge_ind',vvel_S_edge_ind)) = 1; 
% T_tend_adv_along_E_edge = squeeze(sum(sum((repmat(curr_uvel_E_mask.*tarea,[1 1 length(unique_times)]).*layer_thickness_array.*adv_T_tend_uvel_T_reg_all_E_side_only) + (repmat(curr_uvel_W_mask.*tarea,[1 1 length(unique_times)]).*layer_thickness_array.*adv_T_tend_uvel_T_reg_all_W_side_only) + (repmat(curr_vvel_N_mask.*tarea,[1 1 length(unique_times)]).*layer_thickness_array.*adv_T_tend_vvel_T_reg_all_N_side_only) + (repmat(curr_vvel_S_mask.*tarea,[1 1 length(unique_times)]).*layer_thickness_array.*adv_T_tend_vvel_T_reg_all_S_side_only),2),1))./vol_integrated_inbox;
% % T_tend_adv_reg_terms_along_edges(1) = mean(T_tend_adv_along_E_edge(time_avg_from_unique_reg_ind));
% adv_vol_flux_along_E_edge = squeeze(sum(sum((repmat(curr_uvel_E_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_E_vert_avg)) + (repmat(curr_uvel_W_mask,[1 1 length(unique_times)]).*adv_vol_flux_W_vert_avg) + (repmat(curr_vvel_N_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_N_vert_avg)) + (repmat(curr_vvel_S_mask,[1 1 length(unique_times)]).*adv_vol_flux_S_vert_avg),2),1));
% adv_vol_flux_along_E_edge_reg = squeeze(sum(sum((repmat(curr_uvel_E_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_E_reg_vert_avg)) + (repmat(curr_uvel_W_mask,[1 1 length(unique_times)]).*adv_vol_flux_W_reg_vert_avg) + (repmat(curr_vvel_N_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_N_reg_vert_avg)) + (repmat(curr_vvel_S_mask,[1 1 length(unique_times)]).*adv_vol_flux_S_reg_vert_avg),2),1));
% adv_vol_flux_along_E_edge_noreg = squeeze(sum(sum((repmat(curr_uvel_E_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_E_noreg_vert_avg)) + (repmat(curr_uvel_W_mask,[1 1 length(unique_times)]).*adv_vol_flux_W_noreg_vert_avg) + (repmat(curr_vvel_N_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_N_noreg_vert_avg)) + (repmat(curr_vvel_S_mask,[1 1 length(unique_times)]).*adv_vol_flux_S_noreg_vert_avg),2),1));
% 
% curr_uvel_E_mask = zeros(size(in_box_mask));
% curr_uvel_W_mask = zeros(size(in_box_mask));
% curr_uvel_W_mask(intersect([(no_corners_W_edge_ind'); at_NW_corner_ind; at_SW_corner_ind],uvel_W_edge_ind)) = 1; 
% curr_vvel_N_mask = zeros(size(in_box_mask));
% curr_vvel_N_mask(intersect(no_corners_W_edge_ind',vvel_N_edge_ind)) = 1; 
% curr_vvel_S_mask = zeros(size(in_box_mask));
% curr_vvel_S_mask(intersect(no_corners_W_edge_ind',vvel_S_edge_ind)) = 1; 
% T_tend_adv_along_W_edge = squeeze(sum(sum((repmat(curr_uvel_E_mask.*tarea,[1 1 length(unique_times)]).*layer_thickness_array.*adv_T_tend_uvel_T_reg_all_E_side_only) + (repmat(curr_uvel_W_mask.*tarea,[1 1 length(unique_times)]).*layer_thickness_array.*adv_T_tend_uvel_T_reg_all_W_side_only) + (repmat(curr_vvel_N_mask.*tarea,[1 1 length(unique_times)]).*layer_thickness_array.*adv_T_tend_vvel_T_reg_all_N_side_only) + (repmat(curr_vvel_S_mask.*tarea,[1 1 length(unique_times)]).*layer_thickness_array.*adv_T_tend_vvel_T_reg_all_S_side_only),2),1))./vol_integrated_inbox;
% % T_tend_adv_reg_terms_along_edges(2) = mean(T_tend_adv_along_W_edge(time_avg_from_unique_reg_ind));
% adv_vol_flux_along_W_edge = squeeze(sum(sum((repmat(curr_uvel_E_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_E_vert_avg)) + (repmat(curr_uvel_W_mask,[1 1 length(unique_times)]).*adv_vol_flux_W_vert_avg) + (repmat(curr_vvel_N_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_N_vert_avg)) + (repmat(curr_vvel_S_mask,[1 1 length(unique_times)]).*adv_vol_flux_S_vert_avg),2),1));
% adv_vol_flux_along_W_edge_reg = squeeze(sum(sum((repmat(curr_uvel_E_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_E_reg_vert_avg)) + (repmat(curr_uvel_W_mask,[1 1 length(unique_times)]).*adv_vol_flux_W_reg_vert_avg) + (repmat(curr_vvel_N_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_N_reg_vert_avg)) + (repmat(curr_vvel_S_mask,[1 1 length(unique_times)]).*adv_vol_flux_S_reg_vert_avg),2),1));
% adv_vol_flux_along_W_edge_noreg = squeeze(sum(sum((repmat(curr_uvel_E_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_E_noreg_vert_avg)) + (repmat(curr_uvel_W_mask,[1 1 length(unique_times)]).*adv_vol_flux_W_noreg_vert_avg) + (repmat(curr_vvel_N_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_N_noreg_vert_avg)) + (repmat(curr_vvel_S_mask,[1 1 length(unique_times)]).*adv_vol_flux_S_noreg_vert_avg),2),1));
% 
% curr_uvel_E_mask = zeros(size(in_box_mask));
% curr_uvel_E_mask(intersect(no_corners_N_edge_ind',uvel_E_edge_ind)) = 1;
% curr_uvel_W_mask = zeros(size(in_box_mask));
% curr_uvel_W_mask(intersect(no_corners_N_edge_ind',uvel_W_edge_ind)) = 1; 
% curr_vvel_N_mask = zeros(size(in_box_mask));
% curr_vvel_N_mask(intersect([(no_corners_N_edge_ind'); at_NE_corner_ind; at_NW_corner_ind],vvel_N_edge_ind)) = 1; 
% curr_vvel_S_mask = zeros(size(in_box_mask));
% T_tend_adv_along_N_edge = squeeze(sum(sum((repmat(curr_uvel_E_mask.*tarea,[1 1 length(unique_times)]).*layer_thickness_array.*adv_T_tend_uvel_T_reg_all_E_side_only) + (repmat(curr_uvel_W_mask.*tarea,[1 1 length(unique_times)]).*layer_thickness_array.*adv_T_tend_uvel_T_reg_all_W_side_only) + (repmat(curr_vvel_N_mask.*tarea,[1 1 length(unique_times)]).*layer_thickness_array.*adv_T_tend_vvel_T_reg_all_N_side_only) + (repmat(curr_vvel_S_mask.*tarea,[1 1 length(unique_times)]).*layer_thickness_array.*adv_T_tend_vvel_T_reg_all_S_side_only),2),1))./vol_integrated_inbox;
% % T_tend_adv_reg_terms_along_edges(3) = mean(T_tend_adv_along_N_edge(time_avg_from_unique_reg_ind));
% adv_vol_flux_along_N_edge = squeeze(sum(sum((repmat(curr_uvel_E_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_E_vert_avg)) + (repmat(curr_uvel_W_mask,[1 1 length(unique_times)]).*adv_vol_flux_W_vert_avg) + (repmat(curr_vvel_N_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_N_vert_avg)) + (repmat(curr_vvel_S_mask,[1 1 length(unique_times)]).*adv_vol_flux_S_vert_avg),2),1));
% adv_vol_flux_along_N_edge_reg = squeeze(sum(sum((repmat(curr_uvel_E_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_E_reg_vert_avg)) + (repmat(curr_uvel_W_mask,[1 1 length(unique_times)]).*adv_vol_flux_W_reg_vert_avg) + (repmat(curr_vvel_N_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_N_reg_vert_avg)) + (repmat(curr_vvel_S_mask,[1 1 length(unique_times)]).*adv_vol_flux_S_reg_vert_avg),2),1));
% adv_vol_flux_along_N_edge_noreg = squeeze(sum(sum((repmat(curr_uvel_E_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_E_noreg_vert_avg)) + (repmat(curr_uvel_W_mask,[1 1 length(unique_times)]).*adv_vol_flux_W_noreg_vert_avg) + (repmat(curr_vvel_N_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_N_noreg_vert_avg)) + (repmat(curr_vvel_S_mask,[1 1 length(unique_times)]).*adv_vol_flux_S_noreg_vert_avg),2),1));
% 
% curr_uvel_E_mask = zeros(size(in_box_mask));
% curr_uvel_E_mask(intersect(no_corners_S_edge_ind',uvel_E_edge_ind)) = 1;
% curr_uvel_W_mask = zeros(size(in_box_mask));
% curr_uvel_W_mask(intersect(no_corners_S_edge_ind',uvel_W_edge_ind)) = 1; 
% curr_vvel_N_mask = zeros(size(in_box_mask));
% curr_vvel_S_mask = zeros(size(in_box_mask));
% curr_vvel_S_mask(intersect([(no_corners_S_edge_ind'); at_SE_corner_ind; at_SW_corner_ind],vvel_S_edge_ind)) = 1; 
% T_tend_adv_along_S_edge = squeeze(sum(sum((repmat(curr_uvel_E_mask.*tarea,[1 1 length(unique_times)]).*layer_thickness_array.*adv_T_tend_uvel_T_reg_all_E_side_only) + (repmat(curr_uvel_W_mask.*tarea,[1 1 length(unique_times)]).*layer_thickness_array.*adv_T_tend_uvel_T_reg_all_W_side_only) + (repmat(curr_vvel_N_mask.*tarea,[1 1 length(unique_times)]).*layer_thickness_array.*adv_T_tend_vvel_T_reg_all_N_side_only) + (repmat(curr_vvel_S_mask.*tarea,[1 1 length(unique_times)]).*layer_thickness_array.*adv_T_tend_vvel_T_reg_all_S_side_only),2),1))./vol_integrated_inbox;
% % T_tend_adv_reg_terms_along_edges(4) = mean(T_tend_adv_along_S_edge(time_avg_from_unique_reg_ind));
% adv_vol_flux_along_S_edge = squeeze(sum(sum((repmat(curr_uvel_E_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_E_vert_avg)) + (repmat(curr_uvel_W_mask,[1 1 length(unique_times)]).*adv_vol_flux_W_vert_avg) + (repmat(curr_vvel_N_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_N_vert_avg)) + (repmat(curr_vvel_S_mask,[1 1 length(unique_times)]).*adv_vol_flux_S_vert_avg),2),1));
% adv_vol_flux_along_S_edge_reg = squeeze(sum(sum((repmat(curr_uvel_E_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_E_reg_vert_avg)) + (repmat(curr_uvel_W_mask,[1 1 length(unique_times)]).*adv_vol_flux_W_reg_vert_avg) + (repmat(curr_vvel_N_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_N_reg_vert_avg)) + (repmat(curr_vvel_S_mask,[1 1 length(unique_times)]).*adv_vol_flux_S_reg_vert_avg),2),1));
% adv_vol_flux_along_S_edge_noreg = squeeze(sum(sum((repmat(curr_uvel_E_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_E_noreg_vert_avg)) + (repmat(curr_uvel_W_mask,[1 1 length(unique_times)]).*adv_vol_flux_W_noreg_vert_avg) + (repmat(curr_vvel_N_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_N_noreg_vert_avg)) + (repmat(curr_vvel_S_mask,[1 1 length(unique_times)]).*adv_vol_flux_S_noreg_vert_avg),2),1));
% 
% T_tend_adv_along_top_edge = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 length(unique_times)]).*layer_thickness_array.*adv_T_tend_vel_T_reg_all_top,2),1))./vol_integrated_inbox;
% % T_tend_adv_reg_terms_along_edges(5) = mean(T_tend_adv_along_top_edge(time_avg_from_unique_reg_ind));
% adv_vol_flux_vert_through_top = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_top_vert_avg),2),1));
% adv_vol_flux_through_E_sloping_top = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_E_sloping_top_vert_avg),2),1));
% adv_vol_flux_through_W_sloping_top = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*adv_vol_flux_W_sloping_top_vert_avg,2),1));
% adv_vol_flux_through_N_sloping_top = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_N_sloping_top_vert_avg),2),1));
% adv_vol_flux_through_S_sloping_top = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*adv_vol_flux_S_sloping_top_vert_avg,2),1));
% adv_vol_flux_along_top_edge = adv_vol_flux_vert_through_top + adv_vol_flux_through_E_sloping_top + adv_vol_flux_through_W_sloping_top + adv_vol_flux_through_N_sloping_top + adv_vol_flux_through_S_sloping_top;
% adv_vol_flux_vert_through_top_reg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_top_reg_vert_avg),2),1));
% adv_vol_flux_through_E_sloping_top_reg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_E_sloping_top_reg_vert_avg),2),1));
% adv_vol_flux_through_W_sloping_top_reg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*adv_vol_flux_W_sloping_top_reg_vert_avg,2),1));
% adv_vol_flux_through_N_sloping_top_reg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_N_sloping_top_reg_vert_avg),2),1));
% adv_vol_flux_through_S_sloping_top_reg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*adv_vol_flux_S_sloping_top_reg_vert_avg,2),1));
% adv_vol_flux_along_top_edge_reg = adv_vol_flux_vert_through_top_reg + adv_vol_flux_through_E_sloping_top_reg + adv_vol_flux_through_W_sloping_top_reg + adv_vol_flux_through_N_sloping_top_reg + adv_vol_flux_through_S_sloping_top_reg;
% adv_vol_flux_vert_through_top_noreg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_top_noreg_vert_avg),2),1));
% adv_vol_flux_through_E_sloping_top_noreg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_E_sloping_top_noreg_vert_avg),2),1));
% adv_vol_flux_through_W_sloping_top_noreg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*adv_vol_flux_W_sloping_top_noreg_vert_avg,2),1));
% adv_vol_flux_through_N_sloping_top_noreg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_N_sloping_top_noreg_vert_avg),2),1));
% adv_vol_flux_through_S_sloping_top_noreg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*adv_vol_flux_S_sloping_top_noreg_vert_avg,2),1));
% adv_vol_flux_along_top_edge_noreg = adv_vol_flux_vert_through_top_noreg + adv_vol_flux_through_E_sloping_top_noreg + adv_vol_flux_through_W_sloping_top_noreg + adv_vol_flux_through_N_sloping_top_noreg + adv_vol_flux_through_S_sloping_top_noreg;
% 
% T_tend_adv_along_bottom_edge = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 length(unique_times)]).*layer_thickness_array.*adv_T_tend_vel_T_reg_all_bottom,2),1))./vol_integrated_inbox;
% % T_tend_adv_reg_terms_along_edges(6) = mean(T_tend_adv_along_bottom_edge(time_avg_from_unique_reg_ind));
% adv_vol_flux_vert_through_bottom = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*adv_vol_flux_bottom_vert_avg,2),1));
% adv_vol_flux_through_E_sloping_bottom = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_E_sloping_bottom_vert_avg),2),1));
% adv_vol_flux_through_W_sloping_bottom = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*adv_vol_flux_W_sloping_bottom_vert_avg,2),1));
% adv_vol_flux_through_N_sloping_bottom = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_N_sloping_bottom_vert_avg),2),1));
% adv_vol_flux_through_S_sloping_bottom = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*adv_vol_flux_S_sloping_bottom_vert_avg,2),1));
% adv_vol_flux_along_bottom_edge = adv_vol_flux_vert_through_bottom + adv_vol_flux_through_E_sloping_bottom + adv_vol_flux_through_W_sloping_bottom + adv_vol_flux_through_N_sloping_bottom + adv_vol_flux_through_S_sloping_bottom;
% adv_vol_flux_vert_through_bottom_reg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*adv_vol_flux_bottom_reg_vert_avg,2),1));
% adv_vol_flux_through_E_sloping_bottom_reg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_E_sloping_bottom_reg_vert_avg),2),1));
% adv_vol_flux_through_W_sloping_bottom_reg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*adv_vol_flux_W_sloping_bottom_reg_vert_avg,2),1));
% adv_vol_flux_through_N_sloping_bottom_reg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_N_sloping_bottom_reg_vert_avg),2),1));
% adv_vol_flux_through_S_sloping_bottom_reg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*adv_vol_flux_S_sloping_bottom_reg_vert_avg,2),1));
% adv_vol_flux_along_bottom_edge_reg = adv_vol_flux_vert_through_bottom_reg + adv_vol_flux_through_E_sloping_bottom_reg + adv_vol_flux_through_W_sloping_bottom_reg + adv_vol_flux_through_N_sloping_bottom_reg + adv_vol_flux_through_S_sloping_bottom_reg;
% adv_vol_flux_vert_through_bottom_noreg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*adv_vol_flux_bottom_noreg_vert_avg,2),1));
% adv_vol_flux_through_E_sloping_bottom_noreg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_E_sloping_bottom_noreg_vert_avg),2),1));
% adv_vol_flux_through_W_sloping_bottom_noreg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*adv_vol_flux_W_sloping_bottom_noreg_vert_avg,2),1));
% adv_vol_flux_through_N_sloping_bottom_noreg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*(-adv_vol_flux_N_sloping_bottom_noreg_vert_avg),2),1));
% adv_vol_flux_through_S_sloping_bottom_noreg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*adv_vol_flux_S_sloping_bottom_noreg_vert_avg,2),1));
% adv_vol_flux_along_bottom_edge_noreg = adv_vol_flux_vert_through_bottom_noreg + adv_vol_flux_through_E_sloping_bottom_noreg + adv_vol_flux_through_W_sloping_bottom_noreg + adv_vol_flux_through_N_sloping_bottom_noreg + adv_vol_flux_through_S_sloping_bottom_noreg;
% 
% 
% adv_vol_flux_vert_through_bottom = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*adv_vol_flux_bottom_vert_avg,2),1));
% 
% 
% T_tend_adv_all = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 length(unique_times)]).*layer_thickness_array.*adv_T_tend_total,2),1))./vol_integrated_inbox;
% 
% 
% 
% % T_tend_ent_along_top_edge = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*ent_T_tend_top,2),1));
% T_tend_ent_along_top_edge_reg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*ent_T_tend_top,2),1));
% % T_tend_ent_along_top_edge_noreg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*T_tend_ent_top_noreg_vert_avg,2),1));
% % T_tend_ent_along_bottom_edge = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*ent_T_tend_bottom_vert_avg,2),1));
% T_tend_ent_along_bottom_edge_reg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*ent_T_tend_bottom,2),1));
% % T_tend_ent_along_bottom_edge_noreg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*T_tend_ent_bottom_noreg_vert_avg,2),1));
% 
% 
% ent_vol_flux_along_top_edge = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*(-ent_vol_flux_top_vert_avg),2),1));
% ent_vol_flux_along_top_edge_reg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*(-ent_vol_flux_top_reg_vert_avg),2),1));
% ent_vol_flux_along_top_edge_noreg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*(-ent_vol_flux_top_noreg_vert_avg),2),1));
% ent_vol_flux_along_bottom_edge = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*(-ent_vol_flux_bottom_vert_avg),2),1));
% ent_vol_flux_along_bottom_edge_reg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*(-ent_vol_flux_bottom_reg_vert_avg),2),1));
% ent_vol_flux_along_bottom_edge_noreg = squeeze(sum(sum(repmat(in_box_mask,[1 1 length(unique_times)]).*(-ent_vol_flux_bottom_noreg_vert_avg),2),1));
% 
% 
% % adv_T_tend_total_zeronans = adv_T_tend_total;
% % adv_T_tend_total_zeronans(isnan(adv_T_tend_total_zeronans) == 1) = 0;
% % 
% % T_tend_adv_total_inbox = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 length(unique_times)]).*layer_thickness_array.*adv_T_tend_total_zeronans,2),1))./vol_integrated_inbox;
% % T_tend_adv_reg_terms_along_edges(7) = mean(T_tend_adv_total_inbox(time_avg_from_unique_reg_ind));
% 
% % T_tend_adv_reg_terms_along_edges(7) = sum(T_tend_adv_reg_terms_along_edges(1:6));
% T_tend_adv_total_inbox = T_tend_adv_along_E_edge + T_tend_adv_along_W_edge + T_tend_adv_along_N_edge + T_tend_adv_along_S_edge + T_tend_adv_along_top_edge + T_tend_adv_along_bottom_edge;
% adv_vol_flux_net_reg_inbox = adv_vol_flux_along_E_edge_reg + adv_vol_flux_along_W_edge_reg + adv_vol_flux_along_N_edge_reg + adv_vol_flux_along_S_edge_reg + adv_vol_flux_along_top_edge_reg + adv_vol_flux_along_bottom_edge_reg;
% 
% eval(['T_tend_adv_along_E_edge_',reg_var_specifier,' = T_tend_adv_along_E_edge;'])
% clear T_tend_adv_along_E_edge
% eval(['T_tend_adv_along_W_edge_',reg_var_specifier,' = T_tend_adv_along_W_edge;'])
% clear T_tend_adv_along_W_edge
% eval(['T_tend_adv_along_N_edge_',reg_var_specifier,' = T_tend_adv_along_N_edge;'])
% clear T_tend_adv_along_N_edge
% eval(['T_tend_adv_along_S_edge_',reg_var_specifier,' = T_tend_adv_along_S_edge;'])
% clear T_tend_adv_along_S_edge
% eval(['T_tend_adv_along_top_edge_',reg_var_specifier,' = T_tend_adv_along_top_edge;'])
% clear T_tend_adv_along_top_edge
% eval(['T_tend_adv_along_bottom_edge_',reg_var_specifier,' = T_tend_adv_along_bottom_edge;'])
% clear T_tend_adv_along_bottom_edge
% eval(['T_tend_adv_total_inbox_',reg_var_specifier,' = T_tend_adv_total_inbox;'])
% clear T_tend_adv_total_inbox
% 
% eval(['T_tend_ent_along_top_edge_',reg_var_specifier,' = T_tend_ent_along_top_edge_reg;'])
% clear T_tend_ent_along_top_edge_reg
% eval(['T_tend_ent_along_bottom_edge_',reg_var_specifier,' = T_tend_ent_along_bottom_edge_reg;'])
% clear T_tend_ent_along_bottom_edge_reg
% 
% 
% eval(['adv_vol_flux_along_E_edge_',reg_var_specifier,' = adv_vol_flux_along_E_edge_reg;'])
% clear adv_vol_flux_along_E_edge_reg
% eval(['adv_vol_flux_along_W_edge_',reg_var_specifier,' = adv_vol_flux_along_W_edge_reg;'])
% clear adv_vol_flux_along_W_edge_reg
% eval(['adv_vol_flux_along_N_edge_',reg_var_specifier,' = adv_vol_flux_along_N_edge_reg;'])
% clear adv_vol_flux_along_N_edge_reg
% eval(['adv_vol_flux_along_S_edge_',reg_var_specifier,' = adv_vol_flux_along_S_edge_reg;'])
% clear adv_vol_flux_along_S_edge_reg
% eval(['adv_vol_flux_along_top_edge_',reg_var_specifier,' = adv_vol_flux_along_top_edge_reg;'])
% clear adv_vol_flux_along_top_edge_reg
% eval(['adv_vol_flux_along_bottom_edge_',reg_var_specifier,' = adv_vol_flux_along_bottom_edge_reg;'])
% clear adv_vol_flux_along_bottom_edge_reg
% eval(['adv_vol_flux_net_reg_inbox_',reg_var_specifier,' = adv_vol_flux_net_reg_inbox;'])
% clear adv_vol_flux_net_reg_inbox
% 
% eval(['ent_vol_flux_along_top_edge_',reg_var_specifier,' = ent_vol_flux_along_top_edge_reg;'])
% clear ent_vol_flux_along_top_edge_reg
% eval(['ent_vol_flux_along_bottom_edge_',reg_var_specifier,' = ent_vol_flux_along_bottom_edge_reg;'])
% clear ent_vol_flux_along_bottom_edge_reg
% 
% 
% 
% % size_G_reg_array = size(G_reg_array);
% % if length(size_G_reg_array) < 4
% %     size_G_reg_array = [size_G_reg_array 1];
% % end
% 
% eval(['G_reg_cellarray_',reg_var_specifier,' = G_reg_cellarray;'])
% clear G_reg_cellarray
% 
% 
% 
% % G_reg_array_in_seg_avg = NaN([size_G_reg_array([1 2 4]) size(start_dates_avg,1)]);
% % 
% % for seg_ind = 1:size(start_dates_avg,1)
% %     curr_seg_in_unique_times_ind = find((unique_times >= start_datenums_avg(seg_ind)) & (unique_times < end_datenums_avg(seg_ind)));
% %     
% %     G_reg_array_in_seg_avg(:,:,:,seg_ind) = squeeze(mean(G_reg_array(:,:,curr_seg_in_unique_times_ind,:),3));
% % end
% 
% 
% % % save .mat file
% % save(['temp_budget_ws_',reg_avg_file_specifier,'_mod_1.mat'],'-v7.3')
% 
% save(['temp_budget_',reg_avg_file_specifier,'_seasonreg.mat'],'T_tend_adv_along_*','T_tend_adv_total_inbox_*','T_tend_adv_all','T_tend_ent_*','G_reg_cellarray_*','adv_vol_flux_along_*','adv_vol_flux_net_*','ent_vol_flux_along_*','time','unique_times','unique_time_ind','long*','lat*','tlon*','tlat*','adv_T_*','ent_T_*','adv_vol_*_vert_avg','ent_vol_*_vert_avg','vol_integrated_inbox','in_box_mask','layer_thickness_array','tarea','G_seasonal_reg','time_avg_from_unique_reg_ind','-v7.3','-append')
% 
% catch err
% save(['temp_budget_',reg_avg_file_specifier,'_seasonreg_err.mat'],'err')
% % % save .mat file
% % save(['temp_budget_ws_err_',reg_avg_file_specifier,'_seasonreg.mat'],'-v7.3')
% 
% % save(['temp_budget_ws_',reg_avg_file_specifier,'_mod_1_target_qtys.mat'],'T_tend_adv_reg_terms_along_edges','G_reg_array','G_reg_array_in_seg_avg','-v7.3')
% 
% end




% load file to produce map of total process-associated T tend. only
load(['temp_budget_',reg_avg_file_specifier,'_seasonreg.mat'],'adv_T_tend_*_T_reg_all_*','G_seasonal_reg','layer_thickness_array','tarea','vol_integrated_inbox','in_box_mask')

adv_T_tend_vel_T_all_reg = adv_T_tend_uvel_T_reg_all_E_side_only + adv_T_tend_uvel_T_reg_all_W_side_only + adv_T_tend_vvel_T_reg_all_N_side_only + adv_T_tend_vvel_T_reg_all_S_side_only + adv_T_tend_vel_T_reg_all_top + adv_T_tend_vel_T_reg_all_bottom;
size_array = size(adv_T_tend_vel_T_all_reg);
curr_adv_T_tend_vel_T_all_reg_thick_weight = (layer_thickness_array.*adv_T_tend_vel_T_all_reg)./(repmat(reshape(vol_integrated_inbox,[1 1 size_array(3)])/(sum(sum(in_box_mask.*tarea,2),1)),[size_array(1:2) 1]));
adv_T_tend_vel_T_all_reg_seasonal_rect = reshape(reshape(adv_T_tend_vel_T_all_reg,[prod(size_array(1:2)) size_array(3)])*(G_seasonal_reg*(((G_seasonal_reg')*G_seasonal_reg)^(-1)))*(G_seasonal_reg'),size_array);
adv_T_tend_vel_T_all_reg = permute(smooth_endclip(permute(adv_T_tend_vel_T_all_reg - adv_T_tend_vel_T_all_reg_seasonal_rect,[3 1 2]),6),[2 3 1]);

time_avg_from_unique_reg_ind = reshape(repmat((23:1:40)',[1 8]) + repmat(73*([6 7 18 21 27 30 31 32] - 3),[18 1]),[(8*18) 1]);
adv_T_tend_vel_T_all_reg_avg = mean(adv_T_tend_vel_T_all_reg(:,:,time_avg_from_unique_reg_ind),3);

adv_T_tend_vel_T_all_reg_thick_weight_seasonal_rect = reshape(reshape(curr_adv_T_tend_vel_T_all_reg_thick_weight,[prod(size_array(1:2)) size_array(3)])*(G_seasonal_reg*(((G_seasonal_reg')*G_seasonal_reg)^(-1)))*(G_seasonal_reg'),size_array);
adv_T_tend_vel_T_all_reg_thick_weight = permute(smooth_endclip(permute(curr_adv_T_tend_vel_T_all_reg_thick_weight - adv_T_tend_vel_T_all_reg_thick_weight_seasonal_rect,[3 1 2]),6),[2 3 1]);
adv_T_tend_vel_T_all_reg_thick_weight_avg = mean(adv_T_tend_vel_T_all_reg_thick_weight(:,:,time_avg_from_unique_reg_ind),3);

load('temp_budget_Java_map_wstr_SE_Sumatra_allderivs_5lead_1979_to_2009_ML_seasonreg.mat','adv_T_tend_*_T_reg_all_*')
adv_T_tend_vel_T_all_reg = adv_T_tend_uvel_T_reg_all_E_side_only + adv_T_tend_uvel_T_reg_all_W_side_only + adv_T_tend_vvel_T_reg_all_N_side_only + adv_T_tend_vvel_T_reg_all_S_side_only + adv_T_tend_vel_T_reg_all_top + adv_T_tend_vel_T_reg_all_bottom;
curr_adv_T_tend_vel_T_all_reg_thick_weight = (layer_thickness_array.*adv_T_tend_vel_T_all_reg)./(repmat(reshape(vol_integrated_inbox,[1 1 size_array(3)])/(sum(sum(in_box_mask.*tarea,2),1)),[size_array(1:2) 1]));
adv_T_tend_vel_T_all_reg_seasonal_rect = reshape(reshape(adv_T_tend_vel_T_all_reg,[prod(size_array(1:2)) size_array(3)])*(G_seasonal_reg*(((G_seasonal_reg')*G_seasonal_reg)^(-1)))*(G_seasonal_reg'),size_array);
adv_T_tend_vel_T_all_reg = permute(smooth_endclip(permute(adv_T_tend_vel_T_all_reg - adv_T_tend_vel_T_all_reg_seasonal_rect,[3 1 2]),6),[2 3 1]);
adv_T_tend_vel_T_all_reg_avg = adv_T_tend_vel_T_all_reg_avg + mean(adv_T_tend_vel_T_all_reg(:,:,time_avg_from_unique_reg_ind),3);

adv_T_tend_vel_T_all_reg_thick_weight_seasonal_rect = reshape(reshape(curr_adv_T_tend_vel_T_all_reg_thick_weight,[prod(size_array(1:2)) size_array(3)])*(G_seasonal_reg*(((G_seasonal_reg')*G_seasonal_reg)^(-1)))*(G_seasonal_reg'),size_array);
adv_T_tend_vel_T_all_reg_thick_weight = adv_T_tend_vel_T_all_reg_thick_weight + permute(smooth_endclip(permute(curr_adv_T_tend_vel_T_all_reg_thick_weight - adv_T_tend_vel_T_all_reg_thick_weight_seasonal_rect,[3 1 2]),6),[2 3 1]);
adv_T_tend_vel_T_all_reg_thick_weight_avg = mean(adv_T_tend_vel_T_all_reg_thick_weight(:,:,time_avg_from_unique_reg_ind),3);
reg_avg_file_specifier = 'Java_map_wstr_Sumatra_combined_allderivs_1979_to_2009_ML';


% % % load .mat file
% % load(['temp_budget_ws_',reg_avg_file_specifier,'_mod_1.mat'])
% 
% 
% 
% 
% % try
% %     reg_avg_text_specifier = reg_avg_text_specifier_new;
% % end




% plot budget terms


tlon_midlon = tlon - ([diff(tlon(1:2,:),1,1); diff(tlon,1,1)]/2);
tlon_pcolor_plot = tlon_midlon - ([diff(tlon_midlon(:,1:2),1,2) diff(tlon_midlon,1,2)]/2);
tlat_midlat = tlat - ([diff(tlat(:,1:2),1,2) diff(tlat,1,2)]/2);
tlat_pcolor_plot = tlat_midlat - ([diff(tlat_midlat(1:2,:),1,1); diff(tlat_midlat,1,1)]/2);




% % num_overall_terms_to_plot = (1:1:7);
% % 
% % for num_term = 1:length(num_overall_terms_to_plot)
% %     curr_term_name = T_tend_overall_term_names{num_overall_terms_to_plot(num_term)};
% %     
% %     curr_term_array_avg = eval([curr_term_name,'_avg']);
% %     curr_term_array_reg_avg = eval([curr_term_name,'_reg_avg']);
% %     curr_term_array_noreg_avg = eval([curr_term_name,'_noreg_avg']);
% %     
% %     
% %     % plot maps
% %     
% % %     cmap = bcyr(10);
% % %     c_levels = (-0.05:0.01:0.05)';
% % %     cmap = bcyr(12);
% % %     c_levels = (-0.06:0.01:0.06)';
% % %     cmap = bcyr(14);
% % %     bcyr_15 = bcyr(15);
% % %     cmap = bcyr_15([(1:1:7)'; (9:1:15)'],:);
% %     bcyr_15 = bcyr(15);
% %     bcyr_14 = bcyr(14);
% %     cmap = [bcyr_15(1:6,:); bcyr_14(7:8,:); bcyr_15(10:15,:)];
% %     c_levels = (-0.035:0.005:0.035)';
% %     
% %     fig1 = figure(1);
% %     fig1_paper_pos = get(fig1,'PaperPosition');
% %     fig1_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig1_paper_pos(3);
% %     fig1_paper_pos(3:4) = 2*fig1_paper_pos(3:4);
% %     set(fig1,'PaperPosition',fig1_paper_pos,'PaperSize',[22 17])
% %     colormap(cmap)
% %     h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',86400*curr_term_array_avg');
% % %     view(0,90)
% %     caxis([min(c_levels) max(c_levels)])
% %     shading flat
% %     set(h,'edgecolor','none')
% %     set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% %     daspect([1 cosd(mean([latsouth latnorth])) 1])
% %     set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% %     print(gcf,'curr_term_array_plot_temp.png','-dpng','-r300')
% %     close(fig1)
% %     
% %     
% %     % get contour plot and overlay land mask
% %     
% %     rgb_array = imread('curr_term_array_plot_temp.png');
% %     rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% %     
% %     delete('curr_term_array_plot_temp.png')
% %     
% %     
% %     size_rgb_array = size(rgb_array);
% %     landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% %     rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% %     
% %     % convert black undefined areas in SSH field to white shading
% %     black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% %     rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% %     
% %     
% %     rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% %     rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% %     
% %     
% %     fig2 = figure(2);
% %     fig2_paper_pos = get(fig2,'PaperPosition');
% %     set(fig2,'PaperPosition',fig2_paper_pos + [0 (-1.0) 0 2.0])
% %     x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% %     y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% %     h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% %     daspect([1 cosd(mean([latsouth latnorth])) 1])
% % %     set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',16)
% %     set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% %     hold on
% %     line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% % %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% %     hold off
% % %     xlabel('Longitude','FontSize',16)
% % %     ylabel('Latitude','FontSize',16)
% %     xlabel('Longitude','FontSize',20)
% %     ylabel('Latitude','FontSize',20)
% %     % set(gca,'Position',[0.1 0.18 0.8 0.85])
% %     title({['Budget term: ',curr_term_name,',']; reg_avg_text_specifier},'FontSize',12,'Interpreter','none')
% %     colormap(cmap)
% %     cbar = colorbar('location','southoutside');
% %     cbar_labels = cell(1,length(c_levels));
% %     if length(c_levels) < 10
% %         for n_label = 1:length(c_levels)
% %             cbar_labels{n_label} = num2str(c_levels(n_label));
% %         end
% %     else
% %         for n_label = 1:length(c_levels)
% % %             if mod(n_label,2) == 1
% %             
% % %             if ismember(c_levels(n_label),[-0.05 0 0.05]) == 1
% % %         if ismember((1e-10)*round((1e10)*c_levels(n_label)),[-0.05 0 0.05]) == 1
% % %             if ismember((1e-10)*round((1e10)*c_levels(n_label)),((-0.03):0.01:0.03)) == 1
% % %             if ismember((1e-3)*round((1e3)*c_levels(n_label)),((-0.03):0.01:0.03)) == 1
% %             if min(abs(c_levels(n_label) - ((-0.03):0.01:0.03))) < 1e-5
% %                 cbar_labels{n_label} = num2str(c_levels(n_label));
% %             else
% %                 cbar_labels{n_label} = '';
% %             end
% %         end
% %     end
% %     cbar_pos = get(cbar,'Position');
% % %     set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',16)
% % %     set(get(cbar,'xlabel'),'String','Temperature tendency ( ^{o}C day^{-1})','FontSize',16)
% %     set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% %     set(get(cbar,'xlabel'),'String','Temperature tendency ( ^{o}C day^{-1})','FontSize',20)
% %     
% %     saveas(fig2,['Temp_tend_map_',curr_term_name,'_',reg_avg_file_specifier,'.pdf'])
% %     close(fig2)
% %     
% %     
% %     
% %     fig3 = figure(3);
% %     fig3_paper_pos = get(fig3,'PaperPosition');
% %     fig3_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig3_paper_pos(3);
% %     fig3_paper_pos(3:4) = 2*fig3_paper_pos(3:4);
% %     set(fig3,'PaperPosition',fig3_paper_pos,'PaperSize',[22 17])
% %     colormap(cmap)
% %     h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',86400*curr_term_array_reg_avg');
% %     caxis([min(c_levels) max(c_levels)])
% %     shading flat
% %     set(h,'edgecolor','none')
% %     set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% %     daspect([1 cosd(mean([latsouth latnorth])) 1])
% %     set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% %     print(gcf,'curr_term_array_reg_plot_temp.png','-dpng','-r300')
% %     close(fig3)
% %     
% %     
% %     % get contour plot and overlay land mask
% %     
% %     rgb_array = imread('curr_term_array_reg_plot_temp.png');
% %     rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% %     
% %     delete('curr_term_array_reg_plot_temp.png')
% %     
% %     
% %     size_rgb_array = size(rgb_array);
% %     landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% %     rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% %     
% %     % convert black undefined areas in SSH field to white shading
% %     black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% %     rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% %     
% %     
% %     rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% %     rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% %     
% %     
% %     fig4 = figure(4);
% %     fig4_paper_pos = get(fig4,'PaperPosition');
% %     set(fig4,'PaperPosition',fig4_paper_pos + [0 (-1.0) 0 2.0])
% %     x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% %     y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% %     h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% %     daspect([1 cosd(mean([latsouth latnorth])) 1])
% %     set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% %     hold on
% %     line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% % %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% %     hold off
% %     xlabel('Longitude','FontSize',20)
% %     ylabel('Latitude','FontSize',20)
% %     % set(gca,'Position',[0.1 0.18 0.8 0.85])
% %     title({['Budget term: ',curr_term_name,',']; [reg_avg_text_specifier,', regression component']},'FontSize',12,'Interpreter','none')
% %     colormap(cmap)
% %     cbar = colorbar('location','southoutside');
% %     cbar_labels = cell(1,length(c_levels));
% %     if length(c_levels) < 10
% %         for n_label = 1:length(c_levels)
% %             cbar_labels{n_label} = num2str(c_levels(n_label));
% %         end
% %     else
% %         for n_label = 1:length(c_levels)
% % %             if mod(n_label,2) == 1
% % %         if ismember((1e-10)*round((1e10)*c_levels(n_label)),[-0.05 0 0.05]) == 1
% %             if min(abs(c_levels(n_label) - ((-0.03):0.01:0.03))) < 1e-5
% %                 cbar_labels{n_label} = num2str(c_levels(n_label));
% %             else
% %                 cbar_labels{n_label} = '';
% %             end
% %         end
% %     end
% %     cbar_pos = get(cbar,'Position');
% %     set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% %     set(get(cbar,'xlabel'),'String','Temperature tendency ( ^{o}C day^{-1})','FontSize',20)
% %     
% %     saveas(fig4,['Temp_tend_map_',curr_term_name,'_reg_',reg_avg_file_specifier,'.pdf'])
% %     close(fig4)
% %     
% %     
% %     
% %     fig5 = figure(5);
% %     fig5_paper_pos = get(fig5,'PaperPosition');
% %     fig5_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig5_paper_pos(3);
% %     fig5_paper_pos(3:4) = 2*fig5_paper_pos(3:4);
% %     set(fig5,'PaperPosition',fig5_paper_pos,'PaperSize',[22 17])
% %     colormap(cmap)
% %     h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',86400*curr_term_array_noreg_avg');
% %     caxis([min(c_levels) max(c_levels)])
% %     shading flat
% %     set(h,'edgecolor','none')
% %     set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% %     daspect([1 cosd(mean([latsouth latnorth])) 1])
% %     set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% %     print(gcf,'curr_term_array_noreg_plot_temp.png','-dpng','-r300')
% %     close(fig5)
% %     
% %     
% %     % get contour plot and overlay land mask
% %     
% %     rgb_array = imread('curr_term_array_noreg_plot_temp.png');
% %     rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% %     
% %     delete('curr_term_array_noreg_plot_temp.png')
% %     
% %     
% %     size_rgb_array = size(rgb_array);
% %     landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% %     rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% %     
% %     % convert black undefined areas in SSH field to white shading
% %     black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% %     rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% %     
% %     
% %     rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% %     rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% %     
% %     
% %     fig6 = figure(6);
% %     fig6_paper_pos = get(fig6,'PaperPosition');
% %     set(fig6,'PaperPosition',fig6_paper_pos + [0 (-1.0) 0 2.0])
% %     x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% %     y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% %     h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% %     daspect([1 cosd(mean([latsouth latnorth])) 1])
% %     set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% %     hold on
% %     line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% % %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% %     hold off
% %     xlabel('Longitude','FontSize',20)
% %     ylabel('Latitude','FontSize',20)
% %     % set(gca,'Position',[0.1 0.18 0.8 0.85])
% %     title({['Budget term: ',curr_term_name,',']; [reg_avg_text_specifier,', regression removed']},'FontSize',12,'Interpreter','none')
% %     colormap(cmap)
% %     cbar = colorbar('location','southoutside');
% %     cbar_labels = cell(1,length(c_levels));
% %     if length(c_levels) < 10
% %         for n_label = 1:length(c_levels)
% %             cbar_labels{n_label} = num2str(c_levels(n_label));
% %         end
% %     else
% %         for n_label = 1:length(c_levels)
% % %             if mod(n_label,2) == 1
% % %         if ismember((1e-10)*round((1e10)*c_levels(n_label)),[-0.05 0 0.05]) == 1
% %             if min(abs(c_levels(n_label) - ((-0.03):0.01:0.03))) < 1e-5
% %                 cbar_labels{n_label} = num2str(c_levels(n_label));
% %             else
% %                 cbar_labels{n_label} = '';
% %             end
% %         end
% %     end
% %     cbar_pos = get(cbar,'Position');
% %     set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% %     set(get(cbar,'xlabel'),'String','Temperature tendency ( ^{o}C day^{-1})','FontSize',20)
% %     
% %     saveas(fig6,['Temp_tend_map_',curr_term_name,'_noreg_',reg_avg_file_specifier,'.pdf'])
% %     close(fig6)
% %     
% %     
% % end
% % 
% % 
% % 
% % 
% % num_detailed_terms_to_plot = [3 (6:1:10) 25 27 29 30];
% % 
% % for num_term = 1:length(num_detailed_terms_to_plot)
% %     curr_term_name = T_tend_detailed_term_names{num_detailed_terms_to_plot(num_term)};
% %     
% %     curr_term_array_avg = eval([curr_term_name,'_avg']);
% %     curr_term_array_reg_avg = eval([curr_term_name,'_reg_avg']);
% %     curr_term_array_noreg_avg = eval([curr_term_name,'_noreg_avg']);
% %     
% %     
% %     % sum certain terms together for plotting
% %     if num_detailed_terms_to_plot(num_term) == 25
% %         curr_term_name = 'shortwave_flux_T_tend';
% %         curr_term_array_avg = sw_top_flux_T_tend_avg + sw_bottom_flux_T_tend_avg;
% %         curr_term_array_reg_avg = sw_top_flux_T_tend_reg_avg + sw_bottom_flux_T_tend_reg_avg;
% %         curr_term_array_noreg_avg = sw_top_flux_T_tend_noreg_avg + sw_bottom_flux_T_tend_noreg_avg;
% %     elseif num_detailed_terms_to_plot(num_term) == 27
% %         curr_term_name = 'longwave_flux_T_tend';
% %         curr_term_array_avg = longwave_downward_flux_T_tend_avg + longwave_upward_flux_T_tend_avg;
% %         curr_term_array_reg_avg = longwave_downward_flux_T_tend_reg_avg + longwave_upward_flux_T_tend_reg_avg;
% %         curr_term_array_noreg_avg = longwave_downward_flux_T_tend_noreg_avg + longwave_upward_flux_T_tend_noreg_avg;
% %     end
% %     
% %     
% %     % plot maps
% %     
% % %     cmap = bcyr(12);
% % %     c_levels = (-0.06:0.01:0.06)';
% %     bcyr_15 = bcyr(15);
% %     bcyr_14 = bcyr(14);
% %     cmap = [bcyr_15(1:6,:); bcyr_14(7:8,:); bcyr_15(10:15,:)];
% %     c_levels = (-0.035:0.005:0.035)';
% %     
% %     fig1 = figure(1);
% %     fig1_paper_pos = get(fig1,'PaperPosition');
% %     fig1_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig1_paper_pos(3);
% %     fig1_paper_pos(3:4) = 2*fig1_paper_pos(3:4);
% %     set(fig1,'PaperPosition',fig1_paper_pos,'PaperSize',[22 17])
% %     colormap(cmap)
% %     h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',86400*curr_term_array_avg');
% %     caxis([min(c_levels) max(c_levels)])
% %     shading flat
% %     set(h,'edgecolor','none')
% %     set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% %     daspect([1 cosd(mean([latsouth latnorth])) 1])
% %     set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% %     print(gcf,'curr_term_array_plot_temp.png','-dpng','-r300')
% %     close(fig1)
% %     
% %     
% %     % get contour plot and overlay land mask
% %     
% %     rgb_array = imread('curr_term_array_plot_temp.png');
% %     rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% %     
% %     delete('curr_term_array_plot_temp.png')
% %     
% %     
% %     size_rgb_array = size(rgb_array);
% %     landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% %     rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% %     
% %     % convert black undefined areas in SSH field to white shading
% %     black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% %     rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% %     
% %     
% %     rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% %     rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% %     
% %     
% %     fig2 = figure(2);
% %     fig2_paper_pos = get(fig2,'PaperPosition');
% %     set(fig2,'PaperPosition',fig2_paper_pos + [0 (-1.0) 0 2.0])
% %     x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% %     y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% %     h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% %     daspect([1 cosd(mean([latsouth latnorth])) 1])
% %     set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% %     hold on
% %     line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% % %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% %     hold off
% %     xlabel('Longitude','FontSize',20)
% %     ylabel('Latitude','FontSize',20)
% %     % set(gca,'Position',[0.1 0.18 0.8 0.85])
% %     title({['Budget term: ',curr_term_name,',']; reg_avg_text_specifier},'FontSize',12,'Interpreter','none')
% %     colormap(cmap)
% %     cbar = colorbar('location','southoutside');
% %     cbar_labels = cell(1,length(c_levels));
% %     if length(c_levels) < 10
% %         for n_label = 1:length(c_levels)
% %             cbar_labels{n_label} = num2str(c_levels(n_label));
% %         end
% %     else
% %         for n_label = 1:length(c_levels)
% % %             if mod(n_label,2) == 1
% % %         if ismember((1e-10)*round((1e10)*c_levels(n_label)),[-0.05 0 0.05]) == 1
% %             if min(abs(c_levels(n_label) - ((-0.03):0.01:0.03))) < 1e-5
% %                 cbar_labels{n_label} = num2str(c_levels(n_label));
% %             else
% %                 cbar_labels{n_label} = '';
% %             end
% %         end
% %     end
% %     cbar_pos = get(cbar,'Position');
% %     set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% %     set(get(cbar,'xlabel'),'String','Temperature tendency ( ^{o}C day^{-1})','FontSize',20)
% %     
% %     saveas(fig2,['Temp_tend_map_',curr_term_name,'_',reg_avg_file_specifier,'.pdf'])
% %     close(fig2)
% %     
% %     
% %     
% %     fig3 = figure(3);
% %     fig3_paper_pos = get(fig3,'PaperPosition');
% %     fig3_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig3_paper_pos(3);
% %     fig3_paper_pos(3:4) = 2*fig3_paper_pos(3:4);
% %     set(fig3,'PaperPosition',fig3_paper_pos,'PaperSize',[22 17])
% %     colormap(cmap)
% %     h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',86400*curr_term_array_reg_avg');
% %     caxis([min(c_levels) max(c_levels)])
% %     shading flat
% %     set(h,'edgecolor','none')
% %     set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% %     daspect([1 cosd(mean([latsouth latnorth])) 1])
% %     set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% %     print(gcf,'curr_term_array_reg_plot_temp.png','-dpng','-r300')
% %     close(fig3)
% %     
% %     
% %     % get contour plot and overlay land mask
% %     
% %     rgb_array = imread('curr_term_array_reg_plot_temp.png');
% %     rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% %     
% %     delete('curr_term_array_reg_plot_temp.png')
% %     
% %     
% %     size_rgb_array = size(rgb_array);
% %     landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% %     rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% %     
% %     % convert black undefined areas in SSH field to white shading
% %     black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% %     rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% %     
% %     
% %     rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% %     rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% %     
% %     
% %     fig4 = figure(4);
% %     fig4_paper_pos = get(fig4,'PaperPosition');
% %     set(fig4,'PaperPosition',fig4_paper_pos + [0 (-1.0) 0 2.0])
% %     x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% %     y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% %     h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% %     daspect([1 cosd(mean([latsouth latnorth])) 1])
% %     set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% %     hold on
% %     line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% % %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% %     hold off
% %     xlabel('Longitude','FontSize',20)
% %     ylabel('Latitude','FontSize',20)
% %     % set(gca,'Position',[0.1 0.18 0.8 0.85])
% %     title({['Budget term: ',curr_term_name,',']; [reg_avg_text_specifier,', regression component']},'FontSize',12,'Interpreter','none')
% %     colormap(cmap)
% %     cbar = colorbar('location','southoutside');
% %     cbar_labels = cell(1,length(c_levels));
% %     if length(c_levels) < 10
% %         for n_label = 1:length(c_levels)
% %             cbar_labels{n_label} = num2str(c_levels(n_label));
% %         end
% %     else
% %         for n_label = 1:length(c_levels)
% % %             if mod(n_label,2) == 1
% % %         if ismember((1e-10)*round((1e10)*c_levels(n_label)),[-0.05 0 0.05]) == 1
% %             if min(abs(c_levels(n_label) - ((-0.03):0.01:0.03))) < 1e-5
% %                 cbar_labels{n_label} = num2str(c_levels(n_label));
% %             else
% %                 cbar_labels{n_label} = '';
% %             end
% %         end
% %     end
% %     cbar_pos = get(cbar,'Position');
% %     set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% %     set(get(cbar,'xlabel'),'String','Temperature tendency ( ^{o}C day^{-1})','FontSize',20)
% %     
% %     saveas(fig4,['Temp_tend_map_',curr_term_name,'_reg_',reg_avg_file_specifier,'.pdf'])
% %     close(fig4)
% %     
% %     
% %     
% %     fig5 = figure(5);
% %     fig5_paper_pos = get(fig5,'PaperPosition');
% %     fig5_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig5_paper_pos(3);
% %     fig5_paper_pos(3:4) = 2*fig5_paper_pos(3:4);
% %     set(fig5,'PaperPosition',fig5_paper_pos,'PaperSize',[22 17])
% %     colormap(cmap)
% %     h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',86400*curr_term_array_noreg_avg');
% %     caxis([min(c_levels) max(c_levels)])
% %     shading flat
% %     set(h,'edgecolor','none')
% %     set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% %     daspect([1 cosd(mean([latsouth latnorth])) 1])
% %     set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% %     print(gcf,'curr_term_array_noreg_plot_temp.png','-dpng','-r300')
% %     close(fig5)
% %     
% %     
% %     % get contour plot and overlay land mask
% %     
% %     rgb_array = imread('curr_term_array_noreg_plot_temp.png');
% %     rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% %     
% %     delete('curr_term_array_noreg_plot_temp.png')
% %     
% %     
% %     size_rgb_array = size(rgb_array);
% %     landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% %     rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% %     
% %     % convert black undefined areas in SSH field to white shading
% %     black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% %     rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% %     
% %     
% %     rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% %     rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% %     
% %     
% %     fig6 = figure(6);
% %     fig6_paper_pos = get(fig6,'PaperPosition');
% %     set(fig6,'PaperPosition',fig6_paper_pos + [0 (-1.0) 0 2.0])
% %     x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% %     y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% %     h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% %     daspect([1 cosd(mean([latsouth latnorth])) 1])
% %     set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% %     hold on
% %     line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% % %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% %     hold off
% %     xlabel('Longitude','FontSize',20)
% %     ylabel('Latitude','FontSize',20)
% %     % set(gca,'Position',[0.1 0.18 0.8 0.85])
% %     title({['Budget term: ',curr_term_name,',']; [reg_avg_text_specifier,', regression removed']},'FontSize',12,'Interpreter','none')
% %     colormap(cmap)
% %     cbar = colorbar('location','southoutside');
% %     cbar_labels = cell(1,length(c_levels));
% %     if length(c_levels) < 10
% %         for n_label = 1:length(c_levels)
% %             cbar_labels{n_label} = num2str(c_levels(n_label));
% %         end
% %     else
% %         for n_label = 1:length(c_levels)
% % %             if mod(n_label,2) == 1
% % %         if ismember((1e-10)*round((1e10)*c_levels(n_label)),[-0.05 0 0.05]) == 1
% %             if min(abs(c_levels(n_label) - ((-0.03):0.01:0.03))) < 1e-5
% %                 cbar_labels{n_label} = num2str(c_levels(n_label));
% %             else
% %                 cbar_labels{n_label} = '';
% %             end
% %         end
% %     end
% %     cbar_pos = get(cbar,'Position');
% %     set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% %     set(get(cbar,'xlabel'),'String','Temperature tendency ( ^{o}C day^{-1})','FontSize',20)
% %     
% %     saveas(fig6,['Temp_tend_map_',curr_term_name,'_noreg_',reg_avg_file_specifier,'.pdf'])
% %     close(fig6)
% %     
% %     
% % end





    
% plot velocity-temperature regression decomposition terms


% adv_T_tend_vel_reg_T_reg_all_avg = adv_T_tend_uvel_reg_T_reg_all_avg + adv_T_tend_vvel_reg_T_reg_all_avg + adv_T_tend_wvel_reg_T_reg_all_avg;
% adv_T_tend_vel_reg_T_noreg_all_avg = adv_T_tend_uvel_reg_T_noreg_all_avg + adv_T_tend_vvel_reg_T_noreg_all_avg + adv_T_tend_wvel_reg_T_noreg_all_avg;
% adv_T_tend_vel_noreg_T_reg_all_avg = adv_T_tend_uvel_noreg_T_reg_all_avg + adv_T_tend_vvel_noreg_T_reg_all_avg + adv_T_tend_wvel_noreg_T_reg_all_avg;
% adv_T_tend_vel_noreg_T_noreg_all_avg = adv_T_tend_uvel_noreg_T_noreg_all_avg + adv_T_tend_vvel_noreg_T_noreg_all_avg + adv_T_tend_wvel_noreg_T_noreg_all_avg;
% 
% adv_T_tend_vel_T_all_reg_avg = adv_T_tend_vel_reg_T_reg_all_avg + adv_T_tend_vel_reg_T_noreg_all_avg + adv_T_tend_vel_noreg_T_reg_all_avg;

% % adv_T_tend_vel_reg_and_noreg_T_noreg_avg = adv_T_tend_vel_reg_T_noreg_all_avg + adv_T_tend_vel_noreg_T_noreg_all_avg;
% % 
% % 
% % 
% % curr_term_name = 'adv_T_tend_vel_reg_T_reg_all_avg';
% % curr_term_array_avg = adv_T_tend_vel_reg_T_reg_all_avg;
% % 
% % % cmap = bcyr(12);
% % % c_levels = (-0.06:0.01:0.06)';
% % bcyr_15 = bcyr(15);
% % bcyr_14 = bcyr(14);
% % cmap = [bcyr_15(1:6,:); bcyr_14(7:8,:); bcyr_15(10:15,:)];
% % c_levels = (-0.035:0.005:0.035)';
% % 
% % fig1 = figure(1);
% % fig1_paper_pos = get(fig1,'PaperPosition');
% % fig1_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig1_paper_pos(3);
% % fig1_paper_pos(3:4) = 2*fig1_paper_pos(3:4);
% % set(fig1,'PaperPosition',fig1_paper_pos,'PaperSize',[22 17])
% % colormap(cmap)
% % h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',86400*curr_term_array_avg');
% % caxis([min(c_levels) max(c_levels)])
% % shading flat
% % set(h,'edgecolor','none')
% % set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% % print(gcf,'curr_term_array_plot_temp.png','-dpng','-r300')
% % close(fig1)
% % 
% % 
% % % get contour plot and overlay land mask
% % 
% % rgb_array = imread('curr_term_array_plot_temp.png');
% % rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% % 
% % delete('curr_term_array_plot_temp.png')
% % 
% % 
% % size_rgb_array = size(rgb_array);
% % landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% % rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% % 
% % % convert black undefined areas in SSH field to white shading
% % black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% % rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% % 
% % 
% % rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% % rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% % 
% % 
% % fig2 = figure(2);
% % fig2_paper_pos = get(fig2,'PaperPosition');
% % set(fig2,'PaperPosition',fig2_paper_pos + [0 (-1.0) 0 2.0])
% % x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% % y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% % h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% % hold on
% % line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% % %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% % hold off
% % xlabel('Longitude','FontSize',20)
% % ylabel('Latitude','FontSize',20)
% % % set(gca,'Position',[0.1 0.18 0.8 0.85])
% % title({['Budget term: ',curr_term_name,',']; reg_avg_text_specifier},'FontSize',12,'Interpreter','none')
% % colormap(cmap)
% % cbar = colorbar('location','southoutside');
% % cbar_labels = cell(1,length(c_levels));
% % if length(c_levels) < 10
% %     for n_label = 1:length(c_levels)
% %         cbar_labels{n_label} = num2str(c_levels(n_label));
% %     end
% % else
% %     for n_label = 1:length(c_levels)
% % %         if mod(n_label,2) == 1
% % %         if ismember((1e-10)*round((1e10)*c_levels(n_label)),[-0.05 0 0.05]) == 1
% %         if min(abs(c_levels(n_label) - ((-0.03):0.01:0.03))) < 1e-5
% %             cbar_labels{n_label} = num2str(c_levels(n_label));
% %         else
% %             cbar_labels{n_label} = '';
% %         end
% %     end
% % end
% % cbar_pos = get(cbar,'Position');
% % set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% % set(get(cbar,'xlabel'),'String','Temperature tendency ( ^{o}C day^{-1})','FontSize',20)
% % 
% % saveas(fig2,['Temp_tend_map_',curr_term_name,'_',reg_avg_file_specifier,'.pdf'])
% % close(fig2)
% % 
% % 
% % curr_term_name = 'adv_T_tend_vel_reg_T_noreg_all_avg';
% % curr_term_array_avg = adv_T_tend_vel_reg_T_noreg_all_avg;
% % 
% % fig3 = figure(3);
% % fig3_paper_pos = get(fig3,'PaperPosition');
% % fig3_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig3_paper_pos(3);
% % fig3_paper_pos(3:4) = 2*fig3_paper_pos(3:4);
% % set(fig3,'PaperPosition',fig3_paper_pos,'PaperSize',[22 17])
% % colormap(cmap)
% % h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',86400*curr_term_array_avg');
% % caxis([min(c_levels) max(c_levels)])
% % shading flat
% % set(h,'edgecolor','none')
% % set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% % print(gcf,'curr_term_array_plot_temp.png','-dpng','-r300')
% % close(fig3)
% % 
% % 
% % % get contour plot and overlay land mask
% % 
% % rgb_array = imread('curr_term_array_plot_temp.png');
% % rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% % 
% % delete('curr_term_array_plot_temp.png')
% % 
% % 
% % size_rgb_array = size(rgb_array);
% % landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% % rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% % 
% % % convert black undefined areas in SSH field to white shading
% % black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% % rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% % 
% % 
% % rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% % rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% % 
% % 
% % fig4 = figure(4);
% % fig4_paper_pos = get(fig4,'PaperPosition');
% % set(fig4,'PaperPosition',fig4_paper_pos + [0 (-1.0) 0 2.0])
% % x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% % y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% % h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% % hold on
% % line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% % %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% % hold off
% % xlabel('Longitude','FontSize',20)
% % ylabel('Latitude','FontSize',20)
% % % set(gca,'Position',[0.1 0.18 0.8 0.85])
% % title({['Budget term: ',curr_term_name,',']; reg_avg_text_specifier},'FontSize',12,'Interpreter','none')
% % colormap(cmap)
% % cbar = colorbar('location','southoutside');
% % cbar_labels = cell(1,length(c_levels));
% % if length(c_levels) < 10
% %     for n_label = 1:length(c_levels)
% %         cbar_labels{n_label} = num2str(c_levels(n_label));
% %     end
% % else
% %     for n_label = 1:length(c_levels)
% % %         if mod(n_label,2) == 1
% % %         if ismember((1e-10)*round((1e10)*c_levels(n_label)),[-0.05 0 0.05]) == 1
% %         if min(abs(c_levels(n_label) - ((-0.03):0.01:0.03))) < 1e-5
% %             cbar_labels{n_label} = num2str(c_levels(n_label));
% %         else
% %             cbar_labels{n_label} = '';
% %         end
% %     end
% % end
% % cbar_pos = get(cbar,'Position');
% % set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% % set(get(cbar,'xlabel'),'String','Temperature tendency ( ^{o}C day^{-1})','FontSize',20)
% % 
% % saveas(fig4,['Temp_tend_map_',curr_term_name,'_',reg_avg_file_specifier,'.pdf'])
% % close(fig4)
% % 
% % 
% % curr_term_name = 'adv_T_tend_vel_noreg_T_reg_all_avg';
% % curr_term_array_avg = adv_T_tend_vel_noreg_T_reg_all_avg;
% % 
% % fig5 = figure(5);
% % fig5_paper_pos = get(fig5,'PaperPosition');
% % fig5_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig5_paper_pos(3);
% % fig5_paper_pos(3:4) = 2*fig5_paper_pos(3:4);
% % set(fig5,'PaperPosition',fig5_paper_pos,'PaperSize',[22 17])
% % colormap(cmap)
% % h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',86400*curr_term_array_avg');
% % caxis([min(c_levels) max(c_levels)])
% % shading flat
% % set(h,'edgecolor','none')
% % set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% % print(gcf,'curr_term_array_plot_temp.png','-dpng','-r300')
% % close(fig5)
% % 
% % 
% % % get contour plot and overlay land mask
% % 
% % rgb_array = imread('curr_term_array_plot_temp.png');
% % rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% % 
% % delete('curr_term_array_plot_temp.png')
% % 
% % 
% % size_rgb_array = size(rgb_array);
% % landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% % rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% % 
% % % convert black undefined areas in SSH field to white shading
% % black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% % rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% % 
% % 
% % rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% % rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% % 
% % 
% % fig6 = figure(6);
% % fig6_paper_pos = get(fig6,'PaperPosition');
% % set(fig6,'PaperPosition',fig6_paper_pos + [0 (-1.0) 0 2.0])
% % x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% % y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% % h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% % hold on
% % line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% % %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% % hold off
% % xlabel('Longitude','FontSize',20)
% % ylabel('Latitude','FontSize',20)
% % % set(gca,'Position',[0.1 0.18 0.8 0.85])
% % title({['Budget term: ',curr_term_name,',']; reg_avg_text_specifier},'FontSize',12,'Interpreter','none')
% % colormap(cmap)
% % cbar = colorbar('location','southoutside');
% % cbar_labels = cell(1,length(c_levels));
% % if length(c_levels) < 10
% %     for n_label = 1:length(c_levels)
% %         cbar_labels{n_label} = num2str(c_levels(n_label));
% %     end
% % else
% %     for n_label = 1:length(c_levels)
% % %         if mod(n_label,2) == 1
% % %         if ismember((1e-10)*round((1e10)*c_levels(n_label)),[-0.05 0 0.05]) == 1
% %         if min(abs(c_levels(n_label) - ((-0.03):0.01:0.03))) < 1e-5
% %             cbar_labels{n_label} = num2str(c_levels(n_label));
% %         else
% %             cbar_labels{n_label} = '';
% %         end
% %     end
% % end
% % cbar_pos = get(cbar,'Position');
% % set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% % set(get(cbar,'xlabel'),'String','Temperature tendency ( ^{o}C day^{-1})','FontSize',20)
% % 
% % saveas(fig6,['Temp_tend_map_',curr_term_name,'_',reg_avg_file_specifier,'.pdf'])
% % close(fig6)
% % 
% % 
% % curr_term_name = 'adv_T_tend_vel_noreg_T_noreg_all_avg';
% % curr_term_array_avg = adv_T_tend_vel_noreg_T_noreg_all_avg;
% % 
% % fig7 = figure(7);
% % fig7_paper_pos = get(fig7,'PaperPosition');
% % fig7_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig7_paper_pos(3);
% % fig7_paper_pos(3:4) = 2*fig7_paper_pos(3:4);
% % set(fig7,'PaperPosition',fig7_paper_pos,'PaperSize',[22 17])
% % colormap(cmap)
% % h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',86400*curr_term_array_avg');
% % caxis([min(c_levels) max(c_levels)])
% % shading flat
% % set(h,'edgecolor','none')
% % set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% % print(gcf,'curr_term_array_plot_temp.png','-dpng','-r300')
% % close(fig7)
% % 
% % 
% % % get contour plot and overlay land mask
% % 
% % rgb_array = imread('curr_term_array_plot_temp.png');
% % rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% % 
% % delete('curr_term_array_plot_temp.png')
% % 
% % 
% % size_rgb_array = size(rgb_array);
% % landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% % rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% % 
% % % convert black undefined areas in SSH field to white shading
% % black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% % rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% % 
% % 
% % rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% % rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% % 
% % 
% % fig8 = figure(8);
% % fig8_paper_pos = get(fig8,'PaperPosition');
% % set(fig8,'PaperPosition',fig8_paper_pos + [0 (-1.0) 0 2.0])
% % x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% % y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% % h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% % hold on
% % line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% % %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% % hold off
% % xlabel('Longitude','FontSize',20)
% % ylabel('Latitude','FontSize',20)
% % % set(gca,'Position',[0.1 0.18 0.8 0.85])
% % title({['Budget term: ',curr_term_name,',']; reg_avg_text_specifier},'FontSize',12,'Interpreter','none')
% % colormap(cmap)
% % cbar = colorbar('location','southoutside');
% % cbar_labels = cell(1,length(c_levels));
% % if length(c_levels) < 10
% %     for n_label = 1:length(c_levels)
% %         cbar_labels{n_label} = num2str(c_levels(n_label));
% %     end
% % else
% %     for n_label = 1:length(c_levels)
% % %         if mod(n_label,2) == 1
% % %         if ismember((1e-10)*round((1e10)*c_levels(n_label)),[-0.05 0 0.05]) == 1
% %         if min(abs(c_levels(n_label) - ((-0.03):0.01:0.03))) < 1e-5
% %             cbar_labels{n_label} = num2str(c_levels(n_label));
% %         else
% %             cbar_labels{n_label} = '';
% %         end
% %     end
% % end
% % cbar_pos = get(cbar,'Position');
% % set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% % set(get(cbar,'xlabel'),'String','Temperature tendency ( ^{o}C day^{-1})','FontSize',20)
% % 
% % saveas(fig8,['Temp_tend_map_',curr_term_name,'_',reg_avg_file_specifier,'.pdf'])
% % close(fig8)



curr_term_name = 'adv_T_tend_vel_T_all_reg_avg';
curr_term_array_avg = adv_T_tend_vel_T_all_reg_avg;

nan_ind = find(abs(curr_term_array_avg) < 1e-15);
% nan_ind_adj = unique([nan_ind; setdiff(nan_ind - 1,size(curr_term_array_avg,1)*(0:1:(size(curr_term_array_avg,2) - 1))'); setdiff(nan_ind + 1,(size(curr_term_array_avg,1)*(1:1:size(curr_term_array_avg,2))') + 1); setdiff(nan_ind - size(curr_term_array_avg,1),((-size(curr_term_array_avg,1) + 1):1:0)'); setdiff(nan_ind + size(curr_term_array_avg,1),prod(size(curr_term_array_avg)) + (1:1:size(curr_term_array_avg,1))')]);
nan_ind_adj = nan_ind;

curr_term_array_avg(nan_ind_adj) = NaN;
% high_mag_ind = find(abs(curr_term_array_avg) > 0.025/86400);
% isolated_ind = high_mag_ind((ismember(high_mag_ind - 1,high_mag_ind) == 0) & (ismember(high_mag_ind + 1,high_mag_ind) == 0) & (ismember(high_mag_ind - size(curr_term_array_avg,1),high_mag_ind) == 0) & (ismember(high_mag_ind + size(curr_term_array_avg,1),high_mag_ind) == 0));
spiky_ind = find((abs(diff([NaN(1,size(curr_term_array_avg,2)); curr_term_array_avg],1,1)) > 0.01/86400) & (abs(diff([curr_term_array_avg; NaN(1,size(curr_term_array_avg,2))],1,1)) > 0.01/86400) & (abs(diff([NaN(size(curr_term_array_avg,1),1) curr_term_array_avg],1,2)) > 0.01/86400) & (abs(diff([curr_term_array_avg NaN(size(curr_term_array_avg,1),1)],1,2)) > 0.01/86400) & ((sign(diff([NaN(1,size(curr_term_array_avg,2)); curr_term_array_avg],1,1))).*(sign(diff([curr_term_array_avg; NaN(1,size(curr_term_array_avg,2))],1,1))) < 0) & ((sign(diff([NaN(size(curr_term_array_avg,1),1) curr_term_array_avg],1,2))).*(sign(diff([curr_term_array_avg NaN(size(curr_term_array_avg,1),1)],1,2))) < 0));
curr_term_array_avg(spiky_ind) = NaN;


bcyr_15 = bcyr(15);
bcyr_14 = bcyr(14);
cmap = [bcyr_15(1:6,:); bcyr_14(7:8,:); bcyr_15(10:15,:)];
c_levels = (-0.035:0.005:0.035)';

fig9 = figure(9);
fig9_paper_pos = get(fig9,'PaperPosition');
fig9_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig9_paper_pos(3);
fig9_paper_pos(3:4) = 2*fig9_paper_pos(3:4);
set(fig9,'PaperPosition',fig9_paper_pos,'PaperSize',[22 17])
colormap(cmap)
h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',86400*curr_term_array_avg');
caxis([min(c_levels) max(c_levels)])
shading flat
set(h,'edgecolor','none')
set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
daspect([1 cosd(mean([latsouth latnorth])) 1])
set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
print(gcf,'curr_term_array_plot_temp.png','-dpng','-r300')
close(fig9)


% get contour plot and overlay land mask

rgb_array = imread('curr_term_array_plot_temp.png');
rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);

delete('curr_term_array_plot_temp.png')


size_rgb_array = size(rgb_array);
landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);

% convert black undefined areas in SSH field to white shading
black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);


rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);


fig10 = figure(10);
fig10_paper_pos = get(fig10,'PaperPosition');
set(fig10,'PaperPosition',fig10_paper_pos + [0 (-1.0) 0 2.0])
x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
daspect([1 cosd(mean([latsouth latnorth])) 1])
set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
hold on
line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
%     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
hold off
xlabel('Longitude','FontSize',20)
ylabel('Latitude','FontSize',20)
% set(gca,'Position',[0.1 0.18 0.8 0.85])
title({['Budget term: ',curr_term_name,',']; reg_avg_text_specifier},'FontSize',12,'Interpreter','none')
colormap(cmap)
cbar = colorbar('location','southoutside');
cbar_labels = cell(1,length(c_levels));
if length(c_levels) < 10
    for n_label = 1:length(c_levels)
        cbar_labels{n_label} = num2str(c_levels(n_label));
    end
else
    for n_label = 1:length(c_levels)
%         if mod(n_label,2) == 1
%         if ismember((1e-10)*round((1e10)*c_levels(n_label)),[-0.05 0 0.05]) == 1
        if min(abs(c_levels(n_label) - ((-0.03):0.01:0.03))) < 1e-5
            cbar_labels{n_label} = num2str(c_levels(n_label));
        else
            cbar_labels{n_label} = '';
        end
    end
end
cbar_pos = get(cbar,'Position');
set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
set(get(cbar,'xlabel'),'String','Temperature tendency ( ^{o}C day^{-1})','FontSize',20)

saveas(fig10,['Temp_tend_map_',curr_term_name,'_',reg_avg_file_specifier,'_',time_avg_specifier,'.pdf'])
close(fig10)



load('temp_budget_Java_map_Kelvin_diff_85_95_rem_reg_wstr_SE_cent_Sumatra_1979_to_2009_ML_seasonreg.mat','adv_T_tend_*_T_reg_all_*','adv_T_tend_total')
adv_T_tend_vel_T_all_reg = adv_T_tend_uvel_T_reg_all_E_side_only + adv_T_tend_uvel_T_reg_all_W_side_only + adv_T_tend_vvel_T_reg_all_N_side_only + adv_T_tend_vvel_T_reg_all_S_side_only + adv_T_tend_vel_T_reg_all_top + adv_T_tend_vel_T_reg_all_bottom;
curr_adv_T_tend_vel_T_all_reg_thick_weight = (layer_thickness_array.*adv_T_tend_vel_T_all_reg)./(repmat(reshape(vol_integrated_inbox,[1 1 size_array(3)])/(sum(sum(in_box_mask.*tarea,2),1)),[size_array(1:2) 1]));
adv_T_tend_vel_T_all_reg_seasonal_rect = reshape(reshape(adv_T_tend_vel_T_all_reg,[prod(size_array(1:2)) size_array(3)])*(G_seasonal_reg*(((G_seasonal_reg')*G_seasonal_reg)^(-1)))*(G_seasonal_reg'),size_array);
adv_T_tend_vel_T_all_reg = adv_T_tend_vel_T_all_reg - adv_T_tend_vel_T_all_reg_seasonal_rect;
adv_T_tend_vel_T_all_reg_avg = adv_T_tend_vel_T_all_reg_avg + mean(adv_T_tend_vel_T_all_reg(:,:,time_avg_from_unique_reg_ind),3);

adv_T_tend_vel_T_all_reg_thick_weight_seasonal_rect = reshape(reshape(curr_adv_T_tend_vel_T_all_reg_thick_weight,[prod(size_array(1:2)) size_array(3)])*(G_seasonal_reg*(((G_seasonal_reg')*G_seasonal_reg)^(-1)))*(G_seasonal_reg'),size_array);
adv_T_tend_vel_T_all_reg_thick_weight = adv_T_tend_vel_T_all_reg_thick_weight + permute(smooth_endclip(permute(curr_adv_T_tend_vel_T_all_reg_thick_weight - adv_T_tend_vel_T_all_reg_thick_weight_seasonal_rect,[3 1 2]),6),[2 3 1]);
adv_T_tend_vel_T_all_reg_thick_weight_avg = mean(adv_T_tend_vel_T_all_reg_thick_weight(:,:,time_avg_from_unique_reg_ind),3);

load('temp_budget_Java_map_wstr_local_allderivs_rem_reg_Kelvin_wstr_cent_SE_Sumatra_1979_to_2009_ML_seasonreg.mat','adv_T_tend_*_T_reg_all_*')
adv_T_tend_vel_T_all_reg = adv_T_tend_uvel_T_reg_all_E_side_only + adv_T_tend_uvel_T_reg_all_W_side_only + adv_T_tend_vvel_T_reg_all_N_side_only + adv_T_tend_vvel_T_reg_all_S_side_only + adv_T_tend_vel_T_reg_all_top + adv_T_tend_vel_T_reg_all_bottom;
curr_adv_T_tend_vel_T_all_reg_thick_weight = (layer_thickness_array.*adv_T_tend_vel_T_all_reg)./(repmat(reshape(vol_integrated_inbox,[1 1 size_array(3)])/(sum(sum(in_box_mask.*tarea,2),1)),[size_array(1:2) 1]));
adv_T_tend_vel_T_all_reg_seasonal_rect = reshape(reshape(adv_T_tend_vel_T_all_reg,[prod(size_array(1:2)) size_array(3)])*(G_seasonal_reg*(((G_seasonal_reg')*G_seasonal_reg)^(-1)))*(G_seasonal_reg'),size_array);
adv_T_tend_vel_T_all_reg = adv_T_tend_vel_T_all_reg - adv_T_tend_vel_T_all_reg_seasonal_rect;
adv_T_tend_vel_T_all_reg_avg = adv_T_tend_vel_T_all_reg_avg + mean(adv_T_tend_vel_T_all_reg(:,:,time_avg_from_unique_reg_ind),3);

adv_T_tend_vel_T_all_reg_thick_weight_seasonal_rect = reshape(reshape(curr_adv_T_tend_vel_T_all_reg_thick_weight,[prod(size_array(1:2)) size_array(3)])*(G_seasonal_reg*(((G_seasonal_reg')*G_seasonal_reg)^(-1)))*(G_seasonal_reg'),size_array);
adv_T_tend_vel_T_all_reg_thick_weight = adv_T_tend_vel_T_all_reg_thick_weight + permute(smooth_endclip(permute(curr_adv_T_tend_vel_T_all_reg_thick_weight - adv_T_tend_vel_T_all_reg_thick_weight_seasonal_rect,[3 1 2]),6),[2 3 1]);
adv_T_tend_vel_T_all_reg_thick_weight_avg = mean(adv_T_tend_vel_T_all_reg_thick_weight(:,:,time_avg_from_unique_reg_ind),3);

load('temp_budget_Java_map_mesoscale_vvel_withderiv_1979_to_2009_ML_seasonreg.mat','adv_T_tend_*_T_reg_all_*')
adv_T_tend_vel_T_all_reg = adv_T_tend_uvel_T_reg_all_E_side_only + adv_T_tend_uvel_T_reg_all_W_side_only + adv_T_tend_vvel_T_reg_all_N_side_only + adv_T_tend_vvel_T_reg_all_S_side_only + adv_T_tend_vel_T_reg_all_top + adv_T_tend_vel_T_reg_all_bottom;
curr_adv_T_tend_vel_T_all_reg_thick_weight = (layer_thickness_array.*adv_T_tend_vel_T_all_reg)./(repmat(reshape(vol_integrated_inbox,[1 1 size_array(3)])/(sum(sum(in_box_mask.*tarea,2),1)),[size_array(1:2) 1]));
adv_T_tend_vel_T_all_reg_seasonal_rect = reshape(reshape(adv_T_tend_vel_T_all_reg,[prod(size_array(1:2)) size_array(3)])*(G_seasonal_reg*(((G_seasonal_reg')*G_seasonal_reg)^(-1)))*(G_seasonal_reg'),size_array);
adv_T_tend_vel_T_all_reg = adv_T_tend_vel_T_all_reg - adv_T_tend_vel_T_all_reg_seasonal_rect;
adv_T_tend_vel_T_all_reg_avg = adv_T_tend_vel_T_all_reg_avg + mean(adv_T_tend_vel_T_all_reg(:,:,time_avg_from_unique_reg_ind),3);

adv_T_tend_vel_T_all_reg_thick_weight_seasonal_rect = reshape(reshape(curr_adv_T_tend_vel_T_all_reg_thick_weight,[prod(size_array(1:2)) size_array(3)])*(G_seasonal_reg*(((G_seasonal_reg')*G_seasonal_reg)^(-1)))*(G_seasonal_reg'),size_array);
adv_T_tend_vel_T_all_reg_thick_weight = adv_T_tend_vel_T_all_reg_thick_weight + permute(smooth_endclip(permute(curr_adv_T_tend_vel_T_all_reg_thick_weight - adv_T_tend_vel_T_all_reg_thick_weight_seasonal_rect,[3 1 2]),6),[2 3 1]);
adv_T_tend_vel_T_all_reg_thick_weight_avg = mean(adv_T_tend_vel_T_all_reg_thick_weight(:,:,time_avg_from_unique_reg_ind),3);

load('temp_budget_Java_map_Lombok_vvel_5lead_rem_reg_Kelvin_wstr_cent_SE_Sumatra_local_1979_to_2009_ML_seasonreg.mat','adv_T_tend_*_T_reg_all_*')
adv_T_tend_vel_T_all_reg = adv_T_tend_uvel_T_reg_all_E_side_only + adv_T_tend_uvel_T_reg_all_W_side_only + adv_T_tend_vvel_T_reg_all_N_side_only + adv_T_tend_vvel_T_reg_all_S_side_only + adv_T_tend_vel_T_reg_all_top + adv_T_tend_vel_T_reg_all_bottom;
curr_adv_T_tend_vel_T_all_reg_thick_weight = (layer_thickness_array.*adv_T_tend_vel_T_all_reg)./(repmat(reshape(vol_integrated_inbox,[1 1 size_array(3)])/(sum(sum(in_box_mask.*tarea,2),1)),[size_array(1:2) 1]));
adv_T_tend_vel_T_all_reg_seasonal_rect = reshape(reshape(adv_T_tend_vel_T_all_reg,[prod(size_array(1:2)) size_array(3)])*(G_seasonal_reg*(((G_seasonal_reg')*G_seasonal_reg)^(-1)))*(G_seasonal_reg'),size_array);
adv_T_tend_vel_T_all_reg = adv_T_tend_vel_T_all_reg - adv_T_tend_vel_T_all_reg_seasonal_rect;
adv_T_tend_vel_T_all_reg_avg = adv_T_tend_vel_T_all_reg_avg + mean(adv_T_tend_vel_T_all_reg(:,:,time_avg_from_unique_reg_ind),3);

adv_T_tend_vel_T_all_reg_thick_weight_seasonal_rect = reshape(reshape(curr_adv_T_tend_vel_T_all_reg_thick_weight,[prod(size_array(1:2)) size_array(3)])*(G_seasonal_reg*(((G_seasonal_reg')*G_seasonal_reg)^(-1)))*(G_seasonal_reg'),size_array);
adv_T_tend_vel_T_all_reg_thick_weight = adv_T_tend_vel_T_all_reg_thick_weight + permute(smooth_endclip(permute(curr_adv_T_tend_vel_T_all_reg_thick_weight - adv_T_tend_vel_T_all_reg_thick_weight_seasonal_rect,[3 1 2]),6),[2 3 1]);
adv_T_tend_vel_T_all_reg_thick_weight_avg = mean(adv_T_tend_vel_T_all_reg_thick_weight(:,:,time_avg_from_unique_reg_ind),3);


adv_T_tend_total_thick_weight = (layer_thickness_array.*adv_T_tend_total)./(repmat(reshape(vol_integrated_inbox,[1 1 size_array(3)])/(sum(sum(in_box_mask.*tarea,2),1)),[size_array(1:2) 1]));
adv_T_tend_total_seasonal_rect = reshape(reshape(adv_T_tend_total,[prod(size_array(1:2)) size_array(3)])*(G_seasonal_reg*(((G_seasonal_reg')*G_seasonal_reg)^(-1)))*(G_seasonal_reg'),size_array);


adv_T_tend_vel_T_all_reg_avg_residual = mean(adv_T_tend_total(:,:,time_avg_from_unique_reg_ind) - adv_T_tend_total_seasonal_rect(:,:,time_avg_from_unique_reg_ind),3) - adv_T_tend_vel_T_all_reg_avg;

% curr_term_array_avg = adv_T_tend_vel_T_all_reg_avg_residual;
curr_term_array_avg = adv_T_tend_vel_T_all_reg_avg;


% nan_ind = find(abs(curr_term_array_avg) < 1e-15);
% nan_ind_adj = unique([nan_ind; setdiff(nan_ind - 1,size(curr_term_array_avg,1)*(0:1:(size(curr_term_array_avg,2) - 1))'); setdiff(nan_ind + 1,(size(curr_term_array_avg,1)*(1:1:size(curr_term_array_avg,2))') + 1); setdiff(nan_ind - size(curr_term_array_avg,1),((-size(curr_term_array_avg,1) + 1):1:0)'); setdiff(nan_ind + size(curr_term_array_avg,1),prod(size(curr_term_array_avg)) + (1:1:size(curr_term_array_avg,1))')]);
curr_term_array_avg(nan_ind_adj) = NaN;
% high_mag_ind = find(abs(curr_term_array_avg) > 0.025/86400);
% isolated_ind = high_mag_ind((ismember(high_mag_ind - 1,high_mag_ind) == 0) & (ismember(high_mag_ind + 1,high_mag_ind) == 0) & (ismember(high_mag_ind - size(curr_term_array_avg,1),high_mag_ind) == 0) & (ismember(high_mag_ind + size(curr_term_array_avg,1),high_mag_ind) == 0));
spiky_ind = find((abs(diff([NaN(1,size(curr_term_array_avg,2)); curr_term_array_avg],1,1)) > 0.01/86400) & (abs(diff([curr_term_array_avg; NaN(1,size(curr_term_array_avg,2))],1,1)) > 0.01/86400) & (abs(diff([NaN(size(curr_term_array_avg,1),1) curr_term_array_avg],1,2)) > 0.01/86400) & (abs(diff([curr_term_array_avg NaN(size(curr_term_array_avg,1),1)],1,2)) > 0.01/86400) & ((sign(diff([NaN(1,size(curr_term_array_avg,2)); curr_term_array_avg],1,1))).*(sign(diff([curr_term_array_avg; NaN(1,size(curr_term_array_avg,2))],1,1))) < 0) & ((sign(diff([NaN(size(curr_term_array_avg,1),1) curr_term_array_avg],1,2))).*(sign(diff([curr_term_array_avg NaN(size(curr_term_array_avg,1),1)],1,2))) < 0));
curr_term_array_avg(spiky_ind) = NaN;


bcyr_15 = bcyr(15);
bcyr_14 = bcyr(14);
cmap = [bcyr_15(1:6,:); bcyr_14(7:8,:); bcyr_15(10:15,:)];
c_levels = (-0.035:0.005:0.035)';

fig11 = figure(11);
fig11_paper_pos = get(fig11,'PaperPosition');
fig11_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig11_paper_pos(3);
fig11_paper_pos(3:4) = 2*fig11_paper_pos(3:4);
set(fig11,'PaperPosition',fig11_paper_pos,'PaperSize',[22 17])
colormap(cmap)
h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',86400*curr_term_array_avg');
caxis([min(c_levels) max(c_levels)])
shading flat
set(h,'edgecolor','none')
set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
daspect([1 cosd(mean([latsouth latnorth])) 1])
set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
print(gcf,'curr_term_array_plot_temp.png','-dpng','-r300')
close(fig11)


% get contour plot and overlay land mask

rgb_array = imread('curr_term_array_plot_temp.png');
rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);

delete('curr_term_array_plot_temp.png')


size_rgb_array = size(rgb_array);
landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);

% convert black undefined areas in SSH field to white shading
black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);


rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);


fig12 = figure(12);
fig12_paper_pos = get(fig12,'PaperPosition');
set(fig12,'PaperPosition',fig12_paper_pos + [0 (-1.0) 0 2.0])
x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
daspect([1 cosd(mean([latsouth latnorth])) 1])
set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
hold on
line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
%     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
hold off
xlabel('Longitude','FontSize',20)
ylabel('Latitude','FontSize',20)
% set(gca,'Position',[0.1 0.18 0.8 0.85])
% title('Budget term: residual','FontSize',12,'Interpreter','none')
title('Budget term: sum of processes','FontSize',12,'Interpreter','none')
colormap(cmap)
cbar = colorbar('location','southoutside');
cbar_labels = cell(1,length(c_levels));
if length(c_levels) < 10
    for n_label = 1:length(c_levels)
        cbar_labels{n_label} = num2str(c_levels(n_label));
    end
else
    for n_label = 1:length(c_levels)
%         if mod(n_label,2) == 1
%         if ismember((1e-10)*round((1e10)*c_levels(n_label)),[-0.05 0 0.05]) == 1
        if min(abs(c_levels(n_label) - ((-0.03):0.01:0.03))) < 1e-5
            cbar_labels{n_label} = num2str(c_levels(n_label));
        else
            cbar_labels{n_label} = '';
        end
    end
end
cbar_pos = get(cbar,'Position');
set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
set(get(cbar,'xlabel'),'String','Temperature tendency ( ^{o}C day^{-1})','FontSize',20)

% saveas(fig12,['Temp_tend_map_adv_residual_',time_avg_specifier,'.pdf'])
saveas(fig12,['Temp_tend_map_adv_sum_processes_',time_avg_specifier,'.pdf'])
close(fig12)




adv_T_tend_total_thick_weight_seasonal_rect = reshape(reshape(adv_T_tend_total_thick_weight,[prod(size_array(1:2)) size_array(3)])*(G_seasonal_reg*(((G_seasonal_reg')*G_seasonal_reg)^(-1)))*(G_seasonal_reg'),size_array);
adv_T_tend_total_thick_weight = permute(smooth_endclip(permute(adv_T_tend_total_thick_weight - adv_T_tend_total_thick_weight_seasonal_rect,[3 1 2]),6),[2 3 1]);
adv_T_tend_total_thick_weight_avg = mean(adv_T_tend_total_thick_weight(:,:,time_avg_from_unique_reg_ind),3);


% adv_T_tend_vel_T_all_reg_thick_weight_residual = adv_T_tend_total_thick_weight - adv_T_tend_vel_T_all_reg_thick_weight;
% adv_T_tend_vel_T_all_reg_thick_weight_residual_seasonal_rect = reshape(reshape(adv_T_tend_vel_T_all_reg_thick_weight_residual,[prod(size_array(1:2)) size_array(3)])*(G_seasonal_reg*(((G_seasonal_reg')*G_seasonal_reg)^(-1)))*(G_seasonal_reg'),size_array);
% adv_T_tend_vel_T_all_reg_thick_weight_residual = permute(smooth_endclip(permute(adv_T_tend_vel_T_all_reg_thick_weight_residual,[3 1 2]),6),[2 3 1]);
% adv_T_tend_vel_T_all_reg_thick_weight_residual_seasonal_rect = permute(smooth_endclip(permute(adv_T_tend_vel_T_all_reg_thick_weight_residual_seasonal_rect,[3 1 2]),6),[2 3 1]);

% adv_T_tend_vel_T_all_reg_thick_weight_avg_residual = mean(adv_T_tend_vel_T_all_reg_thick_weight_residual(:,:,time_avg_from_unique_reg_ind) - adv_T_tend_vel_T_all_reg_thick_weight_residual_seasonal_rect(:,:,time_avg_from_unique_reg_ind),3);
adv_T_tend_vel_T_all_reg_thick_weight_avg_residual = adv_T_tend_total_thick_weight_avg - adv_T_tend_vel_T_all_reg_thick_weight_avg;

curr_term_array_avg = adv_T_tend_vel_T_all_reg_thick_weight_avg_residual;


curr_term_array_avg(nan_ind_adj) = NaN;
spiky_ind = find((abs(diff([NaN(1,size(curr_term_array_avg,2)); curr_term_array_avg],1,1)) > 0.01/86400) & (abs(diff([curr_term_array_avg; NaN(1,size(curr_term_array_avg,2))],1,1)) > 0.01/86400) & (abs(diff([NaN(size(curr_term_array_avg,1),1) curr_term_array_avg],1,2)) > 0.01/86400) & (abs(diff([curr_term_array_avg NaN(size(curr_term_array_avg,1),1)],1,2)) > 0.01/86400) & ((sign(diff([NaN(1,size(curr_term_array_avg,2)); curr_term_array_avg],1,1))).*(sign(diff([curr_term_array_avg; NaN(1,size(curr_term_array_avg,2))],1,1))) < 0) & ((sign(diff([NaN(size(curr_term_array_avg,1),1) curr_term_array_avg],1,2))).*(sign(diff([curr_term_array_avg NaN(size(curr_term_array_avg,1),1)],1,2))) < 0));
curr_term_array_avg(spiky_ind) = NaN;



bcyr_15 = bcyr(15);
bcyr_14 = bcyr(14);
cmap = [bcyr_15(1:6,:); bcyr_14(7:8,:); bcyr_15(10:15,:)];
c_levels = (-0.035:0.005:0.035)';

fig13 = figure(13);
fig13_paper_pos = get(fig13,'PaperPosition');
fig13_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig13_paper_pos(3);
fig13_paper_pos(3:4) = 2*fig13_paper_pos(3:4);
set(fig13,'PaperPosition',fig13_paper_pos,'PaperSize',[22 17])
colormap(cmap)
h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',86400*curr_term_array_avg');
caxis([min(c_levels) max(c_levels)])
shading flat
set(h,'edgecolor','none')
set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
daspect([1 cosd(mean([latsouth latnorth])) 1])
set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
print(gcf,'curr_term_array_plot_temp.png','-dpng','-r300')
close(fig13)


% get contour plot and overlay land mask

rgb_array = imread('curr_term_array_plot_temp.png');
rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);

delete('curr_term_array_plot_temp.png')


size_rgb_array = size(rgb_array);
landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);

% convert black undefined areas in SSH field to white shading
black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);


rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);


fig14 = figure(14);
fig14_paper_pos = get(fig14,'PaperPosition');
set(fig14,'PaperPosition',fig14_paper_pos + [0 (-1.0) 0 2.0])
x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
daspect([1 cosd(mean([latsouth latnorth])) 1])
set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
hold on
line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
%     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
hold off
xlabel('Longitude','FontSize',20)
ylabel('Latitude','FontSize',20)
% set(gca,'Position',[0.1 0.18 0.8 0.85])
title('Budget term: thickness-weighted residual','FontSize',12,'Interpreter','none')
colormap(cmap)
cbar = colorbar('location','southoutside');
cbar_labels = cell(1,length(c_levels));
if length(c_levels) < 10
    for n_label = 1:length(c_levels)
        cbar_labels{n_label} = num2str(c_levels(n_label));
    end
else
    for n_label = 1:length(c_levels)
%         if mod(n_label,2) == 1
%         if ismember((1e-10)*round((1e10)*c_levels(n_label)),[-0.05 0 0.05]) == 1
        if min(abs(c_levels(n_label) - ((-0.03):0.01:0.03))) < 1e-5
            cbar_labels{n_label} = num2str(c_levels(n_label));
        else
            cbar_labels{n_label} = '';
        end
    end
end
cbar_pos = get(cbar,'Position');
set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
set(get(cbar,'xlabel'),'String','Thickness-weighted temperature tendency ( ^{o}C day^{-1})','FontSize',20)

saveas(fig14,['Temp_tend_map_adv_thick_weight_residual_',time_avg_specifier,'.pdf'])
close(fig14)





% % % curr_term_name = 'adv_T_tend_vel_reg_and_noreg_T_noreg_avg';
% % % curr_term_array_avg = adv_T_tend_vel_reg_and_noreg_T_noreg_avg;
% % % 
% % % fig11 = figure(11);
% % % fig11_paper_pos = get(fig11,'PaperPosition');
% % % fig11_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig11_paper_pos(3);
% % % fig11_paper_pos(3:4) = 2*fig11_paper_pos(3:4);
% % % set(fig11,'PaperPosition',fig11_paper_pos,'PaperSize',[22 17])
% % % colormap(cmap)
% % % h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',86400*curr_term_array_avg');
% % % caxis([min(c_levels) max(c_levels)])
% % % shading flat
% % % set(h,'edgecolor','none')
% % % set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% % % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % % set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% % % print(gcf,'curr_term_array_plot_temp.png','-dpng','-r300')
% % % close(fig11)
% % % 
% % % 
% % % % get contour plot and overlay land mask
% % % 
% % % rgb_array = imread('curr_term_array_plot_temp.png');
% % % rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% % % 
% % % delete('curr_term_array_plot_temp.png')
% % % 
% % % 
% % % size_rgb_array = size(rgb_array);
% % % landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% % % rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% % % 
% % % % convert black undefined areas in SSH field to white shading
% % % black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% % % rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% % % 
% % % 
% % % rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% % % rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% % % 
% % % 
% % % fig12 = figure(12);
% % % fig12_paper_pos = get(fig12,'PaperPosition');
% % % set(fig12,'PaperPosition',fig12_paper_pos + [0 (-1.0) 0 2.0])
% % % x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% % % y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% % % h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% % % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % % set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% % % hold on
% % % line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% % % %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% % % hold off
% % % xlabel('Longitude','FontSize',20)
% % % ylabel('Latitude','FontSize',20)
% % % % set(gca,'Position',[0.1 0.18 0.8 0.85])
% % % title({['Budget term: ',curr_term_name,',']; reg_avg_text_specifier},'FontSize',12,'Interpreter','none')
% % % colormap(cmap)
% % % cbar = colorbar('location','southoutside');
% % % cbar_labels = cell(1,length(c_levels));
% % % if length(c_levels) < 10
% % %     for n_label = 1:length(c_levels)
% % %         cbar_labels{n_label} = num2str(c_levels(n_label));
% % %     end
% % % else
% % %     for n_label = 1:length(c_levels)
% % % %         if mod(n_label,2) == 1
% % % %         if ismember((1e-10)*round((1e10)*c_levels(n_label)),[-0.05 0 0.05]) == 1
% % %         if min(abs(c_levels(n_label) - ((-0.03):0.01:0.03))) < 1e-5
% % %             cbar_labels{n_label} = num2str(c_levels(n_label));
% % %         else
% % %             cbar_labels{n_label} = '';
% % %         end
% % %     end
% % % end
% % % cbar_pos = get(cbar,'Position');
% % % set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% % % set(get(cbar,'xlabel'),'String','Temperature tendency ( ^{o}C day^{-1})','FontSize',20)
% % % 
% % % saveas(fig12,['Temp_tend_map_',curr_term_name,'_',reg_avg_file_specifier,'.pdf'])
% % % close(fig12)
% % % 
% % % 
% % % 
% % % 
% % % 
% % % 
% % % 
% % % 
% % % % plot vertically-averaged velocities and T
% % % 
% % % plot_grid_spacing = 5;   % spacing (in grid cells) of arrows
% % % 
% % % plot_grid_start_ind = floor(plot_grid_spacing/2);
% % % plot_grid_i_ind = (plot_grid_start_ind:plot_grid_spacing:size_array_ij(1))';
% % % plot_grid_j_ind = (plot_grid_start_ind:plot_grid_spacing:size_array_ij(2))';
% % % 
% % % 
% % % % plot maps
% % % 
% % % % cmap = flipdim(bcyr(10),1);
% % % % c_levels = (-5:1:5)';
% % % cmap = flipdim(bcyr(12),1);
% % % c_levels = (-6:1:6)';
% % % 
% % % fig1 = figure(1);
% % % fig1_paper_pos = get(fig1,'PaperPosition');
% % % fig1_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig1_paper_pos(3);
% % % fig1_paper_pos(3:4) = 2*fig1_paper_pos(3:4);
% % % set(fig1,'PaperPosition',fig1_paper_pos,'PaperSize',[22 17])
% % % colormap(cmap)
% % % h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',(1e3)*wvel_bottom_avg');
% % % caxis([min(c_levels) max(c_levels)])
% % % shading flat
% % % set(h,'edgecolor','none')
% % % set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% % % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % % set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% % % print(gcf,'curr_term_array_plot_temp.png','-dpng','-r300')
% % % close(fig1)
% % % 
% % % 
% % % % get contour plot and overlay land mask
% % % 
% % % rgb_array = imread('curr_term_array_plot_temp.png');
% % % rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% % % 
% % % delete('curr_term_array_plot_temp.png')
% % % 
% % % 
% % % size_rgb_array = size(rgb_array);
% % % landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% % % rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% % % 
% % % % convert black undefined areas in SSH field to white shading
% % % black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% % % rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% % % 
% % % 
% % % rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% % % rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% % % 
% % % 
% % % fig2 = figure(2);
% % % fig2_paper_pos = get(fig2,'PaperPosition');
% % % set(fig2,'PaperPosition',fig2_paper_pos + [0 (-1.0) 0 2.0])
% % % x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% % % y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% % % h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% % % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % % hold on
% % % % scale_factor = 0.5/70;
% % % scale_factor = 1/(2.8*20);
% % % max_arrow_dim = max([max(max(abs(uvel_vert_mean_inlayer_avg(plot_grid_i_ind,plot_grid_j_ind)))) max(max(abs(vvel_vert_mean_inlayer_avg(plot_grid_i_ind,plot_grid_j_ind))))]);
% % % quiv_scale = scale_factor/(grid_res*plot_grid_spacing/max_arrow_dim);
% % % quiv = quiver(tlon_pcolor_plot(plot_grid_i_ind,plot_grid_j_ind)',tlat_pcolor_plot(plot_grid_i_ind,plot_grid_j_ind)',uvel_vert_mean_inlayer_avg(plot_grid_i_ind,plot_grid_j_ind)',vvel_vert_mean_inlayer_avg(plot_grid_i_ind,plot_grid_j_ind)',quiv_scale);
% % % set(quiv,'Color','k','LineWidth',1.5)
% % % % scale arrow
% % % scale_arrow_mag = 20;
% % % rectangle('Position',[min(min(tlon_pcolor_plot)) + 0.5,min(min(tlat_pcolor_plot)) + 0.4,2.4,0.75],'FaceColor',[1 1 1])
% % % line([(min(min(tlon_pcolor_plot)) + 0.7) (min(min(tlon_pcolor_plot)) + 0.7 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.72) (min(min(tlat_pcolor_plot)) + 0.72)],'LineWidth',1.5,'Color','k')
% % % line([(min(min(tlon_pcolor_plot)) + 0.7 + (0.7*scale_arrow_mag*scale_factor)) (min(min(tlon_pcolor_plot)) + 0.7 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.72 + (0.15*scale_arrow_mag*scale_factor)) (min(min(tlat_pcolor_plot)) + 0.72)],'LineWidth',1.5,'Color','k')
% % % line([(min(min(tlon_pcolor_plot)) + 0.7 + (0.7*scale_arrow_mag*scale_factor)) (min(min(tlon_pcolor_plot)) + 0.7 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.72 - (0.15*scale_arrow_mag*scale_factor)) (min(min(tlat_pcolor_plot)) + 0.72)],'LineWidth',1.5,'Color','k')
% % % text(min(min(tlon_pcolor_plot)) + 0.9 + (scale_arrow_mag*scale_factor),min(min(tlat_pcolor_plot)) + 0.76,[num2str(scale_arrow_mag),' cm s^{-1}'],'FontSize',10)
% % % hold off
% % % set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% % % hold on
% % % line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% % % %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% % % hold off
% % % xlabel('Longitude','FontSize',20)
% % % ylabel('Latitude','FontSize',20)
% % % % set(gca,'Position',[0.1 0.18 0.8 0.85])
% % % title({'Composite horizontal (arrows) and vertical (shaded) velocities,'; reg_avg_text_specifier},'FontSize',12,'Interpreter','none')
% % % colormap(cmap)
% % % cbar = colorbar('location','southoutside');
% % % cbar_labels = cell(1,length(c_levels));
% % % if length(c_levels) < 10
% % %     for n_label = 1:length(c_levels)
% % %         cbar_labels{n_label} = num2str(c_levels(n_label));
% % %     end
% % % else
% % %     for n_label = 1:length(c_levels)
% % % %         if mod(n_label,2) == 1
% % %         if ismember((1e-10)*round((1e10)*c_levels(n_label)),[-5 0 5]) == 1
% % %             cbar_labels{n_label} = num2str(c_levels(n_label));
% % %         else
% % %             cbar_labels{n_label} = '';
% % %         end
% % %     end
% % % end
% % % cbar_pos = get(cbar,'Position');
% % % set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% % % set(get(cbar,'xlabel'),'String','Vertical velocity (10^{-3} cm s^{-1})','FontSize',20)
% % % 
% % % saveas(fig2,['Velocities_wvel_map_',reg_avg_file_specifier,'.pdf'])
% % % close(fig2)
% % % 
% % % 
% % % 
% % % fig3 = figure(3);
% % % fig3_paper_pos = get(fig3,'PaperPosition');
% % % fig3_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig3_paper_pos(3);
% % % fig3_paper_pos(3:4) = 2*fig3_paper_pos(3:4);
% % % set(fig3,'PaperPosition',fig3_paper_pos,'PaperSize',[22 17])
% % % colormap(cmap)
% % % h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',(1e3)*wvel_bottom_reg_avg');
% % % caxis([min(c_levels) max(c_levels)])
% % % shading flat
% % % set(h,'edgecolor','none')
% % % set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% % % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % % set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% % % print(gcf,'curr_term_array_reg_plot_temp.png','-dpng','-r300')
% % % close(fig3)
% % % 
% % % 
% % % % get contour plot and overlay land mask
% % % 
% % % rgb_array = imread('curr_term_array_reg_plot_temp.png');
% % % rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% % % 
% % % delete('curr_term_array_reg_plot_temp.png')
% % % 
% % % 
% % % size_rgb_array = size(rgb_array);
% % % landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% % % rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% % % 
% % % % convert black undefined areas in SSH field to white shading
% % % black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% % % rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% % % 
% % % 
% % % rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% % % rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% % % 
% % % 
% % % fig4 = figure(4);
% % % fig4_paper_pos = get(fig4,'PaperPosition');
% % % set(fig4,'PaperPosition',fig4_paper_pos + [0 (-1.0) 0 2.0])
% % % x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% % % y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% % % h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% % % hold on
% % % scale_factor = 1/(2.8*20);
% % % % good_ind = find(isnan(uvel_vert_mean_inlayer_reg_avg) == 0);
% % % max_arrow_dim = max([max(max(abs(uvel_vert_mean_inlayer_reg_avg(plot_grid_i_ind,plot_grid_j_ind)))) max(max(abs(vvel_vert_mean_inlayer_reg_avg(plot_grid_i_ind,plot_grid_j_ind))))]);
% % % quiv_scale = scale_factor/(grid_res*plot_grid_spacing/max_arrow_dim);
% % % quiv = quiver(tlon_pcolor_plot(plot_grid_i_ind,plot_grid_j_ind)',tlat_pcolor_plot(plot_grid_i_ind,plot_grid_j_ind)',uvel_vert_mean_inlayer_reg_avg(plot_grid_i_ind,plot_grid_j_ind)',vvel_vert_mean_inlayer_reg_avg(plot_grid_i_ind,plot_grid_j_ind)',quiv_scale);
% % % set(quiv,'Color','k','LineWidth',1.5)
% % % % scale arrow
% % % scale_arrow_mag = 20;
% % % rectangle('Position',[min(min(tlon_pcolor_plot)) + 0.5,min(min(tlat_pcolor_plot)) + 0.4,2.4,0.75],'FaceColor',[1 1 1])
% % % line([(min(min(tlon_pcolor_plot)) + 0.7) (min(min(tlon_pcolor_plot)) + 0.7 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.72) (min(min(tlat_pcolor_plot)) + 0.72)],'LineWidth',1.5,'Color','k')
% % % line([(min(min(tlon_pcolor_plot)) + 0.7 + (0.7*scale_arrow_mag*scale_factor)) (min(min(tlon_pcolor_plot)) + 0.7 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.72 + (0.15*scale_arrow_mag*scale_factor)) (min(min(tlat_pcolor_plot)) + 0.72)],'LineWidth',1.5,'Color','k')
% % % line([(min(min(tlon_pcolor_plot)) + 0.7 + (0.7*scale_arrow_mag*scale_factor)) (min(min(tlon_pcolor_plot)) + 0.7 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.72 - (0.15*scale_arrow_mag*scale_factor)) (min(min(tlat_pcolor_plot)) + 0.72)],'LineWidth',1.5,'Color','k')
% % % text(min(min(tlon_pcolor_plot)) + 0.9 + (scale_arrow_mag*scale_factor),min(min(tlat_pcolor_plot)) + 0.76,[num2str(scale_arrow_mag),' cm s^{-1}'],'FontSize',10)
% % % hold off
% % % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % % set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% % % hold on
% % % line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% % % %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% % % hold off
% % % xlabel('Longitude','FontSize',20)
% % % ylabel('Latitude','FontSize',20)
% % % % set(gca,'Position',[0.1 0.18 0.8 0.85])
% % % title({'Composite horizontal and vertical velocities,'; [reg_avg_text_specifier,', regression component']},'FontSize',12,'Interpreter','none')
% % % colormap(cmap)
% % % cbar = colorbar('location','southoutside');
% % % cbar_labels = cell(1,length(c_levels));
% % % if length(c_levels) < 10
% % %     for n_label = 1:length(c_levels)
% % %         cbar_labels{n_label} = num2str(c_levels(n_label));
% % %     end
% % % else
% % %     for n_label = 1:length(c_levels)
% % % %         if mod(n_label,2) == 1
% % %         if ismember((1e-10)*round((1e10)*c_levels(n_label)),[-5 0 5]) == 1
% % %             cbar_labels{n_label} = num2str(c_levels(n_label));
% % %         else
% % %             cbar_labels{n_label} = '';
% % %         end
% % %     end
% % % end
% % % cbar_pos = get(cbar,'Position');
% % % set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% % % set(get(cbar,'xlabel'),'String','Vertical velocity (10^{-3} cm s^{-1})','FontSize',20)
% % % 
% % % saveas(fig4,['Velocities_wvel_map_reg_',reg_avg_file_specifier,'.pdf'])
% % % close(fig4)
% % % 
% % % 
% % % 
% % % fig5 = figure(5);
% % % fig5_paper_pos = get(fig5,'PaperPosition');
% % % fig5_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig5_paper_pos(3);
% % % fig5_paper_pos(3:4) = 2*fig5_paper_pos(3:4);
% % % set(fig5,'PaperPosition',fig5_paper_pos,'PaperSize',[22 17])
% % % colormap(cmap)
% % % h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',(1e3)*wvel_bottom_noreg_avg');
% % % caxis([min(c_levels) max(c_levels)])
% % % shading flat
% % % set(h,'edgecolor','none')
% % % set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% % % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % % set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% % % print(gcf,'curr_term_array_noreg_plot_temp.png','-dpng','-r300')
% % % close(fig5)
% % % 
% % % 
% % % % get contour plot and overlay land mask
% % % 
% % % rgb_array = imread('curr_term_array_noreg_plot_temp.png');
% % % rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% % % 
% % % delete('curr_term_array_noreg_plot_temp.png')
% % % 
% % % 
% % % size_rgb_array = size(rgb_array);
% % % landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% % % rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% % % 
% % % % convert black undefined areas in SSH field to white shading
% % % black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% % % rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% % % 
% % % 
% % % rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% % % rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% % % 
% % % 
% % % fig6 = figure(6);
% % % fig6_paper_pos = get(fig6,'PaperPosition');
% % % set(fig6,'PaperPosition',fig6_paper_pos + [0 (-1.0) 0 2.0])
% % % x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% % % y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% % % h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% % % hold on
% % % scale_factor = 1/(2.8*20);
% % % % good_ind = find(isnan(uvel_vert_mean_inlayer_noreg_avg) == 0);
% % % max_arrow_dim = max([max(max(abs(uvel_vert_mean_inlayer_noreg_avg(plot_grid_i_ind,plot_grid_j_ind)))) max(max(abs(vvel_vert_mean_inlayer_noreg_avg(plot_grid_i_ind,plot_grid_j_ind))))]);
% % % quiv_scale = scale_factor/(grid_res*plot_grid_spacing/max_arrow_dim);
% % % quiv = quiver(tlon_pcolor_plot(plot_grid_i_ind,plot_grid_j_ind)',tlat_pcolor_plot(plot_grid_i_ind,plot_grid_j_ind)',uvel_vert_mean_inlayer_noreg_avg(plot_grid_i_ind,plot_grid_j_ind)',vvel_vert_mean_inlayer_noreg_avg(plot_grid_i_ind,plot_grid_j_ind)',quiv_scale);
% % % set(quiv,'Color','k','LineWidth',1.5)
% % % % scale arrow
% % % scale_arrow_mag = 20;
% % % rectangle('Position',[min(min(tlon_pcolor_plot)) + 0.5,min(min(tlat_pcolor_plot)) + 0.4,2.4,0.75],'FaceColor',[1 1 1])
% % % line([(min(min(tlon_pcolor_plot)) + 0.7) (min(min(tlon_pcolor_plot)) + 0.7 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.72) (min(min(tlat_pcolor_plot)) + 0.72)],'LineWidth',1.5,'Color','k')
% % % line([(min(min(tlon_pcolor_plot)) + 0.7 + (0.7*scale_arrow_mag*scale_factor)) (min(min(tlon_pcolor_plot)) + 0.7 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.72 + (0.15*scale_arrow_mag*scale_factor)) (min(min(tlat_pcolor_plot)) + 0.72)],'LineWidth',1.5,'Color','k')
% % % line([(min(min(tlon_pcolor_plot)) + 0.7 + (0.7*scale_arrow_mag*scale_factor)) (min(min(tlon_pcolor_plot)) + 0.7 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.72 - (0.15*scale_arrow_mag*scale_factor)) (min(min(tlat_pcolor_plot)) + 0.72)],'LineWidth',1.5,'Color','k')
% % % text(min(min(tlon_pcolor_plot)) + 0.9 + (scale_arrow_mag*scale_factor),min(min(tlat_pcolor_plot)) + 0.76,[num2str(scale_arrow_mag),' cm s^{-1}'],'FontSize',10)
% % % hold off
% % % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % % set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% % % hold on
% % % line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% % % %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% % % hold off
% % % xlabel('Longitude','FontSize',20)
% % % ylabel('Latitude','FontSize',20)
% % % % set(gca,'Position',[0.1 0.18 0.8 0.85])
% % % title({'Composite horizontal and vertical velocities,'; [reg_avg_text_specifier,', regression removed']},'FontSize',12,'Interpreter','none')
% % % colormap(cmap)
% % % cbar = colorbar('location','southoutside');
% % % cbar_labels = cell(1,length(c_levels));
% % % if length(c_levels) < 10
% % %     for n_label = 1:length(c_levels)
% % %         cbar_labels{n_label} = num2str(c_levels(n_label));
% % %     end
% % % else
% % %     for n_label = 1:length(c_levels)
% % % %         if mod(n_label,2) == 1
% % %         if ismember((1e-10)*round((1e10)*c_levels(n_label)),[-5 0 5]) == 1
% % %             cbar_labels{n_label} = num2str(c_levels(n_label));
% % %         else
% % %             cbar_labels{n_label} = '';
% % %         end
% % %     end
% % % end
% % % cbar_pos = get(cbar,'Position');
% % % set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% % % set(get(cbar,'xlabel'),'String','Vertical velocity (10^{-3} cm s^{-1})','FontSize',20)
% % % 
% % % saveas(fig6,['Velocities_wvel_map_noreg_',reg_avg_file_specifier,'.pdf'])
% % % close(fig6)
% % % 
% % % 
% % % 
% % % 
% % % 
% % % % plot velocity maps with temperature
% % % 
% % % % cmap = bcyr(10);
% % % cmap_start = bcyr(26);
% % % cmap = cmap_start([1 2 4 5 6 7 8 9 11 13 14 16 18 19 20 21 22 23 25 26],:);
% % % if reg_level_option == 1
% % % %     c_levels = (25:0.5:30)';
% % %     c_levels = (25:0.25:30)';
% % % else
% % % %     c_levels = ((-2):0.4:2)';
% % %     c_levels = ((-2.5):0.25:2.5)';
% % % end
% % % 
% % % fig1 = figure(1);
% % % fig1_paper_pos = get(fig1,'PaperPosition');
% % % fig1_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig1_paper_pos(3);
% % % fig1_paper_pos(3:4) = 2*fig1_paper_pos(3:4);
% % % set(fig1,'PaperPosition',fig1_paper_pos,'PaperSize',[22 17])
% % % colormap(cmap)
% % % h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',T_vert_mean_inlayer_avg');
% % % caxis([min(c_levels) max(c_levels)])
% % % shading flat
% % % set(h,'edgecolor','none')
% % % set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% % % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % % set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% % % print(gcf,'curr_term_array_plot_temp.png','-dpng','-r300')
% % % close(fig1)
% % % 
% % % 
% % % % get contour plot and overlay land mask
% % % 
% % % rgb_array = imread('curr_term_array_plot_temp.png');
% % % rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% % % 
% % % delete('curr_term_array_plot_temp.png')
% % % 
% % % 
% % % size_rgb_array = size(rgb_array);
% % % landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% % % rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% % % 
% % % % convert black undefined areas in SSH field to white shading
% % % black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% % % rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% % % 
% % % 
% % % rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% % % rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% % % 
% % % 
% % % fig2 = figure(2);
% % % fig2_paper_pos = get(fig2,'PaperPosition');
% % % % set(fig2,'PaperPosition',fig2_paper_pos + [0 (-1.0) 0 2.0])
% % % set(fig2,'PaperPosition',fig2_paper_pos + [0 (-1.0) 0 2.0])
% % % x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% % % y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% % % h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% % % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % % hold on
% % % scale_factor = 1/(2.8*20);
% % % % good_ind = find(isnan(uvel_vert_mean_inlayer_avg) == 0);
% % % max_arrow_dim = max([max(max(abs(uvel_vert_mean_inlayer_avg(plot_grid_i_ind,plot_grid_j_ind)))) max(max(abs(vvel_vert_mean_inlayer_avg(plot_grid_i_ind,plot_grid_j_ind))))]);
% % % quiv_scale = scale_factor/(grid_res*plot_grid_spacing/max_arrow_dim);
% % % quiv = quiver(tlon_pcolor_plot(plot_grid_i_ind,plot_grid_j_ind)',tlat_pcolor_plot(plot_grid_i_ind,plot_grid_j_ind)',uvel_vert_mean_inlayer_avg(plot_grid_i_ind,plot_grid_j_ind)',vvel_vert_mean_inlayer_avg(plot_grid_i_ind,plot_grid_j_ind)',quiv_scale);
% % % set(quiv,'Color','k','LineWidth',1.5)
% % % % scale arrow
% % % scale_arrow_mag = 20;
% % % % rectangle('Position',[min(min(tlon_pcolor_plot)) + 0.5,min(min(tlat_pcolor_plot)) + 0.4,2.4,0.75],'FaceColor',[1 1 1])
% % % % line([(min(min(tlon_pcolor_plot)) + 0.7) (min(min(tlon_pcolor_plot)) + 0.7 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.72) (min(min(tlat_pcolor_plot)) + 0.72)],'LineWidth',1.5,'Color','k')
% % % % line([(min(min(tlon_pcolor_plot)) + 0.7 + (0.7*scale_arrow_mag*scale_factor)) (min(min(tlon_pcolor_plot)) + 0.7 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.72 + (0.15*scale_arrow_mag*scale_factor)) (min(min(tlat_pcolor_plot)) + 0.72)],'LineWidth',1.5,'Color','k')
% % % % line([(min(min(tlon_pcolor_plot)) + 0.7 + (0.7*scale_arrow_mag*scale_factor)) (min(min(tlon_pcolor_plot)) + 0.7 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.72 - (0.15*scale_arrow_mag*scale_factor)) (min(min(tlat_pcolor_plot)) + 0.72)],'LineWidth',1.5,'Color','k')
% % % % text(min(min(tlon_pcolor_plot)) + 0.9 + (scale_arrow_mag*scale_factor),min(min(tlat_pcolor_plot)) + 0.76,[num2str(scale_arrow_mag),' cm s^{-1}'],'FontSize',10)
% % % rectangle('Position',[min(min(tlon_pcolor_plot)) + 0.5,min(min(tlat_pcolor_plot)) + 0.4,3.8,1.2],'FaceColor',[1 1 1])
% % % line([(min(min(tlon_pcolor_plot)) + 0.74) (min(min(tlon_pcolor_plot)) + 0.74 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.94) (min(min(tlat_pcolor_plot)) + 0.94)],'LineWidth',1.5,'Color','k')
% % % line([(min(min(tlon_pcolor_plot)) + 0.74 + (0.74*scale_arrow_mag*scale_factor)) (min(min(tlon_pcolor_plot)) + 0.74 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.94 + (0.27*scale_arrow_mag*scale_factor)) (min(min(tlat_pcolor_plot)) + 0.94)],'LineWidth',1.5,'Color','k')
% % % line([(min(min(tlon_pcolor_plot)) + 0.74 + (0.74*scale_arrow_mag*scale_factor)) (min(min(tlon_pcolor_plot)) + 0.74 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.94 - (0.26*scale_arrow_mag*scale_factor)) (min(min(tlat_pcolor_plot)) + 0.94)],'LineWidth',1.5,'Color','k')
% % % % text(min(min(tlon_pcolor_plot)) + 1.0 + (scale_arrow_mag*scale_factor),min(min(tlat_pcolor_plot)) + 1.0,[num2str(scale_arrow_mag),' cm s^{-1}'],'FontSize',18)
% % % text(min(min(tlon_pcolor_plot)) + 1.0 + (scale_arrow_mag*scale_factor),min(min(tlat_pcolor_plot)) + 1.0,[num2str(scale_arrow_mag),' cm s^{-1}'],'FontSize',20)
% % % hold off
% % % % set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',16)
% % % % set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',18)
% % % set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% % % hold on
% % % line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% % % %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% % % hold off
% % % % xlabel('Longitude','FontSize',16)
% % % % ylabel('Latitude','FontSize',16)
% % % % xlabel('Longitude','FontSize',18)
% % % % ylabel('Latitude','FontSize',18)
% % % xlabel('Longitude','FontSize',20)
% % % ylabel('Latitude','FontSize',20)
% % % % set(gca,'Position',[0.1 0.18 0.8 0.85])
% % % title({'Composite horizontal velocities (arrows) and temperature,'; reg_avg_text_specifier},'FontSize',12,'Interpreter','none')
% % % colormap(cmap)
% % % cbar = colorbar('location','southoutside');
% % % cbar_labels = cell(1,length(c_levels));
% % % if length(c_levels) < 10
% % %     for n_label = 1:length(c_levels)
% % %         cbar_labels{n_label} = num2str(c_levels(n_label));
% % %     end
% % % else
% % %     for n_label = 1:length(c_levels)
% % % %         if mod(n_label,2) == 1
% % %         if mod(n_label,4) == 1
% % %             cbar_labels{n_label} = num2str(c_levels(n_label));
% % %         else
% % %             cbar_labels{n_label} = '';
% % %         end
% % %     end
% % % end
% % % cbar_pos = get(cbar,'Position');
% % % % set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',18)
% % % % set(get(cbar,'xlabel'),'String','Temperature ( ^{o}C)','FontSize',18)
% % % % set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% % % set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% % % set(get(cbar,'xlabel'),'String','Temperature ( ^{o}C)','FontSize',20)
% % % 
% % % saveas(fig2,['Velocities_temp_map_',reg_avg_file_specifier,'.pdf'])
% % % close(fig2)
% % % 
% % % 
% % % 
% % % 
% % % fig3 = figure(3);
% % % fig3_paper_pos = get(fig3,'PaperPosition');
% % % fig3_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig3_paper_pos(3);
% % % fig3_paper_pos(3:4) = 2*fig3_paper_pos(3:4);
% % % set(fig3,'PaperPosition',fig3_paper_pos,'PaperSize',[22 17])
% % % colormap(cmap)
% % % h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',T_vert_mean_inlayer_reg_avg');
% % % caxis([min(c_levels) max(c_levels)])
% % % shading flat
% % % set(h,'edgecolor','none')
% % % set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% % % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % % set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% % % print(gcf,'curr_term_array_reg_plot_temp.png','-dpng','-r300')
% % % close(fig3)
% % % 
% % % 
% % % % get contour plot and overlay land mask
% % % 
% % % rgb_array = imread('curr_term_array_reg_plot_temp.png');
% % % rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% % % 
% % % delete('curr_term_array_reg_plot_temp.png')
% % % 
% % % 
% % % size_rgb_array = size(rgb_array);
% % % landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% % % rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% % % 
% % % % convert black undefined areas in SSH field to white shading
% % % black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% % % rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% % % 
% % % 
% % % rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% % % rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% % % 
% % % 
% % % fig4 = figure(4);
% % % fig4_paper_pos = get(fig4,'PaperPosition');
% % % set(fig4,'PaperPosition',fig4_paper_pos + [0 (-1.0) 0 2.0])
% % % x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% % % y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% % % h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% % % hold on
% % % scale_factor = 1/(2.8*20);
% % % % good_ind = find(isnan(uvel_vert_mean_inlayer_reg_avg) == 0);
% % % max_arrow_dim = max([max(max(abs(uvel_vert_mean_inlayer_reg_avg(plot_grid_i_ind,plot_grid_j_ind)))) max(max(abs(vvel_vert_mean_inlayer_reg_avg(plot_grid_i_ind,plot_grid_j_ind))))]);
% % % quiv_scale = scale_factor/(grid_res*plot_grid_spacing/max_arrow_dim);
% % % quiv = quiver(tlon_pcolor_plot(plot_grid_i_ind,plot_grid_j_ind)',tlat_pcolor_plot(plot_grid_i_ind,plot_grid_j_ind)',uvel_vert_mean_inlayer_reg_avg(plot_grid_i_ind,plot_grid_j_ind)',vvel_vert_mean_inlayer_reg_avg(plot_grid_i_ind,plot_grid_j_ind)',quiv_scale);
% % % set(quiv,'Color','k','LineWidth',1.5)
% % % % scale arrow
% % % scale_arrow_mag = 20;
% % % rectangle('Position',[min(min(tlon_pcolor_plot)) + 0.5,min(min(tlat_pcolor_plot)) + 0.4,3.8,1.2],'FaceColor',[1 1 1])
% % % line([(min(min(tlon_pcolor_plot)) + 0.74) (min(min(tlon_pcolor_plot)) + 0.74 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.94) (min(min(tlat_pcolor_plot)) + 0.94)],'LineWidth',1.5,'Color','k')
% % % line([(min(min(tlon_pcolor_plot)) + 0.74 + (0.74*scale_arrow_mag*scale_factor)) (min(min(tlon_pcolor_plot)) + 0.74 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.94 + (0.27*scale_arrow_mag*scale_factor)) (min(min(tlat_pcolor_plot)) + 0.94)],'LineWidth',1.5,'Color','k')
% % % line([(min(min(tlon_pcolor_plot)) + 0.74 + (0.74*scale_arrow_mag*scale_factor)) (min(min(tlon_pcolor_plot)) + 0.74 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.94 - (0.26*scale_arrow_mag*scale_factor)) (min(min(tlat_pcolor_plot)) + 0.94)],'LineWidth',1.5,'Color','k')
% % % text(min(min(tlon_pcolor_plot)) + 1.0 + (scale_arrow_mag*scale_factor),min(min(tlat_pcolor_plot)) + 1.0,[num2str(scale_arrow_mag),' cm s^{-1}'],'FontSize',20)
% % % hold off
% % % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % % set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% % % hold on
% % % line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% % % %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% % % hold off
% % % xlabel('Longitude','FontSize',20)
% % % ylabel('Latitude','FontSize',20)
% % % % set(gca,'Position',[0.1 0.18 0.8 0.85])
% % % title({'Composite horizontal velocities and temperature,'; [reg_avg_text_specifier,', regression component']},'FontSize',12,'Interpreter','none')
% % % colormap(cmap)
% % % cbar = colorbar('location','southoutside');
% % % cbar_labels = cell(1,length(c_levels));
% % % if length(c_levels) < 10
% % %     for n_label = 1:length(c_levels)
% % %         cbar_labels{n_label} = num2str(c_levels(n_label));
% % %     end
% % % else
% % %     for n_label = 1:length(c_levels)
% % % %         if mod(n_label,2) == 1
% % %         if mod(n_label,4) == 1
% % %             cbar_labels{n_label} = num2str(c_levels(n_label));
% % %         else
% % %             cbar_labels{n_label} = '';
% % %         end
% % %     end
% % % end
% % % cbar_pos = get(cbar,'Position');
% % % set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% % % set(get(cbar,'xlabel'),'String','Temperature ( ^{o}C)','FontSize',20)
% % % 
% % % saveas(fig4,['Velocities_temp_map_reg_',reg_avg_file_specifier,'.pdf'])
% % % close(fig4)
% % % 
% % % 
% % % 
% % % % different contour labels for regression removed component
% % % 
% % % % cmap = bcyr(10);
% % % % c_levels = ((-2):0.4:2)';
% % % cmap_start = bcyr(26);
% % % cmap = cmap_start([1 2 4 5 6 7 8 9 11 13 14 16 18 19 20 21 22 23 25 26],:);
% % % c_levels = (-2.5:0.25:2.5)';
% % % 
% % % fig5 = figure(5);
% % % fig5_paper_pos = get(fig5,'PaperPosition');
% % % fig5_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig5_paper_pos(3);
% % % fig5_paper_pos(3:4) = 2*fig5_paper_pos(3:4);
% % % set(fig5,'PaperPosition',fig5_paper_pos,'PaperSize',[22 17])
% % % colormap(cmap)
% % % h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',T_vert_mean_inlayer_noreg_avg');
% % % caxis([min(c_levels) max(c_levels)])
% % % shading flat
% % % set(h,'edgecolor','none')
% % % set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% % % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % % set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% % % print(gcf,'curr_term_array_noreg_plot_temp.png','-dpng','-r300')
% % % close(fig5)
% % % 
% % % 
% % % % get contour plot and overlay land mask
% % % 
% % % rgb_array = imread('curr_term_array_noreg_plot_temp.png');
% % % rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% % % 
% % % delete('curr_term_array_noreg_plot_temp.png')
% % % 
% % % 
% % % size_rgb_array = size(rgb_array);
% % % landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% % % rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% % % 
% % % % convert black undefined areas in SSH field to white shading
% % % black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% % % rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% % % 
% % % 
% % % rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% % % rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% % % 
% % % 
% % % fig6 = figure(6);
% % % fig6_paper_pos = get(fig6,'PaperPosition');
% % % set(fig6,'PaperPosition',fig6_paper_pos + [0 (-1.0) 0 2.0])
% % % x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% % % y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% % % h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% % % hold on
% % % scale_factor = 1/(2.8*20);
% % % % good_ind = find(isnan(uvel_vert_mean_inlayer_noreg_avg) == 0);
% % % max_arrow_dim = max([max(max(abs(uvel_vert_mean_inlayer_noreg_avg(plot_grid_i_ind,plot_grid_j_ind)))) max(max(abs(vvel_vert_mean_inlayer_noreg_avg(plot_grid_i_ind,plot_grid_j_ind))))]);
% % % quiv_scale = scale_factor/(grid_res*plot_grid_spacing/max_arrow_dim);
% % % quiv = quiver(tlon_pcolor_plot(plot_grid_i_ind,plot_grid_j_ind)',tlat_pcolor_plot(plot_grid_i_ind,plot_grid_j_ind)',uvel_vert_mean_inlayer_noreg_avg(plot_grid_i_ind,plot_grid_j_ind)',vvel_vert_mean_inlayer_noreg_avg(plot_grid_i_ind,plot_grid_j_ind)',quiv_scale);
% % % set(quiv,'Color','k','LineWidth',1.5)
% % % % scale arrow
% % % scale_arrow_mag = 20;
% % % rectangle('Position',[min(min(tlon_pcolor_plot)) + 0.5,min(min(tlat_pcolor_plot)) + 0.4,3.8,1.2],'FaceColor',[1 1 1])
% % % line([(min(min(tlon_pcolor_plot)) + 0.74) (min(min(tlon_pcolor_plot)) + 0.74 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.94) (min(min(tlat_pcolor_plot)) + 0.94)],'LineWidth',1.5,'Color','k')
% % % line([(min(min(tlon_pcolor_plot)) + 0.74 + (0.74*scale_arrow_mag*scale_factor)) (min(min(tlon_pcolor_plot)) + 0.74 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.94 + (0.27*scale_arrow_mag*scale_factor)) (min(min(tlat_pcolor_plot)) + 0.94)],'LineWidth',1.5,'Color','k')
% % % line([(min(min(tlon_pcolor_plot)) + 0.74 + (0.74*scale_arrow_mag*scale_factor)) (min(min(tlon_pcolor_plot)) + 0.74 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.94 - (0.26*scale_arrow_mag*scale_factor)) (min(min(tlat_pcolor_plot)) + 0.94)],'LineWidth',1.5,'Color','k')
% % % text(min(min(tlon_pcolor_plot)) + 1.0 + (scale_arrow_mag*scale_factor),min(min(tlat_pcolor_plot)) + 1.0,[num2str(scale_arrow_mag),' cm s^{-1}'],'FontSize',20)
% % % hold off
% % % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % % set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% % % hold on
% % % line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% % % %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% % % hold off
% % % xlabel('Longitude','FontSize',20)
% % % ylabel('Latitude','FontSize',20)
% % % % set(gca,'Position',[0.1 0.18 0.8 0.85])
% % % title({'Composite horizontal velocities and temperature,'; [reg_avg_text_specifier,', regression removed']},'FontSize',12,'Interpreter','none')
% % % colormap(cmap)
% % % cbar = colorbar('location','southoutside');
% % % cbar_labels = cell(1,length(c_levels));
% % % if length(c_levels) < 10
% % %     for n_label = 1:length(c_levels)
% % %         cbar_labels{n_label} = num2str(c_levels(n_label));
% % %     end
% % % else
% % %     for n_label = 1:length(c_levels)
% % %         if mod(n_label,2) == 1
% % %             cbar_labels{n_label} = num2str(c_levels(n_label));
% % %         else
% % %             cbar_labels{n_label} = '';
% % %         end
% % %     end
% % % end
% % % cbar_pos = get(cbar,'Position');
% % % set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% % % set(get(cbar,'xlabel'),'String','Temperature anomaly ( ^{o}C)','FontSize',20)
% % % 
% % % saveas(fig6,['Velocities_temp_map_noreg_',reg_avg_file_specifier,'.pdf'])
% % % close(fig6)
