% show maps of correlations of a time series with with mixed layer temperature budget terms

path(path,'~/Budget_calculations/')
path(path,'~/plotting_scripts/')
cd('/glade/scratch/adelman/POP_1977_start_JC/')


% define boundaries to plot maps for

longwest = 103.0;
longeast = 118.0;
latsouth = -15.0;
latnorth = -5.0;


% lags (in days) to compute correlations for

% lags = (-30:5:0)';
% lags = (-30:5:(-5))';
lags = (-30:5:(-10))';


% define dates to use in regressions (must include all averaging dates)

% start_dates_reg = [1994 1 1];
% end_dates_reg = [2009 1 1];
% start_dates_reg = [1994 1 31];
% end_dates_reg = [2009 1 1];
% start_dates_reg = [1977 1 31];
% end_dates_reg = [2010 1 1];
% start_dates_reg = [(1977:1:2009)' (4*ones(33,1)) (30*ones(33,1))];
% end_dates_reg = [(1977:1:2009)' (8*ones(33,1)) (3*ones(33,1))];
% start_dates_reg = [(1979:1:2009)' (4*ones(31,1)) (30*ones(31,1))];
% end_dates_reg = [(1979:1:2009)' (8*ones(31,1)) (3*ones(31,1))];
start_dates_reg = [1979 1 1];
end_dates_reg = [2010 1 1];

% define dates to average

% start_dates_avg = [2006 05 15];
% end_dates_avg = [2006 06 14];
% start_dates_avg = [2006 05 30; 2007 06 29; 2008 05 30];
% end_dates_avg = [2006 07 04; 2007 08 03; 2008 07 04];
% start_dates_avg = [1994 04 10; 1997 08 08; 2003 06 04; 2006 05 30; 2007 06 24; 2008 05 05];
% end_dates_avg = [1994 05 30; 1997 09 27; 2003 07 24; 2006 07 19; 2007 08 13; 2008 06 24];
% start_dates_avg = [1994 04 30; 1997 04 30; 2003 04 30; 2006 04 30; 2007 04 30; 2008 04 30];
% end_dates_avg = [1994 09 02; 1997 09 02; 2003 09 02; 2006 09 02; 2007 09 02; 2008 09 02];
% start_dates_avg = [1982 04 30; 1983 04 30; 1987 04 30; 1994 04 30; 1997 04 30; 2003 04 30; 2006 04 30; 2007 04 30; 2008 04 30];
% end_dates_avg = [1982 08 03; 1983 08 03; 1987 08 03; 1994 08 03; 1997 08 03; 2003 08 03; 2006 08 03; 2007 08 03; 2008 08 03];
% start_dates_avg = [(1977:1:2009)' (4*ones(33,1)) (30*ones(33,1))];
% end_dates_avg = [(1977:1:2009)' (8*ones(33,1)) (3*ones(33,1))];
start_dates_avg = [(1979:1:2009)' (4*ones(31,1)) (30*ones(31,1))];
end_dates_avg = [(1979:1:2009)' (8*ones(31,1)) (3*ones(31,1))];



% ent_compute_option = 1: no flux or tendency computed due to changing volume of the surface layer (except for the part due to changes at the surface)
% ent_compute_option = 2: entrainment tendencies are computed based on the residual between the sum of the already-computed budget terms and the actual temperature change
ent_compute_option = 2;


% reg_level_option = 1: first regression applied to raw output (e.g., regression of annual cycle and harmonics)
% reg_level_option = 2: carry out regression with another regressed quantity (e.g., seasonal cycle) already removed
reg_level_option = 2;


% splitting parameters
% ADJUSTABLE SETTING (search "ADJUSTABLE SETTING" all caps to find settings throughout script that may need to be changed for each different regression.)

% number of boxes in x- and y-directions to split for file loading and computation purposes
n_subsets_file_computation = [2 2];

% number of boxes in x- and y-directions to split for regression purposes
% ADJUSTABLE SETTING
n_subsets_regression = [4 4];
% n_subsets_regression = [14 9];
% n_subsets_regression = [14 2];


% file name base to save output of regressed budget
% ADJUSTABLE SETTING
if reg_level_option == 1
%     file_name_base_output = 'seasonal_Java_ML_94_08_reg';
%     file_name_base_output = 'seasonal_Java_ML_77_09_reg';
%     file_name_base_output = 'seasonal_Java_ML_79_09_reg';
    file_name_base_output = 'seasonal_MayJul_Java_map_ML_79_09_reg';
end

% file name base containing previously regressed quantities
% ADJUSTABLE SETTING
if reg_level_option > 1
%     file_name_base_input = 'seasonal_Java_ML_94_08_reg';
%     file_name_base_input = 'seasonal_Java_ML_77_09_reg';
%     file_name_base_input = 'seasonal_Java_ML_79_09_reg';
    file_name_base_input = 'seasonal_Java_map_ML_79_09_reg';
end
    


% specify source file(s)

% nc_filenames = {'pop.h.nday5.JC.00300105-00301231.nc'};
nc_cell_array = struct2cell(dir('pop.h.nday5.JC.*0105-*1231.nc'));
nc_filenames = (nc_cell_array(1,:))';


% model year offset
year_offset = 1976;

% tavg for archived output (in days)
tavg_days = 5;


% specifiers for the regression and averaging range
% ADJUSTABLE SETTINGS

% reg_avg_text_specifier = 'seasonal decomposition, 1994-2008 pIOD May-August composite';
% reg_avg_text_specifier = 'Kelvin wave decomposition, 1994-2008 pIOD May-August composite';
% reg_avg_text_specifier = 'Kelvin wave decomposition, 1977-2009 pIOD May-July composite';
% reg_avg_text_specifier = 'Kelvin SSH diff. wave decomposition, 1977-2009 pIOD May-July composite';
% reg_avg_text_specifier = 'Wind forcing decomposition, zonal wind stress, 1977-2009 pIOD May-July composite';
% reg_avg_text_specifier = 'Mesoscale merid. vel. decomposition, zonal wind stress, 1977-2009 pIOD May-July composite';
% reg_avg_text_specifier = 'Kelvin SSH diff. wave decomposition, 1977-2009 May-July composite';
% reg_avg_text_specifier = 'Mesoscale merid. vel. decomposition, 1977-2009 May-July composite';
% reg_avg_text_specifier = '-(Kelvin SSH diff.) wave decomposition, 1977-2009 May-July composite';
% reg_avg_text_specifier = '-(Kelvin SSH diff.) wave decomposition, 1979-2009 May-July composite';
% reg_avg_text_specifier = 'Mesoscale merid. vel. decomposition, 1979-2009 May-July composite';
% reg_avg_text_specifier = 'Lombok Strait merid. vel. decomposition, 1979-2009';
reg_avg_text_specifier = 'Lombok Strait merid. vel. decomposition, w/ Kelvin, Sumatra wstr, and Java wstr removed, 1979-2009';
% reg_avg_file_specifier = 'seasonal_1994_to_2008_pIOD_MayAug_ML';
% reg_avg_file_specifier = 'Kelvin_1994_to_2008_pIOD_MayAug_ML';
% reg_avg_file_specifier = 'Kelvin_1977_to_2009_pIOD_MayJul_ML';
% reg_avg_file_specifier = 'Kelvin_diff_1977_to_2009_pIOD_MayJul_ML';
% reg_avg_file_specifier = 'wstr_local_zonal_1977_to_2009_pIOD_MayJul_ML';
% reg_avg_file_specifier = 'mesoscale_vvel_1977_to_2009_pIOD_MayJul_ML';
% reg_avg_file_specifier = 'Kelvin_diff_1977_to_2009_MayJul_ML';
% reg_avg_file_specifier = 'mesoscale_vvel_1977_to_2009_MayJul_ML';
% reg_avg_file_specifier = 'Kelvin_diff_neg_1977_to_2009_MayJul_ML';
% reg_avg_file_specifier = 'Kelvin_diff_neg_1979_to_2009_MayJul_ML';
% reg_avg_file_specifier = 'mesoscale_vvel_1979_to_2009_MayJul_ML';
% reg_avg_file_specifier = 'Java_Lombok_vvel_1979_to_2009_ML';
% reg_avg_file_specifier = 'Java_Lombok_nozerolag_vvel_1979_to_2009_ML';
% reg_avg_file_specifier = 'Java_Lombok_nozerofivelag_vvel_1979_to_2009_ML';
reg_avg_file_specifier = 'Java_Lombok_vvel_rem_reg_Kelvin_wstr_Sumatra_Java_20_lp_1979_to_2009_ML';


if reg_level_option > 1
    reg_avg_text_specifier_new = reg_avg_text_specifier;
    reg_avg_file_specifier_new = reg_avg_file_specifier;
end


grid_res = 0.1;


% convert dates to model form
month_start_vec = [0; 31; 59; 90; 120; 151; 181; 212; 243; 273; 304; 334];

start_datenums_reg = (365*(start_dates_reg(:,1) - year_offset)) + month_start_vec(start_dates_reg(:,2)) + start_dates_reg(:,3);
end_datenums_reg = (365*(end_dates_reg(:,1) - year_offset)) + month_start_vec(end_dates_reg(:,2)) + end_dates_reg(:,3);
start_datenums_avg = (365*(start_dates_avg(:,1) - year_offset)) + month_start_vec(start_dates_avg(:,2)) + start_dates_avg(:,3);
end_datenums_avg = (365*(end_dates_avg(:,1) - year_offset)) + month_start_vec(end_dates_avg(:,2)) + end_dates_avg(:,3);



% model output source file(s)

TLAT = ncread(nc_filenames{1},'TLAT');
TLON = ncread(nc_filenames{1},'TLONG');
ULAT = ncread(nc_filenames{1},'ULAT');
ULON = ncread(nc_filenames{1},'ULONG');

z_t = ncread(nc_filenames{1},'z_t');
z_t = double(z_t);
z_w_top = ncread(nc_filenames{1},'z_w_top');
z_w_top = double(z_w_top);
z_w_bot = ncread(nc_filenames{1},'z_w_bot');
z_w_bot = double(z_w_bot);
dz = ncread(nc_filenames{1},'dz');


if reg_level_option == 1
    
    time = [];
    file_num_vec = [];
    in_file_ind_vec = [];
    for file_num = 1:length(nc_filenames)
        time_curr_source_file = ncread(nc_filenames{file_num},'time');
        
        time = [time; time_curr_source_file];
        
        file_num_vec = [file_num_vec; (file_num*ones(length(time_curr_source_file),1))];
        in_file_ind_vec = [in_file_ind_vec; ((1:1:length(time_curr_source_file))')];
    end
    
    
    % adjust time points to lie in centers of 5-day periods
    time = time - 2.5;
    
else
    
    % load time variables for subsequent calculations
    load([file_name_base_input,'_1_1.mat'],'time','unique_time_ind','file_nums_in_time_range','file_num_vec','in_file_ind_vec')
    
    
    time_reg_level1 = time;
    time = time(unique_time_ind);
    
    unique_time_ind_reg_level1 = unique_time_ind;
    
    clear unique_time_ind
    
    reg_avg_text_specifier = reg_avg_text_specifier_new;
    reg_avg_file_specifier = reg_avg_file_specifier_new;
    
end


ind_inrange = find((TLON >= (longwest - (2*grid_res))) & (TLON <= (longeast + (2*grid_res))) & (TLAT >= (latsouth - (2*grid_res))) & (TLAT <= (latnorth + (2*grid_res))));
[lat_ind_mesh,lon_ind_mesh] = meshgrid((1:1:size(TLAT,2)),(1:1:size(TLON,1)));


lon_ind_min_inrange = min(lon_ind_mesh(ind_inrange));
lon_ind_max_inrange = max(lon_ind_mesh(ind_inrange));
lat_ind_min_inrange = min(lat_ind_mesh(ind_inrange));
lat_ind_max_inrange = max(lat_ind_mesh(ind_inrange));

lon_ind_inrange = (lon_ind_min_inrange:1:lon_ind_max_inrange)';
lat_ind_inrange = (lat_ind_min_inrange:1:lat_ind_max_inrange);


tlon = TLON(lon_ind_inrange,lat_ind_inrange);
tlat = TLAT(lon_ind_inrange,lat_ind_inrange);
ulon = ULON(lon_ind_inrange,lat_ind_inrange);
ulat = ULAT(lon_ind_inrange,lat_ind_inrange);

% compute size of subset boxes

subset_x_file_dim_size = ceil((length(lon_ind_inrange) - 3)./n_subsets_file_computation(1)) + 3;
subset_y_file_dim_size = ceil((length(lat_ind_inrange) - 3)./n_subsets_file_computation(2)) + 3;

subset_x_file_start_ind = 1 + ((subset_x_file_dim_size - 3)*(0:1:(n_subsets_file_computation(1) - 1)))';
subset_x_file_end_ind = [(subset_x_file_start_ind(1:(n_subsets_file_computation(1) - 1)) + (subset_x_file_dim_size - 1)); length(lon_ind_inrange)];
subset_y_file_start_ind = 1 + ((subset_y_file_dim_size - 3)*(0:1:(n_subsets_file_computation(2) - 1)));
subset_y_file_end_ind = [(subset_y_file_start_ind(1:(n_subsets_file_computation(2) - 1)) + (subset_y_file_dim_size - 1)); length(lat_ind_inrange)];




% find times in specified ranges
time_reg_ind_inrange = [];
for seg_ind = 1:size(start_dates_reg,1)
    curr_seg_time_reg_ind_inrange = find((time >= start_datenums_reg(seg_ind)) & (time < end_datenums_reg(seg_ind)));
    time_reg_ind_inrange = [time_reg_ind_inrange; curr_seg_time_reg_ind_inrange];
end

time_avg_ind_inrange = [];
for seg_ind = 1:size(start_dates_avg,1)
    curr_seg_time_avg_ind_inrange = find((time >= start_datenums_avg(seg_ind)) & (time < end_datenums_avg(seg_ind)));
    time_avg_ind_inrange = [time_avg_ind_inrange; curr_seg_time_avg_ind_inrange];
end



% remove possible duplication of times across files
[unique_times,unique_time_from_reg_ind,unique_time_rev_ind] = unique(time(time_reg_ind_inrange));
unique_time_ind = time_reg_ind_inrange(unique_time_from_reg_ind);

[time_avg_ind_inrange,~,time_avg_from_unique_reg_ind] = intersect(time_avg_ind_inrange,unique_time_ind);



if reg_level_option == 1
    
    % % use only files that contain times within specified time range
    % file_nums_in_time_range = unique(file_num_vec(time_ind_inrange));
    
    % use all files in source_nc_filenames
    file_nums_in_time_range = unique(file_num_vec);
    
    
    curr_file_start_ind = 1;
    
    mean_ML_depth = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_times));
    for file_num_ind = 1:length(file_nums_in_time_range)
        file_num = file_nums_in_time_range(file_num_ind);
        
        time_curr_source_file = ncread(nc_filenames{file_num},'time');
        
    %     time_ind_infile = find(file_num_vec(time_ind_inrange) == file_num);
    %     curr_time_ind_inrange = in_file_ind_vec(time_ind_inrange(time_ind_infile));
    
        time_ind_infile = find(file_num_vec(unique_time_ind) == file_num);
        if isempty(time_ind_infile) == 1
            continue
        end
        
        curr_time_ind_inrange = in_file_ind_vec(unique_time_ind(time_ind_infile));
    
    
        start_vector_nodepth = [lon_ind_min_inrange lat_ind_min_inrange min(curr_time_ind_inrange)];
        size_vector_nodepth = [length(lon_ind_inrange) length(lat_ind_inrange) (max(curr_time_ind_inrange) - min(curr_time_ind_inrange) + 1)];
        
        
        subsetting_in_time_ind = curr_time_ind_inrange - min(curr_time_ind_inrange) + 1;
        
        curr_file_end_ind = curr_file_start_ind - 1 + length(curr_time_ind_inrange);
        
        % load mixed layer depth
        curr_mean_ML_depth = ncread(nc_filenames{file_num},'HMXL',start_vector_nodepth,size_vector_nodepth,ones(1,3));
        mean_ML_depth(:,:,curr_file_start_ind:curr_file_end_ind) = curr_mean_ML_depth(:,:,subsetting_in_time_ind);
        
        curr_file_start_ind = curr_file_start_ind + length(curr_time_ind_inrange);
        
    end
    
    
    % adjust for problems with the ML depth field
    
    problem_mask = zeros(size(mean_ML_depth));
    
    problem_mask((isnan(mean_ML_depth) == 1) | (mean_ML_depth == 0)) = 1;
    
    sum_problem_mask = squeeze(sum(sum(problem_mask,2),1));
    problem_times_ind = find(sum_problem_mask > (2*min(sum_problem_mask)));
    
    for n_problem_ind = 1:length(problem_times_ind)
        curr_problem_ind = problem_times_ind(n_problem_ind);
        
        if curr_problem_ind == 1
            mean_ML_depth(:,:,1) = mean_ML_depth(:,:,2);
        elseif curr_problem_ind == size(mean_ML_depth,3)
            mean_ML_depth(:,:,size(mean_ML_depth,3)) = mean_ML_depth(:,:,size(mean_ML_depth,3) - 1);
        else
            mean_ML_depth(:,:,curr_problem_ind) = 0.5*(mean_ML_depth(:,:,curr_problem_ind - 1) + mean_ML_depth(:,:,curr_problem_ind + 1));
        end
    end
    
    
    
    z_w_top = ncread(nc_filenames{1},'z_w_top');
    z_w_bot = ncread(nc_filenames{1},'z_w_bot');
    
    
    
    % create depth bound arrays
    
    top_depth_bound_array = 0*ones(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
    % top_depth_bound_array = (double(z_w_top(2)))*ones(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
    % bottom_depth_bound_array = repmat(mean_ML_depth(:,:,1),[1 1 length(unique_time_ind)]);    % this sets bottom depth bound to the mixed layer base
    bottom_depth_bound_array = mean_ML_depth;    % this sets bottom depth bound to the mixed layer base
    % bottom_depth_bound_array = (z_w_bot(7))*ones(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));;    % this sets bottom depth bound to the mixed layer base
    
    
    % load remaining grid variables
    
    start_vector_i_j_only = [min(lon_ind_inrange) min(lat_ind_inrange)];
    size_vector_i_j_only = [length(lon_ind_inrange) length(lat_ind_inrange)];
    
    hte = ncread(nc_filenames{1},'HTE',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
    htn = ncread(nc_filenames{1},'HTN',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
    dxt = ncread(nc_filenames{1},'DXT',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
    dyt = ncread(nc_filenames{1},'DYT',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
    dxu = ncread(nc_filenames{1},'DXU',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
    dyu = ncread(nc_filenames{1},'DYU',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
    tarea = ncread(nc_filenames{1},'TAREA',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
    anglet = ncread(nc_filenames{1},'ANGLET',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
    
    
    
    % compute all depth indices needed for the mixed layer
    
    outside_depth_bounds = [min(min(min(top_depth_bound_array))) max(max(max(bottom_depth_bound_array)))];     % in cm
    z_t_ind_inrange = find((z_t >= outside_depth_bounds(1)) & (z_t <= outside_depth_bounds(2)));
    depth_ind_inrange = (max([1 (min(z_t_ind_inrange) - 1)]):1:min([length(z_t) (max(z_t_ind_inrange) + 1)]))';
    
    
    
    % load partial bottom cell grid variables
    
    KMT = ncread(nc_filenames{1},'KMT');
    kmt = KMT(lon_ind_inrange,lat_ind_inrange);
    clear KMT
    
    HT = ncread(nc_filenames{1},'HT');
    ht = HT(lon_ind_inrange,lat_ind_inrange);
    clear HT
    
    kmt_reshaped = reshape(kmt,[prod(size(kmt)) 1]);
    ht_reshaped = reshape(ht,[prod(size(ht)) 1]);
    
    dzbc_vec = zeros(size(ht_reshaped));
    not_land_ind = find(kmt_reshaped > 0);
    dzbc_vec(not_land_ind) = ht(not_land_ind) - z_w_top(kmt_reshaped(not_land_ind));
    dzbc = reshape(dzbc_vec,[length(lon_ind_inrange) length(lat_ind_inrange)]);
    
    
    
    % compute thickness of cells
    
    dzt = zeros(size(tlon,1),size(tlat,2),length(z_t));
    for curr_k_ind = 1:length(z_t)
        at_deepest_level_ind = find(kmt == curr_k_ind);
        not_at_deepest_level_ind = find(kmt > curr_k_ind);
        
        dzt_curr_level = zeros(size(dzt,1),size(dzt,2));
        dzt_curr_level(at_deepest_level_ind) = dzbc(at_deepest_level_ind);
        dzt_curr_level(not_at_deepest_level_ind) = dz(curr_k_ind)*ones(length(not_at_deepest_level_ind),1);
        
        dzt(:,:,curr_k_ind) = dzt_curr_level;
    end
    
    dzt_corner_ucells = NaN(size(dzt,1),size(dzt,2),size(dzt,3),4);
    dzt_corner_ucells(1:(size(dzt,1) - 1),1:(size(dzt,2) - 1),:,1) = dzt(1:(size(dzt,1) - 1),1:(size(dzt,2) - 1),:);
    dzt_corner_ucells(1:(size(dzt,1) - 1),1:(size(dzt,2) - 1),:,2) = dzt(2:size(dzt,1),1:(size(dzt,2) - 1),:);
    dzt_corner_ucells(1:(size(dzt,1) - 1),1:(size(dzt,2) - 1),:,3) = dzt(1:(size(dzt,1) - 1),2:size(dzt,2),:);
    dzt_corner_ucells(1:(size(dzt,1) - 1),1:(size(dzt,2) - 1),:,4) = dzt(2:size(dzt,1),2:size(dzt,2),:);
    
    dzt_east_wall = squeeze(min(dzt_corner_ucells(:,:,:,[1 2]),[],4));
    dzt_north_wall = squeeze(min(dzt_corner_ucells(:,:,:,[1 3]),[],4));
    dzu = squeeze(min(dzt_corner_ucells,[],4));
    
    
end




% regression from input time series

subset_x_reg_dim_size = (2*ceil((length(lon_ind_inrange) + 1)./(n_subsets_regression(1) + 1))) - 1;
subset_y_reg_dim_size = (2*ceil((length(lat_ind_inrange) + 1)./(n_subsets_regression(2) + 1))) - 1;

subset_x_reg_start_ind = 1 + (((subset_x_reg_dim_size + 1)/2)*(0:1:(n_subsets_regression(1) - 1)))';
subset_x_reg_end_ind = [(subset_x_reg_start_ind(1:(n_subsets_regression(1) - 1)) + (subset_x_reg_dim_size - 1)); length(lon_ind_inrange)];
subset_y_reg_start_ind = 1 + (((subset_y_reg_dim_size + 1)/2)*(0:1:(n_subsets_regression(2) - 1)));
subset_y_reg_end_ind = [(subset_y_reg_start_ind(1:(n_subsets_regression(2) - 1)) + (subset_y_reg_dim_size - 1)) length(lat_ind_inrange)];


% weighting of regressions in spatial domain

standard_weighting_x = repmat((1/((subset_x_reg_dim_size + 1)/2))*[(1:1:((subset_x_reg_dim_size + 1)/2))'; (((subset_x_reg_dim_size - 1)/2):(-1):1)'],[1 subset_y_reg_dim_size]);
standard_weighting_y = repmat((1/((subset_y_reg_dim_size + 1)/2))*[(1:1:((subset_y_reg_dim_size + 1)/2)) (((subset_y_reg_dim_size - 1)/2):(-1):1)],[subset_x_reg_dim_size 1]);
standard_weighting = standard_weighting_x.*standard_weighting_y;

weighting_array_regression = zeros([length(lon_ind_inrange) length(lat_ind_inrange) n_subsets_regression]);
for i_r = 1:n_subsets_regression(1)
    curr_x_start_ind = subset_x_reg_start_ind(i_r);
    curr_x_end_ind = subset_x_reg_end_ind(i_r);
    curr_x_ind = (curr_x_start_ind:1:curr_x_end_ind)';
    for j_r = 1:n_subsets_regression(2)
        curr_y_start_ind = subset_y_reg_start_ind(j_r);
        curr_y_end_ind = subset_y_reg_end_ind(j_r);
        curr_y_ind = (curr_y_start_ind:1:curr_y_end_ind);
        
        weighting_array_regression(curr_x_ind,curr_y_ind,i_r,j_r) = standard_weighting(1:length(curr_x_ind),1:length(curr_y_ind));
    end
end

sum_weighting_array_regression_repmat = repmat(sum(sum(weighting_array_regression,4),3),[1 1 n_subsets_regression]);
weighting_array_regression = weighting_array_regression./sum_weighting_array_regression_repmat;


% % define boundaries of averaging for regression in each subset region

% % ADJUSTABLE SETTING


% longwest_reg_qty = 90.0*ones(n_subsets_regression);
% longeast_reg_qty = 95.0*ones(n_subsets_regression);
% latsouth_reg_qty = -2.0*ones(n_subsets_regression);
% latnorth_reg_qty = 2.0*ones(n_subsets_regression);

% % time_offset = -10;    % in days


% longwest_reg_qty = tlon(subset_x_reg_start_ind,subset_y_reg_start_ind) - (grid_res/2);
% longeast_reg_qty = tlon(subset_x_reg_end_ind,subset_y_reg_end_ind) + (grid_res/2);
% latsouth_reg_qty = tlat(subset_x_reg_start_ind,subset_y_reg_start_ind) - (grid_res/2);
% latnorth_reg_qty = tlat(subset_x_reg_end_ind,subset_y_reg_end_ind) + (grid_res/2);


% % longwest_reg_qty = 109.5*ones(n_subsets_regression);
% % longeast_reg_qty = 110.5*ones(n_subsets_regression);
% % latsouth_reg_qty = -12.5*ones(n_subsets_regression);
% % latnorth_reg_qty = -11.5*ones(n_subsets_regression);
% longwest_reg_qty = 109.0*ones(n_subsets_regression);
% longeast_reg_qty = 111.0*ones(n_subsets_regression);
% latsouth_reg_qty = -13.0*ones(n_subsets_regression);
% latnorth_reg_qty = -11.0*ones(n_subsets_regression);


longwest_reg_qty = 115.5*ones(n_subsets_regression);
longeast_reg_qty = 116.2*ones(n_subsets_regression);
latsouth_reg_qty = -8.5*ones(n_subsets_regression);
latnorth_reg_qty = -8.3*ones(n_subsets_regression);




TLAT = ncread(nc_filenames{1},'TLAT');
TLON = ncread(nc_filenames{1},'TLONG');

ind_inrange = find((TLON >= (min(min(longwest_reg_qty)) - (2*grid_res))) & (TLON <= (max(max(longeast_reg_qty)) + (2*grid_res))) & (TLAT >= (min(min(latsouth_reg_qty)) - (2*grid_res))) & (TLAT <= (max(max(latnorth_reg_qty)) + (2*grid_res))));
[lat_ind_mesh,lon_ind_mesh] = meshgrid((1:1:size(TLAT,2)),(1:1:size(TLON,1)));


lon_ind_min_inrange = min(lon_ind_mesh(ind_inrange));
lon_ind_max_inrange = max(lon_ind_mesh(ind_inrange));
lat_ind_min_inrange = min(lat_ind_mesh(ind_inrange));
lat_ind_max_inrange = max(lat_ind_mesh(ind_inrange));

lon_ind_inrange_reg_qty = (lon_ind_min_inrange:1:lon_ind_max_inrange)';
lat_ind_inrange_reg_qty = (lat_ind_min_inrange:1:lat_ind_max_inrange);

tlon_reg_qty = TLON(lon_ind_inrange_reg_qty,lat_ind_inrange_reg_qty);
tlat_reg_qty = TLAT(lon_ind_inrange_reg_qty,lat_ind_inrange_reg_qty);
ulon_reg_qty = ULON(lon_ind_inrange_reg_qty,lat_ind_inrange_reg_qty);
ulat_reg_qty = ULAT(lon_ind_inrange_reg_qty,lat_ind_inrange_reg_qty);


if reg_level_option == 1
    unique_time_ind_reg_level1 = unique_time_ind;
    time_reg_level1 = time;
end


curr_file_start_ind = 1;

SSH_reg_qty_alltimes = NaN(length(lon_ind_inrange_reg_qty),length(lat_ind_inrange_reg_qty),length(in_file_ind_vec));
% SSH_south_reg_qty_alltimes = NaN(length(lon_ind_inrange_reg_qty),round(0.5*length(lat_ind_inrange_reg_qty)),length(in_file_ind_vec));
% SSH_north_reg_qty_alltimes = NaN(length(lon_ind_inrange_reg_qty),round(0.5*length(lat_ind_inrange_reg_qty)),length(in_file_ind_vec));
tau_x_reg_qty_alltimes = NaN(length(lon_ind_inrange_reg_qty),length(lat_ind_inrange_reg_qty),length(in_file_ind_vec));
tau_y_reg_qty_alltimes = NaN(length(lon_ind_inrange_reg_qty),length(lat_ind_inrange_reg_qty),length(in_file_ind_vec));
vvel_surf_reg_qty_alltimes = NaN(length(lon_ind_inrange_reg_qty),length(lat_ind_inrange_reg_qty),length(in_file_ind_vec));
for file_num = 1:length(nc_filenames)
    time_curr_source_file = ncread(nc_filenames{file_num},'time');
    
%     time_ind_infile = find(file_num_vec(unique_time_ind_reg_level1) == file_num);
    if length(time_curr_source_file) == 0
        continue
    end
    
    curr_time_dim_length = length(time_curr_source_file);
    
    start_vector_nodepth_reg_qty = [min(lon_ind_inrange_reg_qty) min(lat_ind_inrange_reg_qty) 1];
    size_vector_nodepth_reg_qty = [length(lon_ind_inrange_reg_qty) length(lat_ind_inrange_reg_qty) curr_time_dim_length];
    start_vector_surf_only_reg_qty = [min(lon_ind_inrange_reg_qty) min(lat_ind_inrange_reg_qty) 1 1];
    size_vector_surf_only_reg_qty = [length(lon_ind_inrange_reg_qty) length(lat_ind_inrange_reg_qty) 1 curr_time_dim_length];
    
    
%     if file_num == 1
    if curr_file_start_ind == 1
        dxt = ncread(nc_filenames{1},'DXT',start_vector_nodepth_reg_qty(1:2),size_vector_nodepth_reg_qty(1:2),ones(1,2));
        dyt = ncread(nc_filenames{1},'DYT',start_vector_nodepth_reg_qty(1:2),size_vector_nodepth_reg_qty(1:2),ones(1,2));
        dxu = ncread(nc_filenames{1},'DXU',start_vector_nodepth_reg_qty(1:2),size_vector_nodepth_reg_qty(1:2),ones(1,2));
        dyu = ncread(nc_filenames{1},'DYU',start_vector_nodepth_reg_qty(1:2),size_vector_nodepth_reg_qty(1:2),ones(1,2));
        tarea = ncread(nc_filenames{1},'TAREA',start_vector_nodepth_reg_qty(1:2),size_vector_nodepth_reg_qty(1:2),ones(1,2));
    end
    
    
    curr_file_end_ind = curr_file_start_ind - 1 + curr_time_dim_length;
    
    
    SSH_reg_qty_alltimes(:,:,curr_file_start_ind:curr_file_end_ind) = ncread(nc_filenames{file_num},'SSH',start_vector_nodepth_reg_qty,size_vector_nodepth_reg_qty,ones(1,3));
%     SSH_south_reg_qty_alltimes(:,:,curr_file_start_ind:curr_file_end_ind) = ncread(nc_filenames{file_num},'SSH',start_vector_nodepth_reg_qty - [0 30 0],round([1 0.5 1].*size_vector_nodepth_reg_qty),ones(1,3));
%     SSH_north_reg_qty_alltimes(:,:,curr_file_start_ind:curr_file_end_ind) = ncread(nc_filenames{file_num},'SSH',start_vector_nodepth_reg_qty + [0 50 0],round([1 0.5 1].*size_vector_nodepth_reg_qty),ones(1,3));
    tau_x_reg_qty_alltimes(:,:,curr_file_start_ind:curr_file_end_ind) = ncread(nc_filenames{file_num},'TAUX',start_vector_nodepth_reg_qty,size_vector_nodepth_reg_qty,ones(1,3));
    tau_y_reg_qty_alltimes(:,:,curr_file_start_ind:curr_file_end_ind) = ncread(nc_filenames{file_num},'TAUY',start_vector_nodepth_reg_qty,size_vector_nodepth_reg_qty,ones(1,3));
    uvel_surf_reg_qty_alltimes(:,:,curr_file_start_ind:curr_file_end_ind) = squeeze(ncread(nc_filenames{file_num},'UVEL',start_vector_surf_only_reg_qty,size_vector_surf_only_reg_qty,ones(1,4)));
    vvel_surf_reg_qty_alltimes(:,:,curr_file_start_ind:curr_file_end_ind) = squeeze(ncread(nc_filenames{file_num},'VVEL',start_vector_surf_only_reg_qty,size_vector_surf_only_reg_qty,ones(1,4)));
    
    curr_file_start_ind = curr_file_start_ind + curr_time_dim_length;
    
end


% SSH_Kelvin_diff_reg_qty_alltimes = NaN(size(SSH_reg_qty_alltimes));
% SSH_Kelvin_diff_reg_qty_alltimes(:,1:size(SSH_south_reg_qty_alltimes,2),:) = SSH_reg_qty_alltimes(:,1:size(SSH_south_reg_qty_alltimes,2),:) - SSH_south_reg_qty_alltimes;
% SSH_Kelvin_diff_reg_qty_alltimes(:,(size(SSH_south_reg_qty_alltimes,2) + 1):size(SSH_reg_qty_alltimes,2),:) = SSH_reg_qty_alltimes(:,(size(SSH_south_reg_qty_alltimes,2) + 1):size(SSH_reg_qty_alltimes,2),:) - SSH_north_reg_qty_alltimes;



% loop through different time offsets

input_timeseries_array = NaN([n_subsets_regression length(unique_time_ind) length(lags)]);
% G_reg_array = NaN([n_subsets_regression length(unique_time_ind_reg_qty) length(lags)]);
% reg_operator_T_array = NaN([n_subsets_regression length(unique_time_ind_reg_qty) length(lags)]);
for lag_ind = 1:length(lags)
    
    time_offset = lags(lag_ind);
    
    time_ind_offset = round(time_offset/tavg_days);
%     unique_time_ind_reg_qty = unique_time_ind + time_ind_offset;
%     unique_time_ind_reg_qty = unique_time_ind_reg_level1 + time_ind_offset;
    unique_time_ind_reg_qty = unique_time_ind_reg_level1(unique_time_ind) + time_ind_offset;
    unique_times_reg_qty = time_reg_level1(unique_time_ind_reg_qty);
    
    
    SSH_reg_qty = SSH_reg_qty_alltimes(:,:,unique_time_ind_reg_qty);
%     SSH_Kelvin_diff_reg_qty = SSH_Kelvin_diff_reg_qty_alltimes(:,:,unique_time_ind_reg_qty);
    tau_x_reg_qty = tau_x_reg_qty_alltimes(:,:,unique_time_ind_reg_qty);
    tau_y_reg_qty = tau_y_reg_qty_alltimes(:,:,unique_time_ind_reg_qty);
    uvel_surf_reg_qty = uvel_surf_reg_qty_alltimes(:,:,unique_time_ind_reg_qty);
    vvel_surf_reg_qty = vvel_surf_reg_qty_alltimes(:,:,unique_time_ind_reg_qty);
    
    
    % compute wind stress curl
    
    d_tau_y_dx = NaN(size(tau_y_reg_qty));
    dyu_tau_y = repmat(dyu,[1 1 size(tau_y_reg_qty,3)]).*tau_y_reg_qty;
    dyu_tau_y_midlat = dyu_tau_y(:,2:size(tau_y_reg_qty,2),:) - (diff(dyu_tau_y,1,2)/2);
    d_tau_y_dx(2:size(d_tau_y_dx,1),2:size(d_tau_y_dx,2),:) = repmat(1./tarea(2:size(tarea,1),2:size(tarea,2)),[1 1 size(d_tau_y_dx,3)]).*diff(dyu_tau_y_midlat,1,1);
    d_tau_x_dy = NaN(size(tau_x_reg_qty));
    dxu_tau_x = repmat(dxu,[1 1 size(tau_x_reg_qty,3)]).*tau_x_reg_qty;
    dxu_tau_x_midlon = dxu_tau_x(2:size(tau_x_reg_qty,1),:,:) - (diff(dxu_tau_x,1,1)/2);
    d_tau_x_dy(2:size(d_tau_x_dy,1),2:size(d_tau_x_dy,2),:) = repmat(1./tarea(2:size(tarea,1),2:size(tarea,2)),[1 1 size(d_tau_x_dy,3)]).*diff(dxu_tau_x_midlon,1,2);
    
    tau_curl_reg_qty = d_tau_y_dx - d_tau_x_dy;
    
    clear dyu_tau_* dxu_tau_* d_tau_y_dx d_tau_x_dy
    
    
    % band-passing current velocities for mesoscale frequencies (20- to 180-day periods)
    
    df = 1/(5*length(unique_time_ind_reg_qty));
    f_vec = df*(mod((0:1:(length(unique_time_ind_reg_qty) - 1))' + floor(length(unique_time_ind)/2),length(unique_time_ind)) - floor(length(unique_time_ind)/2));
    erf_filter = 0.5*(erf(3600*(abs(f_vec) - (1/180))) - erf(400*(abs(f_vec) - (1/20))));
    
    % screen for occasional NaNs
    uvel_surf_reg_qty_zeronans = uvel_surf_reg_qty;
    nan_uvel_surf_ind = find(isnan(uvel_surf_reg_qty_zeronans) == 1);
    uvel_surf_reg_qty_zeronans(nan_uvel_surf_ind) = 0;
    vvel_surf_reg_qty_zeronans = vvel_surf_reg_qty;
    nan_vvel_surf_ind = find(isnan(vvel_surf_reg_qty_zeronans) == 1);
    vvel_surf_reg_qty_zeronans(nan_vvel_surf_ind) = 0;
    
    fft_uvel_surf_reg_qty = fft(uvel_surf_reg_qty_zeronans,[],3);
    fft_vvel_surf_reg_qty = fft(vvel_surf_reg_qty_zeronans,[],3);
    
    uvel_surf_bandpassed_reg_qty = ifft(repmat(reshape(erf_filter,[1 1 length(f_vec)]),[size(uvel_surf_reg_qty,1) size(uvel_surf_reg_qty,2) 1]).*fft_uvel_surf_reg_qty,[],3);
    vvel_surf_bandpassed_reg_qty = ifft(repmat(reshape(erf_filter,[1 1 length(f_vec)]),[size(vvel_surf_reg_qty,1) size(vvel_surf_reg_qty,2) 1]).*fft_vvel_surf_reg_qty,[],3);
    
    uvel_surf_bandpassed_reg_qty(nan_uvel_surf_ind) = NaN;
    vvel_surf_bandpassed_reg_qty(nan_vvel_surf_ind) = NaN;
    
    
    
    
    % input field(s) -- Adjust this based on field being used (e.g., SSH, wind stress, velocity) for regression.  Also specify grid(s) for input fields, i.e. 'tgrid' or 'ugrid'.

    % % ADJUSTABLE SETTING
    
%     input_reg_qty = {SSH_Kelvin_diff_reg_qty};
%     grid_input_reg_qty = {'tgrid'};
%     input_timeseries_column_num = 1;    % column to use as time series in correlations
    
%     input_reg_qty = {tau_x_reg_qty tau_y_reg_qty tau_curl_reg_qty};
%     grid_input_reg_qty = {'ugrid' 'ugrid' 'tgrid'};
%     input_timeseries_column_num = 1;    % column to use as time series in correlations
    
%     input_reg_qty = {vvel_surf_bandpassed_reg_qty};
%     grid_input_reg_qty = {'ugrid'};
%     input_timeseries_column_num = 1;    % column to use as time series in correlations
    
%     input_reg_qty = {-SSH_Kelvin_diff_reg_qty};
%     grid_input_reg_qty = {'tgrid'};
%     input_timeseries_column_num = 1;    % column to use as time series in correlations
    
    input_reg_qty = {vvel_surf_reg_qty};
    grid_input_reg_qty = {'ugrid'};
    input_timeseries_column_num = 1;    % column to use as time series in correlations
    
    
    
    
    n_input_timeseries = length(grid_input_reg_qty);
    
    input_timeseries_array = NaN([n_subsets_regression length(unique_time_ind_reg_qty) n_input_timeseries]);
    for n_input = 1:n_input_timeseries
        curr_input_timeseries = input_reg_qty{n_input};
        curr_grid_input = grid_input_reg_qty{n_input};
        
        nan_ind = find((isnan(curr_input_timeseries) == 1) | (curr_input_timeseries == 0));
        curr_input_timeseries_zeronans = curr_input_timeseries;
        curr_input_timeseries_zeronans(nan_ind) = 0;
        
        for i_r = 1:n_subsets_regression(1)
            for j_r = 1:n_subsets_regression(2)
                
                if strcmp(curr_grid_input,'tgrid') == 1
                    spatial_ind_reg_qty = find((tlon_reg_qty >= longwest_reg_qty(i_r,j_r)) & (tlon_reg_qty <= longeast_reg_qty(i_r,j_r)) & (tlat_reg_qty >= latsouth_reg_qty(i_r,j_r)) & (tlat_reg_qty <= latnorth_reg_qty(i_r,j_r)));
                else
                    spatial_ind_reg_qty = find((ulon_reg_qty >= longwest_reg_qty(i_r,j_r)) & (ulon_reg_qty <= longeast_reg_qty(i_r,j_r)) & (ulat_reg_qty >= latsouth_reg_qty(i_r,j_r)) & (ulat_reg_qty <= latnorth_reg_qty(i_r,j_r)));
                end
                
                in_box_reg_qty_avg_mask = zeros(size_vector_nodepth_reg_qty([1 2]));
                in_box_reg_qty_avg_mask(spatial_ind_reg_qty) = 1;
                in_box_reg_qty_mask = repmat(in_box_reg_qty_avg_mask,[1 1 length(unique_time_ind_reg_qty)]);
                in_box_reg_qty_mask(nan_ind) = 0;
                
                
                % adjust this based on field being used (e.g., SSH, wind stress, current) for regression
    %             input_timeseries_array(i_r,j_r,:,n_input) = sum(sum(repmat(in_box_reg_qty_avg_mask,[1 1 length(unique_time_ind_reg_qty)]).*curr_input_timeseries,2),1);
                input_timeseries_array(i_r,j_r,:,n_input) = sum(sum(in_box_reg_qty_mask.*curr_input_timeseries_zeronans,2),1)./sum(sum(in_box_reg_qty_mask,2),1);
                % normalize by standard deviation (for better multivariate regressions)
                input_timeseries_array(i_r,j_r,:,n_input) = input_timeseries_array(i_r,j_r,:,n_input)/(std(input_timeseries_array(i_r,j_r,:,n_input)));
                
            end
        end
        
        
        % remove annual cycle and harmonics
        
        G_seasonal_reg = [ones(length(unique_times_reg_qty),1) cos((2*pi/365)*unique_times_reg_qty) sin((2*pi/365)*unique_times_reg_qty) cos((2*pi/(365/2))*unique_times_reg_qty) sin((2*pi/(365/2))*unique_times_reg_qty) cos((2*pi/(365/3))*unique_times_reg_qty) sin((2*pi/(365/3))*unique_times_reg_qty) cos((2*pi/(365/4))*unique_times_reg_qty) sin((2*pi/(365/4))*unique_times_reg_qty)];
        
        m_seasonal_reg_qty = (((G_seasonal_reg')*G_seasonal_reg)^(-1))*((G_seasonal_reg')*(reshape(input_timeseries_array(:,:,:,n_input),[prod(n_subsets_regression) length(unique_time_ind_reg_qty)])'));
        
        curr_input_timeseries_array_noreg = input_timeseries_array(:,:,:,n_input) - reshape((G_seasonal_reg*m_seasonal_reg_qty),[n_subsets_regression length(unique_time_ind_reg_qty)]);
        
        input_timeseries_array(:,:,:,n_input) = curr_input_timeseries_array_noreg;
        
    end
    
    
    
%     % ADJUSTABLE SETTING (comment out if undesired)
%     
%     % low-pass index or indices
%     
%     lp_threshold = 1/20;    % low-pass cutoff frequency
%     steepness_factor = 5;
%     [input_timeseries_array_lp,~,~] = bandpass_err_fcn(input_timeseries_array,3,tavg_days,(2/3)/(tavg_days*size(input_timeseries_array,3)),lp_threshold,5,1,1,0,0);
    
    
    
    % ADJUSTABLE SETTING (comment out if undesired)
    
    % remove influence of another index
    
    primary_input_timeseries_array = input_timeseries_array;
    % % load('temp_budget_Java_Kelvin_diff_1979_to_2009_ML_seasonreg.mat','input_timeseries_array')
    % load('temp_budget_Java_wstr_local_allderivs_1979_to_2009_ML_seasonreg.mat','input_timeseries_array')
    % input_timeseries_array_to_rem_reg = input_timeseries_array;
    
    load('temp_budget_Java_Kelvin_diff_20_lp_1979_to_2009_ML_seasonreg.mat','input_timeseries_array')
    input_timeseries_Kelvin = repmat(input_timeseries_array(1,1,:,:),[14 9]);
    load('temp_budget_Java_wstr_Sumatra_allderivs_10lead_rem_reg_wstr_local_20_lp_1979_to_2009_ML_seasonreg.mat','input_timeseries_array')
    input_timeseries_wstr_Sumatra = input_timeseries_array;
    load('temp_budget_Java_wstr_local_allderivs_1979_to_2009_ML_seasonreg.mat','input_timeseries_array')
    input_timeseries_wstr_local = input_timeseries_array;
    input_timeseries_array_to_rem_reg(:,:,:,1) = input_timeseries_Kelvin;
    input_timeseries_array_to_rem_reg(:,:,:,2:7) = input_timeseries_wstr_Sumatra;
    input_timeseries_array_to_rem_reg(:,:,:,8:13) = input_timeseries_wstr_local;
    
    clear input_timeseries_array
    % rem_reg_input_timeseries = squeeze(input_timeseries_array_to_rem_reg(1,1,:));
    
    input_timeseries_array = NaN(size(primary_input_timeseries_array));
    for i_r = 1:size(primary_input_timeseries_array,1)
        for j_r = 1:size(primary_input_timeseries_array,2)
            rem_reg_input_timeseries = squeeze(input_timeseries_array_to_rem_reg(i_r,j_r,:,:));
            curr_rem_reg_timeseries = (rem_reg_input_timeseries*(((rem_reg_input_timeseries')*rem_reg_input_timeseries)^(-1))*(rem_reg_input_timeseries'))*(squeeze(primary_input_timeseries_array(i_r,j_r,:,:)));
            
            input_timeseries_array(i_r,j_r,:,:) = reshape(squeeze(primary_input_timeseries_array(i_r,j_r,:,:)) - curr_rem_reg_timeseries,[1 1 size(input_timeseries_array,3) size(input_timeseries_array,4)]);
        end
    end
    
    
    
    
    
    % subset times for regressions (in seasonal cycle)
    
    if lag_ind == 1
        t_start_reg = [1 1; 1 31; 3 2; 4 1; 5 1; 5 31; 6 30; 8 4; 9 3; 10 3; 11 2; 12 2];
        % t_end_reg = [4 1; 5 1; 5 31; 6 30; 7 30; 8 29; 9 28; 11 2; 12 2; 1 1; 1 31; 3 2];
        t_reg_seg_length_days = 90;
        t_start_daynums = mod(datenum([(1990*ones(size(t_start_reg,1),1)) t_start_reg]) - datenum([1990 1 1]),365);
        % t_end_daynum = mod(datenum([(1990*ones(size(t_start_reg,1),1)) t_start_reg]) - datenum([1990 1 1]),365);
        t_end_daynums = mod(t_start_daynums + t_reg_seg_length_days,365);
        t_centers = mod(t_start_daynums + ((mod(t_end_daynums - t_start_daynums + 182.5,365) - 182.5)/2),365);
        
        time_daynums = mod(time,365);
        
        time_ind_subset_reg_cellarray = cell(size(t_start_reg,1),length(lags));
        time_weighting_subset_reg_cellarray = cell(size(t_start_reg,1),length(lags));
        G_reg_cellarray = cell(size(t_start_reg,1),length(lags));
        reg_operator_T_cellarray = cell(size(t_start_reg,1),length(lags));
    end
    for t_r = 1:length(time_ind_subset_reg_cellarray)
        curr_start_daynum = t_start_daynums(t_r);
        curr_end_daynum = t_end_daynums(t_r);
        curr_center = t_centers(t_r);
        curr_center_before = t_centers(mod(t_r - 1 - 1,size(t_start_reg,1)) + 1);
        curr_center_after = t_centers(mod(t_r + 1 - 1,size(t_start_reg,1)) + 1);
        
        curr_time_ind_subset_reg = find((mod(time_daynums - curr_start_daynum + 182.5,365) - 182.5 >= 0) & (mod(time_daynums - curr_end_daynum + 182.5,365) - 182.5 < 0));
        
        curr_weighting_before_center = (mod(time_daynums(curr_time_ind_subset_reg) - curr_center_before + 182.5,365) - 182.5)/(mod(curr_center - curr_center_before + 182.5,365) - 182.5);
        curr_weighting_after_center = (mod(-time_daynums(curr_time_ind_subset_reg) + curr_center_after + 182.5,365) - 182.5)/(mod(-curr_center + curr_center_after + 182.5,365) - 182.5);
        curr_weighting_subset_reg = zeros(length(curr_time_ind_subset_reg),1);
        curr_weighting_before_ind = find((curr_weighting_before_center > 0) & (curr_weighting_before_center <= 1));
        curr_weighting_after_ind = find((curr_weighting_after_center > 0) & (curr_weighting_after_center <= 1));
        curr_weighting_subset_reg(curr_weighting_before_ind) = curr_weighting_before_center(curr_weighting_before_ind);
        curr_weighting_subset_reg(curr_weighting_after_ind) = curr_weighting_after_center(curr_weighting_after_ind);
        
        time_ind_subset_reg_cellarray{t_r,lag_ind} = curr_time_ind_subset_reg;
        time_weighting_subset_reg_cellarray{t_r,lag_ind} = curr_weighting_subset_reg;
        
        
        
        G_reg_array = NaN([n_subsets_regression length(curr_time_ind_subset_reg) n_input_timeseries]);
        reg_operator_T_array = NaN([n_subsets_regression length(curr_time_ind_subset_reg) n_input_timeseries]);
        for i_r = 1:n_subsets_regression(1)
            for j_r = 1:n_subsets_regression(2)
    %             % G_reg = [ones(length(unique_times_reg_qty),1) squeeze(input_timeseries_array(i_r,j_r,:,lag_ind))];
    %             G_reg = squeeze(input_timeseries_array(i_r,j_r,:,lag_ind));
    %             G_reg_array(i_r,j_r,:,lag_ind,:) = reshape(G_reg,[1 1 length(unique_time_ind_reg_qty)]);
                curr_G_reg = squeeze(input_timeseries_array(i_r,j_r,:,:));
                G_reg_array(i_r,j_r,:,lag_ind,:) = reshape(curr_G_reg,[1 1 size(curr_G_reg,1) 1 size(curr_G_reg,2)]);
                
                
                % regression operator
                
    %             reg_operator_T_array(i_r,j_r,:,lag_ind) = reshape(((((G_reg')*G_reg)^(-1))*(G_reg'))',[1 1 length(unique_times_reg_qty)]);
                reg_operator_T_array(i_r,j_r,:,lag_ind,:) = reshape(((((curr_G_reg')*curr_G_reg)^(-1))*(curr_G_reg'))',[1 1 size(curr_G_reg,1) 1 size(curr_G_reg,2)]);
                
            end
        end
        
        G_reg_cellarray{t_r,lag_ind} = G_reg_array;
        reg_operator_T_cellarray{t_r,lag_ind} = reg_operator_T_array;
        
    end
            
end






% compute correlations and lags for subset regions


size_array_ij = [length(lon_ind_inrange) length(lat_ind_inrange)];


if reg_level_option == 1
    file_name_base_input = NaN;
else
%     file_nums_in_time_range = NaN;
%     file_num_vec = NaN;
%     in_file_ind_vec = NaN;
    depth_ind_inrange = NaN;
    tarea = NaN(size_array_ij);
    hte = NaN(size_array_ij);
    htn = NaN(size_array_ij);
    dzt = NaN([size_array_ij 1]);
    dzt_east_wall = NaN([size_array_ij 1]);
    dzt_north_wall = NaN([size_array_ij 1]);
    top_depth_bound_array = NaN([size_array_ij 1]);
    bottom_depth_bound_array = NaN([size_array_ij 1]);
    dxu = NaN(size_array_ij);
    dyu = NaN(size_array_ij);
    dzu = NaN([size_array_ij 1]);
    dxt = NaN(size_array_ij);
    dyt = NaN(size_array_ij);
    ht = NaN(size_array_ij);
end

corrcoef_at_optlag_input_vel_vert_mean_inlayer = NaN(size_array_ij);
opt_lag_input_vel_vert_mean_inlayer = NaN(size_array_ij);
opt_angle_input_vel_vert_mean_inlayer = NaN(size_array_ij);
% corrcoef_at_optlag_input_adv_tend_vel_reg = NaN(size_array_ij);
% opt_lag_input_adv_tend_vel_reg = NaN(size_array_ij);
% corrcoef_at_optlag_input_adv_tend_T_reg = NaN(size_array_ij);
% opt_lag_input_adv_tend_T_reg = NaN(size_array_ij);
corrcoef_at_optlag_input_adv_tend_vel_reg_T_reg = NaN(size_array_ij);
opt_lag_input_adv_tend_vel_reg_T_reg = NaN(size_array_ij);
corrcoef_at_optlag_input_adv_tend_vel_reg_T_noreg = NaN(size_array_ij);
opt_lag_input_adv_tend_vel_reg_T_noreg = NaN(size_array_ij);
corrcoef_at_optlag_input_adv_tend_vel_noreg_T_reg = NaN(size_array_ij);
opt_lag_input_adv_tend_vel_noreg_T_reg = NaN(size_array_ij);
corrcoef_at_optlag_input_adv_tend_total = NaN(size_array_ij);
opt_lag_input_adv_tend_total = NaN(size_array_ij);
for i_f = 1:n_subsets_file_computation(1)
    curr_x_start_ind = subset_x_file_start_ind(i_f);
    curr_x_end_ind = subset_x_file_end_ind(i_f);
    curr_x_ind = (curr_x_start_ind:1:curr_x_end_ind)';
    for j_f = 1:n_subsets_file_computation(2)
        curr_y_start_ind = subset_y_file_start_ind(j_f);
        curr_y_end_ind = subset_y_file_end_ind(j_f);
        curr_y_ind = (curr_y_start_ind:1:curr_y_end_ind)';
        
%         [curr_corrcoef_at_optlag_input_vel_vert_mean_inlayer,curr_opt_lag_input_vel_vert_mean_inlayer,curr_opt_angle_input_vel_vert_mean_inlayer,curr_corrcoef_at_optlag_input_adv_tend_vel_reg,curr_opt_lag_input_adv_tend_vel_reg,curr_corrcoef_at_optlag_input_adv_tend_T_reg,curr_opt_lag_input_adv_tend_T_reg,curr_corrcoef_at_optlag_input_adv_tend_total,curr_opt_lag_input_adv_tend_total] = temp_corr_maps_ML_fcn(reg_level_option,file_name_base_input,i_f,j_f,nc_filenames,file_nums_in_time_range,file_num_vec,time,unique_time_ind,in_file_ind_vec,lon_ind_inrange(curr_x_ind),lat_ind_inrange(curr_y_ind),depth_ind_inrange,tarea(curr_x_ind,curr_y_ind),hte(curr_x_ind,curr_y_ind),htn(curr_x_ind,curr_y_ind),dzt(curr_x_ind,curr_y_ind,:),dzt_east_wall(curr_x_ind,curr_y_ind,:),dzt_north_wall(curr_x_ind,curr_y_ind,:),dz,top_depth_bound_array(curr_x_ind,curr_y_ind,:),bottom_depth_bound_array(curr_x_ind,curr_y_ind,:),unique_times,z_w_top,z_w_bot,dxu(curr_x_ind,curr_y_ind),dyu(curr_x_ind,curr_y_ind),dzu(curr_x_ind,curr_y_ind,:),dxt(curr_x_ind,curr_y_ind),dyt(curr_x_ind,curr_y_ind),lags,n_subsets_regression,weighting_array_regression(curr_x_ind,curr_y_ind,:,:),input_timeseries_column_num,G_reg_array,reg_operator_T_array,ht(curr_x_ind,curr_y_ind),ent_compute_option,time_avg_ind_inrange,time_avg_from_unique_reg_ind);
        [curr_corrcoef_at_optlag_input_vel_vert_mean_inlayer,curr_opt_lag_input_vel_vert_mean_inlayer,curr_opt_angle_input_vel_vert_mean_inlayer,curr_corrcoef_at_optlag_input_adv_tend_vel_reg_T_reg,curr_opt_lag_input_adv_tend_vel_reg_T_reg,curr_corrcoef_at_optlag_input_adv_tend_vel_reg_T_noreg,curr_opt_lag_input_adv_tend_vel_reg_T_noreg,curr_corrcoef_at_optlag_input_adv_tend_vel_noreg_T_reg,curr_opt_lag_input_adv_tend_vel_noreg_T_reg,curr_corrcoef_at_optlag_input_adv_tend_total,curr_opt_lag_input_adv_tend_total] = temp_corr_maps_ML_fcn(reg_level_option,file_name_base_input,i_f,j_f,nc_filenames,file_nums_in_time_range,file_num_vec,time,unique_time_ind,in_file_ind_vec,lon_ind_inrange(curr_x_ind),lat_ind_inrange(curr_y_ind),depth_ind_inrange,tarea(curr_x_ind,curr_y_ind),hte(curr_x_ind,curr_y_ind),htn(curr_x_ind,curr_y_ind),dzt(curr_x_ind,curr_y_ind,:),dzt_east_wall(curr_x_ind,curr_y_ind,:),dzt_north_wall(curr_x_ind,curr_y_ind,:),dz,top_depth_bound_array(curr_x_ind,curr_y_ind,:),bottom_depth_bound_array(curr_x_ind,curr_y_ind,:),unique_times,z_w_top,z_w_bot,dxu(curr_x_ind,curr_y_ind),dyu(curr_x_ind,curr_y_ind),dzu(curr_x_ind,curr_y_ind,:),dxt(curr_x_ind,curr_y_ind),dyt(curr_x_ind,curr_y_ind),lags,n_subsets_regression,weighting_array_regression(curr_x_ind,curr_y_ind,:,:),input_timeseries_column_num,G_reg_array,reg_operator_T_array,ht(curr_x_ind,curr_y_ind),ent_compute_option,time_avg_ind_inrange,time_avg_from_unique_reg_ind);
        
        curr_term_subset = curr_corrcoef_at_optlag_input_vel_vert_mean_inlayer;
        curr_term_zeronans = NaN(size_array_ij);
        curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
        curr_term_zero_ind = find(curr_term_zeronans == 0);
        nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
        curr_term_zeronans(nan_ind) = 0;
        curr_term_old = corrcoef_at_optlag_input_vel_vert_mean_inlayer;
        curr_term_old_zero_ind = find(curr_term_old == 0);
        nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
        curr_term_old_zeronans = curr_term_old;
        curr_term_old_zeronans(nan_old_domain_ind) = 0;
        currdomain_mask = zeros(size_array_ij);
        currdomain_mask(nan_old_domain_ind) = 1;
        currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
        currdomain_mask(nan_ind) = 0;
        curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
        curr_term(curr_term == 0) = NaN;
        curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
        corrcoef_at_optlag_input_vel_vert_mean_inlayer = curr_term;
        
        curr_term_subset = curr_opt_lag_input_vel_vert_mean_inlayer;
        curr_term_zeronans = NaN(size_array_ij);
        curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
        curr_term_zero_ind = find(curr_term_zeronans == 0);
        nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
        curr_term_zeronans(nan_ind) = 0;
        curr_term_old = opt_lag_input_vel_vert_mean_inlayer;
        curr_term_old_zero_ind = find(curr_term_old == 0);
        nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
        curr_term_old_zeronans = curr_term_old;
        curr_term_old_zeronans(nan_old_domain_ind) = 0;
        currdomain_mask = zeros(size_array_ij);
        currdomain_mask(nan_old_domain_ind) = 1;
        currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
        currdomain_mask(nan_ind) = 0;
        curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
        curr_term(curr_term == 0) = NaN;
        curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
        opt_lag_input_vel_vert_mean_inlayer = curr_term;
        
        curr_term_subset = curr_opt_angle_input_vel_vert_mean_inlayer;
        curr_term_zeronans = NaN(size_array_ij);
        curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
        curr_term_zero_ind = find(curr_term_zeronans == 0);
        nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
        curr_term_zeronans(nan_ind) = 0;
        curr_term_old = opt_angle_input_vel_vert_mean_inlayer;
        curr_term_old_zero_ind = find(curr_term_old == 0);
        nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
        curr_term_old_zeronans = curr_term_old;
        curr_term_old_zeronans(nan_old_domain_ind) = 0;
        currdomain_mask = zeros(size_array_ij);
        currdomain_mask(nan_old_domain_ind) = 1;
        currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
        currdomain_mask(nan_ind) = 0;
        curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
        curr_term(curr_term == 0) = NaN;
        curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
        opt_angle_input_vel_vert_mean_inlayer = curr_term;
        
%         curr_term_subset = curr_corrcoef_at_optlag_input_adv_tend_vel_reg;
%         curr_term_zeronans = zeros(size_array_ij);
%         curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
%         nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1) | (curr_term_zeronans == 0));
%         curr_term_zeronans(nan_ind) = 0;
%         curr_term_old = corrcoef_at_optlag_input_adv_tend_vel_reg;
%         nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
%         curr_term_old_zeronans = curr_term_old;
%         curr_term_old_zeronans(nan_old_domain_ind) = 0;
%         currdomain_mask = zeros(size_array_ij);
%         currdomain_mask(nan_old_domain_ind) = 1;
%         currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
%         currdomain_mask(nan_ind) = 0;
%         curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
%         curr_term(curr_term == 0) = NaN;
%         corrcoef_at_optlag_input_adv_tend_vel_reg = curr_term;
%         
%         curr_term_subset = curr_opt_lag_input_adv_tend_vel_reg;
%         curr_term_zeronans = zeros(size_array_ij);
%         curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
%         nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1) | (curr_term_zeronans == 0));
%         curr_term_zeronans(nan_ind) = 0;
%         curr_term_old = opt_lag_input_adv_tend_vel_reg;
%         nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
%         curr_term_old_zeronans = curr_term_old;
%         curr_term_old_zeronans(nan_old_domain_ind) = 0;
%         currdomain_mask = zeros(size_array_ij);
%         currdomain_mask(nan_old_domain_ind) = 1;
%         currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
%         currdomain_mask(nan_ind) = 0;
%         curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
%         curr_term(curr_term == 0) = NaN;
%         opt_lag_input_adv_tend_vel_reg = curr_term;
%         
%         curr_term_subset = curr_corrcoef_at_optlag_input_adv_tend_T_reg;
%         curr_term_zeronans = zeros(size_array_ij);
%         curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
%         nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1) | (curr_term_zeronans == 0));
%         curr_term_zeronans(nan_ind) = 0;
%         curr_term_old = corrcoef_at_optlag_input_adv_tend_T_reg;
%         nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
%         curr_term_old_zeronans = curr_term_old;
%         curr_term_old_zeronans(nan_old_domain_ind) = 0;
%         currdomain_mask = zeros(size_array_ij);
%         currdomain_mask(nan_old_domain_ind) = 1;
%         currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
%         currdomain_mask(nan_ind) = 0;
%         curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
%         curr_term(curr_term == 0) = NaN;
%         corrcoef_at_optlag_input_adv_tend_T_reg = curr_term;
%         
%         curr_term_subset = curr_opt_lag_input_adv_tend_T_reg;
%         curr_term_zeronans = zeros(size_array_ij);
%         curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
%         nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1) | (curr_term_zeronans == 0));
%         curr_term_zeronans(nan_ind) = 0;
%         curr_term_old = opt_lag_input_adv_tend_T_reg;
%         nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
%         curr_term_old_zeronans = curr_term_old;
%         curr_term_old_zeronans(nan_old_domain_ind) = 0;
%         currdomain_mask = zeros(size_array_ij);
%         currdomain_mask(nan_old_domain_ind) = 1;
%         currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
%         currdomain_mask(nan_ind) = 0;
%         curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
%         curr_term(curr_term == 0) = NaN;
%         opt_lag_input_adv_tend_T_reg = curr_term;
        
        curr_term_subset = curr_corrcoef_at_optlag_input_adv_tend_vel_reg_T_reg;
        curr_term_zeronans = NaN(size_array_ij);
        curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
        curr_term_zero_ind = find(curr_term_zeronans == 0);
%         nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1) | (curr_term_zeronans == 0));
        nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
        curr_term_zeronans(nan_ind) = 0;
        curr_term_old = corrcoef_at_optlag_input_adv_tend_vel_reg_T_reg;
        curr_term_old_zero_ind = find(curr_term_old == 0);
        nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
        curr_term_old_zeronans = curr_term_old;
        curr_term_old_zeronans(nan_old_domain_ind) = 0;
        currdomain_mask = zeros(size_array_ij);
        currdomain_mask(nan_old_domain_ind) = 1;
        currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
        currdomain_mask(nan_ind) = 0;
        curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
        curr_term(curr_term == 0) = NaN;
        curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
        corrcoef_at_optlag_input_adv_tend_vel_reg_T_reg = curr_term;
        
        curr_term_subset = curr_opt_lag_input_adv_tend_vel_reg_T_reg;
        curr_term_zeronans = NaN(size_array_ij);
        curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
        curr_term_zero_ind = find(curr_term_zeronans == 0);
        nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
        curr_term_zeronans(nan_ind) = 0;
        curr_term_old = opt_lag_input_adv_tend_vel_reg_T_reg;
        curr_term_old_zero_ind = find(curr_term_old == 0);
        nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
        curr_term_old_zeronans = curr_term_old;
        curr_term_old_zeronans(nan_old_domain_ind) = 0;
        currdomain_mask = zeros(size_array_ij);
        currdomain_mask(nan_old_domain_ind) = 1;
        currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
        currdomain_mask(nan_ind) = 0;
        curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
        curr_term(curr_term == 0) = NaN;
        curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
        opt_lag_input_adv_tend_vel_reg_T_reg = curr_term;
%         save('temp_corr_opt_lag_vel_reg_T_reg_ws.mat','-v7.3')
        curr_term_subset = curr_corrcoef_at_optlag_input_adv_tend_vel_reg_T_noreg;
        curr_term_zeronans = NaN(size_array_ij);
        curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
        curr_term_zero_ind = find(curr_term_zeronans == 0);
        nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
        curr_term_zeronans(nan_ind) = 0;
        curr_term_old = corrcoef_at_optlag_input_adv_tend_vel_reg_T_noreg;
        curr_term_old_zero_ind = find(curr_term_old == 0);
        nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
        curr_term_old_zeronans = curr_term_old;
        curr_term_old_zeronans(nan_old_domain_ind) = 0;
        currdomain_mask = zeros(size_array_ij);
        currdomain_mask(nan_old_domain_ind) = 1;
        currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
        currdomain_mask(nan_ind) = 0;
        curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
        curr_term(curr_term == 0) = NaN;
        curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
        corrcoef_at_optlag_input_adv_tend_vel_reg_T_noreg = curr_term;
        
        curr_term_subset = curr_opt_lag_input_adv_tend_vel_reg_T_noreg;
        curr_term_zeronans = NaN(size_array_ij);
        curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
        curr_term_zero_ind = find(curr_term_zeronans == 0);
        nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
        curr_term_zeronans(nan_ind) = 0;
        curr_term_old = opt_lag_input_adv_tend_vel_reg_T_noreg;
        curr_term_old_zero_ind = find(curr_term_old == 0);
        nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
        curr_term_old_zeronans = curr_term_old;
        curr_term_old_zeronans(nan_old_domain_ind) = 0;
        currdomain_mask = zeros(size_array_ij);
        currdomain_mask(nan_old_domain_ind) = 1;
        currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
        currdomain_mask(nan_ind) = 0;
        curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
        curr_term(curr_term == 0) = NaN;
        curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
        opt_lag_input_adv_tend_vel_reg_T_noreg = curr_term;
        
        curr_term_subset = curr_corrcoef_at_optlag_input_adv_tend_vel_noreg_T_reg;
        curr_term_zeronans = NaN(size_array_ij);
        curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
        curr_term_zero_ind = find(curr_term_zeronans == 0);
        nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
        curr_term_zeronans(nan_ind) = 0;
        curr_term_old = corrcoef_at_optlag_input_adv_tend_vel_noreg_T_reg;
        curr_term_old_zero_ind = find(curr_term_old == 0);
        nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
        curr_term_old_zeronans = curr_term_old;
        curr_term_old_zeronans(nan_old_domain_ind) = 0;
        currdomain_mask = zeros(size_array_ij);
        currdomain_mask(nan_old_domain_ind) = 1;
        currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
        currdomain_mask(nan_ind) = 0;
        curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
        curr_term(curr_term == 0) = NaN;
        curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
        corrcoef_at_optlag_input_adv_tend_vel_noreg_T_reg = curr_term;
        
        curr_term_subset = curr_opt_lag_input_adv_tend_vel_noreg_T_reg;
        curr_term_zeronans = NaN(size_array_ij);
        curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
        curr_term_zero_ind = find(curr_term_zeronans == 0);
        nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
        curr_term_zeronans(nan_ind) = 0;
        curr_term_old = opt_lag_input_adv_tend_vel_noreg_T_reg;
        curr_term_old_zero_ind = find(curr_term_old == 0);
        nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
        curr_term_old_zeronans = curr_term_old;
        curr_term_old_zeronans(nan_old_domain_ind) = 0;
        currdomain_mask = zeros(size_array_ij);
        currdomain_mask(nan_old_domain_ind) = 1;
        currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
        currdomain_mask(nan_ind) = 0;
        curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
        curr_term(curr_term == 0) = NaN;
        curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
        opt_lag_input_adv_tend_vel_noreg_T_reg = curr_term;
%         save('temp_corr_opt_lag_vel_noreg_T_reg_ws.mat','-v7.3')
        curr_term_subset = curr_corrcoef_at_optlag_input_adv_tend_total;
        curr_term_zeronans = NaN(size_array_ij);
        curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
        curr_term_zero_ind = find(curr_term_zeronans == 0);
        nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
        curr_term_zeronans(nan_ind) = 0;
        curr_term_old = corrcoef_at_optlag_input_adv_tend_total;
        curr_term_old_zero_ind = find(curr_term_old == 0);
        nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
        curr_term_old_zeronans = curr_term_old;
        curr_term_old_zeronans(nan_old_domain_ind) = 0;
        currdomain_mask = zeros(size_array_ij);
        currdomain_mask(nan_old_domain_ind) = 1;
        currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
        currdomain_mask(nan_ind) = 0;
        curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
        curr_term(curr_term == 0) = NaN;
        curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
        corrcoef_at_optlag_input_adv_tend_total = curr_term;
        
        curr_term_subset = curr_opt_lag_input_adv_tend_total;
        curr_term_zeronans = NaN(size_array_ij);
        curr_term_zeronans(curr_x_ind,curr_y_ind) = curr_term_subset;
        curr_term_zero_ind = find(curr_term_zeronans == 0);
        nan_ind = find((isnan(curr_term_zeronans) == 1) | (isinf(curr_term_zeronans) == 1));
        curr_term_zeronans(nan_ind) = 0;
        curr_term_old = opt_lag_input_adv_tend_total;
        curr_term_old_zero_ind = find(curr_term_old == 0);
        nan_old_domain_ind = find((isnan(curr_term_old) == 1) | (isinf(curr_term_old) == 1));
        curr_term_old_zeronans = curr_term_old;
        curr_term_old_zeronans(nan_old_domain_ind) = 0;
        currdomain_mask = zeros(size_array_ij);
        currdomain_mask(nan_old_domain_ind) = 1;
        currdomain_mask(curr_x_ind,curr_y_ind) = ones(length(curr_x_ind),length(curr_y_ind));
        currdomain_mask(nan_ind) = 0;
        curr_term = ((1 - currdomain_mask).*curr_term_old_zeronans) + (currdomain_mask.*curr_term_zeronans);
        curr_term(curr_term == 0) = NaN;
        curr_term(union(curr_term_old_zero_ind,curr_term_zero_ind)) = 0;
        opt_lag_input_adv_tend_total = curr_term;
        
        disp(['Finished computations: i_f = ',num2str(i_f),', j_f = ',num2str(j_f)])
        
    end
end


clear reg_avg_text_specifier_new reg_avg_file_specifier_new

% save .mat file
save(['temp_corr_ws_',reg_avg_file_specifier,'.mat'],'-v7.3')
% % load .mat file
% load(['temp_corr_ws_',reg_avg_file_specifier,'.mat'])








% plot optimal correlations and lags

try
    reg_avg_text_specifier = reg_avg_text_specifier_new;
    reg_avg_file_specifier = reg_avg_file_specifier_new;
end

tlon_midlon = tlon - ([diff(tlon(1:2,:),1,1); diff(tlon,1,1)]/2);
tlon_pcolor_plot = tlon_midlon - ([diff(tlon_midlon(:,1:2),1,2) diff(tlon_midlon,1,2)]/2);
tlat_midlat = tlat - ([diff(tlat(:,1:2),1,2) diff(tlat,1,2)]/2);
tlat_pcolor_plot = tlat_midlat - ([diff(tlat_midlat(1:2,:),1,1); diff(tlat_midlat,1,1)]/2);


plot_grid_spacing = 5;   % spacing (in grid cells) of arrows

plot_grid_start_ind = floor(plot_grid_spacing/2);
plot_grid_i_ind = (plot_grid_start_ind:plot_grid_spacing:size_array_ij(1))';
plot_grid_j_ind = (plot_grid_start_ind:plot_grid_spacing:size_array_ij(2))';



% plot maps

curr_term_array = corrcoef_at_optlag_input_vel_vert_mean_inlayer;

cmap = flipdim(hot(20),1);
c_levels = (0:0.05:1)';

fig1 = figure(1);
fig1_paper_pos = get(fig1,'PaperPosition');
fig1_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig1_paper_pos(3);
fig1_paper_pos(3:4) = 2*fig1_paper_pos(3:4);
set(fig1,'PaperPosition',fig1_paper_pos,'PaperSize',[22 17])
colormap(cmap)
h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',curr_term_array');
%     view(0,90)
caxis([min(c_levels) max(c_levels)])
shading flat
set(h,'edgecolor','none')
set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
daspect([1 cosd(mean([latsouth latnorth])) 1])
set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
print(gcf,'curr_term_array_plot_temp.png','-dpng','-r300')
close(fig1)


% get contour plot and overlay land mask

rgb_array = imread('curr_term_array_plot_temp.png');
rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);

delete('curr_term_array_plot_temp.png')


size_rgb_array = size(rgb_array);
landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);

% convert black undefined areas in SSH field to white shading
black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);


rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);


fig2 = figure(2);
fig2_paper_pos = get(fig2,'PaperPosition');
set(fig2,'PaperPosition',fig2_paper_pos + [0 (-1.0) 0 2.0])
x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
daspect([1 cosd(mean([latsouth latnorth])) 1])
hold on
scale_factor = 0.5/0.7;
% good_ind = find(isnan(uvel_vert_mean_inlayer_avg) == 0);
max_arrow_dim = max([max(max(abs(cosd(opt_angle_input_vel_vert_mean_inlayer(plot_grid_i_ind,plot_grid_j_ind)).*corrcoef_at_optlag_input_vel_vert_mean_inlayer(plot_grid_i_ind,plot_grid_j_ind)))) max(max(abs(sind(opt_angle_input_vel_vert_mean_inlayer(plot_grid_i_ind,plot_grid_j_ind)).*corrcoef_at_optlag_input_vel_vert_mean_inlayer(plot_grid_i_ind,plot_grid_j_ind))))]);
quiv_scale = scale_factor/(grid_res*plot_grid_spacing/max_arrow_dim);
quiv = quiver(tlon_pcolor_plot(plot_grid_i_ind,plot_grid_j_ind)',tlat_pcolor_plot(plot_grid_i_ind,plot_grid_j_ind)',(cosd(opt_angle_input_vel_vert_mean_inlayer(plot_grid_i_ind,plot_grid_j_ind)).*corrcoef_at_optlag_input_vel_vert_mean_inlayer(plot_grid_i_ind,plot_grid_j_ind))',(sind(opt_angle_input_vel_vert_mean_inlayer(plot_grid_i_ind,plot_grid_j_ind)).*corrcoef_at_optlag_input_vel_vert_mean_inlayer(plot_grid_i_ind,plot_grid_j_ind))',quiv_scale);
set(quiv,'Color','k','LineWidth',1.5)
% % scale arrow
% scale_arrow_mag = 0.5;
% rectangle('Position',[min(min(tlon_pcolor_plot)) + 0.5,min(min(tlat_pcolor_plot)) + 0.4,2.4,0.75],'FaceColor',[1 1 1])
% line([(min(min(tlon_pcolor_plot)) + 0.7) (min(min(tlon_pcolor_plot)) + 0.7 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.72) (min(min(tlat_pcolor_plot)) + 0.72)],'LineWidth',1.5,'Color','k')
% line([(min(min(tlon_pcolor_plot)) + 0.7 + (0.7*scale_arrow_mag*scale_factor)) (min(min(tlon_pcolor_plot)) + 0.7 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.72 + (0.15*scale_arrow_mag*scale_factor)) (min(min(tlat_pcolor_plot)) + 0.72)],'LineWidth',1.5,'Color','k')
% line([(min(min(tlon_pcolor_plot)) + 0.7 + (0.7*scale_arrow_mag*scale_factor)) (min(min(tlon_pcolor_plot)) + 0.7 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.72 - (0.15*scale_arrow_mag*scale_factor)) (min(min(tlat_pcolor_plot)) + 0.72)],'LineWidth',1.5,'Color','k')
% text(min(min(tlon_pcolor_plot)) + 0.9 + (scale_arrow_mag*scale_factor),min(min(tlat_pcolor_plot)) + 0.76,['r = ',num2str(scale_arrow_mag)],'FontSize',10)
hold off
% set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',16)
set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
hold on
line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
%     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
hold off
% xlabel('Longitude','FontSize',16)
% ylabel('Latitude','FontSize',16)
xlabel('Longitude','FontSize',20)
ylabel('Latitude','FontSize',20)
% set(gca,'Position',[0.1 0.18 0.8 0.85])
title({'Correlation coefficient with vertically-averaged velocities,'; reg_avg_text_specifier},'FontSize',12,'Interpreter','none')
colormap(cmap)
cbar = colorbar('location','southoutside');
cbar_labels = cell(1,length(c_levels));
if length(c_levels) < 10
    for n_label = 1:length(c_levels)
        cbar_labels{n_label} = num2str(c_levels(n_label));
    end
else
    for n_label = 1:length(c_levels)
        if mod(n_label,2) == 1
            cbar_labels{n_label} = num2str(c_levels(n_label));
        else
            cbar_labels{n_label} = '';
        end
    end
end
cbar_pos = get(cbar,'Position');
% set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',16)
% set(get(cbar,'xlabel'),'String','Correlation coefficient','FontSize',16)
set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
set(get(cbar,'xlabel'),'String','Correlation coefficient','FontSize',20)

saveas(fig2,['Corr_coeff_vel_vert_mean_',reg_avg_file_specifier,'.pdf'])
close(fig2)



curr_term_array = opt_lag_input_vel_vert_mean_inlayer;


% cmap = 0.85*hot(7);
hot_8 = hot(8);
% cmap = 0.85*(hot_8([(1:1:4)'; (6:1:8)'],:));
% c_levels = ((-32.5):5:2.5)';
% cmap = 0.85*(hot_8([(1:1:4)'; (6:1:7)'],:));
% c_levels = ((-32.5):5:(-2.5))';
cmap = 0.85*(hot_8([(1:1:4)'; 6],:));
c_levels = ((-32.5):5:(-7.5))';

fig3 = figure(3);
fig3_paper_pos = get(fig3,'PaperPosition');
fig3_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig3_paper_pos(3);
fig3_paper_pos(3:4) = 2*fig3_paper_pos(3:4);
set(fig3,'PaperPosition',fig3_paper_pos,'PaperSize',[22 17])
colormap(cmap)
h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',curr_term_array');
%     view(0,90)
caxis([min(c_levels) max(c_levels)])
shading flat
set(h,'edgecolor','none')
set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
daspect([1 cosd(mean([latsouth latnorth])) 1])
set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
print(gcf,'curr_term_array_plot_temp.png','-dpng','-r300')
close(fig3)


% get contour plot and overlay land mask

rgb_array = imread('curr_term_array_plot_temp.png');
rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);

delete('curr_term_array_plot_temp.png')


size_rgb_array = size(rgb_array);
landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);

% convert black undefined areas in SSH field to white shading
black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);


rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);


fig4 = figure(4);
fig4_paper_pos = get(fig4,'PaperPosition');
set(fig4,'PaperPosition',fig4_paper_pos + [0 (-1.0) 0 2.0])
x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
daspect([1 cosd(mean([latsouth latnorth])) 1])
hold on
scale_factor = 0.5/0.7;
% good_ind = find(isnan(uvel_vert_mean_inlayer_avg) == 0);
max_arrow_dim = max([max(max(abs(cosd(opt_angle_input_vel_vert_mean_inlayer(plot_grid_i_ind,plot_grid_j_ind)).*corrcoef_at_optlag_input_vel_vert_mean_inlayer(plot_grid_i_ind,plot_grid_j_ind)))) max(max(abs(sind(opt_angle_input_vel_vert_mean_inlayer(plot_grid_i_ind,plot_grid_j_ind)).*corrcoef_at_optlag_input_vel_vert_mean_inlayer(plot_grid_i_ind,plot_grid_j_ind))))]);
quiv_scale = scale_factor/(grid_res*plot_grid_spacing/max_arrow_dim);
quiv = quiver(tlon_pcolor_plot(plot_grid_i_ind,plot_grid_j_ind)',tlat_pcolor_plot(plot_grid_i_ind,plot_grid_j_ind)',(cosd(opt_angle_input_vel_vert_mean_inlayer(plot_grid_i_ind,plot_grid_j_ind)).*corrcoef_at_optlag_input_vel_vert_mean_inlayer(plot_grid_i_ind,plot_grid_j_ind))',(sind(opt_angle_input_vel_vert_mean_inlayer(plot_grid_i_ind,plot_grid_j_ind)).*corrcoef_at_optlag_input_vel_vert_mean_inlayer(plot_grid_i_ind,plot_grid_j_ind))',quiv_scale);
set(quiv,'Color','k','LineWidth',1.5)
% % scale arrow
% scale_arrow_mag = 0.5;
% rectangle('Position',[min(min(tlon_pcolor_plot)) + 0.5,min(min(tlat_pcolor_plot)) + 0.4,2.4,0.75],'FaceColor',[1 1 1])
% line([(min(min(tlon_pcolor_plot)) + 0.7) (min(min(tlon_pcolor_plot)) + 0.7 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.72) (min(min(tlat_pcolor_plot)) + 0.72)],'LineWidth',1.5,'Color','k')
% line([(min(min(tlon_pcolor_plot)) + 0.7 + (0.7*scale_arrow_mag*scale_factor)) (min(min(tlon_pcolor_plot)) + 0.7 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.72 + (0.15*scale_arrow_mag*scale_factor)) (min(min(tlat_pcolor_plot)) + 0.72)],'LineWidth',1.5,'Color','k')
% line([(min(min(tlon_pcolor_plot)) + 0.7 + (0.7*scale_arrow_mag*scale_factor)) (min(min(tlon_pcolor_plot)) + 0.7 + (scale_arrow_mag*scale_factor))],[(min(min(tlat_pcolor_plot)) + 0.72 - (0.15*scale_arrow_mag*scale_factor)) (min(min(tlat_pcolor_plot)) + 0.72)],'LineWidth',1.5,'Color','k')
% text(min(min(tlon_pcolor_plot)) + 0.9 + (scale_arrow_mag*scale_factor),min(min(tlat_pcolor_plot)) + 0.76,['r = ',num2str(scale_arrow_mag)],'FontSize',10)
hold off
set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
hold on
line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
%     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
hold off
xlabel('Longitude','FontSize',20)
ylabel('Latitude','FontSize',20)
% set(gca,'Position',[0.1 0.18 0.8 0.85])
title({'Optimal leads for vertically-averaged velocity correlations,'; reg_avg_text_specifier},'FontSize',12,'Interpreter','none')
colormap(cmap)
cbar = colorbar('location','southoutside');
% cbar_labels = cell(1,length(c_levels));
% if length(c_levels) < 10
%     for n_label = 1:length(c_levels)
%         cbar_labels{n_label} = num2str(c_levels(n_label));
%     end
% else
%     for n_label = 1:length(c_levels)
%         if mod(n_label,2) == 1
%             cbar_labels{n_label} = num2str(c_levels(n_label));
%         else
%             cbar_labels{n_label} = '';
%         end
%     end
% end
cbar_labels = {'30' '25' '20' '15' '10' '5' '0'};
cbar_pos = get(cbar,'Position');
set(cbar,'xtick',(0:1:(length(cmap) - 1)),'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
set(get(cbar,'xlabel'),'String','Lead (days)','FontSize',20)

saveas(fig4,['Opt_lag_vel_vert_mean_',reg_avg_file_specifier,'.pdf'])
close(fig4)






% % curr_term_array = corrcoef_at_optlag_input_adv_tend_vel_reg;
% % 
% % 
% % cmap = bcyr(20);
% % c_levels = ((-1):0.1:1)';
% % 
% % fig5 = figure(5);
% % fig5_paper_pos = get(fig5,'PaperPosition');
% % fig5_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig5_paper_pos(3);
% % fig5_paper_pos(3:4) = 2*fig5_paper_pos(3:4);
% % set(fig5,'PaperPosition',fig5_paper_pos,'PaperSize',[22 17])
% % colormap(cmap)
% % h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',curr_term_array');
% % caxis([min(c_levels) max(c_levels)])
% % shading flat
% % set(h,'edgecolor','none')
% % set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% % print(gcf,'curr_term_array_reg_plot_temp.png','-dpng','-r300')
% % close(fig5)
% % 
% % 
% % % get contour plot and overlay land mask
% % 
% % rgb_array = imread('curr_term_array_reg_plot_temp.png');
% % rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% % 
% % delete('curr_term_array_reg_plot_temp.png')
% % 
% % 
% % size_rgb_array = size(rgb_array);
% % landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% % rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% % 
% % % convert black undefined areas in SSH field to white shading
% % black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% % rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% % 
% % 
% % rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% % rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% % 
% % 
% % fig6 = figure(6);
% % x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% % y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% % h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',16)
% % hold on
% % line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% % %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% % hold off
% % xlabel('Longitude','FontSize',16)
% % ylabel('Latitude','FontSize',16)
% % % set(gca,'Position',[0.1 0.18 0.8 0.85])
% % title({'Optimum correlation coefficients for velocity regression correlations,'; reg_avg_text_specifier},'FontSize',12,'Interpreter','none')
% % colormap(cmap)
% % cbar = colorbar('location','southoutside');
% % cbar_labels = cell(1,length(c_levels));
% % if length(c_levels) < 10
% %     for n_label = 1:length(c_levels)
% %         cbar_labels{n_label} = num2str(c_levels(n_label));
% %     end
% % else
% %     for n_label = 1:length(c_levels)
% %         if mod(n_label,2) == 1
% %             cbar_labels{n_label} = num2str(c_levels(n_label));
% %         else
% %             cbar_labels{n_label} = '';
% %         end
% %     end
% % end
% % set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',16)
% % set(get(cbar,'xlabel'),'String','Correlation coefficient','FontSize',16)
% % 
% % saveas(fig6,['Corr_coeff_adv_tend_vel_reg_',reg_avg_file_specifier,'.pdf'])
% % close(fig6)
% % 
% % 
% % 
% % curr_term_array = opt_lag_input_adv_tend_vel_reg;
% % 
% % 
% % cmap = 0.85*hot(7);
% % c_levels = ((-32.5):5:2.5)';
% % 
% % fig7 = figure(7);
% % fig7_paper_pos = get(fig7,'PaperPosition');
% % fig7_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig7_paper_pos(3);
% % fig7_paper_pos(3:4) = 2*fig7_paper_pos(3:4);
% % set(fig7,'PaperPosition',fig7_paper_pos,'PaperSize',[22 17])
% % colormap(cmap)
% % h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',curr_term_array');
% % caxis([min(c_levels) max(c_levels)])
% % shading flat
% % set(h,'edgecolor','none')
% % set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% % print(gcf,'curr_term_array_reg_plot_temp.png','-dpng','-r300')
% % close(fig7)
% % 
% % 
% % % get contour plot and overlay land mask
% % 
% % rgb_array = imread('curr_term_array_reg_plot_temp.png');
% % rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% % 
% % delete('curr_term_array_reg_plot_temp.png')
% % 
% % 
% % size_rgb_array = size(rgb_array);
% % landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% % rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% % 
% % % convert black undefined areas in SSH field to white shading
% % black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% % rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% % 
% % 
% % rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% % rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% % 
% % 
% % fig8 = figure(8);
% % x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% % y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% % h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',16)
% % hold on
% % line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% % %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% % hold off
% % xlabel('Longitude','FontSize',16)
% % ylabel('Latitude','FontSize',16)
% % % set(gca,'Position',[0.1 0.18 0.8 0.85])
% % title({'Optimal leads for velocity regression correlations,'; reg_avg_text_specifier},'FontSize',12,'Interpreter','none')
% % colormap(cmap)
% % cbar = colorbar('location','southoutside');
% % % cbar_labels = cell(1,length(c_levels));
% % % if length(c_levels) < 10
% % %     for n_label = 1:length(c_levels)
% % %         cbar_labels{n_label} = num2str(c_levels(n_label));
% % %     end
% % % else
% % %     for n_label = 1:length(c_levels)
% % %         if mod(n_label,2) == 1
% % %             cbar_labels{n_label} = num2str(c_levels(n_label));
% % %         else
% % %             cbar_labels{n_label} = '';
% % %         end
% % %     end
% % % end
% % cbar_labels = {'30' '25' '20' '15' '10' '5' '0'};
% % set(cbar,'xtick',(0:1:(length(cmap) - 1)),'xticklabel',cbar_labels,'FontSize',16)
% % set(get(cbar,'xlabel'),'String','Lead (days)','FontSize',16)
% % 
% % saveas(fig8,['Opt_lag_adv_tend_vel_reg_',reg_avg_file_specifier,'.pdf'])
% % close(fig8)
% % 
% % 
% % 
% % 
% % 
% % curr_term_array = corrcoef_at_optlag_input_adv_tend_T_reg;
% % 
% % 
% % cmap = bcyr(20);
% % c_levels = ((-1):0.1:1)';
% % 
% % fig9 = figure(9);
% % fig9_paper_pos = get(fig9,'PaperPosition');
% % fig9_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig9_paper_pos(3);
% % fig9_paper_pos(3:4) = 2*fig9_paper_pos(3:4);
% % set(fig9,'PaperPosition',fig9_paper_pos,'PaperSize',[22 17])
% % colormap(cmap)
% % h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',curr_term_array');
% % caxis([min(c_levels) max(c_levels)])
% % shading flat
% % set(h,'edgecolor','none')
% % set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% % print(gcf,'curr_term_array_reg_plot_temp.png','-dpng','-r300')
% % close(fig9)
% % 
% % 
% % % get contour plot and overlay land mask
% % 
% % rgb_array = imread('curr_term_array_reg_plot_temp.png');
% % rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% % 
% % delete('curr_term_array_reg_plot_temp.png')
% % 
% % 
% % size_rgb_array = size(rgb_array);
% % landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% % rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% % 
% % % convert black undefined areas in SSH field to white shading
% % black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% % rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% % 
% % 
% % rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% % rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% % 
% % 
% % fig10 = figure(10);
% % x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% % y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% % h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',16)
% % hold on
% % line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% % %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% % hold off
% % xlabel('Longitude','FontSize',16)
% % ylabel('Latitude','FontSize',16)
% % % set(gca,'Position',[0.1 0.18 0.8 0.85])
% % title({'Optimum correlation coefficients for temperature regression correlations,'; reg_avg_text_specifier},'FontSize',12,'Interpreter','none')
% % colormap(cmap)
% % cbar = colorbar('location','southoutside');
% % cbar_labels = cell(1,length(c_levels));
% % if length(c_levels) < 10
% %     for n_label = 1:length(c_levels)
% %         cbar_labels{n_label} = num2str(c_levels(n_label));
% %     end
% % else
% %     for n_label = 1:length(c_levels)
% %         if mod(n_label,2) == 1
% %             cbar_labels{n_label} = num2str(c_levels(n_label));
% %         else
% %             cbar_labels{n_label} = '';
% %         end
% %     end
% % end
% % set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',16)
% % set(get(cbar,'xlabel'),'String','Correlation coefficient','FontSize',16)
% % 
% % saveas(fig10,['Corr_coeff_adv_tend_T_reg_',reg_avg_file_specifier,'.pdf'])
% % close(fig10)
% % 
% % 
% % 
% % curr_term_array = opt_lag_input_adv_tend_T_reg;
% % 
% % 
% % cmap = 0.85*hot(7);
% % c_levels = ((-32.5):5:2.5)';
% % 
% % fig11 = figure(11);
% % fig11_paper_pos = get(fig11,'PaperPosition');
% % fig11_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig11_paper_pos(3);
% % fig11_paper_pos(3:4) = 2*fig11_paper_pos(3:4);
% % set(fig11,'PaperPosition',fig11_paper_pos,'PaperSize',[22 17])
% % colormap(cmap)
% % h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',curr_term_array');
% % caxis([min(c_levels) max(c_levels)])
% % shading flat
% % set(h,'edgecolor','none')
% % set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% % print(gcf,'curr_term_array_reg_plot_temp.png','-dpng','-r300')
% % close(fig11)
% % 
% % 
% % % get contour plot and overlay land mask
% % 
% % rgb_array = imread('curr_term_array_reg_plot_temp.png');
% % rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% % 
% % delete('curr_term_array_reg_plot_temp.png')
% % 
% % 
% % size_rgb_array = size(rgb_array);
% % landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% % rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% % 
% % % convert black undefined areas in SSH field to white shading
% % black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% % rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% % 
% % 
% % rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% % rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% % 
% % 
% % fig12 = figure(12);
% % x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% % y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% % h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% % daspect([1 cosd(mean([latsouth latnorth])) 1])
% % set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',16)
% % hold on
% % line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% % %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% % hold off
% % xlabel('Longitude','FontSize',16)
% % ylabel('Latitude','FontSize',16)
% % % set(gca,'Position',[0.1 0.18 0.8 0.85])
% % title({'Optimal leads for temperature regression correlations,'; reg_avg_text_specifier},'FontSize',12,'Interpreter','none')
% % colormap(cmap)
% % cbar = colorbar('location','southoutside');
% % % cbar_labels = cell(1,length(c_levels));
% % % if length(c_levels) < 10
% % %     for n_label = 1:length(c_levels)
% % %         cbar_labels{n_label} = num2str(c_levels(n_label));
% % %     end
% % % else
% % %     for n_label = 1:length(c_levels)
% % %         if mod(n_label,2) == 1
% % %             cbar_labels{n_label} = num2str(c_levels(n_label));
% % %         else
% % %             cbar_labels{n_label} = '';
% % %         end
% % %     end
% % % end
% % cbar_labels = {'30' '25' '20' '15' '10' '5' '0'};
% % set(cbar,'xtick',(0:1:(length(cmap) - 1)),'xticklabel',cbar_labels,'FontSize',16)
% % set(get(cbar,'xlabel'),'String','Lead (days)','FontSize',16)
% % 
% % saveas(fig12,['Opt_lag_adv_tend_T_reg_',reg_avg_file_specifier,'.pdf'])
% % close(fig12)
% 
% 
% 
% 
% 
% curr_term_array = corrcoef_at_optlag_input_adv_tend_vel_reg_T_reg;
% 
% 
% cmap = bcyr(20);
% c_levels = ((-1):0.1:1)';
% 
% fig5 = figure(5);
% fig5_paper_pos = get(fig5,'PaperPosition');
% fig5_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig5_paper_pos(3);
% fig5_paper_pos(3:4) = 2*fig5_paper_pos(3:4);
% set(fig5,'PaperPosition',fig5_paper_pos,'PaperSize',[22 17])
% colormap(cmap)
% h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',curr_term_array');
% caxis([min(c_levels) max(c_levels)])
% shading flat
% set(h,'edgecolor','none')
% set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% daspect([1 cosd(mean([latsouth latnorth])) 1])
% set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% print(gcf,'curr_term_array_reg_plot_temp.png','-dpng','-r300')
% close(fig5)
% 
% 
% % get contour plot and overlay land mask
% 
% rgb_array = imread('curr_term_array_reg_plot_temp.png');
% rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% 
% delete('curr_term_array_reg_plot_temp.png')
% 
% 
% size_rgb_array = size(rgb_array);
% landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% 
% % convert black undefined areas in SSH field to white shading
% black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% 
% 
% rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% 
% 
% fig6 = figure(6);
% fig6_paper_pos = get(fig6,'PaperPosition');
% set(fig6,'PaperPosition',fig6_paper_pos + [0 (-1.0) 0 2.0])
% x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% daspect([1 cosd(mean([latsouth latnorth])) 1])
% set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% hold on
% line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% hold off
% xlabel('Longitude','FontSize',20)
% ylabel('Latitude','FontSize',20)
% % set(gca,'Position',[0.1 0.18 0.8 0.85])
% title({'Optimum correlation coefficients for {v_R}{T_R} correlations,'; reg_avg_text_specifier},'FontSize',12,'Interpreter','none')
% colormap(cmap)
% cbar = colorbar('location','southoutside');
% cbar_labels = cell(1,length(c_levels));
% if length(c_levels) < 10
%     for n_label = 1:length(c_levels)
%         cbar_labels{n_label} = num2str(c_levels(n_label));
%     end
% else
%     for n_label = 1:length(c_levels)
%         if mod(n_label,2) == 1
%             cbar_labels{n_label} = num2str(c_levels(n_label));
%         else
%             cbar_labels{n_label} = '';
%         end
%     end
% end
% cbar_pos = get(cbar,'Position');
% set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% set(get(cbar,'xlabel'),'String','Correlation coefficient','FontSize',20)
% 
% saveas(fig6,['Corr_coeff_adv_tend_vel_reg_T_reg_',reg_avg_file_specifier,'.pdf'])
% close(fig6)
% 
% 
% 
% curr_term_array = opt_lag_input_adv_tend_vel_reg_T_reg;
% 
% hot_8 = hot(8);
% cmap = 0.85*(hot_8([(1:1:4)'; (6:1:8)'],:));
% c_levels = ((-32.5):5:2.5)';
% 
% fig7 = figure(7);
% fig7_paper_pos = get(fig7,'PaperPosition');
% fig7_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig7_paper_pos(3);
% fig7_paper_pos(3:4) = 2*fig7_paper_pos(3:4);
% set(fig7,'PaperPosition',fig7_paper_pos,'PaperSize',[22 17])
% colormap(cmap)
% h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',curr_term_array');
% caxis([min(c_levels) max(c_levels)])
% shading flat
% set(h,'edgecolor','none')
% set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% daspect([1 cosd(mean([latsouth latnorth])) 1])
% set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% print(gcf,'curr_term_array_reg_plot_temp.png','-dpng','-r300')
% close(fig7)
% 
% 
% % get contour plot and overlay land mask
% 
% rgb_array = imread('curr_term_array_reg_plot_temp.png');
% rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% 
% delete('curr_term_array_reg_plot_temp.png')
% 
% 
% size_rgb_array = size(rgb_array);
% landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% 
% % convert black undefined areas in SSH field to white shading
% black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% 
% 
% rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% 
% 
% fig8 = figure(8);
% fig8_paper_pos = get(fig8,'PaperPosition');
% set(fig8,'PaperPosition',fig8_paper_pos + [0 (-1.0) 0 2.0])
% x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% daspect([1 cosd(mean([latsouth latnorth])) 1])
% set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% hold on
% line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% hold off
% xlabel('Longitude','FontSize',20)
% ylabel('Latitude','FontSize',20)
% % set(gca,'Position',[0.1 0.18 0.8 0.85])
% title({'Optimal leads for {v_R}{T_R} correlations,'; reg_avg_text_specifier},'FontSize',12,'Interpreter','none')
% colormap(cmap)
% cbar = colorbar('location','southoutside');
% % cbar_labels = cell(1,length(c_levels));
% % if length(c_levels) < 10
% %     for n_label = 1:length(c_levels)
% %         cbar_labels{n_label} = num2str(c_levels(n_label));
% %     end
% % else
% %     for n_label = 1:length(c_levels)
% %         if mod(n_label,2) == 1
% %             cbar_labels{n_label} = num2str(c_levels(n_label));
% %         else
% %             cbar_labels{n_label} = '';
% %         end
% %     end
% % end
% cbar_labels = {'30' '25' '20' '15' '10' '5' '0'};
% cbar_pos = get(cbar,'Position');
% set(cbar,'xtick',(0:1:(length(cmap) - 1)),'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% set(get(cbar,'xlabel'),'String','Lead (days)','FontSize',20)
% 
% saveas(fig8,['Opt_lag_adv_tend_vel_reg_T_reg_',reg_avg_file_specifier,'.pdf'])
% close(fig8)
% 
% 
% 
% 
% 
% curr_term_array = corrcoef_at_optlag_input_adv_tend_vel_reg_T_noreg;
% 
% 
% cmap = bcyr(20);
% c_levels = ((-1):0.1:1)';
% 
% fig9 = figure(9);
% fig9_paper_pos = get(fig9,'PaperPosition');
% fig9_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig9_paper_pos(3);
% fig9_paper_pos(3:4) = 2*fig9_paper_pos(3:4);
% set(fig9,'PaperPosition',fig9_paper_pos,'PaperSize',[22 17])
% colormap(cmap)
% h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',curr_term_array');
% caxis([min(c_levels) max(c_levels)])
% shading flat
% set(h,'edgecolor','none')
% set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% daspect([1 cosd(mean([latsouth latnorth])) 1])
% set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% print(gcf,'curr_term_array_reg_plot_temp.png','-dpng','-r300')
% close(fig9)
% 
% 
% % get contour plot and overlay land mask
% 
% rgb_array = imread('curr_term_array_reg_plot_temp.png');
% rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% 
% delete('curr_term_array_reg_plot_temp.png')
% 
% 
% size_rgb_array = size(rgb_array);
% landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% 
% % convert black undefined areas in SSH field to white shading
% black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% 
% 
% rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% 
% 
% fig10 = figure(10);
% fig10_paper_pos = get(fig10,'PaperPosition');
% set(fig10,'PaperPosition',fig10_paper_pos + [0 (-1.0) 0 2.0])
% x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% daspect([1 cosd(mean([latsouth latnorth])) 1])
% set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% hold on
% line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% hold off
% xlabel('Longitude','FontSize',20)
% ylabel('Latitude','FontSize',20)
% % set(gca,'Position',[0.1 0.18 0.8 0.85])
% title({'Optimum correlation coefficients for {v_R}{T_NR} correlations,'; reg_avg_text_specifier},'FontSize',12,'Interpreter','none')
% colormap(cmap)
% cbar = colorbar('location','southoutside');
% cbar_labels = cell(1,length(c_levels));
% if length(c_levels) < 10
%     for n_label = 1:length(c_levels)
%         cbar_labels{n_label} = num2str(c_levels(n_label));
%     end
% else
%     for n_label = 1:length(c_levels)
%         if mod(n_label,2) == 1
%             cbar_labels{n_label} = num2str(c_levels(n_label));
%         else
%             cbar_labels{n_label} = '';
%         end
%     end
% end
% cbar_pos = get(cbar,'Position');
% set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% set(get(cbar,'xlabel'),'String','Correlation coefficient','FontSize',20)
% 
% saveas(fig10,['Corr_coeff_adv_tend_vel_reg_T_noreg_',reg_avg_file_specifier,'.pdf'])
% close(fig10)
% 
% 
% 
% curr_term_array = opt_lag_input_adv_tend_vel_reg_T_noreg;
% 
% hot_8 = hot(8);
% cmap = 0.85*(hot_8([(1:1:4)'; (6:1:8)'],:));
% c_levels = ((-32.5):5:2.5)';
% 
% fig11 = figure(11);
% fig11_paper_pos = get(fig11,'PaperPosition');
% fig11_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig11_paper_pos(3);
% fig11_paper_pos(3:4) = 2*fig11_paper_pos(3:4);
% set(fig11,'PaperPosition',fig11_paper_pos,'PaperSize',[22 17])
% colormap(cmap)
% h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',curr_term_array');
% caxis([min(c_levels) max(c_levels)])
% shading flat
% set(h,'edgecolor','none')
% set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% daspect([1 cosd(mean([latsouth latnorth])) 1])
% set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% print(gcf,'curr_term_array_reg_plot_temp.png','-dpng','-r300')
% close(fig11)
% 
% 
% % get contour plot and overlay land mask
% 
% rgb_array = imread('curr_term_array_reg_plot_temp.png');
% rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% 
% delete('curr_term_array_reg_plot_temp.png')
% 
% 
% size_rgb_array = size(rgb_array);
% landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% 
% % convert black undefined areas in SSH field to white shading
% black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% 
% 
% rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% 
% 
% fig12 = figure(12);
% fig12_paper_pos = get(fig12,'PaperPosition');
% set(fig12,'PaperPosition',fig12_paper_pos + [0 (-1.0) 0 2.0])
% x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% daspect([1 cosd(mean([latsouth latnorth])) 1])
% set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% hold on
% line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% hold off
% xlabel('Longitude','FontSize',20)
% ylabel('Latitude','FontSize',20)
% % set(gca,'Position',[0.1 0.18 0.8 0.85])
% title({'Optimal leads for {v_R}{T_NR} correlations,'; reg_avg_text_specifier},'FontSize',12,'Interpreter','none')
% colormap(cmap)
% cbar = colorbar('location','southoutside');
% % cbar_labels = cell(1,length(c_levels));
% % if length(c_levels) < 10
% %     for n_label = 1:length(c_levels)
% %         cbar_labels{n_label} = num2str(c_levels(n_label));
% %     end
% % else
% %     for n_label = 1:length(c_levels)
% %         if mod(n_label,2) == 1
% %             cbar_labels{n_label} = num2str(c_levels(n_label));
% %         else
% %             cbar_labels{n_label} = '';
% %         end
% %     end
% % end
% cbar_labels = {'30' '25' '20' '15' '10' '5' '0'};
% cbar_pos = get(cbar,'Position');
% set(cbar,'xtick',(0:1:(length(cmap) - 1)),'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% set(get(cbar,'xlabel'),'String','Lead (days)','FontSize',20)
% 
% saveas(fig12,['Opt_lag_adv_tend_vel_reg_T_noreg_',reg_avg_file_specifier,'.pdf'])
% close(fig12)
% 
% 
% 
% 
% 
% curr_term_array = corrcoef_at_optlag_input_adv_tend_vel_noreg_T_reg;
% 
% 
% cmap = bcyr(20);
% c_levels = ((-1):0.1:1)';
% 
% fig13 = figure(13);
% fig13_paper_pos = get(fig13,'PaperPosition');
% fig13_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig13_paper_pos(3);
% fig13_paper_pos(3:4) = 2*fig13_paper_pos(3:4);
% set(fig13,'PaperPosition',fig13_paper_pos,'PaperSize',[22 17])
% colormap(cmap)
% h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',curr_term_array');
% caxis([min(c_levels) max(c_levels)])
% shading flat
% set(h,'edgecolor','none')
% set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% daspect([1 cosd(mean([latsouth latnorth])) 1])
% set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% print(gcf,'curr_term_array_reg_plot_temp.png','-dpng','-r300')
% close(fig13)
% 
% 
% % get contour plot and overlay land mask
% 
% rgb_array = imread('curr_term_array_reg_plot_temp.png');
% rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% 
% delete('curr_term_array_reg_plot_temp.png')
% 
% 
% size_rgb_array = size(rgb_array);
% landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% 
% % convert black undefined areas in SSH field to white shading
% black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% 
% 
% rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% 
% 
% fig14 = figure(14);
% fig14_paper_pos = get(fig14,'PaperPosition');
% set(fig14,'PaperPosition',fig14_paper_pos + [0 (-1.0) 0 2.0])
% x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% daspect([1 cosd(mean([latsouth latnorth])) 1])
% set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% hold on
% line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% hold off
% xlabel('Longitude','FontSize',20)
% ylabel('Latitude','FontSize',20)
% % set(gca,'Position',[0.1 0.18 0.8 0.85])
% title({'Optimum correlation coefficients for {v_NR}{T_R} correlations,'; reg_avg_text_specifier},'FontSize',12,'Interpreter','none')
% colormap(cmap)
% cbar = colorbar('location','southoutside');
% cbar_labels = cell(1,length(c_levels));
% if length(c_levels) < 10
%     for n_label = 1:length(c_levels)
%         cbar_labels{n_label} = num2str(c_levels(n_label));
%     end
% else
%     for n_label = 1:length(c_levels)
%         if mod(n_label,2) == 1
%             cbar_labels{n_label} = num2str(c_levels(n_label));
%         else
%             cbar_labels{n_label} = '';
%         end
%     end
% end
% cbar_pos = get(cbar,'Position');
% set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% set(get(cbar,'xlabel'),'String','Correlation coefficient','FontSize',20)
% 
% saveas(fig14,['Corr_coeff_adv_tend_vel_noreg_T_reg_',reg_avg_file_specifier,'.pdf'])
% close(fig14)
% 
% 
% 
% curr_term_array = opt_lag_input_adv_tend_vel_reg_T_reg;
% 
% hot_8 = hot(8);
% cmap = 0.85*(hot_8([(1:1:4)'; (6:1:8)'],:));
% c_levels = ((-32.5):5:2.5)';
% 
% fig15 = figure(15);
% fig15_paper_pos = get(fig15,'PaperPosition');
% fig15_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig15_paper_pos(3);
% fig15_paper_pos(3:4) = 2*fig15_paper_pos(3:4);
% set(fig15,'PaperPosition',fig15_paper_pos,'PaperSize',[22 17])
% colormap(cmap)
% h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',curr_term_array');
% caxis([min(c_levels) max(c_levels)])
% shading flat
% set(h,'edgecolor','none')
% set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% daspect([1 cosd(mean([latsouth latnorth])) 1])
% set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% print(gcf,'curr_term_array_reg_plot_temp.png','-dpng','-r300')
% close(fig15)
% 
% 
% % get contour plot and overlay land mask
% 
% rgb_array = imread('curr_term_array_reg_plot_temp.png');
% rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% 
% delete('curr_term_array_reg_plot_temp.png')
% 
% 
% size_rgb_array = size(rgb_array);
% landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% 
% % convert black undefined areas in SSH field to white shading
% black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% 
% 
% rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% 
% 
% fig16 = figure(16);
% fig16_paper_pos = get(fig16,'PaperPosition');
% set(fig16,'PaperPosition',fig16_paper_pos + [0 (-1.0) 0 2.0])
% x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% daspect([1 cosd(mean([latsouth latnorth])) 1])
% set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% hold on
% line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% hold off
% xlabel('Longitude','FontSize',20)
% ylabel('Latitude','FontSize',20)
% % set(gca,'Position',[0.1 0.18 0.8 0.85])
% title({'Optimal leads for {v_NR}{T_R} correlations,'; reg_avg_text_specifier},'FontSize',12,'Interpreter','none')
% colormap(cmap)
% cbar = colorbar('location','southoutside');
% % cbar_labels = cell(1,length(c_levels));
% % if length(c_levels) < 10
% %     for n_label = 1:length(c_levels)
% %         cbar_labels{n_label} = num2str(c_levels(n_label));
% %     end
% % else
% %     for n_label = 1:length(c_levels)
% %         if mod(n_label,2) == 1
% %             cbar_labels{n_label} = num2str(c_levels(n_label));
% %         else
% %             cbar_labels{n_label} = '';
% %         end
% %     end
% % end
% cbar_pos = get(cbar,'Position');
% cbar_labels = {'30' '25' '20' '15' '10' '5' '0'};
% set(cbar,'xtick',(0:1:(length(cmap) - 1)),'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% set(get(cbar,'xlabel'),'String','Lead (days)','FontSize',20)
% 
% saveas(fig16,['Opt_lag_adv_tend_vel_noreg_T_reg_',reg_avg_file_specifier,'.pdf'])
% close(fig16)
% 
% 
% 
% 
% 
% curr_term_array = corrcoef_at_optlag_input_adv_tend_total;
% 
% 
% cmap = bcyr(20);
% c_levels = ((-1):0.1:1)';
% 
% fig13 = figure(13);
% fig13_paper_pos = get(fig13,'PaperPosition');
% fig13_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig13_paper_pos(3);
% fig13_paper_pos(3:4) = 2*fig13_paper_pos(3:4);
% set(fig13,'PaperPosition',fig13_paper_pos,'PaperSize',[22 17])
% colormap(cmap)
% h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',curr_term_array');
% caxis([min(c_levels) max(c_levels)])
% shading flat
% set(h,'edgecolor','none')
% set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% daspect([1 cosd(mean([latsouth latnorth])) 1])
% set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% print(gcf,'curr_term_array_reg_plot_temp.png','-dpng','-r300')
% close(fig13)
% 
% 
% % get contour plot and overlay land mask
% 
% rgb_array = imread('curr_term_array_reg_plot_temp.png');
% rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% 
% delete('curr_term_array_reg_plot_temp.png')
% 
% 
% size_rgb_array = size(rgb_array);
% landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% 
% % convert black undefined areas in SSH field to white shading
% black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% 
% 
% rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% 
% 
% fig14 = figure(14);
% fig14_paper_pos = get(fig14,'PaperPosition');
% set(fig14,'PaperPosition',fig14_paper_pos + [0 (-1.0) 0 2.0])
% x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% daspect([1 cosd(mean([latsouth latnorth])) 1])
% set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% hold on
% line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% hold off
% xlabel('Longitude','FontSize',20)
% ylabel('Latitude','FontSize',20)
% % set(gca,'Position',[0.1 0.18 0.8 0.85])
% title({'Optimum correlation coefficients for total advection correlations,'; reg_avg_text_specifier},'FontSize',12,'Interpreter','none')
% colormap(cmap)
% cbar = colorbar('location','southoutside');
% cbar_labels = cell(1,length(c_levels));
% if length(c_levels) < 10
%     for n_label = 1:length(c_levels)
%         cbar_labels{n_label} = num2str(c_levels(n_label));
%     end
% else
%     for n_label = 1:length(c_levels)
%         if mod(n_label,2) == 1
%             cbar_labels{n_label} = num2str(c_levels(n_label));
%         else
%             cbar_labels{n_label} = '';
%         end
%     end
% end
% cbar_pos = get(cbar,'Position');
% set(cbar,'xtick',(0:1:length(cmap)) - 0.5,'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% set(get(cbar,'xlabel'),'String','Correlation coefficient','FontSize',20)
% 
% saveas(fig14,['Corr_coeff_adv_tend_total_',reg_avg_file_specifier,'.pdf'])
% close(fig14)
% 
% 
% 
% curr_term_array = opt_lag_input_adv_tend_total;
% 
% hot_8 = hot(8);
% cmap = 0.85*(hot_8([(1:1:4)'; (6:1:8)'],:));
% c_levels = ((-32.5):5:2.5)';
% 
% fig15 = figure(15);
% fig15_paper_pos = get(fig15,'PaperPosition');
% fig15_paper_pos(4) = ((latnorth - latsouth)/(cosd(mean([latsouth latnorth]))*(longeast - longwest)))*fig15_paper_pos(3);
% fig15_paper_pos(3:4) = 2*fig15_paper_pos(3:4);
% set(fig15,'PaperPosition',fig15_paper_pos,'PaperSize',[22 17])
% colormap(cmap)
% h = pcolor(tlon_pcolor_plot',tlat_pcolor_plot',curr_term_array');
% caxis([min(c_levels) max(c_levels)])
% shading flat
% set(h,'edgecolor','none')
% set(gca,'xlim',[longwest longeast],'ylim',[latsouth latnorth])
% daspect([1 cosd(mean([latsouth latnorth])) 1])
% set(gca,'position',[0 0 1 1],'units','normalized','Visible','off')
% print(gcf,'curr_term_array_reg_plot_temp.png','-dpng','-r300')
% close(fig15)
% 
% 
% % get contour plot and overlay land mask
% 
% rgb_array = imread('curr_term_array_reg_plot_temp.png');
% rgb_array = flipdim(permute(rgb_array,[2 1 3]),2);
% 
% delete('curr_term_array_reg_plot_temp.png')
% 
% 
% size_rgb_array = size(rgb_array);
% landmask_ind = landfind_indices(longwest,longeast,latsouth,latnorth,size_rgb_array(1:2));
% rgb_array_reshaped = reshape(rgb_array,[prod(size_rgb_array(1:2)) 3]);
% 
% % convert black undefined areas in SSH field to white shading
% black_shaded_ind = find((rgb_array_reshaped(:,1) == 0) & (rgb_array_reshaped(:,2) == 0) & (rgb_array_reshaped(:,3) == 0));
% rgb_array_reshaped(black_shaded_ind,:) = 255*ones(length(black_shaded_ind),3);
% 
% 
% rgb_array_reshaped(landmask_ind,:) = zeros(length(landmask_ind),3);
% rgb_array_masked = reshape(rgb_array_reshaped,size_rgb_array);
% 
% 
% fig16 = figure(16);
% fig16_paper_pos = get(fig16,'PaperPosition');
% set(fig16,'PaperPosition',fig16_paper_pos + [0 (-1.0) 0 2.0])
% x_vec = (longwest:((longeast - longwest)/(size(rgb_array,1) - 1)):longeast);
% y_vec = (latsouth:((latnorth - latsouth)/(size(rgb_array,2) - 1)):latnorth)';
% h = image(x_vec,y_vec,permute(rgb_array_masked,[2 1 3]));
% daspect([1 cosd(mean([latsouth latnorth])) 1])
% set(gca,'xlim',[longwest longeast],'xtick',80:2:130,'ydir','normal','ylim',[latsouth latnorth],'ytick',-20:2:10,'FontSize',20)
% hold on
% line([longwest longeast],[0 0],'Color','k','LineStyle','-','LineWidth',1)
% %     line(Kelvin_efold(:,2),Kelvin_efold(:,1),zeros(size(Kelvin_efold,1),1),'Color',[0.5 0.3 0],'LineStyle','--','LineWidth',2)
% hold off
% xlabel('Longitude','FontSize',20)
% ylabel('Latitude','FontSize',20)
% % set(gca,'Position',[0.1 0.18 0.8 0.85])
% title({'Optimal leads for total advection correlations,'; reg_avg_text_specifier},'FontSize',12,'Interpreter','none')
% colormap(cmap)
% cbar = colorbar('location','southoutside');
% % cbar_labels = cell(1,length(c_levels));
% % if length(c_levels) < 10
% %     for n_label = 1:length(c_levels)
% %         cbar_labels{n_label} = num2str(c_levels(n_label));
% %     end
% % else
% %     for n_label = 1:length(c_levels)
% %         if mod(n_label,2) == 1
% %             cbar_labels{n_label} = num2str(c_levels(n_label));
% %         else
% %             cbar_labels{n_label} = '';
% %         end
% %     end
% % end
% cbar_labels = {'30' '25' '20' '15' '10' '5' '0'};
% cbar_pos = get(cbar,'Position');
% set(cbar,'xtick',(0:1:(length(cmap) - 1)),'xticklabel',cbar_labels,'FontSize',20,'Position',cbar_pos + [0.026 (-0.18) 0.163 0])
% set(get(cbar,'xlabel'),'String','Lead (days)','FontSize',20)
% 
% saveas(fig16,['Opt_lag_adv_tend_total_',reg_avg_file_specifier,'.pdf'])
% close(fig16)
