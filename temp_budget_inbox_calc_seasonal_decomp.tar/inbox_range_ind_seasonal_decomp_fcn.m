function [lon_ind_inrange,lat_ind_inrange,unique_time_ind,time_ind_inrange,mean_ML_depth,mean_BL_depth,min_BL_depth,max_BL_depth] = inbox_range_ind_fcn(nc_filenames,NE_corner,NW_corner,SW_corner,SE_corner,time_range)

% t for a 3-D box in POP output

path(path,'~/Budget_calculations/')


grid_res = 0.1;


TLAT = ncread(nc_filenames{1},'TLAT');
TLON = ncread(nc_filenames{1},'TLONG');
ULAT = ncread(nc_filenames{1},'ULAT');
ULON = ncread(nc_filenames{1},'ULONG');

time = [];
file_num_vec = [];
in_file_ind_vec = [];
for file_num = 1:length(nc_filenames)
    time_curr_source_file = ncread(nc_filenames{file_num},'time');
    
    time = [time; time_curr_source_file];
    
    file_num_vec = [file_num_vec; (file_num*ones(length(time_curr_source_file),1))];
    in_file_ind_vec = [in_file_ind_vec; ((1:1:length(time_curr_source_file))')];
end



lat_min = min([NE_corner(1) NW_corner(1) SW_corner(1) SE_corner(1)]);
lat_max = max([NE_corner(1) NW_corner(1) SW_corner(1) SE_corner(1)]);
lon_min = min([NE_corner(2) NW_corner(2) SW_corner(2) SE_corner(2)]);
lon_max = max([NE_corner(2) NW_corner(2) SW_corner(2) SE_corner(2)]);

ind_inrange = find((TLON >= (lon_min - (2*grid_res))) & (TLON <= (lon_max + (2*grid_res))) & (TLAT >= (lat_min - (2*grid_res))) & (TLAT <= (lat_max + (2*grid_res))));
[lat_ind_mesh,lon_ind_mesh] = meshgrid((1:1:size(TLAT,2)),(1:1:size(TLON,1)));


lon_ind_min_inrange = min(lon_ind_mesh(ind_inrange));
lon_ind_max_inrange = max(lon_ind_mesh(ind_inrange));
lat_ind_min_inrange = min(lat_ind_mesh(ind_inrange));
lat_ind_max_inrange = max(lat_ind_mesh(ind_inrange));

lon_ind_inrange = (lon_ind_min_inrange:1:lon_ind_max_inrange)';
lat_ind_inrange = (lat_ind_min_inrange:1:lat_ind_max_inrange);

tlon = TLON(lon_ind_inrange,lat_ind_inrange);
tlat = TLAT(lon_ind_inrange,lat_ind_inrange);
ulon = ULON(lon_ind_inrange,lat_ind_inrange);
ulat = ULAT(lon_ind_inrange,lat_ind_inrange);



% find times in specified range
time_ind_inrange = find((time >= time_range(1)) & (time <= time_range(2)));

% remove possible duplication of times across files
[unique_times,unique_time_ind,unique_time_rev_ind] = unique(time);

time_ind_inrange = intersect(time_ind_inrange,unique_time_ind);


% % use only files that contain times within specified time range
% file_nums_in_time_range = unique(file_num_vec(time_ind_inrange));

% use all files in source_nc_filenames
file_nums_in_time_range = unique(file_num_vec);


curr_file_start_ind = 1;

mean_ML_depth = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_times));
mean_BL_depth = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_times));
min_BL_depth = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_times));
max_BL_depth = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_times));
for file_num_ind = 1:length(file_nums_in_time_range)
    file_num = file_nums_in_time_range(file_num_ind);
    
    time_curr_source_file = ncread(nc_filenames{file_num},'time');
    
%     time_ind_infile = find(file_num_vec(time_ind_inrange) == file_num);
%     curr_time_ind_inrange = in_file_ind_vec(time_ind_inrange(time_ind_infile));

    time_ind_infile = find(file_num_vec(unique_time_ind) == file_num);
    curr_time_ind_inrange = in_file_ind_vec(unique_time_ind(time_ind_infile));


    start_vector_nodepth = [lon_ind_min_inrange lat_ind_min_inrange min(curr_time_ind_inrange)];
    size_vector_nodepth = [length(lon_ind_inrange) length(lat_ind_inrange) (max(curr_time_ind_inrange) - min(curr_time_ind_inrange) + 1)];
    
    
    subsetting_in_time_ind = curr_time_ind_inrange - min(curr_time_ind_inrange) + 1;
    
    curr_file_end_ind = curr_file_start_ind - 1 + length(curr_time_ind_inrange);
    
    % load mixed layer depth
    curr_mean_ML_depth = ncread(nc_filenames{file_num},'HMXL',start_vector_nodepth,size_vector_nodepth,ones(1,3));
    mean_ML_depth(:,:,curr_file_start_ind:curr_file_end_ind) = curr_mean_ML_depth(:,:,subsetting_in_time_ind);
    
    % load boundary layer depth
    curr_mean_BL_depth = ncread(nc_filenames{file_num},'HBLT',start_vector_nodepth,size_vector_nodepth,ones(1,3));
    mean_BL_depth(:,:,curr_file_start_ind:curr_file_end_ind) = curr_mean_BL_depth(:,:,subsetting_in_time_ind);
    curr_min_BL_depth = ncread(nc_filenames{file_num},'TBLT',start_vector_nodepth,size_vector_nodepth,ones(1,3));
    min_BL_depth(:,:,curr_file_start_ind:curr_file_end_ind) = curr_min_BL_depth(:,:,subsetting_in_time_ind);
    curr_max_BL_depth = ncread(nc_filenames{file_num},'XBLT',start_vector_nodepth,size_vector_nodepth,ones(1,3));
    max_BL_depth(:,:,curr_file_start_ind:curr_file_end_ind) = curr_max_BL_depth(:,:,subsetting_in_time_ind);
    
    curr_file_start_ind = curr_file_start_ind + length(curr_time_ind_inrange);
    
end
