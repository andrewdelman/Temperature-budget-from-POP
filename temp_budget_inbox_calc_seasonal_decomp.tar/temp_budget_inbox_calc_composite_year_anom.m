% compute composite anomalies of temperature budget terms, from .mat file


path(path,'~/Budget_calculations/')
path(path,'~/plotting_scripts/')
cd('/glade/scratch/adelman/POP_1977_start_JC/')


% load('Java_budget_1977_2009_seasonal_decomp.mat')
load('Java_budget_1979_2009_seasonal_decomp.mat')

time_inrange = time_inrange_modelyr;


% years to use to construct composite

% year_nums_to_composite = [6; 7; 11; 18; 21; 27; 30; 31; 32];
year_nums_to_composite = [6; 7; 18; 21; 27; 30; 31; 32];

% years to use as samples in bootstrap calculations

year_nums_for_bootstrap = (3:1:33)';


T_tend_overall_terms_anom_for_composite = NaN((365/5) + 8,size(T_tend_overall_terms_anom_array,2),length(year_nums_to_composite));
T_tend_detailed_terms_anom_for_composite = NaN((365/5) + 8,size(T_tend_detailed_terms_anom_array,2),length(year_nums_to_composite));
vardepth_breakdown_terms_anom_for_composite = NaN((365/5) + 8,size(vardepth_breakdown_terms_anom_array,2),length(year_nums_to_composite));
vol_flux_anom_for_composite = NaN((365/5) + 8,size(vol_flux_anom_array,2),length(year_nums_to_composite));
for year_ind = 1:length(year_nums_to_composite)
%     in_curr_year_ind = find(floor((time_inrange_modelyr - (tavg_days/2))/365) == year_nums_to_composite(year_ind));
    in_curr_year_ind = find((time_inrange >= ((365*(year_nums_to_composite(year_ind))) + (tavg_days/2) - 20)) & (time_inrange <= ((365*(year_nums_to_composite(year_ind) + 1)) + (tavg_days/2) + 20)));
    
    T_tend_overall_terms_anom_for_composite(:,:,year_ind) = T_tend_overall_terms_anom_array(in_curr_year_ind,:);
    T_tend_detailed_terms_anom_for_composite(:,:,year_ind) = T_tend_detailed_terms_anom_array(in_curr_year_ind,:);
    vardepth_breakdown_terms_anom_for_composite(:,:,year_ind) = vardepth_breakdown_terms_anom_array(in_curr_year_ind,:);
    vol_flux_anom_for_composite(:,:,year_ind) = vol_flux_anom_array(in_curr_year_ind,:);
end


% span for smoothing in plots
span = t_plot_smooth_days/tavg_days;


% T_tend_overall_terms_anom_for_bootstrap = NaN((365/5) + 3,size(T_tend_overall_terms_anom_array,2),length(year_nums_for_bootstrap));
% T_tend_detailed_terms_anom_for_bootstrap = NaN((365/5) + 3,size(T_tend_detailed_terms_anom_array,2),length(year_nums_for_bootstrap));
% vardepth_breakdown_terms_anom_for_bootstrap = NaN((365/5) + 3,size(vardepth_breakdown_terms_anom_array,2),length(year_nums_for_bootstrap));
% vol_flux_anom_for_bootstrap = NaN((365/5) + 3,size(vol_flux_anom_array,2),length(year_nums_for_bootstrap));
% for year_ind = 1:length(year_nums_for_bootstrap)
%     in_curr_year_ind = find((time_inrange >= ((365*(year_nums_for_bootstrap(year_ind))) + (tavg_days/2) - 20)) & (time_inrange <= ((365*(year_nums_for_bootstrap(year_ind) + 1)) + (tavg_days/2) + 20)));
%     
%     T_tend_overall_terms_anom_for_bootstrap(:,:,year_ind) = smooth_endclip(T_tend_overall_terms_anom_array(in_curr_year_ind,:),span);
%     T_tend_detailed_terms_anom_for_bootstrap(:,:,year_ind) = smooth_endclip(T_tend_detailed_terms_anom_array(in_curr_year_ind,:),span);
%     vardepth_breakdown_terms_anom_for_bootstrap(:,:,year_ind) = smooth_endclip(vardepth_breakdown_terms_anom_array(in_curr_year_ind,:),span);
%     vol_flux_anom_for_bootstrap(:,:,year_ind) = smooth_endclip(vol_flux_anom_array(in_curr_year_ind,:),span);
% end
% 
% 
% T_tend_overall_terms_anom_for_composite = NaN((365/5) + 8,size(T_tend_overall_terms_anom_array,2),length(year_nums_to_composite));
% T_tend_detailed_terms_anom_for_composite = NaN((365/5) + 8,size(T_tend_detailed_terms_anom_array,2),length(year_nums_to_composite));
% vardepth_breakdown_terms_anom_for_composite = NaN((365/5) + 8,size(vardepth_breakdown_terms_anom_array,2),length(year_nums_to_composite));
% vol_flux_anom_for_composite = NaN((365/5) + 8,size(vol_flux_anom_array,2),length(year_nums_to_composite));
% for year_ind = 1:length(year_nums_to_composite)
%     curr_year_ind = find(abs(year_nums_for_bootstrap - year_nums_to_composite(year_ind)) < 0.5);
%     
%     T_tend_overall_terms_anom_for_composite(:,:,year_ind) = T_tend_overall_terms_anom_for_bootstrap(curr_year_ind,:);
%     T_tend_detailed_terms_anom_for_composite(:,:,year_ind) = T_tend_detailed_terms_anom_for_bootstrap(curr_year_ind,:);
%     vardepth_breakdown_terms_anom_for_composite(:,:,year_ind) = vardepth_breakdown_terms_anom_for_bootstrap(curr_year_ind,:);
%     vol_flux_anom_for_composite(:,:,year_ind) = vol_flux_anom_for_bootstrap(curr_year_ind,:);
% end



% n_bootstrap = 1000;   % number of combinations to average for bootstrap calculation
n_bootstrap = 10000;   % number of combinations to average for bootstrap calculation

bootstrap_random_year_ind = randi(length(year_nums_for_bootstrap),[length(year_nums_to_composite),n_bootstrap]);


% T_tend_overall_terms_anom_bootstrap_avg = NaN((365/5) + 3,size(T_tend_overall_terms_anom_array,2),n_bootstrap);
% T_tend_detailed_terms_anom_bootstrap_avg = NaN((365/5) + 3,size(T_tend_detailed_terms_anom_array,2),n_bootstrap);
% vardepth_breakdown_terms_anom_bootstrap_avg = NaN((365/5) + 3,size(vardepth_breakdown_terms_anom_array,2),n_bootstrap);
% vol_flux_anom_bootstrap_avg = NaN((365/5) + 3,size(vol_flux_anom_array,2),n_bootstrap);
% for n_bstrap = 1:n_bootstrap
%     curr_bstrap_year_ind = bootstrap_random_year_ind(:,n_bstrap);
%     
%     T_tend_overall_terms_anom_bootstrap_avg(:,:,n_bstrap) = mean(T_tend_overall_terms_anom_for_bootstrap(:,:,curr_bstrap_year_ind),3);
%     T_tend_detailed_terms_anom_bootstrap_avg(:,:,n_bstrap) = mean(T_tend_detailed_terms_anom_for_bootstrap(:,:,curr_bstrap_year_ind),3);
%     vardepth_breakdown_terms_anom_bootstrap_avg(:,:,n_bstrap) = mean(vardepth_breakdown_terms_anom_for_bootstrap(:,:,curr_bstrap_year_ind),3);
%     vol_flux_anom_bootstrap_avg(:,:,n_bstrap) = mean(vol_flux_anom_for_bootstrap(:,:,curr_bstrap_year_ind),3);
% end
% 
% 
% T_tend_overall_terms_anom_bootstrap_sorted = sort(T_tend_overall_terms_anom_bootstrap_avg,3,'ascend');
% T_tend_detailed_terms_anom_bootstrap_sorted = sort(T_tend_detailed_terms_anom_bootstrap_avg,3,'ascend');
% vardepth_breakdown_terms_anom_bootstrap_sorted = sort(vardepth_breakdown_terms_anom_bootstrap_avg,3,'ascend');
% vol_flux_anom_bootstrap_sorted = sort(vol_flux_anom_bootstrap_avg,3,'ascend');


cdf_vec = ((1:1:n_bootstrap)' - 0.5)/n_bootstrap;

% T_tend_overall_terms_anom_bootstrap_2p5_97p5_bounds = permute(interp1(cdf_vec,permute(T_tend_overall_terms_anom_bootstrap_sorted,[3 1 2]),[0.025; 0.975]),[2 3 1]);
% T_tend_detailed_terms_anom_bootstrap_2p5_97p5_bounds = permute(squeeze(interp1(cdf_vec,permute(T_tend_detailed_terms_anom_bootstrap_sorted,[3 1 2]),[0.025; 0.975]),[2 3 1]);
% vardepth_breakdown_terms_anom_bootstrap_2p5_97p5_bounds = permute(interp1(cdf_vec,permute(vardepth_breakdown_terms_anom_bootstrap_sorted,[3 1 2]),[0.025; 0.975]),[2 3 1]);
% vol_flux_anom_bootstrap_2p5_97p5_bounds = permute(interp1(cdf_vec,permute(vol_flux_anom_bootstrap_sorted,[3 1 2]),[0.025; 0.975]),[2 3 1]);
% 
% T_tend_overall_terms_anom_bootstrap_5_95_bounds = permute(interp1(cdf_vec,permute(T_tend_overall_terms_anom_bootstrap_sorted,[3 1 2]),[0.05 0.95]),[2 3 1]);
% T_tend_detailed_terms_anom_bootstrap_5_95_bounds = permute(interp1(cdf_vec,permute(T_tend_detailed_terms_anom_bootstrap_sorted,[3 1 2]),[0.025 0.975]),[2 3 1]);
% vardepth_breakdown_terms_anom_bootstrap_5_95_bounds = permute(interp1(cdf_vec,permute(vardepth_breakdown_terms_anom_bootstrap_sorted,[3 1 2]),[0.05 0.95]),[2 3 1]);
% vol_flux_anom_bootstrap_5_95_bounds = permute(interp1(cdf_vec,permute(vol_flux_anom_bootstrap_sorted,[3 1 2]),[0.05 0.95]),[2 3 1]);




T_tend_overall_terms_anom_composite = mean(T_tend_overall_terms_anom_for_composite,3);
T_tend_detailed_terms_anom_composite = mean(T_tend_detailed_terms_anom_for_composite,3);
vardepth_breakdown_terms_anom_composite = mean(vardepth_breakdown_terms_anom_for_composite,3);
vol_flux_anom_composite = mean(vol_flux_anom_for_composite,3);


adv_T_tend_total_anom_composite = T_tend_overall_terms_anom_composite(:,1);
hdiff_T_tend_total_anom_composite = T_tend_overall_terms_anom_composite(:,2);
ent_T_tend_total_anom_composite = T_tend_overall_terms_anom_composite(:,3);
diab_vert_T_tend_anom_composite = T_tend_overall_terms_anom_composite(:,4);
kpp_src_T_tend_anom_composite = T_tend_overall_terms_anom_composite(:,5);
sfc_flux_T_tend_anom_composite = T_tend_overall_terms_anom_composite(:,6);
if size(T_tend_overall_terms_anom_composite,2) > 6
    total_T_tend_anom_composite = T_tend_overall_terms_anom_composite(:,7);
end


adv_T_tend_N_edge_anom_composite = T_tend_detailed_terms_anom_composite(:,1);
adv_T_tend_W_edge_anom_composite = T_tend_detailed_terms_anom_composite(:,2);
adv_T_tend_S_edge_anom_composite = T_tend_detailed_terms_anom_composite(:,3);
adv_T_tend_E_edge_anom_composite = T_tend_detailed_terms_anom_composite(:,4);
adv_T_tend_top_edge_anom_composite = T_tend_detailed_terms_anom_composite(:,5);
adv_T_tend_bottom_edge_anom_composite = T_tend_detailed_terms_anom_composite(:,6);
var_depth_adv_T_tend_top_anom_composite = T_tend_detailed_terms_anom_composite(:,7);
var_depth_adv_T_tend_bottom_anom_composite = T_tend_detailed_terms_anom_composite(:,8);
hdiff_T_tend_N_edge_anom_composite = T_tend_detailed_terms_anom_composite(:,9);
hdiff_T_tend_W_edge_anom_composite = T_tend_detailed_terms_anom_composite(:,10);
hdiff_T_tend_S_edge_anom_composite = T_tend_detailed_terms_anom_composite(:,11);
hdiff_T_tend_E_edge_anom_composite = T_tend_detailed_terms_anom_composite(:,12);
hdiff_T_tend_top_edge_anom_composite = T_tend_detailed_terms_anom_composite(:,13);
hdiff_T_tend_bottom_edge_anom_composite = T_tend_detailed_terms_anom_composite(:,14);
var_depth_hdiff_T_tend_top_anom_composite = T_tend_detailed_terms_anom_composite(:,15);
var_depth_hdiff_T_tend_bottom_anom_composite = T_tend_detailed_terms_anom_composite(:,16);
ent_T_tend_top_anom_composite = T_tend_detailed_terms_anom_composite(:,17);
ent_T_tend_bottom_anom_composite = T_tend_detailed_terms_anom_composite(:,18);
diab_vert_T_tend_top_anom_composite = T_tend_detailed_terms_anom_composite(:,19);
diab_vert_T_tend_bottom_anom_composite = T_tend_detailed_terms_anom_composite(:,20);
% kpp_src_T_tend_anom_composite = T_tend_detailed_terms_anom_composite(:,21);
sw_top_flux_T_tend_anom_composite = T_tend_detailed_terms_anom_composite(:,22);
sw_bottom_flux_T_tend_anom_composite = T_tend_detailed_terms_anom_composite(:,23);
longwave_downward_flux_T_tend_anom_composite = T_tend_detailed_terms_anom_composite(:,24);
longwave_upward_flux_T_tend_anom_composite = T_tend_detailed_terms_anom_composite(:,25);
latent_heat_flux_T_tend_anom_composite = T_tend_detailed_terms_anom_composite(:,26);
sensible_heat_flux_T_tend_anom_composite = T_tend_detailed_terms_anom_composite(:,27);
% total_T_tend_anom_composite = T_tend_detailed_terms_anom_composite(:,28);

adv_T_tend_N_sloping_top_anom_composite = vardepth_breakdown_terms_anom_composite(:,1);
adv_T_tend_W_sloping_top_anom_composite = vardepth_breakdown_terms_anom_composite(:,2);
adv_T_tend_S_sloping_top_anom_composite = vardepth_breakdown_terms_anom_composite(:,3);
adv_T_tend_E_sloping_top_anom_composite = vardepth_breakdown_terms_anom_composite(:,4);
hdiff_T_tend_N_sloping_top_anom_composite = vardepth_breakdown_terms_anom_composite(:,5);
hdiff_T_tend_W_sloping_top_anom_composite = vardepth_breakdown_terms_anom_composite(:,6);
hdiff_T_tend_S_sloping_top_anom_composite = vardepth_breakdown_terms_anom_composite(:,7);
hdiff_T_tend_E_sloping_top_anom_composite = vardepth_breakdown_terms_anom_composite(:,8);
ent_T_tend_top_anom_composite = vardepth_breakdown_terms_anom_composite(:,9);
adv_T_tend_N_sloping_bottom_anom_composite = vardepth_breakdown_terms_anom_composite(:,10);
adv_T_tend_W_sloping_bottom_anom_composite = vardepth_breakdown_terms_anom_composite(:,11);
adv_T_tend_S_sloping_bottom_anom_composite = vardepth_breakdown_terms_anom_composite(:,12);
adv_T_tend_E_sloping_bottom_anom_composite = vardepth_breakdown_terms_anom_composite(:,13);
hdiff_T_tend_N_sloping_bottom_anom_composite = vardepth_breakdown_terms_anom_composite(:,14);
hdiff_T_tend_W_sloping_bottom_anom_composite = vardepth_breakdown_terms_anom_composite(:,15);
hdiff_T_tend_S_sloping_bottom_anom_composite = vardepth_breakdown_terms_anom_composite(:,16);
hdiff_T_tend_E_sloping_bottom_anom_composite = vardepth_breakdown_terms_anom_composite(:,17);
ent_T_tend_bottom_anom_composite = vardepth_breakdown_terms_anom_composite(:,18);


adv_vol_flux_N_anom_composite = vol_flux_anom_composite(:,1);
adv_vol_flux_W_anom_composite = vol_flux_anom_composite(:,2);
adv_vol_flux_S_anom_composite = vol_flux_anom_composite(:,3);
adv_vol_flux_E_anom_composite = vol_flux_anom_composite(:,4);
adv_vol_flux_top_anom_composite = vol_flux_anom_composite(:,5);
adv_vol_flux_bottom_anom_composite = vol_flux_anom_composite(:,6);
adv_vol_flux_N_sloping_top_anom_composite = vol_flux_anom_composite(:,7);
adv_vol_flux_W_sloping_top_anom_composite = vol_flux_anom_composite(:,8);
adv_vol_flux_S_sloping_top_anom_composite = vol_flux_anom_composite(:,9);
adv_vol_flux_E_sloping_top_anom_composite = vol_flux_anom_composite(:,10);
adv_vol_flux_N_sloping_bottom_anom_composite = vol_flux_anom_composite(:,11);
adv_vol_flux_W_sloping_bottom_anom_composite = vol_flux_anom_composite(:,12);
adv_vol_flux_S_sloping_bottom_anom_composite = vol_flux_anom_composite(:,13);
adv_vol_flux_E_sloping_bottom_anom_composite = vol_flux_anom_composite(:,14);
ent_vol_flux_top_anom_composite = vol_flux_anom_composite(:,15);
ent_vol_flux_bottom_anom_composite = vol_flux_anom_composite(:,16);



% date labels

month_start_vec = [0; 31; 59; 90; 120; 151; 181; 212; 243; 273; 304; 334];
time_date_label = month_start_vec;
% date_label = {'Jan-01'; ''; 'Mar-01'; ''; 'May-01'; ''; 'Jul-01'; ''; 'Sep-01'; ''; 'Nov-01'; ''};
date_label = {'Jan-01'; ''; ''; 'Apr-01'; ''; ''; 'Jul-01'; ''; ''; 'Oct-01'; ''; ''};


% time vector (in year)
time_inyear = ((2.5 - 20):5:(362.5 + 20))';

% % span for smoothing in plots
% span = t_plot_smooth_days/tavg_days;

% smoothed time vector
time_inyear_smoothed = smooth_endclip(time_inyear,span);




% create figures


fig13 = figure(13);
fig13_paper_pos = get(fig13,'PaperPosition');
% fig13_paper_pos(3) = 1.5*fig13_paper_pos(4);
fig13_paper_pos(3) = 1.8*fig13_paper_pos(4);
fig13_paper_pos(3:4) = 0.8*fig13_paper_pos(3:4);
set(fig13,'PaperPosition',fig13_paper_pos)
% h = plot(time_inyear_smoothed,86400*smooth_endclip(adv_T_tend_total_anom_composite,span),time_inyear_smoothed,86400*smooth_endclip(ent_T_tend_total_anom_composite,span),time_inyear_smoothed,86400*smooth_endclip(sfc_flux_T_tend_anom_composite,span),time_inyear_smoothed,86400*smooth_endclip(hdiff_T_tend_total_anom_composite,span),time_inyear_smoothed,86400*smooth_endclip(diab_vert_T_tend_anom_composite,span),time_inyear_smoothed,86400*smooth_endclip(kpp_src_T_tend_anom_composite,span),time_inyear_smoothed,86400*smooth_endclip(total_T_tend_anom_composite,span));
h = plot(time_inyear_smoothed,86400*smooth_endclip(adv_T_tend_total_anom_composite,span),time_inyear_smoothed,86400*smooth_endclip(ent_T_tend_total_anom_composite,span),time_inyear_smoothed,86400*smooth_endclip(sfc_flux_T_tend_anom_composite,span),time_inyear_smoothed,86400*smooth_endclip(hdiff_T_tend_total_anom_composite,span),time_inyear_smoothed,86400*smooth_endclip(diab_vert_T_tend_anom_composite + kpp_src_T_tend_anom_composite,span),time_inyear_smoothed,86400*smooth_endclip(total_T_tend_anom_composite,span));
set(h(1),'LineWidth',1)
set(h(2),'LineWidth',1)
% set(h(3),'Color',[0.7 0 0],'LineStyle','--','LineWidth',1)
% set(h(4),'LineStyle','--','LineWidth',1)
% set(h(5),'LineStyle','-.','LineWidth',1)
% % set(h(6),'Color',[0.8 0.5 0],'LineStyle','-.','LineWidth',1)
% % set(h(7),'Color','k','LineWidth',1)
set(h(3),'Color',[0.7 0 0],'LineStyle','-','LineWidth',1)
set(h(4),'LineStyle','-','LineWidth',1)
set(h(5),'LineStyle','-','LineWidth',1)
set(h(6),'Color','k','LineWidth',1)
weight_white = 0.7;     % proportion of color adjustment towards white
for h_ind = 1:length(h)
    full_color_vec = get(h(h_ind),'Color');
    set(h(h_ind),'Color',(weight_white*[1 1 1]) + (1 - weight_white)*full_color_vec)
end
% plot_series_specifiers_allyears = {'T_tend_overall_terms_anom_array(:,1)'; 'T_tend_overall_terms_anom_array(:,3)'; 'T_tend_overall_terms_anom_array(:,6)'; 'T_tend_overall_terms_anom_array(:,2)'; 'T_tend_overall_terms_anom_array(:,4)'; 'T_tend_overall_terms_anom_array(:,5)'; 'T_tend_overall_terms_anom_array(:,7)'};
% plot_series_specifiers_composite = {'T_tend_overall_terms_anom_composite(:,1)'; 'T_tend_overall_terms_anom_composite(:,3)'; 'T_tend_overall_terms_anom_composite(:,6)'; 'T_tend_overall_terms_anom_composite(:,2)'; 'T_tend_overall_terms_anom_composite(:,4)'; 'T_tend_overall_terms_anom_composite(:,5)'; 'T_tend_overall_terms_anom_composite(:,7)'};
plot_series_specifiers_allyears = {'T_tend_overall_terms_anom_array(:,1)'; 'T_tend_overall_terms_anom_array(:,3)'; 'T_tend_overall_terms_anom_array(:,6)'; 'T_tend_overall_terms_anom_array(:,2)'; 'sum(T_tend_overall_terms_anom_array(:,4:5),2)'; 'T_tend_overall_terms_anom_array(:,7)'};
plot_series_specifiers_composite = {'T_tend_overall_terms_anom_composite(:,1)'; 'T_tend_overall_terms_anom_composite(:,3)'; 'T_tend_overall_terms_anom_composite(:,6)'; 'T_tend_overall_terms_anom_composite(:,2)'; 'sum(T_tend_overall_terms_anom_composite(:,4:5),2)'; 'T_tend_overall_terms_anom_composite(:,7)'};
hold on
h_b = NaN(length(plot_series_specifiers_composite),1);
for n_series = 1:length(plot_series_specifiers_allyears)
    curr_series_for_bootstrap = NaN((365/5) + 3,length(year_nums_for_bootstrap));
    
    curr_series = eval(plot_series_specifiers_allyears{n_series});
    
    for year_ind = 1:length(year_nums_for_bootstrap)
        in_curr_year_ind = find((time_inrange >= ((365*(year_nums_for_bootstrap(year_ind))) + (tavg_days/2) - 20)) & (time_inrange <= ((365*(year_nums_for_bootstrap(year_ind) + 1)) + (tavg_days/2) + 20)));
        
%         curr_series_for_bootstrap(:,year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
        if year_ind == 1
            begin_ind = size(curr_series_for_bootstrap,1) - length(in_curr_year_ind) + span;
            curr_series_for_bootstrap(begin_ind:size(curr_series_for_bootstrap,1),year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
            curr_series_for_bootstrap(1:(begin_ind - 1),year_ind) = curr_series_for_bootstrap(begin_ind,year_ind);
        elseif year_ind == length(year_nums_for_bootstrap)
            end_ind = length(in_curr_year_ind) - span + 1;
            curr_series_for_bootstrap(1:end_ind,year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
            curr_series_for_bootstrap((end_ind + 1):size(curr_series_for_bootstrap,1),year_ind) = curr_series_for_bootstrap(end_ind,year_ind);
        else
            curr_series_for_bootstrap(:,year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
        end
    end
    
    curr_series_bootstrap_avg = NaN((365/5) + 3,n_bootstrap);
    for n_bstrap = 1:n_bootstrap
        curr_bstrap_year_ind = bootstrap_random_year_ind(:,n_bstrap);
        
        curr_series_bootstrap_avg(:,n_bstrap) = mean(curr_series_for_bootstrap(:,curr_bstrap_year_ind),2);
    end
    
    curr_series_bootstrap_sorted = sort(curr_series_bootstrap_avg,2,'ascend');
    
    curr_series_bootstrap_2p5_97p5_bounds = (interp1(cdf_vec,curr_series_bootstrap_sorted',[0.025; 0.975]))';
    curr_series_bootstrap_5_95_bounds = (interp1(cdf_vec,curr_series_bootstrap_sorted',[0.05; 0.95]))';
    
    curr_color_vec = get(h(n_series),'Color');
    curr_linestyle = get(h(n_series),'LineStyle');
    curr_linewidth = get(h(n_series),'LineWidth');
    curr_ydata = get(h(n_series),'YData');
    
%     h_e = errorbar(time_inyear_smoothed,curr_ydata,86400*curr_series_bootstrap_2p5_97p5_bounds(:,2),86400*(-curr_series_bootstrap_2p5_97p5_bounds(:,1)));
%     set(h_e,'Color',curr_color_vec,'LineWidth',curr_linewidth)
    
    weight_white_reverse = -weight_white/(1 - weight_white);
    full_color_vec = (weight_white_reverse*[1 1 1]) + (1 - weight_white_reverse)*curr_color_vec;
    curr_series_bootstrap_test = eval(['smooth_endclip(',plot_series_specifiers_composite{n_series},',span)']);
    
    curr_h_ydata = get(h(n_series),'YData');
    outside_range_ind = find((curr_series_bootstrap_test < curr_series_bootstrap_5_95_bounds(:,1)) | (curr_series_bootstrap_test > curr_series_bootstrap_5_95_bounds(:,2)));
    outside_range_no_transition_ind = intersect(intersect(outside_range_ind - 1,outside_range_ind),outside_range_ind + 1);
    curr_h_ydata(outside_range_no_transition_ind) = NaN;
    set(h(n_series),'YData',curr_h_ydata)
    
    curr_series_bootstrap_test((curr_series_bootstrap_test >= curr_series_bootstrap_5_95_bounds(:,1)) & (curr_series_bootstrap_test <= curr_series_bootstrap_5_95_bounds(:,2))) = NaN;
    h_b(n_series) = line(time_inyear_smoothed,86400*curr_series_bootstrap_test,'Color',full_color_vec,'LineStyle',curr_linestyle,'LineWidth',curr_linewidth + 1);
    
end

xlim_bounds = [0 365];
% set(gca,'xlim',xlim_bounds,'ylim',[-0.15 0.15],'xtick',time_date_label,'xticklabel',date_label)
set(gca,'xlim',xlim_bounds,'xtick',time_date_label,'xticklabel',date_label,'FontSize',14)
set(gca,'ylim',[-0.05 0.05],'ytick',(-0.05):0.01:0.05)
line(xlim_bounds,[0 0],[0 0],'Color','k','LineStyle','-','LineWidth',0.5)
hold off
ylabel('Temp. tendency anomaly ( ^{o}C day^{-1})')
% legend('Advection','Vol. change (ent.)','Surface/shortwave','Horiz. diffusion','Diabatic vert. mixing','Non-local (convective)','Total tend. anom.','Location','northwest')
% legend('Advection','Vol. change (ent.)','Surface/shortwave','Horiz. diffusion','Diabatic vert. mixing','Convective','Total tend. anom.','Location','northwest')
% legend(h_b,'Advection','Volume change','Surface fluxes','Horizontal diffusion','Vertical mixing','Convection','Total tend. anom.','Location','eastoutside')
% legend(h,'Advection','Volume change','Surface fluxes','Horizontal diffusion','Vertical mixing','Convection','Total tend. anom.','Location','eastoutside')
legend(h_b,'Advection','Volume change','Surface fluxes','Horizontal diffusion','Vertical mixing','Total tend. anom.','Location','eastoutside')
title({'Contributions to the composite temp. tendency anomaly from various mechanisms:'; region_desc},'FontSize',10)

saveas(fig13,['Java_temp_budget_T_tend_anom_pIOD_composite_all_terms_',file_end,'.pdf'])
close(fig13)



fig15 = figure(15);
fig15_paper_pos = get(fig15,'PaperPosition');
% fig15_paper_pos(3) = 1.5*fig15_paper_pos(4);
fig15_paper_pos(3) = 1.8*fig15_paper_pos(4);
fig15_paper_pos(3:4) = 0.8*fig15_paper_pos(3:4);
set(fig15,'PaperPosition',fig15_paper_pos)
h = plot(time_inyear_smoothed,86400*(smooth_endclip(sw_top_flux_T_tend_anom_composite,span) + smooth_endclip(sw_bottom_flux_T_tend_anom_composite,span)),'y-',time_inyear_smoothed,86400*(smooth_endclip(longwave_upward_flux_T_tend_anom_composite,span) + smooth_endclip(longwave_downward_flux_T_tend_anom_composite,span)),'g-',time_inyear_smoothed,86400*smooth_endclip(latent_heat_flux_T_tend_anom_composite,span),'b-',time_inyear_smoothed,86400*smooth_endclip(sensible_heat_flux_T_tend_anom_composite,span),'c-',time_inyear_smoothed,86400*smooth_endclip(sfc_flux_T_tend_anom_composite,span),'r-');
set(h(1),'Color',[0.8 0.5 0],'LineWidth',1)
set(h(2),'Color',[0 0.7 0],'LineWidth',1)
% set(h(3),'Color',[0 0 0.7],'LineStyle','-.','LineWidth',1)
% set(h(4),'Color',[0 0.5 0.5],'LineStyle','-.','LineWidth',1)
% set(h(5),'Color',[0.7 0 0],'LineWidth',1.5,'LineStyle','--')
set(h(3),'Color',[0 0 0.7],'LineStyle','-','LineWidth',1)
set(h(4),'Color',[0 0.5 0.5],'LineStyle','-','LineWidth',1)
set(h(5),'Color',[0.7 0 0],'LineWidth',1.5,'LineStyle','-')
weight_white = 0.7;     % proportion of color adjustment towards white
for h_ind = 1:length(h)
    full_color_vec = get(h(h_ind),'Color');
    set(h(h_ind),'Color',(weight_white*[1 1 1]) + (1 - weight_white)*full_color_vec)
end
plot_series_specifiers_allyears = {'sum(T_tend_detailed_terms_anom_array(:,22:23),2)'; 'sum(T_tend_detailed_terms_anom_array(:,24:25),2)'; 'T_tend_detailed_terms_anom_array(:,26)'; 'T_tend_detailed_terms_anom_array(:,27)'; 'T_tend_overall_terms_anom_array(:,6)'};
plot_series_specifiers_composite = {'sum(T_tend_detailed_terms_anom_composite(:,22:23),2)'; 'sum(T_tend_detailed_terms_anom_composite(:,24:25),2)'; 'T_tend_detailed_terms_anom_composite(:,26)'; 'T_tend_detailed_terms_anom_composite(:,27)'; 'T_tend_overall_terms_anom_composite(:,6)'};
hold on
h_b = NaN(length(plot_series_specifiers_composite),1);
for n_series = 1:length(plot_series_specifiers_allyears)
    curr_series_for_bootstrap = NaN((365/5) + 3,length(year_nums_for_bootstrap));
%     curr_series_for_bootstrap = NaN((365/5) + 8,length(year_nums_for_bootstrap));
    
    curr_series = eval(plot_series_specifiers_allyears{n_series});
    for year_ind = 1:length(year_nums_for_bootstrap)
        in_curr_year_ind = find((time_inrange >= ((365*(year_nums_for_bootstrap(year_ind))) + (tavg_days/2) - 20)) & (time_inrange <= ((365*(year_nums_for_bootstrap(year_ind) + 1)) + (tavg_days/2) + 20)));
        
        if year_ind == 1
            begin_ind = size(curr_series_for_bootstrap,1) - length(in_curr_year_ind) + span;
            curr_series_for_bootstrap(begin_ind:size(curr_series_for_bootstrap,1),year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
            curr_series_for_bootstrap(1:(begin_ind - 1),year_ind) = curr_series_for_bootstrap(begin_ind,year_ind);
        elseif year_ind == length(year_nums_for_bootstrap)
            end_ind = length(in_curr_year_ind) - span + 1;
            curr_series_for_bootstrap(1:end_ind,year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
            curr_series_for_bootstrap((end_ind + 1):size(curr_series_for_bootstrap,1),year_ind) = curr_series_for_bootstrap(end_ind,year_ind);
        else
            curr_series_for_bootstrap(:,year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
        end
    end
    
    curr_series_bootstrap_avg = NaN((365/5) + 3,n_bootstrap);
    for n_bstrap = 1:n_bootstrap
        curr_bstrap_year_ind = bootstrap_random_year_ind(:,n_bstrap);
        
        curr_series_bootstrap_avg(:,n_bstrap) = mean(curr_series_for_bootstrap(:,curr_bstrap_year_ind),2);
    end
    
    curr_series_bootstrap_sorted = sort(curr_series_bootstrap_avg,2,'ascend');
    
    curr_series_bootstrap_2p5_97p5_bounds = (interp1(cdf_vec,curr_series_bootstrap_sorted',[0.025; 0.975]))';
    curr_series_bootstrap_5_95_bounds = (interp1(cdf_vec,curr_series_bootstrap_sorted',[0.05; 0.95]))';
    
    curr_color_vec = get(h(n_series),'Color');
    curr_linestyle = get(h(n_series),'LineStyle');
    curr_linewidth = get(h(n_series),'LineWidth');
    curr_ydata = get(h(n_series),'YData');
    
%     h_e = errorbar(time_inyear_smoothed,curr_ydata,86400*curr_series_bootstrap_2p5_97p5_bounds(:,2),86400*curr_series_bootstrap_2p5_97p5_bounds(:,1));
%     set(h_e,'Color',curr_color,'LineWidth',curr_linewidth)
    
    weight_white_reverse = -weight_white/(1 - weight_white);
    full_color_vec = (weight_white_reverse*[1 1 1]) + (1 - weight_white_reverse)*curr_color_vec;
    curr_series_bootstrap_test = eval(['smooth_endclip(',plot_series_specifiers_composite{n_series},',span)']);
    
    curr_h_ydata = get(h(n_series),'YData');
    outside_range_ind = find((curr_series_bootstrap_test < curr_series_bootstrap_5_95_bounds(:,1)) | (curr_series_bootstrap_test > curr_series_bootstrap_5_95_bounds(:,2)));
    outside_range_no_transition_ind = intersect(intersect(outside_range_ind - 1,outside_range_ind),outside_range_ind + 1);
    curr_h_ydata(outside_range_no_transition_ind) = NaN;
    set(h(n_series),'YData',curr_h_ydata)
    
    curr_series_bootstrap_test((curr_series_bootstrap_test >= curr_series_bootstrap_5_95_bounds(:,1)) & (curr_series_bootstrap_test <= curr_series_bootstrap_5_95_bounds(:,2))) = NaN;
    h_b(n_series) = line(time_inyear_smoothed,86400*curr_series_bootstrap_test,'Color',full_color_vec,'LineStyle',curr_linestyle,'LineWidth',curr_linewidth + 1);
    
end

% set(gca,'ylim',[-0.15 0.15])
xlim_bounds = [0 365];
% set(gca,'xlim',xlim_bounds,'xtick',time_date_label,'xticklabel',date_label)
set(gca,'xlim',xlim_bounds,'xtick',time_date_label,'xticklabel',date_label,'FontSize',14)
set(gca,'ylim',[-0.05 0.05],'ytick',(-0.05):0.01:0.05)
line(xlim_bounds,[0 0],[0 0],'Color','k','LineStyle','-','LineWidth',0.5)
hold off
ylabel('Temp. tendency anomaly ( ^{o}C day^{-1})')
% legend('Net shortwave rad.','Net longwave rad.','Latent heat flux','Sensible heat flux','Total sfc. tend. mean','Location','northwest')
% legend(h_b,'Net shortwave rad.','Net longwave rad.','Latent heat flux','Sensible heat flux','Total sfc. tend. anom.','Location','eastoutside')
legend(h,'Net shortwave rad.','Net longwave rad.','Latent heat flux','Sensible heat flux','Total sfc. tend. anom.','Location','eastoutside')
title({'Contributions to the composite temp. tendency anomaly from surface flux components:'; region_desc},'FontSize',10)

saveas(fig15,['Java_temp_budget_T_tend_anom_pIOD_composite_from_sfc_fluxes_',file_end,'.pdf'])
close(fig15)



var_depth_vol_flux_top_anom_composite = adv_vol_flux_N_sloping_top_anom_composite + adv_vol_flux_W_sloping_top_anom_composite + adv_vol_flux_S_sloping_top_anom_composite + adv_vol_flux_E_sloping_top_anom_composite + ent_vol_flux_top_anom_composite;
var_depth_vol_flux_bottom_anom_composite = adv_vol_flux_N_sloping_bottom_anom_composite + adv_vol_flux_W_sloping_bottom_anom_composite + adv_vol_flux_S_sloping_bottom_anom_composite + adv_vol_flux_E_sloping_bottom_anom_composite + ent_vol_flux_bottom_anom_composite;

fig17 = figure(17);
fig17_paper_pos = get(fig17,'PaperPosition');
fig17_paper_pos(3) = 1.8*fig17_paper_pos(4);
fig17_paper_pos(3:4) = 0.8*fig17_paper_pos(3:4);
set(fig17,'PaperPosition',fig17_paper_pos)
% h = plot(time_inyear_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_N_anom_composite,span),time_inyear_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_W_anom_composite,span),time_inyear_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_S_anom_composite,span),time_inyear_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_E_anom_composite,span),time_inyear_smoothed,(1e-12)*(smooth_endclip(-adv_vol_flux_top_anom_composite,span) + smooth_endclip(-var_depth_vol_flux_top_anom_composite,span) + smooth_endclip(-ent_vol_flux_top_anom_composite,span)),time_inyear_smoothed,(1e-12)*(smooth_endclip(-adv_vol_flux_bottom_anom_composite,span) + smooth_endclip(-var_depth_vol_flux_bottom_anom_composite,span)),time_inyear_smoothed,(1e-12)*(smooth_endclip(-ent_vol_flux_top_anom_composite,span) + smooth_endclip(-ent_vol_flux_bottom_anom_composite,span)));
% h = plot(time_inyear_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_N_anom_composite,span),time_inyear_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_W_anom_composite,span),time_inyear_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_S_anom_composite,span),time_inyear_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_E_anom_composite,span),time_inyear_smoothed,(1e-12)*(smooth_endclip(-adv_vol_flux_top_anom_composite,span) + smooth_endclip(-var_depth_vol_flux_top_anom_composite,span)),time_inyear_smoothed,(1e-12)*(smooth_endclip(-adv_vol_flux_bottom_anom_composite,span) + smooth_endclip(-var_depth_vol_flux_bottom_anom_composite,span)),time_inyear_smoothed,(1e-12)*(smooth_endclip(-ent_vol_flux_top_anom_composite,span) + smooth_endclip(-ent_vol_flux_bottom_anom_composite,span)));
h = plot(time_inyear_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_N_anom_composite,span),time_inyear_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_S_anom_composite,span),time_inyear_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_E_anom_composite,span),time_inyear_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_W_anom_composite,span),time_inyear_smoothed,(1e-12)*(smooth_endclip(-adv_vol_flux_top_anom_composite,span) + smooth_endclip(-var_depth_vol_flux_top_anom_composite,span)),time_inyear_smoothed,(1e-12)*(smooth_endclip(-adv_vol_flux_bottom_anom_composite,span) + smooth_endclip(-var_depth_vol_flux_bottom_anom_composite,span)),time_inyear_smoothed,(1e-12)*(smooth_endclip(-ent_vol_flux_top_anom_composite,span) + smooth_endclip(-ent_vol_flux_bottom_anom_composite,span)));
set(h(1),'Color',[0 0.8 0.5],'LineStyle','-','LineWidth',1)
set(h(2),'Color',[0.5 0 0.5],'LineStyle','-','LineWidth',1)
% set(h(3),'Color',[0.7 0 0],'LineStyle','--','LineWidth',1)
% set(h(4),'Color',[0 0.4 0.2],'LineStyle','--','LineWidth',1)
% set(h(5),'LineStyle','-.','LineWidth',1)
% set(h(6),'Color',[0 0 0.4],'LineStyle','-.','LineWidth',1)
set(h(3),'Color',[0.7 0 0],'LineStyle','-','LineWidth',1)
set(h(4),'Color',[0 0.4 0.2],'LineStyle','-','LineWidth',1)
set(h(5),'LineStyle','-','LineWidth',1)
set(h(6),'Color',[0 0 0.4],'LineStyle','-','LineWidth',1)
set(h(7),'Color','k','LineWidth',1.5)
weight_white = 0.7;     % proportion of color adjustment towards white
for h_ind = 1:length(h)
    full_color_vec = get(h(h_ind),'Color');
    set(h(h_ind),'Color',(weight_white*[1 1 1]) + (1 - weight_white)*full_color_vec)
end
plot_series_specifiers_allyears = {'-vol_flux_anom_array(:,1)'; '-vol_flux_anom_array(:,3)'; '-vol_flux_anom_array(:,4)'; '-vol_flux_anom_array(:,2)'; '-sum(vol_flux_anom_array(:,[5; (7:1:10)'']),2)'; '-sum(vol_flux_anom_array(:,[6; (11:1:14)'']),2)'; '-sum(vol_flux_anom_array(:,15:16),2)'};
plot_series_specifiers_composite = {'-vol_flux_anom_composite(:,1)'; '-vol_flux_anom_composite(:,3)'; '-vol_flux_anom_composite(:,4)'; '-vol_flux_anom_composite(:,2)'; '-sum(vol_flux_anom_composite(:,[5; (7:1:10)'']),2)'; '-sum(vol_flux_anom_composite(:,[6; (11:1:14)'']),2)'; '-sum(vol_flux_anom_composite(:,15:16),2)'};
hold on
h_b = NaN(length(plot_series_specifiers_composite),1);
for n_series = 1:length(plot_series_specifiers_allyears)
    curr_series_for_bootstrap = NaN((365/5) + 3,length(year_nums_for_bootstrap));
    
    curr_series = eval(plot_series_specifiers_allyears{n_series});
    for year_ind = 1:length(year_nums_for_bootstrap)
        in_curr_year_ind = find((time_inrange >= ((365*(year_nums_for_bootstrap(year_ind))) + (tavg_days/2) - 20)) & (time_inrange <= ((365*(year_nums_for_bootstrap(year_ind) + 1)) + (tavg_days/2) + 20)));
        
        if year_ind == 1
            begin_ind = size(curr_series_for_bootstrap,1) - length(in_curr_year_ind) + span;
            curr_series_for_bootstrap(begin_ind:size(curr_series_for_bootstrap,1),year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
            curr_series_for_bootstrap(1:(begin_ind - 1),year_ind) = curr_series_for_bootstrap(begin_ind,year_ind);
        elseif year_ind == length(year_nums_for_bootstrap)
            end_ind = length(in_curr_year_ind) - span + 1;
            curr_series_for_bootstrap(1:end_ind,year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
            curr_series_for_bootstrap((end_ind + 1):size(curr_series_for_bootstrap,1),year_ind) = curr_series_for_bootstrap(end_ind,year_ind);
        else
            curr_series_for_bootstrap(:,year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
        end
    end
    
    curr_series_bootstrap_avg = NaN((365/5) + 3,n_bootstrap);
    for n_bstrap = 1:n_bootstrap
        curr_bstrap_year_ind = bootstrap_random_year_ind(:,n_bstrap);
        
        curr_series_bootstrap_avg(:,n_bstrap) = mean(curr_series_for_bootstrap(:,curr_bstrap_year_ind),2);
    end
    
    curr_series_bootstrap_sorted = sort(curr_series_bootstrap_avg,2,'ascend');
    
    curr_series_bootstrap_2p5_97p5_bounds = (interp1(cdf_vec,curr_series_bootstrap_sorted',[0.025; 0.975]))';
    curr_series_bootstrap_5_95_bounds = (interp1(cdf_vec,curr_series_bootstrap_sorted',[0.05; 0.95]))';
    
    curr_color_vec = get(h(n_series),'Color');
    curr_linestyle = get(h(n_series),'LineStyle');
    curr_linewidth = get(h(n_series),'LineWidth');
    curr_ydata = get(h(n_series),'YData');
    
%     h_e = errorbar(time_inyear_smoothed,curr_ydata,(1e-12)*curr_series_bootstrap_2p5_97p5_bounds(:,2),(1e-12)*curr_series_bootstrap_2p5_97p5_bounds(:,1));
%     set(h_e,'Color',curr_color,'LineWidth',curr_linewidth)
    
    weight_white_reverse = -weight_white/(1 - weight_white);
    full_color_vec = (weight_white_reverse*[1 1 1]) + (1 - weight_white_reverse)*curr_color_vec;
    curr_series_bootstrap_test = eval(['smooth_endclip(',plot_series_specifiers_composite{n_series},',span)']);
    
    curr_h_ydata = get(h(n_series),'YData');
    outside_range_ind = find((curr_series_bootstrap_test < curr_series_bootstrap_5_95_bounds(:,1)) | (curr_series_bootstrap_test > curr_series_bootstrap_5_95_bounds(:,2)));
    outside_range_no_transition_ind = intersect(intersect(outside_range_ind - 1,outside_range_ind),outside_range_ind + 1);
    curr_h_ydata(outside_range_no_transition_ind) = NaN;
    set(h(n_series),'YData',curr_h_ydata)
    
    curr_series_bootstrap_test((curr_series_bootstrap_test >= curr_series_bootstrap_5_95_bounds(:,1)) & (curr_series_bootstrap_test <= curr_series_bootstrap_5_95_bounds(:,2))) = NaN;
    h_b(n_series) = line(time_inyear_smoothed,(1e-12)*curr_series_bootstrap_test,'Color',full_color_vec,'LineStyle',curr_linestyle,'LineWidth',curr_linewidth + 1);
    
end

% xlim_bounds = [(min(time_inrange) - (tavg_days/2)) (max(time_inrange) + (tavg_days/2))];
xlim_bounds = [0 365];
set(gca,'xlim',xlim_bounds,'xtick',time_date_label,'xticklabel',date_label,'FontSize',14)
set(gca,'ylim',[-4 4],'ytick',(-4):1:4)
hold on
line(xlim_bounds,[0 0],[0 0],'Color','k','LineStyle','-','LineWidth',0.5)
hold off
ylabel('Volume flux anomaly (Sv)')
% legend('North flux','West flux','South flux','East flux','Top flux','Bottom flux','Net vol. change','Location','southwest')
% legend(h_b,'North flux','South flux','East flux','West flux','Top flux','Bottom flux','Vol. change anom.','Location','eastoutside')
legend(h,'North flux','South flux','East flux','West flux','Top flux','Bottom flux','Vol. change ','Location','eastoutside')
% title(['Composite volume flux into each side of the region: ',region_desc])
title(['Composite volume flux anomaly into each side of the region: ',region_desc],'FontSize',10)

saveas(fig17,['Java_temp_budget_vol_fluxes_anom_pIOD_composite_',file_end,'.pdf'])
close(fig17)



% plot the directional advective tendency components - seasonal cycle & anomalies

fig19 = figure(19);
fig19_paper_pos = get(fig19,'PaperPosition');
% fig19_paper_pos(3) = 1.5*fig19_paper_pos(4);
fig19_paper_pos(3) = 1.8*fig19_paper_pos(4);
fig19_paper_pos(3:4) = 0.8*fig19_paper_pos(3:4);
set(fig19,'PaperPosition',fig19_paper_pos)
% h = plot(time_inyear_smoothed,86400*smooth_endclip(adv_T_tend_N_edge_anom_composite,span),time_inyear_smoothed,86400*smooth_endclip(adv_T_tend_W_edge_anom_composite,span),time_inyear_smoothed,86400*smooth_endclip(adv_T_tend_S_edge_anom_composite,span),time_inyear_smoothed,86400*smooth_endclip(adv_T_tend_E_edge_anom_composite,span),time_inyear_smoothed,86400*(smooth_endclip(adv_T_tend_top_edge_anom_composite,span) + smooth_endclip(var_depth_adv_T_tend_top_anom_composite,span)),time_inyear_smoothed,86400*(smooth_endclip(adv_T_tend_bottom_edge_anom_composite,span) + smooth_endclip(var_depth_adv_T_tend_bottom_anom_composite,span)),time_inyear_smoothed,86400*smooth_endclip(adv_T_tend_total_anom_composite,span));
h = plot(time_inyear_smoothed,86400*smooth_endclip(adv_T_tend_N_edge_anom_composite,span),time_inyear_smoothed,86400*smooth_endclip(adv_T_tend_S_edge_anom_composite,span),time_inyear_smoothed,86400*smooth_endclip(adv_T_tend_E_edge_anom_composite,span),time_inyear_smoothed,86400*smooth_endclip(adv_T_tend_W_edge_anom_composite,span),time_inyear_smoothed,86400*(smooth_endclip(adv_T_tend_top_edge_anom_composite,span) + smooth_endclip(var_depth_adv_T_tend_top_anom_composite,span)),time_inyear_smoothed,86400*(smooth_endclip(adv_T_tend_bottom_edge_anom_composite,span) + smooth_endclip(var_depth_adv_T_tend_bottom_anom_composite,span)),time_inyear_smoothed,86400*smooth_endclip(adv_T_tend_total_anom_composite,span));
set(h(1),'Color',[0 0.8 0.5],'LineStyle','-','LineWidth',1)
set(h(2),'Color',[0.5 0 0.5],'LineStyle','-','LineWidth',1)
% set(h(3),'Color',[0.7 0 0],'LineStyle','--','LineWidth',1)
% set(h(4),'Color',[0 0.4 0.2],'LineStyle','--','LineWidth',1)
% set(h(5),'LineStyle','-.','LineWidth',1)
% set(h(6),'Color',[0 0 0.4],'LineStyle','-.','LineWidth',1)
set(h(3),'Color',[0.7 0 0],'LineStyle','-','LineWidth',1)
set(h(4),'Color',[0 0.4 0.2],'LineStyle','-','LineWidth',1)
set(h(5),'LineStyle','-','LineWidth',1)
set(h(6),'Color',[0 0 0.4],'LineStyle','-','LineWidth',1)
set(h(7),'Color',[0 0 1],'LineWidth',1.5)
weight_white = 0.7;     % proportion of color adjustment towards white
for h_ind = 1:length(h)
    full_color_vec = get(h(h_ind),'Color');
    set(h(h_ind),'Color',(weight_white*[1 1 1]) + (1 - weight_white)*full_color_vec)
end
plot_series_specifiers_allyears = {'T_tend_detailed_terms_anom_array(:,1)'; 'T_tend_detailed_terms_anom_array(:,3)'; 'T_tend_detailed_terms_anom_array(:,4)'; 'T_tend_detailed_terms_anom_array(:,2)'; 'sum(T_tend_detailed_terms_anom_array(:,[5; 7]),2)'; 'sum(T_tend_detailed_terms_anom_array(:,[6; 8]),2)'; 'T_tend_overall_terms_anom_array(:,1)'};
plot_series_specifiers_composite = {'T_tend_detailed_terms_anom_composite(:,1)'; 'T_tend_detailed_terms_anom_composite(:,3)'; 'T_tend_detailed_terms_anom_composite(:,4)'; 'T_tend_detailed_terms_anom_composite(:,2)'; 'sum(T_tend_detailed_terms_anom_composite(:,[5; 7]),2)'; 'sum(T_tend_detailed_terms_anom_composite(:,[6; 8]),2)'; 'T_tend_overall_terms_anom_composite(:,1)'};
hold on
h_b = NaN(length(plot_series_specifiers_composite),1);
for n_series = 1:length(plot_series_specifiers_allyears)
    curr_series_for_bootstrap = NaN((365/5) + 3,length(year_nums_for_bootstrap));
    
    curr_series = eval(plot_series_specifiers_allyears{n_series});
    for year_ind = 1:length(year_nums_for_bootstrap)
        in_curr_year_ind = find((time_inrange >= ((365*(year_nums_for_bootstrap(year_ind))) + (tavg_days/2) - 20)) & (time_inrange <= ((365*(year_nums_for_bootstrap(year_ind) + 1)) + (tavg_days/2) + 20)));
        
        if year_ind == 1
            begin_ind = size(curr_series_for_bootstrap,1) - length(in_curr_year_ind) + span;
            curr_series_for_bootstrap(begin_ind:size(curr_series_for_bootstrap,1),year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
            curr_series_for_bootstrap(1:(begin_ind - 1),year_ind) = curr_series_for_bootstrap(begin_ind,year_ind);
        elseif year_ind == length(year_nums_for_bootstrap)
            end_ind = length(in_curr_year_ind) - span + 1;
            curr_series_for_bootstrap(1:end_ind,year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
            curr_series_for_bootstrap((end_ind + 1):size(curr_series_for_bootstrap,1),year_ind) = curr_series_for_bootstrap(end_ind,year_ind);
        else
            curr_series_for_bootstrap(:,year_ind) = smooth_endclip(curr_series(in_curr_year_ind),span);
        end
    end
    
    curr_series_bootstrap_avg = NaN((365/5) + 3,n_bootstrap);
    for n_bstrap = 1:n_bootstrap
        curr_bstrap_year_ind = bootstrap_random_year_ind(:,n_bstrap);
        
        curr_series_bootstrap_avg(:,n_bstrap) = mean(curr_series_for_bootstrap(:,curr_bstrap_year_ind),2);
    end
    
    curr_series_bootstrap_sorted = sort(curr_series_bootstrap_avg,2,'ascend');
    
    curr_series_bootstrap_2p5_97p5_bounds = (interp1(cdf_vec,curr_series_bootstrap_sorted',[0.025; 0.975]))';
    curr_series_bootstrap_5_95_bounds = (interp1(cdf_vec,curr_series_bootstrap_sorted',[0.05; 0.95]))';
    
    curr_color_vec = get(h(n_series),'Color');
    curr_linestyle = get(h(n_series),'LineStyle');
    curr_linewidth = get(h(n_series),'LineWidth');
    curr_ydata = get(h(n_series),'YData');
    
%     h_e = errorbar(time_inyear_smoothed,curr_ydata,86400*curr_series_bootstrap_2p5_97p5_bounds(:,2),86400*curr_series_bootstrap_2p5_97p5_bounds(:,1));
%     set(h_e,'Color',curr_color,'LineWidth',curr_linewidth)
    
    weight_white_reverse = -weight_white/(1 - weight_white);
    full_color_vec = (weight_white_reverse*[1 1 1]) + (1 - weight_white_reverse)*curr_color_vec;
    curr_series_bootstrap_test = eval(['smooth_endclip(',plot_series_specifiers_composite{n_series},',span)']);
    
    curr_h_ydata = get(h(n_series),'YData');
    outside_range_ind = find((curr_series_bootstrap_test < curr_series_bootstrap_5_95_bounds(:,1)) | (curr_series_bootstrap_test > curr_series_bootstrap_5_95_bounds(:,2)));
    outside_range_no_transition_ind = intersect(intersect(outside_range_ind - 1,outside_range_ind),outside_range_ind + 1);
    curr_h_ydata(outside_range_no_transition_ind) = NaN;
    set(h(n_series),'YData',curr_h_ydata)
    
    curr_series_bootstrap_test((curr_series_bootstrap_test >= curr_series_bootstrap_5_95_bounds(:,1)) & (curr_series_bootstrap_test <= curr_series_bootstrap_5_95_bounds(:,2))) = NaN;
    h_b(n_series) = line(time_inyear_smoothed,86400*curr_series_bootstrap_test,'Color',full_color_vec,'LineStyle',curr_linestyle,'LineWidth',curr_linewidth + 1);
    
end

xlim_bounds = [0 365];
set(gca,'xlim',xlim_bounds,'xtick',time_date_label,'xticklabel',date_label,'FontSize',14)
set(gca,'ylim',[-0.05 0.05],'ytick',(-0.05):0.01:0.05)
hold on
line(xlim_bounds,[0 0],[0 0],'Color','k','LineStyle','-','LineWidth',0.5)
hold off
ylabel('Temp. tendency anomaly ( ^{o}C day^{-1})')
% legend('North edge','West edge','South edge','East edge','Top edge','Bottom edge','Total adv. tend. anom.','location','eastoutside')
% legend(h_b,'North edge','South edge','East edge','West edge','Top edge','Bottom edge','Total adv. tend. anom.','location','eastoutside')
legend(h,'North edge','South edge','East edge','West edge','Top edge','Bottom edge','Total adv. tend. anom.','location','eastoutside')
title({'Contributions to the composite advective temp. anomaly from each side of the region:'; region_desc},'FontSize',10)

% saveas(fig19,['Java_temp_budget_T_tend_from_adv_fluxes_anom_pIOD_composite_',file_end,'.pdf'])
saveas(fig19,['Java_temp_budget_T_tend_anom_pIOD_composite_from_adv_fluxes_',file_end,'.pdf'])
close(fig19)
