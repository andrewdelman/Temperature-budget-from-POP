% compute temperature budget for a netCDF output file


% Make sure script is being run from the same directory as these other required functions: inbox_range_ind_seasonal_decomp_fcn.m, temp_budget_inbox_vardepth_calc_seasonal_decomp_fcn.m, and flux_edge_vardepth_calc_fcn.m.  Alternatively, the directory containing these functions can be added to the path before running the script.


% add current directory to path (so function files can be called)
path(path,pwd)

% add plotting scripts folder to path
path(path,'~/plotting_scripts/')

% BEGIN USER-DEFINED OPTIONS

% directory containing model output files (in netCDF format) -- full (not relative) path needs to be specified
source_dir = '/glade/scratch/adelman/POP_1977_start_JC/';
% directory to save figures to -- full (not relative) path needs to be specified
target_dir = '/glade/scratch/adelman/POP_1977_start_JC/';


% source file options
% source_file_option = 1: use the one netCDF source file named in source_nc_filename to compute the budget
% source_file_option = 2: use the multiple netCDF source files named in source_nc_filenames to compute the budget (names must be strings in a cell array, in chronological order)
% source_file_option = 3: use the string source_nc_specifier (can include asterisk wildcard).  All files in the source_dir that match this string will be included in the budget computations.
source_file_option = 2;

if source_file_option == 1
    % model output source file
    source_nc_filename = 'pop.h.nday5.JC.00300105-00301231.nc';
elseif source_file_option == 2
%     % cell array of file names (in chronological order)
%     source_nc_filenames = {'pop.h.nday5.JC.00300105-00301231.nc'; 'pop.h.nday5.JC.00310105-00311231.nc'; 'pop.h.nday5.JC.00320105-00321231.nc'};
    
    source_nc_filenames = {};
    for year_num = 3:1:33
        if year_num < 10
            source_nc_filenames{length(source_nc_filenames) + 1} = ['pop.h.nday5.JC.000',num2str(year_num),'0105-000',num2str(year_num),'1231.nc'];
        else
            source_nc_filenames{length(source_nc_filenames) + 1} = ['pop.h.nday5.JC.00',num2str(year_num),'0105-00',num2str(year_num),'1231.nc'];
        end
    end
elseif source_file_option == 3
    % find file names using specifier
    source_nc_specifier = 'pop.h.nday5.JC.*0105-*1231.nc';
end




% for region_definition_option = 1 only; use (i,j,k) index values automatically in naming of figure files?
% index_naming_option = 1: yes; this supersedes the file_start, file_end, and region_desc options below
% index_naming_option = 2: no, use file_start and file_end to name files
index_naming_option = 1;
if index_naming_option == 1
    run_spec = 'JC';     % identifier used to specify model run
end

% designate name options for generated figures
% file_start = 'Java_temp_budget_2006_2008';    % start of file names for all generated figures
% file_start = 'Sumatra_temp_budget_2006_2008';    % start of file names for all generated figures
% file_start = 'Java_temp_budget_1977_2009';    % start of file names for all generated figures
file_start = 'Java_temp_budget_1983';    % start of file names for all generated figures
file_end = 'ML_JC';    % end of file names for all generated figures
region_desc = 'south of Java, mixed layer, JC run';    % description of region, for figure titles
% region_desc = 'west of Sumatra, mixed layer, JC run';    % description of region, for figure titles


% region definition options
% option 1: define a single cell (i,j,k) to compute the budget for
% option 2: define a range of cells (i_begin:i_end,j_start:j_end,k_start:k_end) to compute the budget for
% % Note: indices are defined for the source file; unless the source file has a global domain, these are NOT the global indices

% option 3: define a region with four corner points to compute the budget for; inputs are lat,lon for the corner points and the region does not need to be rectangular

region_definition_option = 3;

if region_definition_option == 1
    cell_indices = [2198 1104 9];    % [i j k] indices
elseif region_definition_option == 2
    i_index_bounds = [2151 2160];    % [min max] i indices of cells
    j_index_bounds = [1081 1090];    % [min max] j indices of cells
    k_index_bounds = [1 3];          % [min max] k indices of cells
elseif region_definition_option == 3
    
    % define [lat lon] of 4 corners of region
    
%     NE_corner = [-8.55 114.5];
    NE_corner = [-8.65 115.2];
    NW_corner = [-6.65 105.2];
    SW_corner = [-10.0 105.2];
    SE_corner = [-10.0 114.5];
%     NE_corner = [0.0 100.0];
%     NW_corner = [0.0 90.0];
%     SW_corner = [-6.0 95.0];
%     SE_corner = [-6.0 104.7];
%     NE_corner = [-9.7 105.5];
%     NW_corner = [-9.7 105.2];
%     SW_corner = [-10.0 105.2];
%     SE_corner = [-10.0 105.5];
    
    % depth bound option (region_definition_option = 3 only)
    % option 1: define a fixed upper and lower bound (an upper bound of 0 will default to the spatially & temporally-varying height surface)
    % option 2: define spatially & temporally-varying upper and lower bounds (later in the code)
    depth_bound_option = 2;
    
    if depth_bound_option == 1
        depth_bounds = [0 50];       % fixed depth bounds [upper lower], in meters
    end
    
end



% time bound options
% option 1: compute budget for all times in the source file
% option 2: specify time bounds to compute budget for (bounds must be in the same units as the times archived in the source file(s)!)
time_bound_option = 2;

if time_bound_option == 2
%     time_bounds = [(365*30) (365*33)] + 2.5;
    time_bounds = [((365*7) - 15 - 5) ((365*8) + 15 + 5)] + 2.5;
end


% entrainment computation options
% option 1: do not compute entrainment term in the tendency (this option is best for checking whether the budget balances)
% option 2: compute entrainment term, as the residual between the sum of the other budget terms and the actual temperature change
entrainment_computation_option = 2;


% origin of time scale (year that the archived time variable is counted from)
% e.g., if time variable is in units of "days from 1970-01-01 00:00:00", then time_year_origin = 1970
time_year_origin = 0;

% time year offset (This applies to the Johnson/Carton run, where year 1 has CORE forcing from 1977, thus time_year_offset = 1976.  Otherwise time_year_offset = 0.)
time_year_offset = 1976;

% time period averaging, in days
tavg_days = 5;

% time period for plot smoothing, in days (must be a multiple of tavg_days)
t_plot_smooth_days = 30;

% grid resolution (in degrees, approximate)
grid_res = 0.1;


% END OF USER-DEFINED OPTIONS
% (except for user-defined variable depth bounds, if region_definition_option = 3 and depth_bound_option = 2; see approximately lines 185-186 to set these)


% change current directory to target directory for output figures
cd(target_dir)



% use these to overwrite pre-saved fields when loading from .mat file

file_start_new = file_start;
file_end_new = file_end;
region_desc_new = region_desc;
time_bounds_new = time_bounds;



% START COMMENTING HERE IF LOADING FROM .MAT FILE

% define cell array of source filenames (if source_file_option = 1 or 3)
if source_file_option == 1
    source_nc_filenames = {source_nc_filename};
elseif source_file_option == 3
    curr_dir = pwd;
    cd(source_dir)
    source_nc_cell_array = struct2cell(dir(source_nc_specifier));
    source_nc_filenames = (source_nc_cell_array(1,:))';
    
    cd(curr_dir)
end


% file name(s) of source .nc file(s), with path
source_nc_filenames_with_path = cell(size(source_nc_filenames));
for file_num = 1:length(source_nc_filenames)
    source_nc_filenames_with_path{file_num} = [source_dir,source_nc_filenames{file_num}];
end

% pull basic coordinate information from source file where needed

if ((region_definition_option == 1) || (region_definition_option == 2))
    ulat = ncread(source_nc_filename_with_path,'ULAT');
    ulon = ncread(source_nc_filename_with_path,'ULONG');
    
    if region_definition_option == 1
        NE_corner = [ulat(cell_indices(1),cell_indices(2)) ulon(cell_indices(1),cell_indices(2))];
        NW_corner = [ulat(cell_indices(1) - 1,cell_indices(2)) ulon(cell_indices(1) - 1,cell_indices(2))];
        SW_corner = [ulat(cell_indices(1) - 1,cell_indices(2) - 1) ulon(cell_indices(1) - 1,cell_indices(2) - 1)];
        SE_corner = [ulat(cell_indices(1),cell_indices(2) - 1) ulon(cell_indices(1),cell_indices(2) - 1)];
    elseif region_definition_option == 2
        NE_corner = [ulat(i_index_bounds(2),j_index_bounds(2)) ulon(i_index_bounds(2),j_index_bounds(2))];
        NW_corner = [ulat(i_index_bounds(1) - 1,j_index_bounds(2)) ulon(i_index_bounds(1) - 1,j_index_bounds(2))];
        SW_corner = [ulat(i_index_bounds(1) - 1,j_index_bounds(1) - 1) ulon(i_index_bounds(1) - 1,j_index_bounds(1) - 1)];
        SE_corner = [ulat(i_index_bounds(2),j_index_bounds(1) - 1) ulon(i_index_bounds(2),j_index_bounds(1) - 1)];
    end
    
end


% implement index_naming_option, if set to 1
if ((region_definition_option == 1) && (index_naming_option == 1))
    file_start = ['Temp_budget_i_',num2str(cell_indices(1)),'_j_',num2str(cell_indices(2)),'_k_',num2str(cell_indices(3))];
    file_end = run_spec;
    
    tlat = ncread(source_nc_filename_with_path,'TLAT');
    tlon = ncread(source_nc_filename_with_path,'TLONG');
    z_t = ncread(source_nc_filename_with_path,'z_t');
    
    region_desc = ['cell nearest to ',num2str(round(tlat(cell_indices(1),cell_indices(2))/0.05)*0.05),' deg lat, ',num2str(round(tlon(cell_indices(1),cell_indices(2))/0.05)*0.05),' deg lon, ',num2str(round(z_t(cell_indices(3))/100)),' m depth'];
    
end


% if time_bound_option == 1
time_source_files = [];
for file_num = 1:length(source_nc_filenames_with_path)
    time_curr_source_file = ncread(source_nc_filenames_with_path{file_num},'time');
    time_source_files = [time_source_files; time_curr_source_file];
end

time_all_bounds = [(min(time_source_files) - (tavg_days/2)) (max(time_source_files) + (tavg_days/2))];
if time_bound_option == 1
    time_bounds = time_all_bounds;
end
% end



% find indices to pull all of the budget terms for, and extract mixed/boundary layer depths in case they are needed to define region
[lon_ind_inrange,lat_ind_inrange,unique_time_ind,time_ind_inrange,mean_ML_depth,mean_BL_depth,min_BL_depth,max_BL_depth] = inbox_range_ind_seasonal_decomp_fcn(source_nc_filenames_with_path,NE_corner,NW_corner,SW_corner,SE_corner,time_bounds);

z_w_top = ncread(source_nc_filenames_with_path{1},'z_w_top');
z_w_bot = ncread(source_nc_filenames_with_path{1},'z_w_bot');



% create depth bound arrays

% for region_definition_option = 1 or 2
if region_definition_option == 1
    top_depth_bound_array = (z_w_top(cell_indices(3)))*ones(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
    bottom_depth_bound_array = (z_w_bot(cell_indices(3)))*ones(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
elseif region_definition_option == 2
    top_depth_bound_array = (z_w_top(k_index_bounds(1)))*ones(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
    bottom_depth_bound_array = (z_w_bot(k_index_bounds(2)))*ones(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
end

% for region_definition_option = 3
if region_definition_option == 3

    % set depth bound arrays based on earlier-defined fixed depths (if depth_bound_option = 1 was selected)
    
    if depth_bound_option == 1
        top_depth_bound_array = (100*depth_bounds(1))*ones(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
        bottom_depth_bound_array = (100*depth_bounds(2))*ones(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
    end
    
    % USER-DEFINED layer bounds (if depth_bound_option = 2 was selected)
    
    if depth_bound_option == 2
        top_depth_bound_array = 0*ones(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
        bottom_depth_bound_array = mean_ML_depth;    % this sets bottom depth bound to the mixed layer base
%         bottom_depth_bound_array = repmat(mean_ML_depth(:,:,1),[1 1 length(unique_time_ind)]);
        
    end
    
end

save('seasonal_decomp.mat','source*with_path','*_corner','*_ind_inrange','*_depth_bound_array','time_all_bounds','entrainment_computation_option','-v7.3')

% call function to compute the budget for the given cell or region
[time_inrange_modelyr,T_tend_overall_terms_array,T_tend_detailed_terms_array,vardepth_breakdown_terms_array,T_mean_inbox,vol_flux_array,T_tend_overall_terms_mean_array,T_tend_detailed_terms_mean_array,vardepth_breakdown_terms_mean_array,T_mean_inbox_seasonal_mean,vol_flux_mean_array,T_tend_overall_terms_anom_array,T_tend_detailed_terms_anom_array,vardepth_breakdown_terms_anom_array,T_mean_inbox_seasonal_anom,vol_flux_anom_array,adv_T_tend_mean_mean_array,adv_T_tend_mean_anom_array,adv_T_tend_anom_mean_array,adv_T_tend_anom_anom_array] = temp_budget_inbox_vardepth_calc_seasonal_decomp_fcn(source_nc_filenames_with_path,NE_corner,NW_corner,SW_corner,SE_corner,lon_ind_inrange,lat_ind_inrange,top_depth_bound_array,bottom_depth_bound_array,time_all_bounds,entrainment_computation_option);


clear file_start_new file_end_new region_desc_new time_bounds_new

% % save('Java_budget_2006_2008_seasonal_decomp.mat','-v7.3')
% % load('Java_budget_2006_2008_seasonal_decomp.mat')
% % save('Java_budget_13yr_seasonal_decomp.mat','-v7.3')
% % load('Java_budget_13yr_seasonal_decomp.mat')
% % save('Java_budget_1977_2009_seasonal_decomp.mat','-v7.3')
% % load('Java_budget_1977_2009_seasonal_decomp.mat')
% save('Java_budget_1979_2009_seasonal_decomp.mat','-v7.3')
% load('Java_budget_1979_2009_seasonal_decomp.mat')



% overwrite pre-saved values in .mat file
try
    file_start = file_start_new;
    file_end = file_end_new;
    region_desc = region_desc_new;
    time_bounds = time_bounds_new;
end


% subset times for plotting

in_time_range_ind = find((time_inrange_modelyr >= time_bounds(1)) & (time_inrange_modelyr < time_bounds(2)));

time_inrange_modelyr = time_inrange_modelyr(in_time_range_ind);
T_tend_overall_terms_array = T_tend_overall_terms_array(in_time_range_ind,:);
T_tend_detailed_terms_array = T_tend_detailed_terms_array(in_time_range_ind,:);
vardepth_breakdown_terms_array = vardepth_breakdown_terms_array(in_time_range_ind,:);
T_mean_inbox = T_mean_inbox(in_time_range_ind);
vol_flux_array = vol_flux_array(in_time_range_ind,:);
T_tend_overall_terms_mean_array = T_tend_overall_terms_mean_array(in_time_range_ind,:);
T_tend_detailed_terms_mean_array = T_tend_detailed_terms_mean_array(in_time_range_ind,:);
vardepth_breakdown_terms_mean_array = vardepth_breakdown_terms_mean_array(in_time_range_ind,:);
T_mean_inbox_seasonal_mean = T_mean_inbox_seasonal_mean(in_time_range_ind);
vol_flux_mean_array = vol_flux_mean_array(in_time_range_ind,:);
T_tend_overall_terms_anom_array = T_tend_overall_terms_anom_array(in_time_range_ind,:);
T_tend_detailed_terms_anom_array = T_tend_detailed_terms_anom_array(in_time_range_ind,:);
vardepth_breakdown_terms_anom_array = vardepth_breakdown_terms_anom_array(in_time_range_ind,:);
T_mean_inbox_seasonal_anom = T_mean_inbox_seasonal_anom(in_time_range_ind);
vol_flux_anom_array = vol_flux_anom_array(in_time_range_ind,:);
adv_T_tend_mean_mean_array = adv_T_tend_mean_mean_array(in_time_range_ind,:);
adv_T_tend_mean_anom_array = adv_T_tend_mean_anom_array(in_time_range_ind,:);
adv_T_tend_anom_mean_array = adv_T_tend_anom_mean_array(in_time_range_ind,:);
adv_T_tend_anom_anom_array = adv_T_tend_anom_anom_array(in_time_range_ind,:);



% perform needed time adjustments
time_inrange_modelyr = time_inrange_modelyr - (tavg_days/2);
time_inrange = time_inrange_modelyr + (365*time_year_offset);


% extract individual budget terms and volume fluxes from arrays

adv_T_tend_total = T_tend_overall_terms_array(:,1);
hdiff_T_tend_total = T_tend_overall_terms_array(:,2);
ent_T_tend_total = T_tend_overall_terms_array(:,3);
diab_vert_T_tend = T_tend_overall_terms_array(:,4);
kpp_src_T_tend = T_tend_overall_terms_array(:,5);
sfc_flux_T_tend = T_tend_overall_terms_array(:,6);
if size(T_tend_overall_terms_array,2) > 6
    total_T_tend = T_tend_overall_terms_array(:,7);
end

adv_T_tend_N_edge = T_tend_detailed_terms_array(:,1);
adv_T_tend_W_edge = T_tend_detailed_terms_array(:,2);
adv_T_tend_S_edge = T_tend_detailed_terms_array(:,3);
adv_T_tend_E_edge = T_tend_detailed_terms_array(:,4);
adv_T_tend_top_edge = T_tend_detailed_terms_array(:,5);
adv_T_tend_bottom_edge = T_tend_detailed_terms_array(:,6);
var_depth_adv_T_tend_top = T_tend_detailed_terms_array(:,7);
var_depth_adv_T_tend_bottom = T_tend_detailed_terms_array(:,8);
hdiff_T_tend_N_edge = T_tend_detailed_terms_array(:,9);
hdiff_T_tend_W_edge = T_tend_detailed_terms_array(:,10);
hdiff_T_tend_S_edge = T_tend_detailed_terms_array(:,11);
hdiff_T_tend_E_edge = T_tend_detailed_terms_array(:,12);
hdiff_T_tend_top_edge = T_tend_detailed_terms_array(:,13);
hdiff_T_tend_bottom_edge = T_tend_detailed_terms_array(:,14);
var_depth_hdiff_T_tend_top = T_tend_detailed_terms_array(:,15);
var_depth_hdiff_T_tend_bottom = T_tend_detailed_terms_array(:,16);
ent_T_tend_top = T_tend_detailed_terms_array(:,17);
ent_T_tend_bottom = T_tend_detailed_terms_array(:,18);
diab_vert_T_tend_top = T_tend_detailed_terms_array(:,19);
diab_vert_T_tend_bottom = T_tend_detailed_terms_array(:,20);
% kpp_src_T_tend = T_tend_detailed_terms_array(:,21);
sw_top_flux_T_tend = T_tend_detailed_terms_array(:,22);
sw_bottom_flux_T_tend = T_tend_detailed_terms_array(:,23);
longwave_downward_flux_T_tend = T_tend_detailed_terms_array(:,24);
longwave_upward_flux_T_tend = T_tend_detailed_terms_array(:,25);
latent_heat_flux_T_tend = T_tend_detailed_terms_array(:,26);
sensible_heat_flux_T_tend = T_tend_detailed_terms_array(:,27);
% total_T_tend = T_tend_detailed_terms_array(:,28);

adv_T_tend_N_sloping_top = vardepth_breakdown_terms_array(:,1);
adv_T_tend_W_sloping_top = vardepth_breakdown_terms_array(:,2);
adv_T_tend_S_sloping_top = vardepth_breakdown_terms_array(:,3);
adv_T_tend_E_sloping_top = vardepth_breakdown_terms_array(:,4);
hdiff_T_tend_N_sloping_top = vardepth_breakdown_terms_array(:,5);
hdiff_T_tend_W_sloping_top = vardepth_breakdown_terms_array(:,6);
hdiff_T_tend_S_sloping_top = vardepth_breakdown_terms_array(:,7);
hdiff_T_tend_E_sloping_top = vardepth_breakdown_terms_array(:,8);
ent_T_tend_top = vardepth_breakdown_terms_array(:,9);
adv_T_tend_N_sloping_bottom = vardepth_breakdown_terms_array(:,10);
adv_T_tend_W_sloping_bottom = vardepth_breakdown_terms_array(:,11);
adv_T_tend_S_sloping_bottom = vardepth_breakdown_terms_array(:,12);
adv_T_tend_E_sloping_bottom = vardepth_breakdown_terms_array(:,13);
hdiff_T_tend_N_sloping_bottom = vardepth_breakdown_terms_array(:,14);
hdiff_T_tend_W_sloping_bottom = vardepth_breakdown_terms_array(:,15);
hdiff_T_tend_S_sloping_bottom = vardepth_breakdown_terms_array(:,16);
hdiff_T_tend_E_sloping_bottom = vardepth_breakdown_terms_array(:,17);
ent_T_tend_bottom = vardepth_breakdown_terms_array(:,18);


adv_vol_flux_N = vol_flux_array(:,1);
adv_vol_flux_W = vol_flux_array(:,2);
adv_vol_flux_S = vol_flux_array(:,3);
adv_vol_flux_E = vol_flux_array(:,4);
adv_vol_flux_top = vol_flux_array(:,5);
adv_vol_flux_bottom = vol_flux_array(:,6);
adv_vol_flux_N_sloping_top = vol_flux_array(:,7);
adv_vol_flux_W_sloping_top = vol_flux_array(:,8);
adv_vol_flux_S_sloping_top = vol_flux_array(:,9);
adv_vol_flux_E_sloping_top = vol_flux_array(:,10);
adv_vol_flux_N_sloping_bottom = vol_flux_array(:,11);
adv_vol_flux_W_sloping_bottom = vol_flux_array(:,12);
adv_vol_flux_S_sloping_bottom = vol_flux_array(:,13);
adv_vol_flux_E_sloping_bottom = vol_flux_array(:,14);
ent_vol_flux_top = vol_flux_array(:,15);
ent_vol_flux_bottom = vol_flux_array(:,16);


adv_T_tend_total_mean = T_tend_overall_terms_mean_array(:,1);
hdiff_T_tend_total_mean = T_tend_overall_terms_mean_array(:,2);
ent_T_tend_total_mean = T_tend_overall_terms_mean_array(:,3);
diab_vert_T_tend_mean = T_tend_overall_terms_mean_array(:,4);
kpp_src_T_tend_mean = T_tend_overall_terms_mean_array(:,5);
sfc_flux_T_tend_mean = T_tend_overall_terms_mean_array(:,6);
if size(T_tend_overall_terms_mean_array,2) > 6
    total_T_tend_mean = T_tend_overall_terms_mean_array(:,7);
end

adv_T_tend_total_anom = T_tend_overall_terms_anom_array(:,1);
hdiff_T_tend_total_anom = T_tend_overall_terms_anom_array(:,2);
ent_T_tend_total_anom = T_tend_overall_terms_anom_array(:,3);
diab_vert_T_tend_anom = T_tend_overall_terms_anom_array(:,4);
kpp_src_T_tend_anom = T_tend_overall_terms_anom_array(:,5);
sfc_flux_T_tend_anom = T_tend_overall_terms_anom_array(:,6);
if size(T_tend_overall_terms_anom_array,2) > 6
    total_T_tend_anom = T_tend_overall_terms_anom_array(:,7);
end


adv_T_tend_N_edge_mean = T_tend_detailed_terms_mean_array(:,1);
adv_T_tend_W_edge_mean = T_tend_detailed_terms_mean_array(:,2);
adv_T_tend_S_edge_mean = T_tend_detailed_terms_mean_array(:,3);
adv_T_tend_E_edge_mean = T_tend_detailed_terms_mean_array(:,4);
adv_T_tend_top_edge_mean = T_tend_detailed_terms_mean_array(:,5);
adv_T_tend_bottom_edge_mean = T_tend_detailed_terms_mean_array(:,6);
var_depth_adv_T_tend_top_mean = T_tend_detailed_terms_mean_array(:,7);
var_depth_adv_T_tend_bottom_mean = T_tend_detailed_terms_mean_array(:,8);

adv_T_tend_N_edge_anom = T_tend_detailed_terms_anom_array(:,1);
adv_T_tend_W_edge_anom = T_tend_detailed_terms_anom_array(:,2);
adv_T_tend_S_edge_anom = T_tend_detailed_terms_anom_array(:,3);
adv_T_tend_E_edge_anom = T_tend_detailed_terms_anom_array(:,4);
adv_T_tend_top_edge_anom = T_tend_detailed_terms_anom_array(:,5);
adv_T_tend_bottom_edge_anom = T_tend_detailed_terms_anom_array(:,6);
var_depth_adv_T_tend_top_anom = T_tend_detailed_terms_anom_array(:,7);
var_depth_adv_T_tend_bottom_anom = T_tend_detailed_terms_anom_array(:,8);

sw_top_flux_T_tend_mean = T_tend_detailed_terms_mean_array(:,22);
sw_bottom_flux_T_tend_mean = T_tend_detailed_terms_mean_array(:,23);
longwave_downward_flux_T_tend_mean = T_tend_detailed_terms_mean_array(:,24);
longwave_upward_flux_T_tend_mean = T_tend_detailed_terms_mean_array(:,25);
latent_heat_flux_T_tend_mean = T_tend_detailed_terms_mean_array(:,26);
sensible_heat_flux_T_tend_mean = T_tend_detailed_terms_mean_array(:,27);

sw_top_flux_T_tend_anom = T_tend_detailed_terms_anom_array(:,22);
sw_bottom_flux_T_tend_anom = T_tend_detailed_terms_anom_array(:,23);
longwave_downward_flux_T_tend_anom = T_tend_detailed_terms_anom_array(:,24);
longwave_upward_flux_T_tend_anom = T_tend_detailed_terms_anom_array(:,25);
latent_heat_flux_T_tend_anom = T_tend_detailed_terms_anom_array(:,26);
sensible_heat_flux_T_tend_anom = T_tend_detailed_terms_anom_array(:,27);


adv_T_tend_mean_mean_N_edge = adv_T_tend_mean_mean_array(:,1);
adv_T_tend_mean_mean_W_edge = adv_T_tend_mean_mean_array(:,2);
adv_T_tend_mean_mean_S_edge = adv_T_tend_mean_mean_array(:,3);
adv_T_tend_mean_mean_E_edge = adv_T_tend_mean_mean_array(:,4);
adv_T_tend_mean_mean_top_edge = adv_T_tend_mean_mean_array(:,5);
adv_T_tend_mean_mean_bottom_edge = adv_T_tend_mean_mean_array(:,6);
var_depth_adv_T_tend_mean_mean_top = sum(adv_T_tend_mean_mean_array(:,7:10),2);
var_depth_adv_T_tend_mean_mean_bottom = sum(adv_T_tend_mean_mean_array(:,11:14),2);
adv_T_tend_mean_mean_total = sum(adv_T_tend_mean_mean_array,2);

adv_T_tend_mean_anom_N_edge = adv_T_tend_mean_anom_array(:,1);
adv_T_tend_mean_anom_W_edge = adv_T_tend_mean_anom_array(:,2);
adv_T_tend_mean_anom_S_edge = adv_T_tend_mean_anom_array(:,3);
adv_T_tend_mean_anom_E_edge = adv_T_tend_mean_anom_array(:,4);
adv_T_tend_mean_anom_top_edge = adv_T_tend_mean_anom_array(:,5);
adv_T_tend_mean_anom_bottom_edge = adv_T_tend_mean_anom_array(:,6);
var_depth_adv_T_tend_mean_anom_top = sum(adv_T_tend_mean_anom_array(:,7:10),2);
var_depth_adv_T_tend_mean_anom_bottom = sum(adv_T_tend_mean_anom_array(:,11:14),2);
adv_T_tend_mean_anom_total = sum(adv_T_tend_mean_anom_array,2);

adv_T_tend_anom_mean_N_edge = adv_T_tend_anom_mean_array(:,1);
adv_T_tend_anom_mean_W_edge = adv_T_tend_anom_mean_array(:,2);
adv_T_tend_anom_mean_S_edge = adv_T_tend_anom_mean_array(:,3);
adv_T_tend_anom_mean_E_edge = adv_T_tend_anom_mean_array(:,4);
adv_T_tend_anom_mean_top_edge = adv_T_tend_anom_mean_array(:,5);
adv_T_tend_anom_mean_bottom_edge = adv_T_tend_anom_mean_array(:,6);
var_depth_adv_T_tend_anom_mean_top = sum(adv_T_tend_anom_mean_array(:,7:10),2);
var_depth_adv_T_tend_anom_mean_bottom = sum(adv_T_tend_anom_mean_array(:,11:14),2);
adv_T_tend_anom_mean_total = sum(adv_T_tend_anom_mean_array,2);

adv_T_tend_anom_anom_N_edge = adv_T_tend_anom_anom_array(:,1);
adv_T_tend_anom_anom_W_edge = adv_T_tend_anom_anom_array(:,2);
adv_T_tend_anom_anom_S_edge = adv_T_tend_anom_anom_array(:,3);
adv_T_tend_anom_anom_E_edge = adv_T_tend_anom_anom_array(:,4);
adv_T_tend_anom_anom_top_edge = adv_T_tend_anom_anom_array(:,5);
adv_T_tend_anom_anom_bottom_edge = adv_T_tend_anom_anom_array(:,6);
var_depth_adv_T_tend_anom_anom_top = sum(adv_T_tend_anom_anom_array(:,7:10),2);
var_depth_adv_T_tend_anom_anom_bottom = sum(adv_T_tend_anom_anom_array(:,11:14),2);
adv_T_tend_anom_anom_total = sum(adv_T_tend_anom_anom_array,2);


adv_vol_flux_mean_N = vol_flux_mean_array(:,1);
adv_vol_flux_mean_W = vol_flux_mean_array(:,2);
adv_vol_flux_mean_S = vol_flux_mean_array(:,3);
adv_vol_flux_mean_E = vol_flux_mean_array(:,4);
adv_vol_flux_mean_top = vol_flux_mean_array(:,5);
adv_vol_flux_mean_bottom = vol_flux_mean_array(:,6);
var_depth_vol_flux_mean_top = sum(vol_flux_mean_array(:,7:10),2);
% var_depth_vol_flux_mean_bottom = sum(vol_flux_mean_array(:,8:14),2);
var_depth_vol_flux_mean_bottom = sum(vol_flux_mean_array(:,11:14),2);
ent_vol_flux_mean_top = vol_flux_mean_array(:,15);
ent_vol_flux_mean_bottom = vol_flux_mean_array(:,16);

adv_vol_flux_anom_N = vol_flux_anom_array(:,1);
adv_vol_flux_anom_W = vol_flux_anom_array(:,2);
adv_vol_flux_anom_S = vol_flux_anom_array(:,3);
adv_vol_flux_anom_E = vol_flux_anom_array(:,4);
adv_vol_flux_anom_top = vol_flux_anom_array(:,5);
adv_vol_flux_anom_bottom = vol_flux_anom_array(:,6);
var_depth_vol_flux_anom_top = sum(vol_flux_anom_array(:,7:10),2);
% var_depth_vol_flux_anom_bottom = sum(vol_flux_anom_array(:,8:14),2);
var_depth_vol_flux_anom_bottom = sum(vol_flux_anom_array(:,11:14),2);
ent_vol_flux_anom_top = vol_flux_anom_array(:,15);
ent_vol_flux_anom_bottom = vol_flux_anom_array(:,16);



% date labels for figures

time_year = floor(time_inrange/365);
min_year = min(time_year);
% max_year = max(time_year);
max_year = floor((time_inrange(length(time_inrange)) + (tavg_days/2))/365);
% if diff(time_bounds) <= 200
if diff(time_bounds) <= 500
    months_to_label = (1:1:12)';
% elseif ((diff(time_bounds) > 200) && (diff(time_bounds) <= 500))
%     months_to_label = (1:2:11)';
elseif ((diff(time_bounds) > 500) && (diff(time_bounds) <= 1200))
    months_to_label = [1; 7];
else
    months_to_label = 1;
end
month_start_vec = [0; 31; 59; 90; 120; 151; 181; 212; 243; 273; 304; 334];
years_in_span = max_year - min_year + 1;
year_array = repmat((min_year:1:max_year),[length(months_to_label) 1]);
month_array = repmat(months_to_label,[1 years_in_span]);
time_date_label = NaN(1,length(months_to_label)*years_in_span);
date_label = cell(1,length(months_to_label)*years_in_span);
for date_label_ind = 1:length(time_date_label)
    time_date_label(date_label_ind) = (365*(year_array(date_label_ind))) + (month_start_vec(months_to_label(mod(date_label_ind - 1,length(months_to_label)) + 1)));
    if month_array(date_label_ind) < 10
        month_str = strcat('0',num2str(month_array(date_label_ind)));
    else
        month_str = num2str(month_array(date_label_ind));
    end
    date_label{date_label_ind} = strcat(num2str(year_array(date_label_ind)),'-',month_str,'-01');
end

% seasonal cycle date labels
time_date_label_seasonal = (365*(year_array(1) + 1)) + month_start_vec;
% date_label_seasonal = {'Jan'; ''; 'Mar'; ''; 'May'; ''; 'Jul'; ''; 'Sep'; ''; 'Nov'; ''};
% date_label_seasonal = {'Jan-01'; ''; 'Mar-01'; ''; 'May-01'; ''; 'Jul-01'; ''; 'Sep-01'; ''; 'Nov-01'; ''};
date_label_seasonal = {'Jan-01'; ''; ''; 'Apr-01'; ''; ''; 'Jul-01'; ''; ''; 'Oct-01'; ''; ''};

% span for smoothing in plots
span = t_plot_smooth_days/tavg_days;

% smoothed time vector
time_inrange_smoothed = smooth_endclip(time_inrange,span);



% create figures

% % plot the advective fluxes
% 
% fig1 = figure(1);
% % plot(time_inrange,86400*adv_T_tend_N_edge,time_inrange,86400*adv_T_tend_W_edge,time_inrange,86400*adv_T_tend_S_edge,time_inrange,86400*adv_T_tend_E_edge,time_inrange,86400*(adv_T_tend_top_edge + var_depth_adv_T_tend_top),time_inrange,86400*(adv_T_tend_bottom_edge + var_depth_adv_T_tend_bottom))
% plot(time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_N_edge,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_W_edge,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_S_edge,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_E_edge,span),time_inrange_smoothed,86400*(smooth_endclip(adv_T_tend_top_edge,span) + smooth_endclip(var_depth_adv_T_tend_top,span)),time_inrange_smoothed,86400*(smooth_endclip(adv_T_tend_bottom_edge,span) + smooth_endclip(var_depth_adv_T_tend_bottom,span)))
% set(gca,'xlim',[(min(time_inrange) - (tavg_days/2)) (max(time_inrange) + (tavg_days/2))],'xtick',time_date_label,'xticklabel',date_label)
% ylabel('Temp. tendency ( ^{o}C day^{-1})')
% legend('North edge','West edge','South edge','East edge','Top edge','Bottom edge')
% title({'Contributions to the advective temp. tendency from each side of the region:'; region_desc})
% 
% saveas(fig1,[file_start,'_T_tend_from_adv_fluxes_',file_end,'.pdf'])
% close(fig1)
% 
% % plot the advective/entrainment fluxes through the bottom bound (if region_definition_option = 3 and depth_bound_option = 2)
% 
% if ((region_definition_option == 3) && (depth_bound_option == 2))
%     fig2 = figure(2);
% %     plot(time_inrange,86400*adv_T_tend_N_sloping_bottom,time_inrange,86400*adv_T_tend_W_sloping_bottom,time_inrange,86400*adv_T_tend_S_sloping_bottom,time_inrange,86400*adv_T_tend_E_sloping_bottom,time_inrange,86400*adv_T_tend_bottom_edge,time_inrange,86400*ent_T_tend_bottom)
%     plot(time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_N_sloping_bottom,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_W_sloping_bottom,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_S_sloping_bottom,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_E_sloping_bottom,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_bottom_edge,span),time_inrange_smoothed,86400*smooth_endclip(ent_T_tend_bottom,span))
%     set(gca,'xlim',[(min(time_inrange) - (tavg_days/2)) (max(time_inrange) + (tavg_days/2))],'xtick',time_date_label,'xticklabel',date_label)
%     ylabel('Temp. tendency ( ^{o}C day^{-1})')
%     legend('North facing vT(dh/dy)','West facing uT(dh/dx)','South facing vT(dh/dy)','East facing uT(dh/dx)','Vertical adv.','Base depth change (ent.)')
%     title({'Contributions to the advective and entrainment temp. tendencies through the bottom bound:'; region_desc})
%     
%     saveas(fig2,[file_start,'_T_tend_from_adv_ent_bottom_',file_end,'.pdf'])
%     close(fig2)
% end
% 
% 
% % plot all the budget terms
% 
% fig3 = figure(3);
% % plot(time_inrange,86400*adv_T_tend_total,time_inrange,86400*ent_T_tend_total,time_inrange,86400*sfc_flux_T_tend,time_inrange,86400*hdiff_T_tend_total,time_inrange,86400*diab_vert_T_tend,time_inrange,86400*kpp_src_T_tend)
% plot(time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_total,span),time_inrange_smoothed,86400*smooth_endclip(ent_T_tend_total,span),time_inrange_smoothed,86400*smooth_endclip(sfc_flux_T_tend,span),time_inrange_smoothed,86400*smooth_endclip(hdiff_T_tend_total,span),time_inrange_smoothed,86400*smooth_endclip(diab_vert_T_tend,span),time_inrange_smoothed,86400*smooth_endclip(kpp_src_T_tend,span))
% set(gca,'xlim',[(min(time_inrange) - (tavg_days/2)) (max(time_inrange) + (tavg_days/2))],'xtick',time_date_label,'xticklabel',date_label)
% ylabel('Temp. tendency ( ^{o}C day^{-1})')
% legend('Advection','Vol. change (ent.)','Surface & shortwave','Horiz. diffusion','Diabatic vert. mixing','Non-local (convective)')
% title({'Contributions to the temperature tendency from various mechanisms:'; region_desc})
% 
% saveas(fig3,[file_start,'_T_tend_all_terms_',file_end,'.pdf'])
% close(fig3)
% 
% 
% % plot the sums of budget terms, actual tavg temp. changes, and archived temp. tendency
% 
% T_tend_sum_terms = adv_T_tend_total + hdiff_T_tend_total + ent_T_tend_total + diab_vert_T_tend + kpp_src_T_tend + sfc_flux_T_tend;
% 
% time_inrange_midpts = time_inrange(2:length(time_inrange)) - (diff(time_inrange)/2);
% 
% time_inrange_midpts_smoothed = smooth_endclip(time_inrange_midpts,span);
% 
% actual_dT_tavg_dt_C_perday = diff(T_mean_inbox)./diff(time_inrange);
% 
% 
% fig4 = figure(4);
% if size(T_tend_overall_terms_array,2) > 6
% %     plot(time_inrange,86400*T_tend_sum_terms,'r-',time_inrange_midpts,actual_dT_tavg_dt_C_perday,'b-',time_inrange,86400*total_T_tend,'g-')
%     plot(time_inrange_smoothed,86400*smooth_endclip(T_tend_sum_terms,span),'r-',time_inrange_midpts_smoothed,smooth_endclip(actual_dT_tavg_dt_C_perday,span),'b-',time_inrange_smoothed,86400*smooth_endclip(total_T_tend,span),'g-')
% else
% %     plot(time_inrange,86400*T_tend_sum_terms,'r-',time_inrange_midpts,actual_dT_tavg_dt_C_perday,'b-')
%     plot(time_inrange_smoothed,86400*smooth_endclip(T_tend_sum_terms,span),'r-',time_inrange_midpts_smoothed,smooth_endclip(actual_dT_tavg_dt_C_perday,span),'b-')
% end
% set(gca,'xlim',[(min(time_inrange) - (tavg_days/2)) (max(time_inrange) + (tavg_days/2))],'xtick',time_date_label,'xticklabel',date_label)
% ylabel('Temp. tendency ( ^{o}C day^{-1})')
% if size(T_tend_overall_terms_array,2) > 6
%     legend('Budget terms sum','Temp. change from T_{tavg}','Archived temp. tend.')
% else
%     legend('Budget terms sum','Temp. change from T_{tavg}')
% end
% title(['Comparison of temperature tendencies: ',region_desc])
% 
% saveas(fig4,[file_start,'_T_tend_net_budget_terms_and_actual_',file_end,'.pdf'])
% close(fig4)
% 
% 
% 
% % plot the cumulative temp. change from the sum of the budget terms and the actual
% 
% time_bounds_for_cum_plot = [(time_inrange_midpts(1) - 5); time_inrange_midpts; (time_inrange_midpts(length(time_inrange_midpts)) + 5)];
% cum_T_change_sum_terms = [0; cumsum(86400*T_tend_sum_terms.*[5; diff(time_inrange_midpts); 5])];
% actual_cum_T_change = [((1.5*T_mean_inbox(1)) + ((-0.5)*T_mean_inbox(2))); (T_mean_inbox(2:length(T_mean_inbox)) - (diff(T_mean_inbox)/2)); (((-0.5)*T_mean_inbox(length(T_mean_inbox) - 1)) + (1.5*T_mean_inbox(length(T_mean_inbox))))];
% actual_cum_T_change = actual_cum_T_change - actual_cum_T_change(1);
% 
% T_tend_sum_terms_tavg = (([diff(time_inrange_midpts); 5].*T_tend_sum_terms(2:length(T_tend_sum_terms))) - (diff([5; diff(time_inrange_midpts); 5].*T_tend_sum_terms)/2))./diff(time_inrange);
% cum_T_change_sum_terms_tavg = [0; cumsum(86400*T_tend_sum_terms_tavg.*diff(time_inrange))];
% actual_cum_T_tavg_change = T_mean_inbox - T_mean_inbox(1);
% 
% if size(T_tend_overall_terms_array,2) > 6
%     cum_total_T_tend = [0; cumsum(86400*total_T_tend.*[5; diff(time_inrange_midpts); 5])];
%     
%     total_T_tend_tavg = (([diff(time_inrange_midpts); 5].*total_T_tend(2:length(total_T_tend))) - (diff([5; diff(time_inrange_midpts); 5].*total_T_tend)/2))./diff(time_inrange);
%     cum_total_T_tend_tavg = [0; cumsum(86400*total_T_tend_tavg.*diff(time_inrange))];
% end
% 
% 
% fig5 = figure(5);
% if size(T_tend_overall_terms_array,2) > 6
%     plot(time_inrange,cum_T_change_sum_terms_tavg,'r-',time_inrange,actual_cum_T_tavg_change,'b-',time_inrange,cum_total_T_tend_tavg,'g-')
% else
%     plot(time_inrange,cum_T_change_sum_terms_tavg,'r-',time_inrange,actual_cum_T_tavg_change,'b-')
% end
% set(gca,'xlim',[(min(time_inrange) - (tavg_days/2)) (max(time_inrange) + (tavg_days/2))],'xtick',time_date_label,'xticklabel',date_label)
% ylabel('Temp. change ( ^{o}C)')
% if size(T_tend_overall_terms_array,2) > 6
%     legend('Cum. budget terms sum','Temp. change from T_{tavg}','Cum. archived temp. tend.','location','southwest')
% else
%     legend('Cum. budget terms sum','Temp. change from T_{tavg}','location','southwest')
% end
% title(['Comparison of cumulative temperature change: ',region_desc])
% 
% saveas(fig5,[file_start,'_cum_T_change_net_budget_terms_and_actual_tavg_',file_end,'.pdf'])
% close(fig5)
% 
% 
% 
% % plot bias of the sum of the budget terms, relative to the total temperature tendency (if the latter is archived)
% 
% if size(T_tend_overall_terms_array,2) > 6
%     cum_bias_sum_terms_vs_temp_tend = cum_T_change_sum_terms - cum_total_T_tend;
%     
%     fig6 = figure(6);
%     plot(time_bounds_for_cum_plot,cum_bias_sum_terms_vs_temp_tend,'g-')
%     set(gca,'xlim',[(min(time_inrange) - 0.5) (max(time_inrange) + 0.5)],'xtick',time_date_label,'xticklabel',date_label)
%     hold on
%     line([(min(time_inrange) - 0.5) (max(time_inrange) + 0.5)],[0 0],[0 0],'Color','k','LineStyle','-')
%     hold off
%     ylabel('Cumulative temp. bias ( ^{o}C)')
%     title({'Cumulative bias of archived TEND TEMP relative to sum of budget terms: POP JC run,'; region_desc})
%     
%     saveas(fig6,[file_start,'_cum_tend_sum_budget_terms_vs_temp_tend_',file_end,'.pdf'])
%     close(fig6)
% end
% 
% 
% % plot constituents of surface flux
% 
% fig7 = figure(7);
% % plot(time_inrange,86400*sw_top_flux_T_tend,time_inrange,86400*sw_bottom_flux_T_tend,time_inrange,86400*longwave_upward_flux_T_tend,time_inrange,86400*longwave_downward_flux_T_tend,time_inrange,86400*latent_heat_flux_T_tend,time_inrange,86400*sensible_heat_flux_T_tend,time_inrange,86400*sfc_flux_T_tend)
% % plot(time_inrange_smoothed,86400*smooth_endclip(sw_top_flux_T_tend,span),'y-',time_inrange_smoothed,86400*smooth_endclip(sw_bottom_flux_T_tend,span),'y--',time_inrange_smoothed,86400*smooth_endclip(longwave_upward_flux_T_tend,span),'g-',time_inrange_smoothed,86400*smooth_endclip(longwave_downward_flux_T_tend,span),'g--',time_inrange_smoothed,86400*smooth_endclip(latent_heat_flux_T_tend,span),'b-',time_inrange_smoothed,86400*smooth_endclip(sensible_heat_flux_T_tend,span),'c-',time_inrange_smoothed,86400*smooth_endclip(sfc_flux_T_tend,span),'r-')
% plot(time_inrange_smoothed,86400*(smooth_endclip(sw_top_flux_T_tend,span) + smooth_endclip(sw_bottom_flux_T_tend,span)),'r-',time_inrange_smoothed,86400*(smooth_endclip(longwave_upward_flux_T_tend,span) + smooth_endclip(longwave_downward_flux_T_tend,span)),'g-',time_inrange_smoothed,86400*smooth_endclip(latent_heat_flux_T_tend,span),'b-',time_inrange_smoothed,86400*smooth_endclip(sensible_heat_flux_T_tend,span),'c-',time_inrange_smoothed,86400*smooth_endclip(sfc_flux_T_tend,span),'r-')
% set(gca,'xlim',[(min(time_inrange) - (tavg_days/2)) (max(time_inrange) + (tavg_days/2))],'xtick',time_date_label,'xticklabel',date_label)
% ylabel('Temp. tendency ( ^{o}C day^{-1})')
% % legend('Shortwave rad. - top','Shortwave rad. - bottom','Longwave rad. - outgoing','Longwave rad. - incoming','Latent heat flux','Sensible heat flux','Total')
% legend('Net shortwave rad.','Net longwave rad.','Latent heat flux','Sensible heat flux','Total')
% title({'Contributions to the temp. tendency from surface flux components:'; region_desc})
% 
% saveas(fig7,[file_start,'_T_tend_from_sfc_fluxes_',file_end,'.pdf'])
% close(fig7)
% 
% 
% 
% % plot volume fluxes into and out of region
% % fluxes are plotted so that positive is exiting the region, negative is entering the region
% 
% % plot total volume fluxes
% 
% var_depth_vol_flux_top = adv_vol_flux_N_sloping_top + adv_vol_flux_W_sloping_top + adv_vol_flux_S_sloping_top + adv_vol_flux_E_sloping_top + ent_vol_flux_top;
% var_depth_vol_flux_bottom = adv_vol_flux_N_sloping_bottom + adv_vol_flux_W_sloping_bottom + adv_vol_flux_S_sloping_bottom + adv_vol_flux_E_sloping_bottom + ent_vol_flux_bottom;
% 
% fig8 = figure(8);
% % plot(time_inrange,(1e-12)*adv_vol_flux_N,time_inrange,(1e-12)*adv_vol_flux_W,time_inrange,(1e-12)*adv_vol_flux_S,time_inrange,(1e-12)*adv_vol_flux_E,time_inrange,(1e-12)*(adv_vol_flux_top + var_depth_vol_flux_top),time_inrange,(1e-12)*(adv_vol_flux_bottom + var_depth_vol_flux_bottom))
% plot(time_inrange_smoothed,(1e-12)*smooth_endclip(adv_vol_flux_N,span),time_inrange_smoothed,(1e-12)*smooth_endclip(adv_vol_flux_W,span),time_inrange_smoothed,(1e-12)*smooth_endclip(adv_vol_flux_S,span),time_inrange_smoothed,(1e-12)*smooth_endclip(adv_vol_flux_E,span),time_inrange_smoothed,(1e-12)*(smooth_endclip(adv_vol_flux_top,span) + smooth_endclip(var_depth_vol_flux_top,span)),time_inrange_smoothed,(1e-12)*(smooth_endclip(adv_vol_flux_bottom,span) + smooth_endclip(var_depth_vol_flux_bottom,span)))
% set(gca,'xlim',[(min(time_inrange) - (tavg_days/2)) (max(time_inrange) + (tavg_days/2))],'xtick',time_date_label,'xticklabel',date_label)
% ylabel('Volume flux (Sv)')
% legend('North edge','West edge','South edge','East edge','Top edge','Bottom edge')
% title(['Volume fluxes out of each side of the region: ',region_desc])
% 
% saveas(fig8,[file_start,'_vol_fluxes_',file_end,'.pdf'])
% close(fig8)
% 
% 
% % plot the volume fluxes at the bottom of the layer (if region_definition_option = 3 and depth_bound_option = 2)
% 
% if ((region_definition_option == 3) && (depth_bound_option == 2))
%     fig9 = figure(9);
% %     plot(time_inrange,(1e-12)*adv_vol_flux_N_sloping_bottom,time_inrange,(1e-12)*adv_vol_flux_W_sloping_bottom,time_inrange,(1e-12)*adv_vol_flux_S_sloping_bottom,time_inrange,(1e-12)*adv_vol_flux_E_sloping_bottom,time_inrange,(1e-12)*adv_vol_flux_bottom,time_inrange,(1e-12)*ent_vol_flux_bottom)
%     plot(time_inrange_smoothed,(1e-12)*smooth_endclip(adv_vol_flux_N_sloping_bottom,span),time_inrange_smoothed,(1e-12)*smooth_endclip(adv_vol_flux_W_sloping_bottom,span),time_inrange_smoothed,(1e-12)*smooth_endclip(adv_vol_flux_S_sloping_bottom,span),time_inrange_smoothed,(1e-12)*smooth_endclip(adv_vol_flux_E_sloping_bottom,span),time_inrange_smoothed,(1e-12)*smooth_endclip(adv_vol_flux_bottom,span),time_inrange_smoothed,(1e-12)*smooth_endclip(ent_vol_flux_bottom,span))
%     set(gca,'xlim',[(min(time_inrange) - (tavg_days/2)) (max(time_inrange) + (tavg_days/2))],'xtick',time_date_label,'xticklabel',date_label)
%     ylabel('Volume flux (Sv)')
%     legend('North facing V(dh/dy)','West facing U(dh/dx)','South facing V(dh/dy)','East facing U(dh/dx)','Vertical flow','Base depth change (ent.)')
%     title(['Volume fluxes through the layer base: ',region_desc])
%     
%     saveas(fig9,[file_start,'_vol_fluxes_bottom_',file_end,'.pdf'])
%     close(fig9)
% end




% plot the seasonal anomaly terms


% fig9 = figure(9);
% h = plot(time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_mean_mean_N_edge,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_mean_mean_W_edge,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_mean_mean_S_edge,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_mean_mean_E_edge,span),time_inrange_smoothed,86400*(smooth_endclip(adv_T_tend_mean_mean_top_edge,span) + smooth_endclip(var_depth_adv_T_tend_mean_mean_top,span)),time_inrange_smoothed,86400*(smooth_endclip(adv_T_tend_mean_mean_bottom_edge,span) + smooth_endclip(var_depth_adv_T_tend_mean_mean_bottom,span)),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_mean_mean_total,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_total_mean,span));
% set(h(1),'Color',[0 0.5 0.5])
% set(h(7),'Color','b','LineStyle','--','LineWidth',1)
% set(h(8),'Color','b','LineWidth',1)
% xlim_bounds = [(min(time_inrange) - (tavg_days/2)) (max(time_inrange) + (tavg_days/2))];
% set(gca,'xlim',xlim_bounds,'xtick',time_date_label,'xticklabel',date_label)
% set(gca,'ylim',[-0.08 0.08])
% hold on
% line(xlim_bounds,[0 0],[0 0],'Color','k','LineStyle','-','LineWidth',0.5)
% hold off
% ylabel('Temp. tendency anomaly ( ^{o}C day^{-1})')
% legend('North edge','West edge','South edge','East edge','Top edge','Bottom edge','Total {{\bf u}_m}{T_m} tend.','Total adv. tend. mean')
% title({'Contributions to the advective temp. tendency from {u_{mean}}{T_{mean}}:'; region_desc})
% 
% saveas(fig9,[file_start,'_T_tend_from_adv_velmean_Tmean_',file_end,'.pdf'])
% close(fig9)
% 
% fig10 = figure(10);
% h = plot(time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_mean_anom_N_edge,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_mean_anom_W_edge,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_mean_anom_S_edge,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_mean_anom_E_edge,span),time_inrange_smoothed,86400*(smooth_endclip(adv_T_tend_mean_anom_top_edge,span) + smooth_endclip(var_depth_adv_T_tend_mean_anom_top,span)),time_inrange_smoothed,86400*(smooth_endclip(adv_T_tend_mean_anom_bottom_edge,span) + smooth_endclip(var_depth_adv_T_tend_mean_anom_bottom,span)),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_mean_anom_total,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_total_anom,span));
% set(h(1),'Color',[0 0.5 0.5])
% set(h(7),'Color','b','LineStyle','--','LineWidth',1)
% set(h(8),'Color','b','LineWidth',1)
% xlim_bounds = [(min(time_inrange) - (tavg_days/2)) (max(time_inrange) + (tavg_days/2))];
% set(gca,'xlim',xlim_bounds,'xtick',time_date_label,'xticklabel',date_label)
% set(gca,'ylim',[-0.08 0.08])
% hold on
% line(xlim_bounds,[0 0],[0 0],'Color','k','LineStyle','-','LineWidth',0.5)
% hold off
% ylabel('Temp. tendency anomaly ( ^{o}C day^{-1})')
% legend('North edge','West edge','South edge','East edge','Top edge','Bottom edge','Total {{\bf u}_m}{T_a} tend.','Total adv. tend. anom.')
% title({'Contributions to the advective temp. tendency from {u_{mean}}{T_{anom}}:'; region_desc})
% 
% saveas(fig10,[file_start,'_T_tend_from_adv_velmean_Tanom_',file_end,'.pdf'])
% close(fig10)
% 
% fig11 = figure(11);
% h = plot(time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_anom_mean_N_edge,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_anom_mean_W_edge,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_anom_mean_S_edge,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_anom_mean_E_edge,span),time_inrange_smoothed,86400*(smooth_endclip(adv_T_tend_anom_mean_top_edge,span) + smooth_endclip(var_depth_adv_T_tend_anom_mean_top,span)),time_inrange_smoothed,86400*(smooth_endclip(adv_T_tend_anom_mean_bottom_edge,span) + smooth_endclip(var_depth_adv_T_tend_anom_mean_bottom,span)),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_anom_mean_total,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_total_anom,span));
% set(h(1),'Color',[0 0.5 0.5])
% set(h(7),'Color','b','LineStyle','--','LineWidth',1)
% set(h(8),'Color','b','LineWidth',1)
% xlim_bounds = [(min(time_inrange) - (tavg_days/2)) (max(time_inrange) + (tavg_days/2))];
% set(gca,'xlim',xlim_bounds,'xtick',time_date_label,'xticklabel',date_label)
% set(gca,'ylim',[-0.15 0.15])
% hold on
% line(xlim_bounds,[0 0],[0 0],'Color','k','LineStyle','-','LineWidth',0.5)
% hold off
% ylabel('Temp. tendency anomaly ( ^{o}C day^{-1})')
% legend('North edge','West edge','South edge','East edge','Top edge','Bottom edge','Total {{\bf u}_a}{T_m} tend.','Total adv. tend. anom.')
% title({'Contributions to the advective temp. tendency from {u_{anom}}{T_{mean}}:'; region_desc})
% 
% saveas(fig11,[file_start,'_T_tend_from_adv_velanom_Tmean_',file_end,'.pdf'])
% close(fig11)
% 
% fig12 = figure(12);
% h = plot(time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_anom_anom_N_edge,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_anom_anom_W_edge,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_anom_anom_S_edge,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_anom_anom_E_edge,span),time_inrange_smoothed,86400*(smooth_endclip(adv_T_tend_anom_anom_top_edge,span) + smooth_endclip(var_depth_adv_T_tend_anom_anom_top,span)),time_inrange_smoothed,86400*(smooth_endclip(adv_T_tend_anom_anom_bottom_edge,span) + smooth_endclip(var_depth_adv_T_tend_anom_anom_bottom,span)),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_anom_anom_total,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_total_anom,span));
% set(h(1),'Color',[0 0.5 0.5])
% set(h(7),'Color','b','LineStyle','--','LineWidth',1)
% set(h(8),'Color','b','LineWidth',1)
% xlim_bounds = [(min(time_inrange) - (tavg_days/2)) (max(time_inrange) + (tavg_days/2))];
% set(gca,'xlim',xlim_bounds,'xtick',time_date_label,'xticklabel',date_label)
% set(gca,'ylim',[-0.12 0.12])
% hold on
% line(xlim_bounds,[0 0],[0 0],'Color','k','LineStyle','-','LineWidth',0.5)
% hold off
% ylabel('Temp. tendency ( ^{o}C day^{-1})')
% legend('North edge','West edge','South edge','East edge','Top edge','Bottom edge','Total {{\bf u}_a}{T_a} tend.','Total tend. anom.')
% title({'Contributions to the advective temp. tendency from {u_{anom}}{T_{anom}}:'; region_desc})
% 
% saveas(fig12,[file_start,'_T_tend_from_adv_velanom_Tanom_',file_end,'.pdf'])
% close(fig12)




fig13 = figure(13);
fig13_paper_pos = get(fig13,'PaperPosition');
fig13_paper_pos(3) = 1.8*fig13_paper_pos(4);
fig13_paper_pos(3:4) = 0.8*fig13_paper_pos(3:4);
set(fig13,'PaperPosition',fig13_paper_pos)
% h = plot(time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_total_mean,span),time_inrange_smoothed,86400*smooth_endclip(ent_T_tend_total_mean,span),time_inrange_smoothed,86400*smooth_endclip(sfc_flux_T_tend_mean,span),time_inrange_smoothed,86400*smooth_endclip(hdiff_T_tend_total_mean,span),time_inrange_smoothed,86400*smooth_endclip(diab_vert_T_tend_mean,span),time_inrange_smoothed,86400*smooth_endclip(kpp_src_T_tend_mean,span),time_inrange_smoothed,86400*smooth_endclip(total_T_tend_mean,span));
h = plot(time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_total_mean,span),time_inrange_smoothed,86400*smooth_endclip(ent_T_tend_total_mean,span),time_inrange_smoothed,86400*smooth_endclip(sfc_flux_T_tend_mean,span),time_inrange_smoothed,86400*smooth_endclip(hdiff_T_tend_total_mean,span),time_inrange_smoothed,86400*smooth_endclip(diab_vert_T_tend_mean + kpp_src_T_tend_mean,span),time_inrange_smoothed,86400*smooth_endclip(total_T_tend_mean,span));
set(h(1),'LineWidth',1)
set(h(2),'LineWidth',1)
% set(h(3),'Color',[0.7 0 0],'LineStyle','--','LineWidth',1)
% set(h(4),'LineStyle','--','LineWidth',1)
% set(h(5),'LineStyle','-.','LineWidth',1)
% % set(h(6),'Color',[0.8 0.5 0],'LineStyle','-.','LineWidth',1)
% % set(h(7),'Color','k','LineWidth',1.5)
set(h(3),'Color',[0.7 0 0],'LineStyle','-','LineWidth',1)
set(h(4),'LineStyle','-','LineWidth',1)
set(h(5),'LineStyle','-','LineWidth',1)
set(h(6),'Color','k','LineWidth',1.5)
% xlim_bounds = [(min(time_inrange) - (tavg_days/2)) (max(time_inrange) + (tavg_days/2))];
% set(gca,'xlim',xlim_bounds,'xtick',time_date_label,'xticklabel',date_label)
% xlim_bounds = [(time_inrange(74) - (tavg_days/2)) (time_inrange(146) + (tavg_days/2))];
xlim_bounds = [(min(time_inrange) - (tavg_days/2) + (t_plot_smooth_days/2) + 5) (max(time_inrange) + (tavg_days/2) - (t_plot_smooth_days/2) - 5)];
set(gca,'xlim',xlim_bounds,'xtick',time_date_label_seasonal,'xticklabel',date_label_seasonal,'FontSize',14)
set(gca,'ylim',[-0.05 0.05],'ytick',(-0.05):0.01:0.05)
hold on
line(xlim_bounds,[0 0],[0 0],'Color','k','LineStyle','-','LineWidth',0.5)
hold off
% ylabel('Temp. tendency mean ( ^{o}C day^{-1})')
ylabel('Seasonal temp. tendency ( ^{o}C day^{-1})')
% legend('Advection','Vol. change (ent.)','Surface/shortwave','Horiz. diffusion','Diabatic vert. mixing','Non-local (convective)','Total tend. mean','Location','northwest')
% legend('Advection','Vol. change (ent.)','Surface/shortwave','Horiz. diffusion','Diabatic vert. mixing','Non-local (convective)','Total seasonal tend.','Location','northwest')
% legend('Advection','Volume change','Surface fluxes','Horizontal diffusion','Vertical mixing','Convection','Total seasonal tend.','Location','eastoutside')
legend('Advection','Volume change','Surface fluxes','Horizontal diffusion','Vertical mixing','Total seasonal tend.','Location','eastoutside')
title({'Contributions to the temperature tendency seasonal cycle from various mechanisms:'; region_desc},'FontSize',10)

saveas(fig13,[file_start,'_T_tend_mean_all_terms_',file_end,'.pdf'])
close(fig13)


% time_date_label_thisplot = time_date_label(7:13);
% date_label_thisplot = {date_label{7} '' '' date_label{10} '' '' date_label{13}};
time_date_label_thisplot = time_date_label(13:25);
date_label_thisplot = {date_label{13} '' '' '' '' '' date_label{19} '' '' '' '' '' date_label{25}};

fig14 = figure(14);
fig14_paper_pos = get(fig14,'PaperPosition');
fig14_paper_pos(3) = 1.0*fig14_paper_pos(4);
% fig14_paper_pos(3:4) = 0.7*fig14_paper_pos(3:4);
fig14_paper_pos(3:4) = 0.5*fig14_paper_pos(3:4);
% set(fig14,'PaperPosition',fig14_paper_pos,'PaperSize',[6 6])
set(fig14,'PaperPosition',fig14_paper_pos,'PaperSize',[9 9])
% h = plot(time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_total_anom,span),time_inrange_smoothed,86400*smooth_endclip(ent_T_tend_total_anom,span),time_inrange_smoothed,86400*smooth_endclip(sfc_flux_T_tend_anom,span),time_inrange_smoothed,86400*smooth_endclip(hdiff_T_tend_total_anom,span),time_inrange_smoothed,86400*smooth_endclip(diab_vert_T_tend_anom,span),time_inrange_smoothed,86400*smooth_endclip(kpp_src_T_tend_anom,span),time_inrange_smoothed,86400*smooth_endclip(total_T_tend_anom,span));
h = plot(time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_total_anom,span),time_inrange_smoothed,86400*smooth_endclip(ent_T_tend_total_anom,span),time_inrange_smoothed,86400*smooth_endclip(sfc_flux_T_tend_anom,span),time_inrange_smoothed,86400*smooth_endclip(hdiff_T_tend_total_anom,span),time_inrange_smoothed,86400*smooth_endclip(diab_vert_T_tend_anom + kpp_src_T_tend_anom,span),time_inrange_smoothed,86400*smooth_endclip(total_T_tend_anom,span));
set(h(1),'LineWidth',1)
set(h(2),'LineWidth',1)
% set(h(3),'Color',[0.7 0 0],'LineStyle','--','LineWidth',1)
% set(h(4),'LineStyle','--','LineWidth',1)
% set(h(5),'LineStyle','-.','LineWidth',1)
% % set(h(6),'Color',[0.8 0.5 0],'LineStyle','-.','LineWidth',1)
% % set(h(7),'Color','k','LineWidth',1.5)
set(h(3),'Color',[0.7 0 0],'LineStyle','-','LineWidth',1)
set(h(4),'LineStyle','-','LineWidth',1)
set(h(5),'LineStyle','-','LineWidth',1)
set(h(6),'Color','k','LineWidth',1.5)
% xlim_bounds = [(min(time_inrange) - (tavg_days/2)) (max(time_inrange) + (tavg_days/2))];
% xlim_bounds = [(min(time_inrange) - (tavg_days/2) + (t_plot_smooth_days/2)) (max(time_inrange) + (tavg_days/2) - (t_plot_smooth_days/2))];
xlim_bounds = [(min(time_inrange) - (tavg_days/2) + (t_plot_smooth_days/2) + 5) (max(time_inrange) + (tavg_days/2) - (t_plot_smooth_days/2) - 5)];
% set(gca,'xlim',xlim_bounds,'xtick',time_date_label,'xticklabel',date_label)
set(gca,'xlim',xlim_bounds,'ylim',[-0.1 0.1],'xtick',time_date_label_thisplot,'xticklabel',date_label_thisplot)
% set(gca,'xlim',xlim_bounds,'ylim',[-0.15 0.15],'xtick',time_date_label_thisplot,'xticklabel',date_label_thisplot)
hold on
line(xlim_bounds,[0 0],[0 0],'Color','k','LineStyle','-','LineWidth',0.5)
hold off
% ylabel('Temp. tendency anomaly ( ^{o}C day^{-1})')
ylabel('Temp. tend. anom. ( ^{o}C day^{-1})')
% legend('Advection','Vol. change (ent.)','Surface/shortwave','Horiz. diffusion','Diabatic vert. mixing','Non-local (convective)','Total tend. anom.','Location','northeast')
% title({'Contributions to the temperature tendency anomaly from various mechanisms:'; region_desc})
title({'Contributions to the temperature tendency'; 'anomaly from various mechanisms:'; region_desc},'FontSize',10)

saveas(fig14,[file_start,'_T_tend_anom_all_terms_',file_end,'.pdf'])
close(fig14)



fig15 = figure(15);
fig15_paper_pos = get(fig15,'PaperPosition');
fig15_paper_pos(3) = 1.8*fig15_paper_pos(4);
fig15_paper_pos(3:4) = 0.8*fig15_paper_pos(3:4);
set(fig15,'PaperPosition',fig15_paper_pos)
h = plot(time_inrange_smoothed,86400*(smooth_endclip(sw_top_flux_T_tend_mean,span) + smooth_endclip(sw_bottom_flux_T_tend_mean,span)),'y-',time_inrange_smoothed,86400*(smooth_endclip(longwave_upward_flux_T_tend_mean,span) + smooth_endclip(longwave_downward_flux_T_tend_mean,span)),'g-',time_inrange_smoothed,86400*smooth_endclip(latent_heat_flux_T_tend_mean,span),'b-',time_inrange_smoothed,86400*smooth_endclip(sensible_heat_flux_T_tend_mean,span),'c-',time_inrange_smoothed,86400*smooth_endclip(sfc_flux_T_tend_mean,span),'r-');
set(h(1),'Color',[0.8 0.5 0],'LineWidth',1)
set(h(2),'Color',[0 0.7 0],'LineWidth',1)
% set(h(3),'Color',[0 0 0.7],'LineStyle','-.','LineWidth',1)
% set(h(4),'Color',[0 0.5 0.5],'LineStyle','-.','LineWidth',1)
% set(h(5),'Color',[0.7 0 0],'LineWidth',1.5,'LineStyle','--')
set(h(3),'Color',[0 0 0.7],'LineStyle','-','LineWidth',1)
set(h(4),'Color',[0 0.5 0.5],'LineStyle','-','LineWidth',1)
set(h(5),'Color',[0.7 0 0],'LineWidth',1.5,'LineStyle','-')
% xlim_bounds = [(min(time_inrange) - (tavg_days/2)) (max(time_inrange) + (tavg_days/2))];
% set(gca,'xlim',xlim_bounds,'xtick',time_date_label,'xticklabel',date_label)
xlim_bounds = [(min(time_inrange) - (tavg_days/2) + (t_plot_smooth_days/2) + 5) (max(time_inrange) + (tavg_days/2) - (t_plot_smooth_days/2) - 5)];
set(gca,'xlim',xlim_bounds,'xtick',time_date_label_seasonal,'xticklabel',date_label_seasonal,'FontSize',14)
% set(gca,'ylim',[-0.2 0.2])
set(gca,'ylim',[-0.15 0.15],'ytick',(-0.15):0.05:0.15)
hold on
line(xlim_bounds,[0 0],[0 0],'Color','k','LineStyle','-','LineWidth',0.5)
hold off
ylabel('Seasonal temp. tendency ( ^{o}C day^{-1})')
% legend('Net shortwave rad.','Net longwave rad.','Latent heat flux','Sensible heat flux','Total sfc. tend. mean','Location','northeast')
% legend('Net shortwave rad.','Net longwave rad.','Latent heat flux','Sensible heat flux','Total seasonal sfc. tend.','Location','northeast')
legend('Net shortwave rad.','Net longwave rad.','Latent heat flux','Sensible heat flux','Total seasonal sfc. tend.','Location','eastoutside')
title({'Contributions to the temp. tendency seasonal cycle from surface flux components:'; region_desc},'FontSize',10)

saveas(fig15,[file_start,'_T_tend_mean_from_sfc_fluxes_',file_end,'.pdf'])
close(fig15)



% time_date_label_thisplot = time_date_label(7:13);
% date_label_thisplot = {date_label{7} '' '' date_label{10} '' '' date_label{13}};
time_date_label_thisplot = time_date_label(13:25);
date_label_thisplot = {date_label{13} '' '' '' '' '' date_label{19} '' '' '' '' '' date_label{25}};

fig16 = figure(16);
fig16_paper_pos = get(fig16,'PaperPosition');
fig16_paper_pos(3) = 1.0*fig16_paper_pos(4);
fig16_paper_pos(3:4) = 0.5*fig16_paper_pos(3:4);
set(fig16,'PaperPosition',fig16_paper_pos,'PaperSize',[9 9])
h = plot(time_inrange_smoothed,86400*(smooth_endclip(sw_top_flux_T_tend_anom,span) + smooth_endclip(sw_bottom_flux_T_tend_anom,span)),'y-',time_inrange_smoothed,86400*(smooth_endclip(longwave_upward_flux_T_tend_anom,span) + smooth_endclip(longwave_downward_flux_T_tend_anom,span)),'g-',time_inrange_smoothed,86400*smooth_endclip(latent_heat_flux_T_tend_anom,span),'b-',time_inrange_smoothed,86400*smooth_endclip(sensible_heat_flux_T_tend_anom,span),'c-',time_inrange_smoothed,86400*smooth_endclip(sfc_flux_T_tend_anom,span),'r-');
set(h(1),'Color',[0.8 0.5 0],'LineWidth',1)
set(h(2),'Color',[0 0.7 0],'LineWidth',1)
% set(h(3),'Color',[0 0 0.7],'LineStyle','-.','LineWidth',1)
% set(h(4),'Color',[0 0.5 0.5],'LineStyle','-.','LineWidth',1)
% % set(h(5),'LineWidth',1.5,'LineStyle','--')
% set(h(5),'Color',[0.7 0 0],'LineWidth',1.5,'LineStyle','--')
set(h(3),'Color',[0 0 0.7],'LineStyle','-','LineWidth',1)
set(h(4),'Color',[0 0.5 0.5],'LineStyle','-','LineWidth',1)
set(h(5),'Color',[0.7 0 0],'LineWidth',1.5,'LineStyle','-')
xlim_bounds = [(min(time_inrange) - (tavg_days/2) + (t_plot_smooth_days/2) + 5) (max(time_inrange) + (tavg_days/2) - (t_plot_smooth_days/2) - 5)];
set(gca,'xlim',xlim_bounds,'xtick',time_date_label_thisplot,'xticklabel',date_label_thisplot)
set(gca,'ylim',[-0.1 0.1])
hold on
line(xlim_bounds,[0 0],[0 0],'Color','k','LineStyle','-','LineWidth',0.5)
hold off
ylabel('Temp. tend. anom. ( ^{o}C day^{-1})')
% legend('Net shortwave rad.','Net longwave rad.','Latent heat flux','Sensible heat flux','Total sfc. tend. anom.','Location','northeast')
title({'Contributions to the temp. tendency anomaly'; 'from surface flux components:'; region_desc},'FontSize',10)

saveas(fig16,[file_start,'_T_tend_anom_from_sfc_fluxes_',file_end,'.pdf'])
close(fig16)



% var_depth_vol_flux_anom_top = adv_vol_flux_anom_N_sloping_top + adv_vol_flux_anom_W_sloping_top + adv_vol_flux_anom_S_sloping_top + adv_vol_flux_anom_E_sloping_top + ent_vol_flux_anom_top;
% var_depth_vol_flux_bottom = adv_vol_flux_anom_N_sloping_bottom + adv_vol_flux_anom_W_sloping_bottom + adv_vol_flux_anom_S_sloping_bottom + adv_vol_flux_anom_E_sloping_bottom + ent_vol_flux_anom_bottom;

fig17 = figure(17);
fig17_paper_pos = get(fig17,'PaperPosition');
fig17_paper_pos(3) = 1.8*fig17_paper_pos(4);
fig17_paper_pos(3:4) = 0.8*fig17_paper_pos(3:4);
set(fig17,'PaperPosition',fig17_paper_pos)
% h = plot(time_inrange_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_mean_N,span),time_inrange_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_mean_W,span),time_inrange_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_mean_S,span),time_inrange_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_mean_E,span),time_inrange_smoothed,(1e-12)*(smooth_endclip(-adv_vol_flux_mean_top,span) + smooth_endclip(-var_depth_vol_flux_mean_top,span) + smooth_endclip(-ent_vol_flux_mean_top,span)),time_inrange_smoothed,(1e-12)*(smooth_endclip(-adv_vol_flux_mean_bottom,span) + smooth_endclip(-var_depth_vol_flux_mean_bottom,span)),time_inrange_smoothed,(1e-12)*(smooth_endclip(-ent_vol_flux_mean_top,span) + smooth_endclip(-ent_vol_flux_mean_bottom,span)));
h = plot(time_inrange_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_mean_N,span),time_inrange_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_mean_S,span),time_inrange_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_mean_E,span),time_inrange_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_mean_W,span),time_inrange_smoothed,(1e-12)*(smooth_endclip(-adv_vol_flux_mean_top,span) + smooth_endclip(-var_depth_vol_flux_mean_top,span)),time_inrange_smoothed,(1e-12)*(smooth_endclip(-adv_vol_flux_mean_bottom,span) + smooth_endclip(-var_depth_vol_flux_mean_bottom,span)),time_inrange_smoothed,(1e-12)*(smooth_endclip(-ent_vol_flux_mean_top,span) + smooth_endclip(-ent_vol_flux_mean_bottom,span)));
set(h(1),'Color',[0 0.8 0.5],'LineStyle','-','LineWidth',1)
set(h(2),'Color',[0.5 0 0.5],'LineStyle','-','LineWidth',1)
% set(h(3),'Color',[0.7 0 0],'LineStyle','--','LineWidth',1)
% set(h(4),'Color',[0 0.4 0.2],'LineStyle','--','LineWidth',1)
% set(h(5),'LineStyle','-.','LineWidth',1)
% set(h(6),'Color',[0 0 0.4],'LineStyle','-.','LineWidth',1)
set(h(3),'Color',[0.7 0 0],'LineStyle','-','LineWidth',1)
set(h(4),'Color',[0 0.4 0.2],'LineStyle','-','LineWidth',1)
set(h(5),'LineStyle','-','LineWidth',1)
set(h(6),'Color',[0 0 0.4],'LineStyle','-','LineWidth',1)
set(h(7),'Color','k','LineWidth',1.5)
% xlim_bounds = [(min(time_inrange) - (tavg_days/2)) (max(time_inrange) + (tavg_days/2))];
% set(gca,'xlim',xlim_bounds,'xtick',time_date_label,'xticklabel',date_label)
xlim_bounds = [(min(time_inrange) - (tavg_days/2) + (t_plot_smooth_days/2) + 5) (max(time_inrange) + (tavg_days/2) - (t_plot_smooth_days/2) - 5)];
set(gca,'xlim',xlim_bounds,'xtick',time_date_label_seasonal,'xticklabel',date_label_seasonal,'FontSize',14)
set(gca,'ylim',[-4 4],'ytick',(-4):1:4)
hold on
line(xlim_bounds,[0 0],[0 0],'Color','k','LineStyle','-','LineWidth',0.5)
hold off
ylabel('Seasonal volume flux (Sv)')
% legend('North flux','West flux','South flux','East flux','Top flux','Bottom flux','Net vol. change','Location','northeast')
legend('North flux','South flux','East flux','West flux','Top flux','Bottom flux','Vol. change ','Location','eastoutside')
title(['Volume flux seasonal cycle into each side of the region: ',region_desc],'FontSize',10)

saveas(fig17,[file_start,'_vol_fluxes_mean_',file_end,'.pdf'])
close(fig17)



time_date_label_thisplot = time_date_label(13:25);
date_label_thisplot = {date_label{13} '' '' '' '' '' date_label{19} '' '' '' '' '' date_label{25}};

fig18 = figure(18);
% h = plot(time_inrange_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_anom_N,span),time_inrange_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_anom_W,span),time_inrange_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_anom_S,span),time_inrange_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_anom_E,span),time_inrange_smoothed,(1e-12)*(smooth_endclip(-adv_vol_flux_anom_top,span) + smooth_endclip(-var_depth_vol_flux_anom_top,span) + smooth_endclip(-ent_vol_flux_anom_top,span)),time_inrange_smoothed,(1e-12)*(smooth_endclip(-adv_vol_flux_anom_bottom,span) + smooth_endclip(-var_depth_vol_flux_anom_bottom,span) + smooth_endclip(-ent_vol_flux_anom_bottom,span)),time_inrange_smoothed,(1e-12)*(smooth_endclip(-ent_vol_flux_anom_top,span) + smooth_endclip(-ent_vol_flux_anom_bottom,span)));
h = plot(time_inrange_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_anom_N,span),time_inrange_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_anom_S,span),time_inrange_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_anom_E,span),time_inrange_smoothed,(1e-12)*smooth_endclip(-adv_vol_flux_anom_W,span),time_inrange_smoothed,(1e-12)*(smooth_endclip(-adv_vol_flux_anom_top,span) + smooth_endclip(-var_depth_vol_flux_anom_top,span)),time_inrange_smoothed,(1e-12)*(smooth_endclip(-adv_vol_flux_anom_bottom,span) + smooth_endclip(-var_depth_vol_flux_anom_bottom,span)),time_inrange_smoothed,(1e-12)*(smooth_endclip(-ent_vol_flux_anom_top,span) + smooth_endclip(-ent_vol_flux_anom_bottom,span)));
set(h(1),'Color',[0 0.8 0.5],'LineStyle','-','LineWidth',1)
set(h(2),'Color',[0.5 0 0.5],'LineStyle','-','LineWidth',1)
% set(h(3),'Color',[0.7 0 0],'LineStyle','--','LineWidth',1)
% set(h(4),'Color',[0 0.4 0.2],'LineStyle','--','LineWidth',1)
% set(h(5),'LineStyle','-.','LineWidth',1)
% set(h(6),'Color',[0 0 0.4],'LineStyle','-.','LineWidth',1)
set(h(3),'Color',[0.7 0 0],'LineStyle','-','LineWidth',1)
set(h(4),'Color',[0 0.4 0.2],'LineStyle','-','LineWidth',1)
set(h(5),'LineStyle','-','LineWidth',1)
set(h(6),'Color',[0 0 0.4],'LineStyle','-','LineWidth',1)
set(h(7),'Color','k','LineWidth',1.5)
xlim_bounds = [(min(time_inrange) - (tavg_days/2) + (t_plot_smooth_days/2) + 5) (max(time_inrange) + (tavg_days/2) - (t_plot_smooth_days/2) - 5)];
% set(gca,'xlim',xlim_bounds,'xtick',time_date_label,'xticklabel',date_label)
set(gca,'xlim',xlim_bounds,'xtick',time_date_label_thisplot,'xticklabel',date_label_thisplot)
hold on
line(xlim_bounds,[0 0],[0 0],'Color','k','LineStyle','-','LineWidth',0.5)
hold off
ylabel('Volume flux anomaly (Sv)')
% legend('North flux','West flux','South flux','East flux','Top flux','Bottom flux','Net vol. change','Location','south')
legend('North flux','South flux','East flux','West flux','Top flux','Bottom flux','Net vol. change','Location','south')
title(['Volume flux anomalies out of each side of the region: ',region_desc],'FontSize',10)

saveas(fig18,[file_start,'_vol_fluxes_anom_',file_end,'.pdf'])
close(fig18)



% plot the directional advective tendency components - seasonal cycle & anomalies

fig19 = figure(19);
fig19_paper_pos = get(fig19,'PaperPosition');
fig19_paper_pos(3) = 1.8*fig19_paper_pos(4);
fig19_paper_pos(3:4) = 0.8*fig19_paper_pos(3:4);
set(fig19,'PaperPosition',fig19_paper_pos)
% plot(time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_N_edge_mean,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_W_edge_mean,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_S_edge_mean,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_E_edge_mean,span),time_inrange_smoothed,86400*(smooth_endclip(adv_T_tend_top_edge_mean,span) + smooth_endclip(var_depth_adv_T_tend_top_mean,span)),time_inrange_smoothed,86400*(smooth_endclip(adv_T_tend_bottom_edge_mean,span) + smooth_endclip(var_depth_adv_T_tend_bottom_mean,span)))
% h = plot(time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_N_edge_mean,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_W_edge_mean,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_S_edge_mean,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_E_edge_mean,span),time_inrange_smoothed,86400*(smooth_endclip(adv_T_tend_top_edge_mean,span) + smooth_endclip(var_depth_adv_T_tend_top_mean,span)),time_inrange_smoothed,86400*(smooth_endclip(adv_T_tend_bottom_edge_mean,span) + smooth_endclip(var_depth_adv_T_tend_bottom_mean,span)),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_total_mean,span));
h = plot(time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_N_edge_mean,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_S_edge_mean,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_E_edge_mean,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_W_edge_mean,span),time_inrange_smoothed,86400*(smooth_endclip(adv_T_tend_top_edge_mean,span) + smooth_endclip(var_depth_adv_T_tend_top_mean,span)),time_inrange_smoothed,86400*(smooth_endclip(adv_T_tend_bottom_edge_mean,span) + smooth_endclip(var_depth_adv_T_tend_bottom_mean,span)),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_total_mean,span));
set(h(1),'Color',[0 0.8 0.5],'LineStyle','-','LineWidth',1)
set(h(2),'Color',[0.5 0 0.5],'LineStyle','-','LineWidth',1)
% set(h(3),'Color',[0.7 0 0],'LineStyle','--','LineWidth',1)
% set(h(4),'Color',[0 0.4 0.2],'LineStyle','--','LineWidth',1)
% set(h(5),'LineStyle','-.','LineWidth',1)
% set(h(6),'Color',[0 0 0.4],'LineStyle','-.','LineWidth',1)
set(h(3),'Color',[0.7 0 0],'LineStyle','-','LineWidth',1)
set(h(4),'Color',[0 0.4 0.2],'LineStyle','-','LineWidth',1)
set(h(5),'LineStyle','-','LineWidth',1)
set(h(6),'Color',[0 0 0.4],'LineStyle','-','LineWidth',1)
set(h(7),'Color',[0 0 1],'LineWidth',1.5)
% xlim_bounds = [(min(time_inrange) - (tavg_days/2)) (max(time_inrange) + (tavg_days/2))];
xlim_bounds = [(min(time_inrange) - (tavg_days/2) + (t_plot_smooth_days/2) + 5) (max(time_inrange) + (tavg_days/2) - (t_plot_smooth_days/2) - 5)];
% set(gca,'xlim',xlim_bounds,'xtick',time_date_label,'xticklabel',date_label)
set(gca,'xlim',xlim_bounds,'xtick',time_date_label_seasonal,'xticklabel',date_label_seasonal,'FontSize',14)
% set(gca,'ylim',[-0.04 0.04])
set(gca,'ylim',[-0.05 0.05],'ytick',(-0.05):0.01:0.05)
hold on
line(xlim_bounds,[0 0],[0 0],'Color','k','LineStyle','-','LineWidth',0.5)
hold off
ylabel('Seasonal temp. tendency ( ^{o}C day^{-1})')
% legend('North edge','West edge','South edge','East edge','Top edge','Bottom edge')
% legend('North edge','West edge','South edge','East edge','Top edge','Bottom edge','Total advective tend.','location','northwest')
legend('North edge','South edge','East edge','West edge','Top edge','Bottom edge','Total advective tend.','location','eastoutside')
title({'Contributions to the advective temp. seasonal cycle from each side of the region:'; region_desc},'FontSize',10)

% saveas(fig19,[file_start,'_T_tend_from_adv_fluxes_mean_',file_end,'.pdf'])
saveas(fig19,[file_start,'_T_tend_mean_from_adv_fluxes_',file_end,'.pdf'])
close(fig19)


% time_date_label_thisplot = time_date_label(7:13);
% date_label_thisplot = {date_label{7} '' '' date_label{10} '' '' date_label{13}};
time_date_label_thisplot = time_date_label(13:25);
date_label_thisplot = {date_label{13} '' '' '' '' '' date_label{19} '' '' '' '' '' date_label{25}};

fig20 = figure(20);
fig20_paper_pos = get(fig20,'PaperPosition');
fig20_paper_pos(3) = 1.0*fig20_paper_pos(4);
fig20_paper_pos(3:4) = 0.5*fig20_paper_pos(3:4);
set(fig20,'PaperPosition',fig20_paper_pos,'PaperSize',[9 9])
% plot(time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_N_edge_anom,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_W_edge_anom,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_S_edge_anom,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_E_edge_anom,span),time_inrange_smoothed,86400*(smooth_endclip(adv_T_tend_top_edge_anom,span) + smooth_endclip(var_depth_adv_T_tend_top_anom,span)),time_inrange_smoothed,86400*(smooth_endclip(adv_T_tend_bottom_edge_anom,span) + smooth_endclip(var_depth_adv_T_tend_bottom_anom,span)))
% h = plot(time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_N_edge_anom,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_W_edge_anom,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_S_edge_anom,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_E_edge_anom,span),time_inrange_smoothed,86400*(smooth_endclip(adv_T_tend_top_edge_anom,span) + smooth_endclip(var_depth_adv_T_tend_top_anom,span)),time_inrange_smoothed,86400*(smooth_endclip(adv_T_tend_bottom_edge_anom,span) + smooth_endclip(var_depth_adv_T_tend_bottom_anom,span)),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_total_anom,span));
h = plot(time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_N_edge_anom,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_S_edge_anom,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_E_edge_anom,span),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_W_edge_anom,span),time_inrange_smoothed,86400*(smooth_endclip(adv_T_tend_top_edge_anom,span) + smooth_endclip(var_depth_adv_T_tend_top_anom,span)),time_inrange_smoothed,86400*(smooth_endclip(adv_T_tend_bottom_edge_anom,span) + smooth_endclip(var_depth_adv_T_tend_bottom_anom,span)),time_inrange_smoothed,86400*smooth_endclip(adv_T_tend_total_anom,span));
set(h(1),'Color',[0 0.8 0.5],'LineStyle','-','LineWidth',1)
set(h(2),'Color',[0.5 0 0.5],'LineStyle','-','LineWidth',1)
% set(h(3),'Color',[0.7 0 0],'LineStyle','--','LineWidth',1)
% set(h(4),'Color',[0 0.4 0.2],'LineStyle','--','LineWidth',1)
% set(h(5),'LineStyle','-.','LineWidth',1)
% set(h(6),'Color',[0 0 0.4],'LineStyle','-.','LineWidth',1)
set(h(3),'Color',[0.7 0 0],'LineStyle','-','LineWidth',1)
set(h(4),'Color',[0 0.4 0.2],'LineStyle','-','LineWidth',1)
set(h(5),'LineStyle','-','LineWidth',1)
set(h(6),'Color',[0 0 0.4],'LineStyle','-','LineWidth',1)
set(h(7),'Color',[0 0 1],'LineWidth',1.5)
xlim_bounds = [(min(time_inrange) - (tavg_days/2) + (t_plot_smooth_days/2) + 5) (max(time_inrange) + (tavg_days/2) - (t_plot_smooth_days/2) - 5)];
set(gca,'xlim',xlim_bounds,'xtick',time_date_label_thisplot,'xticklabel',date_label_thisplot)
set(gca,'ylim',[-0.1 0.1])
hold on
line(xlim_bounds,[0 0],[0 0],'Color','k','LineStyle','-','LineWidth',0.5)
hold off
ylabel('Temp. tend. anom. ( ^{o}C day^{-1})')
% legend('North edge','West edge','South edge','East edge','Top edge','Bottom edge')
title({'Contributions to the advective temp. tendency'; 'anomaly from each side of the region:'; region_desc},'FontSize',10)

% saveas(fig20,[file_start,'_T_tend_from_adv_fluxes_anom_',file_end,'.pdf'])
saveas(fig20,[file_start,'_T_tend_anom_from_adv_fluxes_',file_end,'.pdf'])
close(fig20)
