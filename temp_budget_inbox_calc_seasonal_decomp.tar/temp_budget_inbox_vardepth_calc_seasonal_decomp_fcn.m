function [time_inrange,T_tend_overall_terms_array,T_tend_detailed_terms_array,vardepth_breakdown_terms_array,T_mean_inbox,vol_flux_array,T_tend_overall_terms_mean_array,T_tend_detailed_terms_mean_array,vardepth_breakdown_terms_mean_array,T_mean_inbox_seasonal_mean,vol_flux_mean_array,T_tend_overall_terms_anom_array,T_tend_detailed_terms_anom_array,vardepth_breakdown_terms_anom_array,T_mean_inbox_seasonal_anom,vol_flux_anom_array,adv_T_tend_mean_mean_array,adv_T_tend_mean_anom_array,adv_T_tend_anom_mean_array,adv_T_tend_anom_anom_array] = temp_budget_inbox_vardepth_calc_seasonal_decomp_fcn(nc_filenames,NE_corner,NW_corner,SW_corner,SE_corner,lon_ind_inrange,lat_ind_inrange,top_depth_bound_array,bottom_depth_bound_array,time_range,ent_compute_option)
try
% compute temperature budget with seasonal mean-anomaly decomposition for a 3-D box in POP output

path(path,'~/Budget_calculations/')


grid_res = 0.1;


TLAT = ncread(nc_filenames{1},'TLAT');
TLON = ncread(nc_filenames{1},'TLONG');
ULAT = ncread(nc_filenames{1},'ULAT');
ULON = ncread(nc_filenames{1},'ULONG');

z_t = ncread(nc_filenames{1},'z_t');
z_t = double(z_t);
z_w_top = ncread(nc_filenames{1},'z_w_top');
z_w_top = double(z_w_top);
z_w_bot = ncread(nc_filenames{1},'z_w_bot');
z_w_bot = double(z_w_bot);
dz = ncread(nc_filenames{1},'dz');

time = [];
file_num_vec = [];
in_file_ind_vec = [];
for file_num = 1:length(nc_filenames)
    time_curr_source_file = ncread(nc_filenames{file_num},'time');
    
    time = [time; time_curr_source_file];
    
    file_num_vec = [file_num_vec; (file_num*ones(length(time_curr_source_file),1))];
    in_file_ind_vec = [in_file_ind_vec; ((1:1:length(time_curr_source_file))')];
end



tlon = TLON(lon_ind_inrange,lat_ind_inrange);
tlat = TLAT(lon_ind_inrange,lat_ind_inrange);
ulon = ULON(lon_ind_inrange,lat_ind_inrange);
ulat = ULAT(lon_ind_inrange,lat_ind_inrange);


% find times in specified range
time_orig_ind_inrange = find((time >= time_range(1)) & (time <= time_range(2)));

% remove possible duplication of times across files
[unique_times,unique_time_ind,unique_time_rev_ind] = unique(time);

time_ind_inrange = intersect(time_orig_ind_inrange,unique_time_ind);

time_inrange_from_unique_ind = unique_time_rev_ind(time_ind_inrange);


% % use only files that contain times within specified time range
% file_nums_in_time_range = unique(file_num_vec(time_ind_inrange));

% use all files in source_nc_filenames
file_nums_in_time_range = unique(file_num_vec);


% load remaining grid variables

start_vector_i_j_only = [min(lon_ind_inrange) min(lat_ind_inrange)];
size_vector_i_j_only = [length(lon_ind_inrange) length(lat_ind_inrange)];

hte = ncread(nc_filenames{1},'HTE',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
htn = ncread(nc_filenames{1},'HTN',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
dxt = ncread(nc_filenames{1},'DXT',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
dyt = ncread(nc_filenames{1},'DYT',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
dxu = ncread(nc_filenames{1},'DXU',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
dyu = ncread(nc_filenames{1},'DYU',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
tarea = ncread(nc_filenames{1},'TAREA',start_vector_i_j_only,size_vector_i_j_only,[1 1]);
anglet = ncread(nc_filenames{1},'ANGLET',start_vector_i_j_only,size_vector_i_j_only,[1 1]);



% compute all depth indices needed for the mixed layer

outside_depth_bounds = [min(min(min(top_depth_bound_array))) max(max(max(bottom_depth_bound_array)))];     % in cm
z_t_ind_inrange = find((z_t >= outside_depth_bounds(1)) & (z_t <= outside_depth_bounds(2)));
depth_ind_inrange = (max([1 (min(z_t_ind_inrange) - 1)]):1:min([length(z_t) (max(z_t_ind_inrange) + 1)]))';



% load partial bottom cell grid variables

KMT = ncread(nc_filenames{1},'KMT');
kmt = KMT(lon_ind_inrange,lat_ind_inrange);
clear KMT

HT = ncread(nc_filenames{1},'HT');
ht = HT(lon_ind_inrange,lat_ind_inrange);
clear HT

kmt_reshaped = reshape(kmt,[prod(size(kmt)) 1]);
ht_reshaped = reshape(ht,[prod(size(ht)) 1]);

dzbc_vec = zeros(size(ht_reshaped));
not_land_ind = find(kmt_reshaped > 0);
dzbc_vec(not_land_ind) = ht(not_land_ind) - z_w_top(kmt_reshaped(not_land_ind));
dzbc = reshape(dzbc_vec,[length(lon_ind_inrange) length(lat_ind_inrange)]);



% compute thickness of cells

dzt = zeros(size(tlon,1),size(tlat,2),length(z_t));
for curr_k_ind = 1:length(z_t)
    at_deepest_level_ind = find(kmt == curr_k_ind);
    not_at_deepest_level_ind = find(kmt > curr_k_ind);
    
    dzt_curr_level = zeros(size(dzt,1),size(dzt,2));
    dzt_curr_level(at_deepest_level_ind) = dzbc(at_deepest_level_ind);
    dzt_curr_level(not_at_deepest_level_ind) = dz(curr_k_ind)*ones(length(not_at_deepest_level_ind),1);
    
    dzt(:,:,curr_k_ind) = dzt_curr_level;
end

dzt_corner_ucells = NaN(size(dzt,1),size(dzt,2),size(dzt,3),4);
dzt_corner_ucells(1:(size(dzt,1) - 1),1:(size(dzt,2) - 1),:,1) = dzt(1:(size(dzt,1) - 1),1:(size(dzt,2) - 1),:);
dzt_corner_ucells(1:(size(dzt,1) - 1),1:(size(dzt,2) - 1),:,2) = dzt(2:size(dzt,1),1:(size(dzt,2) - 1),:);
dzt_corner_ucells(1:(size(dzt,1) - 1),1:(size(dzt,2) - 1),:,3) = dzt(1:(size(dzt,1) - 1),2:size(dzt,2),:);
dzt_corner_ucells(1:(size(dzt,1) - 1),1:(size(dzt,2) - 1),:,4) = dzt(2:size(dzt,1),2:size(dzt,2),:);

dzt_east_wall = squeeze(min(dzt_corner_ucells(:,:,:,[1 2]),[],4));
dzt_north_wall = squeeze(min(dzt_corner_ucells(:,:,:,[1 3]),[],4));
dzu = squeeze(min(dzt_corner_ucells,[],4));

dzt_east_wall(isnan(dzt_east_wall) == 1) = 0;
dzt_north_wall(isnan(dzt_north_wall) == 1) = 0;


% load archived fields

curr_file_start_ind = 1;

SSH = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
ML_depth = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
uvel = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
vvel = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
wvel = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
temp = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
uet = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
vnt = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
wtt = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
hdif_gridx_temp = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
hdif_gridy_temp = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
hdif_gridz_temp = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
diab_imp_vert_T_flux_bottom = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
kpp_src_temp = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
sfc_heat_flux = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
% sfc_freshwater_flux = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
sw_flux_top = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
evap_mass_flux = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
longwave_downward_flux = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
longwave_upward_flux = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
sensible_heat_flux = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_time_ind));
tot_temp_tend = NaN(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_time_ind));
tend_temp_present_vec = [];
for file_num_ind = 1:length(nc_filenames)
    file_num = file_nums_in_time_range(file_num_ind);
    
    time_curr_source_file = ncread(nc_filenames{file_num},'time');
    
%     time_ind_infile = find(file_num_vec(time_ind_inrange) == file_num);
%     curr_time_ind_inrange = in_file_ind_vec(time_ind_inrange(time_ind_infile));

    time_ind_infile = find(file_num_vec(unique_time_ind) == file_num);
    curr_time_ind_inrange = in_file_ind_vec(unique_time_ind(time_ind_infile));
    
    
    start_vector_nodepth = [min(lon_ind_inrange) min(lat_ind_inrange) min(curr_time_ind_inrange)];
    size_vector_nodepth = [length(lon_ind_inrange) length(lat_ind_inrange) (max(curr_time_ind_inrange) - min(curr_time_ind_inrange) + 1)];
    
    
    subsetting_in_time_ind = curr_time_ind_inrange - min(curr_time_ind_inrange) + 1;
    
    curr_file_end_ind = curr_file_start_ind - 1 + length(curr_time_ind_inrange);
    
    
    % load SSH
    curr_SSH = ncread(nc_filenames{file_num},'SSH',start_vector_nodepth,size_vector_nodepth,ones(1,3));
    SSH(:,:,curr_file_start_ind:curr_file_end_ind) = curr_SSH(:,:,subsetting_in_time_ind);
    
    
    % load mixed layer depth
    curr_ML_depth = ncread(nc_filenames{file_num},'HMXL',start_vector_nodepth,size_vector_nodepth,ones(1,3));
    ML_depth(:,:,curr_file_start_ind:curr_file_end_ind) = curr_ML_depth(:,:,subsetting_in_time_ind);
    
    
    
    % load velocity and tracer flux variables
    
    start_vector = [min(lon_ind_inrange) min(lat_ind_inrange) min(depth_ind_inrange) min(curr_time_ind_inrange)];
    size_vector = [length(lon_ind_inrange) length(lat_ind_inrange) length(depth_ind_inrange) (max(curr_time_ind_inrange) - min(curr_time_ind_inrange) + 1)];
    
    curr_uvel = ncread(nc_filenames{file_num},'UVEL',start_vector,size_vector,ones(1,4));
    uvel(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_uvel(:,:,:,subsetting_in_time_ind);
    curr_vvel = ncread(nc_filenames{file_num},'VVEL',start_vector,size_vector,ones(1,4));
    vvel(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_vvel(:,:,:,subsetting_in_time_ind);
    curr_wvel = ncread(nc_filenames{file_num},'WVEL',start_vector,size_vector,ones(1,4));
    wvel(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_wvel(:,:,:,subsetting_in_time_ind);
    
    curr_temp = ncread(nc_filenames{file_num},'TEMP',start_vector,size_vector,ones(1,4));
    temp(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_temp(:,:,:,subsetting_in_time_ind);
    
    curr_uet = ncread(nc_filenames{file_num},'UET',start_vector,size_vector,ones(1,4));
    uet(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_uet(:,:,:,subsetting_in_time_ind);
    curr_vnt = ncread(nc_filenames{file_num},'VNT',start_vector,size_vector,ones(1,4));
    vnt(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_vnt(:,:,:,subsetting_in_time_ind);
    curr_wtt = ncread(nc_filenames{file_num},'WTT',start_vector,size_vector,ones(1,4));
    wtt(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_wtt(:,:,:,subsetting_in_time_ind);
    
    
    
    % load horizontal diffusion variables
    
    curr_hdif_gridx_temp = ncread(nc_filenames{file_num},'HDIFE_TEMP',start_vector,size_vector,ones(1,4));
    hdif_gridx_temp(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_hdif_gridx_temp(:,:,:,subsetting_in_time_ind);
    curr_hdif_gridy_temp = ncread(nc_filenames{file_num},'HDIFN_TEMP',start_vector,size_vector,ones(1,4));
    hdif_gridy_temp(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_hdif_gridy_temp(:,:,:,subsetting_in_time_ind);
    curr_hdif_gridz_temp = ncread(nc_filenames{file_num},'HDIFB_TEMP',start_vector,size_vector,ones(1,4));
    curr_hdif_gridz_temp(isnan(curr_hdif_gridz_temp) == 1) = 0;
    hdif_gridz_temp(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_hdif_gridz_temp(:,:,:,subsetting_in_time_ind);
    
    
    
    % load diabatic vertical mixing flux variable
    curr_diab_imp_vert_T_flux_bottom = ncread(nc_filenames{file_num},'DIA_IMPVF_TEMP',start_vector,size_vector,ones(1,4));
    curr_diab_imp_vert_T_flux_bottom(isnan(curr_diab_imp_vert_T_flux_bottom) == 1) = 0;
    diab_imp_vert_T_flux_bottom(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_diab_imp_vert_T_flux_bottom(:,:,:,subsetting_in_time_ind);
    
    
    % load non-local source term variable (boundary layer convection)
    curr_kpp_src_temp = ncread(nc_filenames{file_num},'KPP_SRC_TEMP',start_vector,size_vector,ones(1,4));
    curr_kpp_src_temp(isnan(curr_kpp_src_temp) == 1) = 0;
    kpp_src_temp(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_kpp_src_temp(:,:,:,subsetting_in_time_ind);
    
    % load surface flux, shortwave flux, and other component variables
    curr_sfc_heat_flux = ncread(nc_filenames{file_num},'SHF',start_vector([1 2 4]),size_vector([1 2 4]),ones(1,3));
    curr_sfc_heat_flux(isnan(curr_sfc_heat_flux) == 1) = 0;
    sfc_heat_flux(:,:,curr_file_start_ind:curr_file_end_ind) = curr_sfc_heat_flux(:,:,subsetting_in_time_ind);
%     curr_sfc_freshwater_flux = ncread(nc_filenames{file_num},'SFWF',start_vector([1 2 4]),size_vector([1 2 4]),ones(1,3));
%     curr_sfc_freshwater_flux(isnan(curr_sfc_freshwater_flux) == 1) = 0;
%     sfc_freshwater_flux(:,:,curr_file_start_ind:curr_file_end_ind) = curr_sfc_freshwater_flux(:,:,subsetting_in_time_ind);
    curr_sw_flux_top = ncread(nc_filenames{file_num},'QSW_3D',start_vector,size_vector,ones(1,4));
    curr_sw_flux_top(isnan(curr_sw_flux_top) == 1) = 0;
    sw_flux_top(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_sw_flux_top(:,:,:,subsetting_in_time_ind);
    
    curr_evap_mass_flux = ncread(nc_filenames{file_num},'EVAP_F',start_vector([1 2 4]),size_vector([1 2 4]),ones(1,3));
    curr_evap_mass_flux(isnan(curr_evap_mass_flux) == 1) = 0;
    evap_mass_flux(:,:,curr_file_start_ind:curr_file_end_ind) = curr_evap_mass_flux(:,:,subsetting_in_time_ind);
    curr_longwave_downward_flux = ncread(nc_filenames{file_num},'LWDN_F',start_vector([1 2 4]),size_vector([1 2 4]),ones(1,3));
    curr_longwave_downward_flux(isnan(curr_longwave_downward_flux) == 1) = 0;
    longwave_downward_flux(:,:,curr_file_start_ind:curr_file_end_ind) = curr_longwave_downward_flux(:,:,subsetting_in_time_ind);
    curr_longwave_upward_flux = ncread(nc_filenames{file_num},'LWUP_F',start_vector([1 2 4]),size_vector([1 2 4]),ones(1,3));
    curr_longwave_upward_flux(isnan(curr_longwave_upward_flux) == 1) = 0;
    longwave_upward_flux(:,:,curr_file_start_ind:curr_file_end_ind) = curr_longwave_upward_flux(:,:,subsetting_in_time_ind);
    curr_sensible_heat_flux = ncread(nc_filenames{file_num},'SENH_F',start_vector([1 2 4]),size_vector([1 2 4]),ones(1,3));
    curr_sensible_heat_flux(isnan(curr_sensible_heat_flux) == 1) = 0;
    sensible_heat_flux(:,:,curr_file_start_ind:curr_file_end_ind) = curr_sensible_heat_flux(:,:,subsetting_in_time_ind);
    
    
    % load total temperature tendency variable (if archived)
    try
        curr_tot_temp_tend = ncread(nc_filenames{file_num},'TEND_TEMP',start_vector,size_vector,ones(1,4));
        curr_tot_temp_tend(isnan(curr_tot_temp_tend) == 1) = 0;
        tot_temp_tend(:,:,:,curr_file_start_ind:curr_file_end_ind) = curr_tot_temp_tend(:,:,:,subsetting_in_time_ind);
        tend_temp_present_vec = [tend_temp_present_vec; 1];
    catch
        tend_temp_present_vec = [tend_temp_present_vec; 0];
    end
    
    curr_file_start_ind = curr_file_start_ind + length(curr_time_ind_inrange);
    
end


% if archived temperature tendency is missing in any source file, do not include it in calculations
if isempty(find(tend_temp_present_vec == 0)) == 0
    tend_temp_present = 0;
    clear tot_temp_tend
else
    tend_temp_present = 1;
end


% load conversion factor for surface heat flux
hflux_factor = ncread(nc_filenames{1},'hflux_factor');

% load conversion factor for latent heat flux (latent heat of vaporization)
latent_heat_vapor = ncread(nc_filenames{1},'latent_heat_vapor');


disp('Completed loading archived terms')

% save('/glade/scratch/adelman/POP_1977_start_JC/Budget_test_ws.mat','-v7.3')
% load('/glade/scratch/adelman/POP_1977_start_JC/Budget_test_ws.mat')
% load('/glade/scratch/adelman/POP_1977_start_JC/Budget_test_ws_no_bottom_change.mat')

% recover temp. fluxes in the correct units

uT_east = repmat(tarea./hte,[1 1 size(uet,3) size(uet,4)]).*repmat(dzt(:,:,depth_ind_inrange)./dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 size(uet,4)]).*uet;
uT_east((isnan(uT_east) == 1) | (isinf(uT_east) == 1)) = 0;
vT_north = repmat(tarea./htn,[1 1 size(vnt,3) size(vnt,4)]).*repmat(dzt(:,:,depth_ind_inrange)./dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 size(vnt,4)]).*vnt;
vT_north((isnan(vT_north) == 1) | (isinf(vT_north) == 1)) = 0;
wT_top = repmat(reshape(dz(depth_ind_inrange),[1 1 length(depth_ind_inrange) 1]),[size(wtt,1) size(wtt,2) 1 size(wtt,4)]).*wtt;

% clear uet vnt wtt


% recover horizontal diffusive fluxes in the correct units

hdiff_T_flux_east = -repmat(tarea./hte,[1 1 size(hdif_gridx_temp,3) size(hdif_gridx_temp,4)]).*repmat(dzt(:,:,depth_ind_inrange)./dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 size(hdif_gridx_temp,4)]).*hdif_gridx_temp;
hdiff_T_flux_east((isnan(hdiff_T_flux_east) == 1) | (isinf(hdiff_T_flux_east) == 1)) = 0;
hdiff_T_flux_north = -repmat(tarea./htn,[1 1 size(hdif_gridy_temp,3) size(hdif_gridy_temp,4)]).*repmat(dzt(:,:,depth_ind_inrange)./dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 size(hdif_gridy_temp,4)]).*hdif_gridy_temp;
hdiff_T_flux_north((isnan(hdiff_T_flux_north) == 1) | (isinf(hdiff_T_flux_north) == 1)) = 0;
hdiff_T_flux_bottom = -repmat(reshape(dz(depth_ind_inrange),[1 1 length(depth_ind_inrange)]),[length(lon_ind_inrange) length(lat_ind_inrange) 1 size(hdif_gridz_temp,4)]).*hdif_gridz_temp;

% clear hdif_gridx_temp hdif_gridy_temp hdif_gridz_temp



% compute the boundaries of the box


% create depth integrating array for region

no_thickness_ind = find(bottom_depth_bound_array - top_depth_bound_array < 0);
    
depth_integrating_array = zeros(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_times));
for curr_depth_ind = 1:length(depth_ind_inrange)
    curr_k_ind = depth_ind_inrange(curr_depth_ind);
    
    at_shallowest_level_ind = find((top_depth_bound_array >= z_w_top(curr_k_ind)) & (top_depth_bound_array < z_w_bot(curr_k_ind)));
    at_deepest_level_ind = find((bottom_depth_bound_array > z_w_top(curr_k_ind)) & (bottom_depth_bound_array <= z_w_bot(curr_k_ind)));
    only_one_in_level_ind = intersect(at_shallowest_level_ind,at_deepest_level_ind);
    not_vert_edge_adj_ind = find((top_depth_bound_array < z_w_top(curr_k_ind)) & (bottom_depth_bound_array > z_w_bot(curr_k_ind)));
    
    depth_integrating_curr_level = zeros(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_times));
    depth_integrating_curr_level(at_shallowest_level_ind) = z_w_bot(curr_k_ind) - top_depth_bound_array(at_shallowest_level_ind);
    depth_integrating_curr_level(at_deepest_level_ind) = bottom_depth_bound_array(at_deepest_level_ind) - z_w_top(curr_k_ind);
    depth_integrating_curr_level(only_one_in_level_ind) = bottom_depth_bound_array(only_one_in_level_ind) - top_depth_bound_array(only_one_in_level_ind);
    depth_integrating_curr_level(not_vert_edge_adj_ind) = dz(curr_k_ind)*ones(length(not_vert_edge_adj_ind),1);
    
    depth_integrating_curr_level(no_thickness_ind) = 0;
    
    depth_integrating_array(:,:,curr_depth_ind,:) = reshape(depth_integrating_curr_level,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]);
end


% compute horizontal edges of the region

m_N = (NE_corner(1) - NW_corner(1))/(NE_corner(2) - NW_corner(2));
n_W = (NW_corner(2) - SW_corner(2))/(NW_corner(1) - SW_corner(1));
m_S = (SW_corner(1) - SE_corner(1))/(SW_corner(2) - SE_corner(2));
n_E = (SE_corner(2) - NE_corner(2))/(SE_corner(1) - NE_corner(1));

b_N = NE_corner(1) - (m_N*NE_corner(2));
c_W = NW_corner(2) - (n_W*NW_corner(1));
b_S = SW_corner(1) - (m_S*SW_corner(2));
c_E = SE_corner(2) - (n_E*SE_corner(1));


pos_rel_to_N_edge = tlat - (m_N*tlon) - b_N;
pos_rel_to_W_edge = tlon - (n_W*tlat) - c_W;
pos_rel_to_S_edge = tlat - (m_S*tlon) - b_S;
pos_rel_to_E_edge = tlon - (n_E*tlat) - c_E;


in_box_ind = find((pos_rel_to_N_edge < 0) & (pos_rel_to_W_edge >= 0) & (pos_rel_to_S_edge >= 0) & (pos_rel_to_E_edge < 0));

% create mask of points in region, for horizontal integration
in_box_mask = zeros(size(tarea));
in_box_mask(in_box_ind) = 1;



at_N_edge_ind_ind = find((pos_rel_to_N_edge(in_box_ind) >= -grid_res));
at_N_edge_ind = in_box_ind(at_N_edge_ind_ind);
at_W_edge_ind_ind = find((pos_rel_to_W_edge(in_box_ind) < grid_res));
at_W_edge_ind = in_box_ind(at_W_edge_ind_ind);
at_S_edge_ind_ind = find((pos_rel_to_S_edge(in_box_ind) < grid_res));
at_S_edge_ind = in_box_ind(at_S_edge_ind_ind);
at_E_edge_ind_ind = find((pos_rel_to_E_edge(in_box_ind) >= -grid_res));
at_E_edge_ind = in_box_ind(at_E_edge_ind_ind);



at_N_edge_i_ind = mod(at_N_edge_ind - 1, size(tlat,1)) + 1;
at_N_edge_j_ind = ceil(at_N_edge_ind/size(tlat,1));

at_NE_corner_ind = intersect(at_N_edge_ind,at_E_edge_ind);
at_NW_corner_ind = intersect(at_W_edge_ind,at_N_edge_ind);
at_SW_corner_ind = intersect(at_S_edge_ind,at_W_edge_ind);
at_SE_corner_ind = intersect(at_E_edge_ind,at_S_edge_ind);

at_all_corners_ind = union(at_NE_corner_ind,at_NW_corner_ind);
at_all_corners_ind = union(at_all_corners_ind,at_SW_corner_ind);
at_all_corners_ind = union(at_all_corners_ind,at_SE_corner_ind);

no_corners_N_edge_ind = setdiff(at_N_edge_ind,at_all_corners_ind);
no_corners_W_edge_ind = setdiff(at_W_edge_ind,at_all_corners_ind);
no_corners_S_edge_ind = setdiff(at_S_edge_ind,at_all_corners_ind);
no_corners_E_edge_ind = setdiff(at_E_edge_ind,at_all_corners_ind);


% interpolate horizontal velocities to the middle of T-cell walls

dyu_dzu_uvel = repmat(dyu,[1 1 size(uvel,3) size(uvel,4)]).*repmat(dzu(:,:,depth_ind_inrange),[1 1 1 size(uvel,4)]).*uvel;
uvel_east = zeros(size(uvel));
uvel_east(:,2:size(uvel_east,2),:,:) = repmat(1./hte(:,2:size(dyt,2)),[1 1 size(uvel,3) size(uvel,4)]).*repmat(1./dzt_east_wall(:,2:size(dzt_east_wall,2),depth_ind_inrange),[1 1 1 size(uvel,4)]).*(dyu_dzu_uvel(:,2:size(dyu_dzu_uvel,2),:,:) - (diff(dyu_dzu_uvel,1,2)/2));
uvel_east(isnan(uvel_east) == 1) = 0;
clear dyu_dzu_uvel

dxu_dzu_vvel = repmat(dxu,[1 1 size(vvel,3) size(vvel,4)]).*repmat(dzu(:,:,depth_ind_inrange),[1 1 1 size(vvel,4)]).*vvel;
vvel_north = zeros(size(vvel));
vvel_north(2:size(vvel_north,1),:,:,:) = repmat(1./htn(2:size(dxt,1),:),[1 1 size(vvel,3) size(vvel,4)]).*repmat(1./dzt_north_wall(2:size(dzt_north_wall,1),:,depth_ind_inrange),[1 1 1 size(vvel,4)]).*(dxu_dzu_vvel(2:size(dxu_dzu_vvel,1),:,:,:) - (diff(dxu_dzu_vvel,1,1)/2));
vvel_north(isnan(vvel_north) == 1) = 0;
clear dxu_dzu_vvel




% create depth integrating array that accounts for presence of bathymetry

min_dzt_depth_integrating_array_5D = zeros(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_times),2);
min_dzt_depth_integrating_array_5D(:,:,:,:,1) = depth_integrating_array;
min_dzt_depth_integrating_array_5D(:,:,:,:,2) = repmat(dzt(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]);
min_dzt_depth_integrating_array = squeeze(min(min_dzt_depth_integrating_array_5D,[],5));


% compute the average temperature in the box

temp(isnan(temp) == 1) = 0;

SSH_depth_integrating_top_layer = zeros(size(SSH));
top_at_sfc_ind = find(top_depth_bound_array <= 0);
SSH_depth_integrating_top_layer(top_at_sfc_ind) = SSH(top_at_sfc_ind);
SSH_depth_integrating_top_layer(isnan(SSH_depth_integrating_top_layer) == 1) = 0;
SSH_depth_integrating_array = zeros(size(min_dzt_depth_integrating_array));
SSH_depth_integrating_array(:,:,1,:) = reshape(SSH_depth_integrating_top_layer,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]);

vol_integrated_inbox = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 1 size(min_dzt_depth_integrating_array,4)]).*sum(min_dzt_depth_integrating_array + SSH_depth_integrating_array,3),2),1));
T_integrated_inbox = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 1 size(min_dzt_depth_integrating_array,4)]).*sum((min_dzt_depth_integrating_array + SSH_depth_integrating_array).*temp,3),2),1));

T_mean_inbox = T_integrated_inbox./vol_integrated_inbox;


% time array for seasonal harmonic regressions (with 3 harmonics)

G_seasonal = [ones(length(unique_times),1) cos((2*pi/365)*unique_times) sin((2*pi/365)*unique_times) cos((2*pi/(365/2))*unique_times) sin((2*pi/(365/2))*unique_times) cos((2*pi/(365/3))*unique_times) sin((2*pi/(365/3))*unique_times) cos((2*pi/(365/4))*unique_times) sin((2*pi/(365/4))*unique_times)];

seasonal_reg_operator_T = ((((G_seasonal')*G_seasonal)^(-1))*(G_seasonal'))';




% compute advective volume and tracer fluxes, diffusive fluxes


adv_vol_flux_N = zeros(length(unique_times),1);
adv_vol_flux_W = zeros(length(unique_times),1);
adv_vol_flux_S = zeros(length(unique_times),1);
adv_vol_flux_E = zeros(length(unique_times),1);
adv_T_flux_N = zeros(length(unique_times),1);
adv_T_flux_W = zeros(length(unique_times),1);
adv_T_flux_S = zeros(length(unique_times),1);
adv_T_flux_E = zeros(length(unique_times),1);
adv_vmean_Tmean_tend_N = zeros(length(unique_times),1);
adv_umean_Tmean_tend_W = zeros(length(unique_times),1);
adv_vmean_Tmean_tend_S = zeros(length(unique_times),1);
adv_umean_Tmean_tend_E = zeros(length(unique_times),1);
adv_vmean_Tanom_tend_N = zeros(length(unique_times),1);
adv_umean_Tanom_tend_W = zeros(length(unique_times),1);
adv_vmean_Tanom_tend_S = zeros(length(unique_times),1);
adv_umean_Tanom_tend_E = zeros(length(unique_times),1);
adv_vanom_Tmean_tend_N = zeros(length(unique_times),1);
adv_uanom_Tmean_tend_W = zeros(length(unique_times),1);
adv_vanom_Tmean_tend_S = zeros(length(unique_times),1);
adv_uanom_Tmean_tend_E = zeros(length(unique_times),1);
adv_vanom_Tanom_tend_N = zeros(length(unique_times),1);
adv_uanom_Tanom_tend_W = zeros(length(unique_times),1);
adv_vanom_Tanom_tend_S = zeros(length(unique_times),1);
adv_uanom_Tanom_tend_E = zeros(length(unique_times),1);
diff_T_flux_N = zeros(length(unique_times),1);
diff_T_flux_W = zeros(length(unique_times),1);
diff_T_flux_S = zeros(length(unique_times),1);
diff_T_flux_E = zeros(length(unique_times),1);
diff_T_flux_mean_N = zeros(length(unique_times),1);
diff_T_flux_mean_W = zeros(length(unique_times),1);
diff_T_flux_mean_S = zeros(length(unique_times),1);
diff_T_flux_mean_E = zeros(length(unique_times),1);
diff_T_flux_anom_N = zeros(length(unique_times),1);
diff_T_flux_anom_W = zeros(length(unique_times),1);
diff_T_flux_anom_S = zeros(length(unique_times),1);
diff_T_flux_anom_E = zeros(length(unique_times),1);


% set NaNs in SSH array to zero
SSH(isnan(SSH) == 1) = 0;



size_array = [length(lon_ind_inrange) length(lat_ind_inrange) length(depth_ind_inrange) length(unique_times)];

uvel_west = zeros(size_array);
uvel_west(2:length(lon_ind_inrange),:,:,:) = uvel_east(1:(length(lon_ind_inrange) - 1),:,:,:);
uT_west = zeros(size_array);
uT_west(2:length(lon_ind_inrange),:,:,:) = uT_east(1:(length(lon_ind_inrange) - 1),:,:,:);
hdiff_T_flux_west = zeros(size_array);
hdiff_T_flux_west(2:length(lon_ind_inrange),:,:,:) = hdiff_T_flux_east(1:(length(lon_ind_inrange) - 1),:,:,:);

vvel_south = zeros(size_array);
vvel_south(:,2:length(lat_ind_inrange),:,:) = vvel_north(:,1:(length(lat_ind_inrange) - 1),:,:);
vT_south = zeros(size_array);
vT_south(:,2:length(lat_ind_inrange),:,:) = vT_north(:,1:(length(lat_ind_inrange) - 1),:,:);
hdiff_T_flux_south = zeros(size_array);
hdiff_T_flux_south(:,2:length(lat_ind_inrange),:,:) = hdiff_T_flux_north(:,1:(length(lat_ind_inrange) - 1),:,:);


hte_east_side = hte;
hte_east_side(isnan(hte_east_side) == 1) = 0;
hte_west_side = zeros(size_array(1:2));
hte_west_side(2:length(lon_ind_inrange),:) = hte(1:(length(lon_ind_inrange) - 1),:);

htn_north_side = htn;
htn_north_side(isnan(htn_north_side) == 1) = 0;
htn_south_side = zeros(size_array(1:2));
htn_south_side(:,2:length(lat_ind_inrange)) = htn(:,1:(length(lat_ind_inrange) - 1));

% adv_T_flux_E_pts = NaN(0,4,length(unique_times));
% adv_T_flux_W_pts = NaN(0,4,length(unique_times));
% adv_T_flux_N_pts = NaN(0,4,length(unique_times));
% adv_T_flux_S_pts = NaN(0,4,length(unique_times));

% calculate fluxes for the corners of the region

for ind_ind = 1:length(at_NE_corner_ind)
    curr_ind = at_NE_corner_ind(ind_ind);
    curr_i_ind = mod(curr_ind - 1,size(tlat,1)) + 1;
    curr_j_ind = ceil(curr_ind/size(tlat,1));
    
    if ismember(curr_ind + 1,in_box_ind) == 0
        curr_depth_integrating = reshape(min([reshape(squeeze(min(depth_integrating_array(curr_i_ind:(curr_i_ind + 1),curr_j_ind,:,:),[],1)),[(length(depth_ind_inrange)*length(unique_times)) 1]) repmat(squeeze(min(dzt(curr_i_ind:(curr_i_ind + 1),curr_j_ind,depth_ind_inrange),[],1)),[length(unique_times) 1])],[],2),[1 1 length(depth_ind_inrange) length(unique_times)]);
        curr_adv_vol_flux_E = squeeze(hte(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating.*uvel_east(curr_i_ind,curr_j_ind,:,:),3));
        adv_vol_flux_E = adv_vol_flux_E + curr_adv_vol_flux_E;
        curr_adv_T_flux_E = squeeze(hte(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating.*uT_east(curr_i_ind,curr_j_ind,:,:),3)) - (curr_adv_vol_flux_E.*T_mean_inbox(:));
        adv_T_flux_E = adv_T_flux_E + curr_adv_T_flux_E;
%         adv_T_flux_E_pts = [adv_T_flux_E_pts; curr_i_ind curr_j_ind curr_depth_integrating curr_adv_T_flux_E];
        
        uvel_east_norm_at_pos = squeeze(uvel_east(curr_i_ind,curr_j_ind,:,:))./repmat(vol_integrated_inbox',[size(uvel_east,3) 1]);
        m_seasonal_uvel_east_norm_at_pos = uvel_east_norm_at_pos*seasonal_reg_operator_T;
        umean_east_norm_at_pos = m_seasonal_uvel_east_norm_at_pos*(G_seasonal');
        uanom_east_norm_at_pos = uvel_east_norm_at_pos - umean_east_norm_at_pos;
        
        T_minus_T_inboxmean_at_pos = squeeze(mean(temp(curr_i_ind:(curr_i_ind + 1),curr_j_ind,:,:),1)) - repmat(T_mean_inbox',[size(temp,3) 1]);
        m_seasonal_T_at_pos = T_minus_T_inboxmean_at_pos*seasonal_reg_operator_T;
        Tmean_at_pos = m_seasonal_T_at_pos*(G_seasonal');
        Tanom_at_pos = T_minus_T_inboxmean_at_pos - Tmean_at_pos;
        
        curr_depth_integrating_squeezed = squeeze(curr_depth_integrating);
        
        curr_adv_umean_Tmean_tend_E = -squeeze(hte(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating_squeezed.*umean_east_norm_at_pos(:,:).*Tmean_at_pos(:,:),1))';
        adv_umean_Tmean_tend_E = adv_umean_Tmean_tend_E + curr_adv_umean_Tmean_tend_E;
        curr_adv_umean_Tanom_tend_E = -squeeze(hte(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating_squeezed.*umean_east_norm_at_pos(:,:).*Tanom_at_pos(:,:),1))';
        adv_umean_Tanom_tend_E = adv_umean_Tanom_tend_E + curr_adv_umean_Tanom_tend_E;
        curr_adv_uanom_Tmean_tend_E = -squeeze(hte(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating_squeezed.*uanom_east_norm_at_pos(:,:).*Tmean_at_pos(:,:),1))';
        adv_uanom_Tmean_tend_E = adv_uanom_Tmean_tend_E + curr_adv_uanom_Tmean_tend_E;
        adv_uanom_Tanom_tend_E = adv_uanom_Tanom_tend_E + ((-curr_adv_T_flux_E./vol_integrated_inbox(:)) - curr_adv_umean_Tmean_tend_E - curr_adv_umean_Tanom_tend_E - curr_adv_uanom_Tmean_tend_E);
        
        
        diff_T_flux_E = diff_T_flux_E + squeeze(hte(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating.*hdiff_T_flux_east(curr_i_ind,curr_j_ind,:,:),3));
        
    end
    if ismember(curr_ind + size(tlat,1),in_box_ind) == 0
        curr_depth_integrating = reshape(min([reshape(squeeze(min(depth_integrating_array(curr_i_ind,curr_j_ind:(curr_j_ind + 1),:,:),[],2)),[(length(depth_ind_inrange)*length(unique_times)) 1]) repmat(squeeze(min(dzt(curr_i_ind,curr_j_ind:(curr_j_ind + 1),depth_ind_inrange),[],2)),[length(unique_times) 1])],[],2),[1 1 length(depth_ind_inrange) length(unique_times)]);
        curr_adv_vol_flux_N = squeeze(htn(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating.*vvel_north(curr_i_ind,curr_j_ind,:,:),3));
        adv_vol_flux_N = adv_vol_flux_N + curr_adv_vol_flux_N;
        curr_adv_T_flux_N = squeeze(htn(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating.*vT_north(curr_i_ind,curr_j_ind,:,:),3)) - (curr_adv_vol_flux_N.*T_mean_inbox(:));
        adv_T_flux_N = adv_T_flux_N + curr_adv_T_flux_N;
%         adv_T_flux_N_pts = [adv_T_flux_N_pts; curr_i_ind curr_j_ind curr_depth_integrating curr_adv_T_flux_N];
        
        vvel_north_norm_at_pos = squeeze(vvel_north(curr_i_ind,curr_j_ind,:,:))./repmat(vol_integrated_inbox',[size(vvel_north,3) 1]);
        m_seasonal_vvel_north_norm_at_pos = vvel_north_norm_at_pos*seasonal_reg_operator_T;
        vmean_north_norm_at_pos = m_seasonal_vvel_north_norm_at_pos*(G_seasonal');
        vanom_north_norm_at_pos = vvel_north_norm_at_pos - vmean_north_norm_at_pos;
        
        T_minus_T_inboxmean_at_pos = squeeze(mean(temp(curr_i_ind,curr_j_ind:(curr_j_ind + 1),:,:),2)) - repmat(T_mean_inbox',[size(temp,3) 1]);
        m_seasonal_T_at_pos = T_minus_T_inboxmean_at_pos*seasonal_reg_operator_T;
        Tmean_at_pos = m_seasonal_T_at_pos*(G_seasonal');
        Tanom_at_pos = T_minus_T_inboxmean_at_pos - Tmean_at_pos;
        
        curr_depth_integrating_squeezed = squeeze(curr_depth_integrating);
        
        curr_adv_vmean_Tmean_tend_N = -squeeze(htn(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating_squeezed.*vmean_north_norm_at_pos(:,:).*Tmean_at_pos(:,:),1))';
        adv_vmean_Tmean_tend_N = adv_vmean_Tmean_tend_N + curr_adv_vmean_Tmean_tend_N;
        curr_adv_vmean_Tanom_tend_N = -squeeze(htn(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating_squeezed.*vmean_north_norm_at_pos(:,:).*Tanom_at_pos(:,:),1))';
        adv_vmean_Tanom_tend_N = adv_vmean_Tanom_tend_N + curr_adv_vmean_Tanom_tend_N;
        curr_adv_vanom_Tmean_tend_N = -squeeze(htn(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating_squeezed.*vanom_north_norm_at_pos(:,:).*Tmean_at_pos(:,:),1))';
        adv_vanom_Tmean_tend_N = adv_vanom_Tmean_tend_N + curr_adv_vanom_Tmean_tend_N;
        adv_vanom_Tanom_tend_N = adv_vanom_Tanom_tend_N + ((-curr_adv_T_flux_N./vol_integrated_inbox(:)) - curr_adv_vmean_Tmean_tend_N - curr_adv_vmean_Tanom_tend_N - curr_adv_vanom_Tmean_tend_N);
        
        diff_T_flux_N = diff_T_flux_N + squeeze(htn(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating.*hdiff_T_flux_north(curr_i_ind,curr_j_ind,:,:),3));
        
    end
end

for ind_ind = 1:length(at_NW_corner_ind)
    curr_ind = at_NW_corner_ind(ind_ind);
    curr_i_ind = mod(curr_ind - 1,size(tlat,1)) + 1;
    curr_j_ind = ceil(curr_ind/size(tlat,1));
    
    if ((ismember(curr_ind + size(tlat,1),in_box_ind) == 0) & (ismember(curr_ind,at_NE_corner_ind) == 0))
        curr_depth_integrating = reshape(min([reshape(squeeze(min(depth_integrating_array(curr_i_ind,curr_j_ind:(curr_j_ind + 1),:,:),[],2)),[(length(depth_ind_inrange)*length(unique_times)) 1]) repmat(squeeze(min(dzt(curr_i_ind,curr_j_ind:(curr_j_ind + 1),depth_ind_inrange),[],2)),[length(unique_times) 1])],[],2),[1 1 length(depth_ind_inrange) length(unique_times)]);
        curr_adv_vol_flux_N = squeeze(htn(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating.*vvel_north(curr_i_ind,curr_j_ind,:,:),3));
        adv_vol_flux_N = adv_vol_flux_N + curr_adv_vol_flux_N;
        curr_adv_T_flux_N = squeeze(htn(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating.*vT_north(curr_i_ind,curr_j_ind,:,:),3)) - (curr_adv_vol_flux_N.*T_mean_inbox(:));
        adv_T_flux_N = adv_T_flux_N + curr_adv_T_flux_N;
%         adv_T_flux_N_pts = [adv_T_flux_N_pts; curr_i_ind curr_j_ind curr_depth_integrating curr_adv_T_flux_N];
        
        vvel_north_norm_at_pos = squeeze(vvel_north(curr_i_ind,curr_j_ind,:,:))./repmat(vol_integrated_inbox',[size(vvel_north,3) 1]);
        m_seasonal_vvel_north_norm_at_pos = vvel_north_norm_at_pos*seasonal_reg_operator_T;
        vmean_north_norm_at_pos = m_seasonal_vvel_north_norm_at_pos*(G_seasonal');
        vanom_north_norm_at_pos = vvel_north_norm_at_pos - vmean_north_norm_at_pos;
        
        T_minus_T_inboxmean_at_pos = squeeze(mean(temp(curr_i_ind,curr_j_ind:(curr_j_ind + 1),:,:),2)) - repmat(T_mean_inbox',[size(temp,3) 1]);
        m_seasonal_T_at_pos = T_minus_T_inboxmean_at_pos*seasonal_reg_operator_T;
        Tmean_at_pos = m_seasonal_T_at_pos*(G_seasonal');
        Tanom_at_pos = T_minus_T_inboxmean_at_pos - Tmean_at_pos;
        
        curr_depth_integrating_squeezed = squeeze(curr_depth_integrating);
        
        curr_adv_vmean_Tmean_tend_N = -squeeze(htn(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating_squeezed.*vmean_north_norm_at_pos(:,:).*Tmean_at_pos(:,:),1))';
        adv_vmean_Tmean_tend_N = adv_vmean_Tmean_tend_N + curr_adv_vmean_Tmean_tend_N;
        curr_adv_vmean_Tanom_tend_N = -squeeze(htn(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating_squeezed.*vmean_north_norm_at_pos(:,:).*Tanom_at_pos(:,:),1))';
        adv_vmean_Tanom_tend_N = adv_vmean_Tanom_tend_N + curr_adv_vmean_Tanom_tend_N;
        curr_adv_vanom_Tmean_tend_N = -squeeze(htn(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating_squeezed.*vanom_north_norm_at_pos(:,:).*Tmean_at_pos(:,:),1))';
        adv_vanom_Tmean_tend_N = adv_vanom_Tmean_tend_N + curr_adv_vanom_Tmean_tend_N;
        adv_vanom_Tanom_tend_N = adv_vanom_Tanom_tend_N + ((-curr_adv_T_flux_N./vol_integrated_inbox(:)) - curr_adv_vmean_Tmean_tend_N - curr_adv_vmean_Tanom_tend_N - curr_adv_vanom_Tmean_tend_N);
        
        
        diff_T_flux_N = diff_T_flux_N + squeeze(htn(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating.*hdiff_T_flux_north(curr_i_ind,curr_j_ind,:,:),3));
        
    end
    if ismember(curr_ind - 1,in_box_ind) == 0
        curr_depth_integrating = reshape(min([reshape(squeeze(min(depth_integrating_array((curr_i_ind - 1):curr_i_ind,curr_j_ind,:,:),[],1)),[(length(depth_ind_inrange)*length(unique_times)) 1]) repmat(squeeze(min(dzt((curr_i_ind - 1):curr_i_ind,curr_j_ind,depth_ind_inrange),[],1)),[length(unique_times) 1])],[],2),[1 1 length(depth_ind_inrange) length(unique_times)]);
        curr_adv_vol_flux_W = squeeze(-hte(curr_i_ind - 1,curr_j_ind)*sum(curr_depth_integrating.*uvel_east(curr_i_ind - 1,curr_j_ind,:,:),3));
        adv_vol_flux_W = adv_vol_flux_W + curr_adv_vol_flux_W;
        curr_adv_T_flux_W = squeeze(-hte(curr_i_ind - 1,curr_j_ind)*sum(curr_depth_integrating.*uT_east(curr_i_ind - 1,curr_j_ind,:,:),3)) - (curr_adv_vol_flux_W.*T_mean_inbox(:));
        adv_T_flux_W = adv_T_flux_W + curr_adv_T_flux_W;
%         adv_T_flux_W_pts = [adv_T_flux_W_pts; curr_i_ind curr_j_ind curr_depth_integrating curr_adv_T_flux_W];
        
        uvel_east_norm_at_pos = squeeze(-uvel_east(curr_i_ind - 1,curr_j_ind,:,:))./repmat(vol_integrated_inbox',[size(uvel_east,3) 1]);
        m_seasonal_uvel_east_norm_at_pos = uvel_east_norm_at_pos*seasonal_reg_operator_T;
        umean_east_norm_at_pos = m_seasonal_uvel_east_norm_at_pos*(G_seasonal');
        uanom_east_norm_at_pos = uvel_east_norm_at_pos - umean_east_norm_at_pos;
        
        T_minus_T_inboxmean_at_pos = squeeze(mean(temp((curr_i_ind - 1):curr_i_ind,curr_j_ind,:,:),1)) - repmat(T_mean_inbox',[size(temp,3) 1]);
        m_seasonal_T_at_pos = T_minus_T_inboxmean_at_pos*seasonal_reg_operator_T;
        Tmean_at_pos = m_seasonal_T_at_pos*(G_seasonal');
        Tanom_at_pos = T_minus_T_inboxmean_at_pos - Tmean_at_pos;
        
        curr_depth_integrating_squeezed = squeeze(curr_depth_integrating);
        
        curr_adv_umean_Tmean_tend_W = -squeeze(hte(curr_i_ind - 1,curr_j_ind)*sum(curr_depth_integrating_squeezed.*umean_east_norm_at_pos(:,:).*Tmean_at_pos(:,:),1))';
        adv_umean_Tmean_tend_W = adv_umean_Tmean_tend_W + curr_adv_umean_Tmean_tend_W;
        curr_adv_umean_Tanom_tend_W = -squeeze(hte(curr_i_ind - 1,curr_j_ind)*sum(curr_depth_integrating_squeezed.*umean_east_norm_at_pos(:,:).*Tanom_at_pos(:,:),1))';
        adv_umean_Tanom_tend_W = adv_umean_Tanom_tend_W + curr_adv_umean_Tanom_tend_W;
        curr_adv_uanom_Tmean_tend_W = -squeeze(hte(curr_i_ind - 1,curr_j_ind)*sum(curr_depth_integrating_squeezed.*uanom_east_norm_at_pos(:,:).*Tmean_at_pos(:,:),1))';
        adv_uanom_Tmean_tend_W = adv_uanom_Tmean_tend_W + curr_adv_uanom_Tmean_tend_W;
        adv_uanom_Tanom_tend_W = adv_uanom_Tanom_tend_W + ((-curr_adv_T_flux_W./vol_integrated_inbox(:)) - curr_adv_umean_Tmean_tend_W - curr_adv_umean_Tanom_tend_W - curr_adv_uanom_Tmean_tend_W);
        
        
        diff_T_flux_W = diff_T_flux_W - squeeze(hte(curr_i_ind - 1,curr_j_ind)*sum(curr_depth_integrating.*hdiff_T_flux_east(curr_i_ind - 1,curr_j_ind,:,:),3));
        
    end
end

for ind_ind = 1:length(at_SW_corner_ind)
    curr_ind = at_SW_corner_ind(ind_ind);
    curr_i_ind = mod(curr_ind - 1,size(tlat,1)) + 1;
    curr_j_ind = ceil(curr_ind/size(tlat,1));
    
    if ((ismember(curr_ind - 1,in_box_ind) == 0) & (ismember(curr_ind,at_NW_corner_ind) == 0))
        curr_depth_integrating = reshape(min([reshape(squeeze(min(depth_integrating_array((curr_i_ind - 1):curr_i_ind,curr_j_ind,:,:),[],1)),[(length(depth_ind_inrange)*length(unique_times)) 1]) repmat(squeeze(min(dzt((curr_i_ind - 1):curr_i_ind,curr_j_ind,depth_ind_inrange),[],1)),[length(unique_times) 1])],[],2),[1 1 length(depth_ind_inrange) length(unique_times)]);
        curr_adv_vol_flux_W = -squeeze(hte(curr_i_ind - 1,curr_j_ind)*sum(curr_depth_integrating.*uvel_east(curr_i_ind - 1,curr_j_ind,:,:),3));
        adv_vol_flux_W = adv_vol_flux_W + curr_adv_vol_flux_W;
        curr_adv_T_flux_W = squeeze(-hte(curr_i_ind - 1,curr_j_ind)*sum(curr_depth_integrating.*uT_east(curr_i_ind - 1,curr_j_ind,:,:),3)) - (curr_adv_vol_flux_W.*T_mean_inbox(:));
        adv_T_flux_W = adv_T_flux_W + curr_adv_T_flux_W;
%         adv_T_flux_W_pts = [adv_T_flux_W_pts; curr_i_ind curr_j_ind curr_depth_integrating curr_adv_T_flux_W];
        
        uvel_east_norm_at_pos = squeeze(-uvel_east(curr_i_ind - 1,curr_j_ind,:,:))./repmat(vol_integrated_inbox',[size(uvel_east,3) 1]);
        m_seasonal_uvel_east_norm_at_pos = uvel_east_norm_at_pos*seasonal_reg_operator_T;
        umean_east_norm_at_pos = m_seasonal_uvel_east_norm_at_pos*(G_seasonal');
        uanom_east_norm_at_pos = uvel_east_norm_at_pos - umean_east_norm_at_pos;
        
        T_minus_T_inboxmean_at_pos = squeeze(mean(temp((curr_i_ind - 1):curr_i_ind,curr_j_ind,:,:),1)) - repmat(T_mean_inbox',[size(temp,3) 1]);
        m_seasonal_T_at_pos = T_minus_T_inboxmean_at_pos*seasonal_reg_operator_T;
        Tmean_at_pos = m_seasonal_T_at_pos*(G_seasonal');
        Tanom_at_pos = T_minus_T_inboxmean_at_pos - Tmean_at_pos;
        
        curr_depth_integrating_squeezed = squeeze(curr_depth_integrating);
        
        curr_adv_umean_Tmean_tend_W = -squeeze(hte(curr_i_ind - 1,curr_j_ind)*sum(curr_depth_integrating_squeezed.*umean_east_norm_at_pos(:,:).*Tmean_at_pos(:,:),1))';
        adv_umean_Tmean_tend_W = adv_umean_Tmean_tend_W + curr_adv_umean_Tmean_tend_W;
        curr_adv_umean_Tanom_tend_W = -squeeze(hte(curr_i_ind - 1,curr_j_ind)*sum(curr_depth_integrating_squeezed.*umean_east_norm_at_pos(:,:).*Tanom_at_pos(:,:),1))';
        adv_umean_Tanom_tend_W = adv_umean_Tanom_tend_W + curr_adv_umean_Tanom_tend_W;
        curr_adv_uanom_Tmean_tend_W = -squeeze(hte(curr_i_ind - 1,curr_j_ind)*sum(curr_depth_integrating_squeezed.*uanom_east_norm_at_pos(:,:).*Tmean_at_pos(:,:),1))';
        adv_uanom_Tmean_tend_W = adv_uanom_Tmean_tend_W + curr_adv_uanom_Tmean_tend_W;
        adv_uanom_Tanom_tend_W = adv_uanom_Tanom_tend_W + ((-curr_adv_T_flux_W./vol_integrated_inbox(:)) - curr_adv_umean_Tmean_tend_W - curr_adv_umean_Tanom_tend_W - curr_adv_uanom_Tmean_tend_W);
        
        
        diff_T_flux_W = diff_T_flux_W - squeeze(hte(curr_i_ind - 1,curr_j_ind)*sum(curr_depth_integrating.*hdiff_T_flux_east(curr_i_ind - 1,curr_j_ind,:,:),3));
        
    end    
    if ismember(curr_ind - size(tlat,1),in_box_ind) == 0
        curr_depth_integrating = reshape(min([reshape(squeeze(min(depth_integrating_array(curr_i_ind,(curr_j_ind - 1):curr_j_ind,:,:),[],2)),[(length(depth_ind_inrange)*length(unique_times)) 1]) repmat(squeeze(min(dzt(curr_i_ind,(curr_j_ind - 1):curr_j_ind,depth_ind_inrange),[],2)),[length(unique_times) 1])],[],2),[1 1 length(depth_ind_inrange) length(unique_times)]);
        curr_adv_vol_flux_S = -squeeze(htn(curr_i_ind,curr_j_ind - 1)*sum(curr_depth_integrating.*vvel_north(curr_i_ind,curr_j_ind - 1,:,:),3));
        adv_vol_flux_S = adv_vol_flux_S + curr_adv_vol_flux_S;
        curr_adv_T_flux_S = squeeze(-htn(curr_i_ind,curr_j_ind - 1)*sum(curr_depth_integrating.*vT_north(curr_i_ind,curr_j_ind - 1,:,:),3)) - (curr_adv_vol_flux_S.*T_mean_inbox(:));
        adv_T_flux_S = adv_T_flux_S + curr_adv_T_flux_S;
%         adv_T_flux_S_pts = [adv_T_flux_S_pts; curr_i_ind curr_j_ind curr_depth_integrating curr_adv_T_flux_S];
        
        vvel_north_norm_at_pos = squeeze(-vvel_north(curr_i_ind,curr_j_ind - 1,:,:))./repmat(vol_integrated_inbox',[size(vvel_north,3) 1]);
        m_seasonal_vvel_north_norm_at_pos = vvel_north_norm_at_pos*seasonal_reg_operator_T;
        vmean_north_norm_at_pos = m_seasonal_vvel_north_norm_at_pos*(G_seasonal');
        vanom_north_norm_at_pos = vvel_north_norm_at_pos - vmean_north_norm_at_pos;
        
        T_minus_T_inboxmean_at_pos = squeeze(mean(temp(curr_i_ind,(curr_j_ind - 1):curr_j_ind,:,:),2)) - repmat(T_mean_inbox',[size(temp,3) 1]);
        m_seasonal_T_at_pos = T_minus_T_inboxmean_at_pos*seasonal_reg_operator_T;
        Tmean_at_pos = m_seasonal_T_at_pos*(G_seasonal');
        Tanom_at_pos = T_minus_T_inboxmean_at_pos - Tmean_at_pos;
        
        curr_depth_integrating_squeezed = squeeze(curr_depth_integrating);
        
        curr_adv_vmean_Tmean_tend_S = -squeeze(htn(curr_i_ind,curr_j_ind - 1)*sum(curr_depth_integrating_squeezed.*vmean_north_norm_at_pos(:,:).*Tmean_at_pos(:,:),1))';
        adv_vmean_Tmean_tend_S = adv_vmean_Tmean_tend_S + curr_adv_vmean_Tmean_tend_S;
        curr_adv_vmean_Tanom_tend_S = -squeeze(htn(curr_i_ind,curr_j_ind - 1)*sum(curr_depth_integrating_squeezed.*vmean_north_norm_at_pos(:,:).*Tanom_at_pos(:,:),1))';
        adv_vmean_Tanom_tend_S = adv_vmean_Tanom_tend_S + curr_adv_vmean_Tanom_tend_S;
        curr_adv_vanom_Tmean_tend_S = -squeeze(htn(curr_i_ind,curr_j_ind - 1)*sum(curr_depth_integrating_squeezed.*vanom_north_norm_at_pos(:,:).*Tmean_at_pos(:,:),1))';
        adv_vanom_Tmean_tend_S = adv_vanom_Tmean_tend_S + curr_adv_vanom_Tmean_tend_S;
        adv_vanom_Tanom_tend_S = adv_vanom_Tanom_tend_S + ((-curr_adv_T_flux_S./vol_integrated_inbox(:)) - curr_adv_vmean_Tmean_tend_S - curr_adv_vmean_Tanom_tend_S - curr_adv_vanom_Tmean_tend_S);
        
        
        diff_T_flux_S = diff_T_flux_S - squeeze(htn(curr_i_ind,curr_j_ind - 1)*sum(curr_depth_integrating.*hdiff_T_flux_north(curr_i_ind,curr_j_ind - 1,:,:),3));
    end   
end

for ind_ind = 1:length(at_SE_corner_ind)
    curr_ind = at_SE_corner_ind(ind_ind);
    curr_i_ind = mod(curr_ind - 1,size(tlat,1)) + 1;
    curr_j_ind = ceil(curr_ind/size(tlat,1));
    
    if ((ismember(curr_ind - size(tlat,1),in_box_ind) == 0) & (ismember(curr_ind,at_SW_corner_ind) == 0))
        curr_depth_integrating = reshape(min([reshape(squeeze(min(depth_integrating_array(curr_i_ind,(curr_j_ind - 1):curr_j_ind,:,:),[],2)),[(length(depth_ind_inrange)*length(unique_times)) 1]) repmat(squeeze(min(dzt(curr_i_ind,(curr_j_ind - 1):curr_j_ind,depth_ind_inrange),[],2)),[length(unique_times) 1])],[],2),[1 1 length(depth_ind_inrange) length(unique_times)]);
        curr_adv_vol_flux_S = -squeeze(htn(curr_i_ind,curr_j_ind - 1)*sum(curr_depth_integrating.*vvel_north(curr_i_ind,curr_j_ind - 1,:,:),3));
        adv_vol_flux_S = adv_vol_flux_S + curr_adv_vol_flux_S;
        curr_adv_T_flux_S = squeeze(-htn(curr_i_ind,curr_j_ind - 1)*sum(curr_depth_integrating.*vT_north(curr_i_ind,curr_j_ind - 1,:,:),3)) - (curr_adv_vol_flux_S.*T_mean_inbox(:));
        adv_T_flux_S = adv_T_flux_S + curr_adv_T_flux_S;
%         adv_T_flux_S_pts = [adv_T_flux_S_pts; curr_i_ind curr_j_ind curr_depth_integrating curr_adv_T_flux_S];
        
        vvel_north_norm_at_pos = squeeze(-vvel_north(curr_i_ind,curr_j_ind - 1,:,:))./repmat(vol_integrated_inbox',[size(vvel_north,3) 1]);
        m_seasonal_vvel_north_norm_at_pos = vvel_north_norm_at_pos*seasonal_reg_operator_T;
        vmean_north_norm_at_pos = m_seasonal_vvel_north_norm_at_pos*(G_seasonal');
        vanom_north_norm_at_pos = vvel_north_norm_at_pos - vmean_north_norm_at_pos;
        
        T_minus_T_inboxmean_at_pos = squeeze(mean(temp(curr_i_ind,(curr_j_ind - 1):curr_j_ind,:,:),2)) - repmat(T_mean_inbox',[size(temp,3) 1]);
        m_seasonal_T_at_pos = T_minus_T_inboxmean_at_pos*seasonal_reg_operator_T;
        Tmean_at_pos = m_seasonal_T_at_pos*(G_seasonal');
        Tanom_at_pos = T_minus_T_inboxmean_at_pos - Tmean_at_pos;
        
        curr_depth_integrating_squeezed = squeeze(curr_depth_integrating);
        
        curr_adv_vmean_Tmean_tend_S = -squeeze(htn(curr_i_ind,curr_j_ind - 1)*sum(curr_depth_integrating_squeezed.*vmean_north_norm_at_pos(:,:).*Tmean_at_pos(:,:),1))';
        adv_vmean_Tmean_tend_S = adv_vmean_Tmean_tend_S + curr_adv_vmean_Tmean_tend_S;
        curr_adv_vmean_Tanom_tend_S = -squeeze(htn(curr_i_ind,curr_j_ind - 1)*sum(curr_depth_integrating_squeezed.*vmean_north_norm_at_pos(:,:).*Tanom_at_pos(:,:),1))';
        adv_vmean_Tanom_tend_S = adv_vmean_Tanom_tend_S + curr_adv_vmean_Tanom_tend_S;
        curr_adv_vanom_Tmean_tend_S = -squeeze(htn(curr_i_ind,curr_j_ind - 1)*sum(curr_depth_integrating_squeezed.*vanom_north_norm_at_pos(:,:).*Tmean_at_pos(:,:),1))';
        adv_vanom_Tmean_tend_S = adv_vanom_Tmean_tend_S + curr_adv_vanom_Tmean_tend_S;
        adv_vanom_Tanom_tend_S = adv_vanom_Tanom_tend_S + ((-curr_adv_T_flux_S./vol_integrated_inbox(:)) - curr_adv_vmean_Tmean_tend_S - curr_adv_vmean_Tanom_tend_S - curr_adv_vanom_Tmean_tend_S);
        
        
        diff_T_flux_S = diff_T_flux_S - squeeze(htn(curr_i_ind,curr_j_ind - 1)*sum(curr_depth_integrating.*hdiff_T_flux_north(curr_i_ind,curr_j_ind - 1,:,:),3));
    end
    if ((ismember(curr_ind + 1,in_box_ind) == 0) & (ismember(curr_ind,at_NE_corner_ind) == 0))
        curr_depth_integrating = reshape(min([reshape(squeeze(min(depth_integrating_array(curr_i_ind:(curr_i_ind + 1),curr_j_ind,:,:),[],1)),[(length(depth_ind_inrange)*length(unique_times)) 1]) repmat(squeeze(min(dzt(curr_i_ind:(curr_i_ind + 1),curr_j_ind,depth_ind_inrange),[],1)),[length(unique_times) 1])],[],2),[1 1 length(depth_ind_inrange) length(unique_times)]);
        curr_adv_vol_flux_E = squeeze(hte(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating.*uvel_east(curr_i_ind,curr_j_ind,:,:),3));
        adv_vol_flux_E = adv_vol_flux_E + curr_adv_vol_flux_E;
        curr_adv_T_flux_E = squeeze(hte(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating.*uT_east(curr_i_ind,curr_j_ind,:,:),3)) - (curr_adv_vol_flux_E.*T_mean_inbox(:));
        adv_T_flux_E = adv_T_flux_E + curr_adv_T_flux_E;
%         adv_T_flux_E_pts = [adv_T_flux_E_pts; curr_i_ind curr_j_ind curr_depth_integrating curr_adv_T_flux_E];
        
        uvel_east_norm_at_pos = squeeze(uvel_east(curr_i_ind,curr_j_ind,:,:))./repmat(vol_integrated_inbox',[size(uvel_east,3) 1]);
        m_seasonal_uvel_east_norm_at_pos = uvel_east_norm_at_pos*seasonal_reg_operator_T;
        umean_east_norm_at_pos = m_seasonal_uvel_east_norm_at_pos*(G_seasonal');
        uanom_east_norm_at_pos = uvel_east_norm_at_pos - umean_east_norm_at_pos;
        
        T_minus_T_inboxmean_at_pos = squeeze(mean(temp(curr_i_ind:(curr_i_ind + 1),curr_j_ind,:,:),1)) - repmat(T_mean_inbox',[size(temp,3) 1]);
        m_seasonal_T_at_pos = T_minus_T_inboxmean_at_pos*seasonal_reg_operator_T;
        Tmean_at_pos = m_seasonal_T_at_pos*(G_seasonal');
        Tanom_at_pos = T_minus_T_inboxmean_at_pos - Tmean_at_pos;
        
        curr_depth_integrating_squeezed = squeeze(curr_depth_integrating);
        
        curr_adv_umean_Tmean_tend_E = -squeeze(hte(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating_squeezed.*umean_east_norm_at_pos(:,:).*Tmean_at_pos(:,:),1))';
        adv_umean_Tmean_tend_E = adv_umean_Tmean_tend_E + curr_adv_umean_Tmean_tend_E;
        curr_adv_umean_Tanom_tend_E = -squeeze(hte(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating_squeezed.*umean_east_norm_at_pos(:,:).*Tanom_at_pos(:,:),1))';
        adv_umean_Tanom_tend_E = adv_umean_Tanom_tend_E + curr_adv_umean_Tanom_tend_E;
        curr_adv_uanom_Tmean_tend_E = -squeeze(hte(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating_squeezed.*uanom_east_norm_at_pos(:,:).*Tmean_at_pos(:,:),1))';
        adv_uanom_Tmean_tend_E = adv_uanom_Tmean_tend_E + curr_adv_uanom_Tmean_tend_E;
        adv_uanom_Tanom_tend_E = adv_uanom_Tanom_tend_E + ((-curr_adv_T_flux_E./vol_integrated_inbox(:)) - curr_adv_umean_Tmean_tend_E - curr_adv_umean_Tanom_tend_E - curr_adv_uanom_Tmean_tend_E);
        
        
        diff_T_flux_E = diff_T_flux_E + squeeze(hte(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating.*hdiff_T_flux_east(curr_i_ind,curr_j_ind,:,:),3));
        
    end   
end



% add the fluxes along the non-corner parts of the edges

% top_depth_bound_array_reshaped = reshape(top_depth_bound_array,[(length(lon_ind_inrange)*length(lat_ind_inrange)) length(unique_times)]);
top_depth_bound_array_reshaped = reshape(top_depth_bound_array,[(length(lon_ind_inrange)*length(lat_ind_inrange)) length(unique_times)]);

for ind_ind = 1:length(no_corners_N_edge_ind)
    curr_ind = no_corners_N_edge_ind(ind_ind);
%     adv_vol_flux_N_prev = adv_vol_flux_N;
    adv_vol_flux_N = flux_edge_vardepth_calc_fcn(adv_vol_flux_N,in_box_ind,curr_ind,hte,htn,dzt,depth_ind_inrange,depth_integrating_array(:,:,:,:),uvel_east(:,:,:,:),vvel_north(:,:,:,:));
    [adv_T_flux_N,adv_vmean_Tmean_tend_N,adv_vmean_Tanom_tend_N,adv_vanom_Tmean_tend_N,adv_vanom_Tanom_tend_N] = flux_edge_vardepth_calc_seasonal_decomp_fcn(adv_T_flux_N,adv_vmean_Tmean_tend_N,adv_vmean_Tanom_tend_N,adv_vanom_Tmean_tend_N,adv_vanom_Tanom_tend_N,in_box_ind,curr_ind,hte,htn,dzt,depth_ind_inrange,depth_integrating_array,uT_east,vT_north,uvel_east,vvel_north,temp,T_mean_inbox,vol_integrated_inbox,G_seasonal,seasonal_reg_operator_T);
    
    diff_T_flux_N = flux_edge_vardepth_calc_fcn(diff_T_flux_N,in_box_ind,curr_ind,hte,htn,dzt,depth_ind_inrange,depth_integrating_array,hdiff_T_flux_east,hdiff_T_flux_north);
    
end
for ind_ind = 1:length(no_corners_W_edge_ind)
    curr_ind = no_corners_W_edge_ind(ind_ind);
    
    adv_vol_flux_W = flux_edge_vardepth_calc_fcn(adv_vol_flux_W,in_box_ind,curr_ind,hte,htn,dzt,depth_ind_inrange,depth_integrating_array,uvel_east,vvel_north);
    [adv_T_flux_W,adv_umean_Tmean_tend_W,adv_umean_Tanom_tend_W,adv_uanom_Tmean_tend_W,adv_uanom_Tanom_tend_W] = flux_edge_vardepth_calc_seasonal_decomp_fcn(adv_T_flux_W,adv_umean_Tmean_tend_W,adv_umean_Tanom_tend_W,adv_uanom_Tmean_tend_W,adv_uanom_Tanom_tend_W,in_box_ind,curr_ind,hte,htn,dzt,depth_ind_inrange,depth_integrating_array,uT_east,vT_north,uvel_east,vvel_north,temp,T_mean_inbox,vol_integrated_inbox,G_seasonal,seasonal_reg_operator_T);
    
    diff_T_flux_W = flux_edge_vardepth_calc_fcn(diff_T_flux_W,in_box_ind,curr_ind,hte,htn,dzt,depth_ind_inrange,depth_integrating_array,hdiff_T_flux_east,hdiff_T_flux_north);
end
for ind_ind = 1:length(no_corners_S_edge_ind)
    curr_ind = no_corners_S_edge_ind(ind_ind);
    
    adv_vol_flux_S = flux_edge_vardepth_calc_fcn(adv_vol_flux_S,in_box_ind,curr_ind,hte,htn,dzt,depth_ind_inrange,depth_integrating_array,uvel_east,vvel_north);
    [adv_T_flux_S,adv_vmean_Tmean_tend_S,adv_vmean_Tanom_tend_S,adv_vanom_Tmean_tend_S,adv_vanom_Tanom_tend_S] = flux_edge_vardepth_calc_seasonal_decomp_fcn(adv_T_flux_S,adv_vmean_Tmean_tend_S,adv_vmean_Tanom_tend_S,adv_vanom_Tmean_tend_S,adv_vanom_Tanom_tend_S,in_box_ind,curr_ind,hte,htn,dzt,depth_ind_inrange,depth_integrating_array,uT_east,vT_north,uvel_east,vvel_north,temp,T_mean_inbox,vol_integrated_inbox,G_seasonal,seasonal_reg_operator_T);
    
    diff_T_flux_S = flux_edge_vardepth_calc_fcn(diff_T_flux_S,in_box_ind,curr_ind,hte,htn,dzt,depth_ind_inrange,depth_integrating_array,hdiff_T_flux_east,hdiff_T_flux_north);
end
for ind_ind = 1:length(no_corners_E_edge_ind)
    curr_ind = no_corners_E_edge_ind(ind_ind);
    
    adv_vol_flux_E = flux_edge_vardepth_calc_fcn(adv_vol_flux_E,in_box_ind,curr_ind,hte,htn,dzt,depth_ind_inrange,depth_integrating_array,uvel_east,vvel_north);
    [adv_T_flux_E,adv_umean_Tmean_tend_E,adv_umean_Tanom_tend_E,adv_uanom_Tmean_tend_E,adv_uanom_Tanom_tend_E] = flux_edge_vardepth_calc_seasonal_decomp_fcn(adv_T_flux_E,adv_umean_Tmean_tend_E,adv_umean_Tanom_tend_E,adv_uanom_Tmean_tend_E,adv_uanom_Tanom_tend_E,in_box_ind,curr_ind,hte,htn,dzt,depth_ind_inrange,depth_integrating_array,uT_east,vT_north,uvel_east,vvel_north,temp,T_mean_inbox,vol_integrated_inbox,G_seasonal,seasonal_reg_operator_T);
    
    diff_T_flux_E = flux_edge_vardepth_calc_fcn(diff_T_flux_E,in_box_ind,curr_ind,hte,htn,dzt,depth_ind_inrange,depth_integrating_array,hdiff_T_flux_east,hdiff_T_flux_north);
end



% compute the top and bottom fluxes

% create depth integrating array that accounts for presence of bathymetry
min_dzt_depth_integrating_array_5D = zeros(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_times),2);
min_dzt_depth_integrating_array_5D(:,:,:,:,1) = depth_integrating_array;
min_dzt_depth_integrating_array_5D(:,:,:,:,2) = repmat(dzt(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]);
min_dzt_depth_integrating_array = squeeze(min(min_dzt_depth_integrating_array_5D,[],5));


% create array to help identify top and bottom bounds of region

nonzero_mask_depth_integrating_dzt_combined = zeros(size(min_dzt_depth_integrating_array));
nonzero_mask_depth_integrating_dzt_combined(min_dzt_depth_integrating_array ~= 0) = 1;

diff_z_nonzero_mask = zeros(length(lon_ind_inrange),length(lat_ind_inrange),(length(depth_ind_inrange) + 1),length(unique_times));
diff_z_nonzero_mask(:,:,1,:) = nonzero_mask_depth_integrating_dzt_combined(:,:,1,:) - 0;
diff_z_nonzero_mask(:,:,2:length(depth_ind_inrange),:) = diff(nonzero_mask_depth_integrating_dzt_combined,1,3);
diff_z_nonzero_mask(:,:,length(depth_ind_inrange) + 1,:) = 0 - nonzero_mask_depth_integrating_dzt_combined(:,:,length(depth_ind_inrange),:);



% identify top and bottom depth cells for each (horizontal point), and create a weighting array for vertical fluxes

top_bound_cell_ind = find(diff_z_nonzero_mask(:,:,1:length(depth_ind_inrange),:) == 1);
top_bound_depth_ind = mod((ceil(top_bound_cell_ind/(length(lon_ind_inrange)*length(lat_ind_inrange)))) - 1,length(depth_ind_inrange)) + 1;

top_cell_k_ind = depth_ind_inrange(top_bound_depth_ind);
repmat_top_depth_bound_array = repmat(reshape(top_depth_bound_array,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[1 1 length(depth_ind_inrange) 1]);
repmat_dzt_in_depth_range = repmat(dzt(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]);
frac_below_top = (repmat_top_depth_bound_array(top_bound_cell_ind) - z_w_top(top_cell_k_ind))./repmat_dzt_in_depth_range(top_bound_cell_ind);
frac_below_top(frac_below_top > 1) = 1;
frac_above_top = 1 - frac_below_top;

top_bound_weighting_array = zeros(size(min_dzt_depth_integrating_array));
top_bound_weighting_array(top_bound_cell_ind) = frac_above_top;
top_bound_weighting_array(top_bound_cell_ind + (length(lon_ind_inrange)*length(lat_ind_inrange))) = frac_below_top;



bottom_bound_cell_ind = find(diff_z_nonzero_mask(:,:,2:(length(depth_ind_inrange) + 1),:) == (-1));
bottom_bound_depth_ind = mod((ceil(bottom_bound_cell_ind/(length(lon_ind_inrange)*length(lat_ind_inrange)))) - 1,length(depth_ind_inrange)) + 1;

bottom_cell_k_ind = depth_ind_inrange(bottom_bound_depth_ind);
repmat_bottom_depth_bound_array = repmat(reshape(bottom_depth_bound_array,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[1 1 length(depth_ind_inrange) 1]);

% account for the possibility that the prescribed bottom depth bounds are deeper than the bathymetry
thickness_at_base_layer_array = zeros(length(bottom_bound_cell_ind),2);
thickness_at_base_layer_array(:,1) = repmat_bottom_depth_bound_array(bottom_bound_cell_ind) - z_w_top(bottom_cell_k_ind);
thickness_at_base_layer_array(:,2) = repmat_dzt_in_depth_range(bottom_bound_cell_ind);

frac_below_bottom = min(thickness_at_base_layer_array,[],2)./repmat_dzt_in_depth_range(bottom_bound_cell_ind);
bottom_bound_bottom_level_ind = find(repmat_bottom_depth_bound_array(bottom_bound_cell_ind) > z_w_top(depth_ind_inrange(size(wvel,3))));
frac_below_bottom(bottom_bound_bottom_level_ind) = 0;
frac_below_bottom(isnan(frac_below_bottom) == 1) = 0;
frac_above_bottom = 1 - frac_below_bottom;


bottom_bound_weighting_array = zeros(size(min_dzt_depth_integrating_array));
bottom_bound_weighting_array(bottom_bound_cell_ind) = frac_above_bottom;
bottom_bound_not_bottom_level_ind = setdiff((1:1:length(bottom_bound_cell_ind))',bottom_bound_bottom_level_ind);
bottom_bound_weighting_array(bottom_bound_cell_ind(bottom_bound_not_bottom_level_ind) + (length(lon_ind_inrange)*length(lat_ind_inrange))) = frac_below_bottom(bottom_bound_not_bottom_level_ind);



% adjustment to the advective tracer flux at z = 0
% Note: though in POP wT = 0 through the surface, this adjustment is to represent the advective flux at z = 0 consistently with other fluxes, and recover the true temp. tendency.  For the surface layer, which varies in thickness, the tendency due to the advective flux through z = 0 is essentially balanced in this formulation by the entrainment tendency at the top surface as the top depth bound changes with time.  (Unless there is freshwater input at the surface, in which case the top advective and entrainment tendencies may not quite balance.)
wT_top(:,:,1,:) = wvel(:,:,1,:).*temp(:,:,1,:);

wvel(isnan(wvel) == 1) = 0;
wT_top(isnan(wT_top) == 1) = 0;



% volume, advective, and diffusive vertical fluxes are calculated

adv_vol_flux_top = squeeze(sum(sum((repmat(in_box_mask.*tarea,[1 1 1 length(unique_times)]).*sum(top_bound_weighting_array(:,:,:,:).*wvel(:,:,:,:),3)),2),1));
adv_T_flux_top = squeeze(sum(sum((repmat(in_box_mask.*tarea,[1 1 1 length(unique_times)]).*sum(top_bound_weighting_array(:,:,:,:).*wT_top(:,:,:,:),3)),2),1)) - (adv_vol_flux_top.*T_mean_inbox);

size_wvel = size(wvel);
wvel_norm_reshaped = reshape(-wvel,[prod(size_wvel(1:3)) size_wvel(4)])./repmat(vol_integrated_inbox',[prod(size_wvel(1:3)) 1]);
m_seasonal_wvel_norm = wvel_norm_reshaped*seasonal_reg_operator_T;
wmean_norm_array = reshape(m_seasonal_wvel_norm*(G_seasonal'),size_wvel);
wanom_norm_array = (-wvel./repmat(reshape(vol_integrated_inbox,[1 1 1 length(vol_integrated_inbox)]),size_wvel(1:3))) - wmean_norm_array;

temp_interp_at_w_level = zeros(size(temp));
temp_interp_at_w_level(:,:,1,:) = temp(:,:,1,:);
temp_interp_at_w_level(:,:,2:size(temp,3),:) = (0.5*temp(:,:,1:(size(temp,3) - 1),:)) + (0.5*temp(:,:,2:size(temp,3),:));
T_minus_T_inboxmean_at_w_level = temp_interp_at_w_level - repmat(reshape(T_mean_inbox,[1 1 1 length(T_mean_inbox)]),[size(temp,1) size(temp,2) size(temp,3) 1]);
m_seasonal_T_at_pos = reshape(T_minus_T_inboxmean_at_w_level,[prod(size_wvel(1:3)) size_wvel(4)])*seasonal_reg_operator_T;
Tmean_array_at_w_level = reshape(m_seasonal_T_at_pos*(G_seasonal'),size_wvel);
Tanom_array_at_w_level = T_minus_T_inboxmean_at_w_level - Tmean_array_at_w_level;


adv_wmean_Tmean_tend_top = squeeze(sum(sum((repmat(in_box_mask.*tarea,[1 1 1 length(unique_times)]).*sum(top_bound_weighting_array(:,:,:,:).*(wmean_norm_array(:,:,:,:).*Tmean_array_at_w_level(:,:,:,:)),3)),2),1));
adv_wmean_Tanom_tend_top = squeeze(sum(sum((repmat(in_box_mask.*tarea,[1 1 1 length(unique_times)]).*sum(top_bound_weighting_array(:,:,:,:).*(wmean_norm_array(:,:,:,:).*Tanom_array_at_w_level(:,:,:,:)),3)),2),1));
adv_wanom_Tmean_tend_top = squeeze(sum(sum((repmat(in_box_mask.*tarea,[1 1 1 length(unique_times)]).*sum(top_bound_weighting_array(:,:,:,:).*(wanom_norm_array(:,:,:,:).*Tmean_array_at_w_level(:,:,:,:)),3)),2),1));
adv_wanom_Tanom_tend_top = (-adv_T_flux_top./vol_integrated_inbox(:)) - adv_wmean_Tmean_tend_top - adv_wmean_Tanom_tend_top - adv_wanom_Tmean_tend_top;


diff_T_flux_top_pre_spatavg = squeeze(sum(top_bound_weighting_array(:,:,2:length(depth_ind_inrange),:).*hdiff_T_flux_bottom(:,:,1:(length(depth_ind_inrange) - 1),:),3));
diab_vert_T_flux_top_pre_spatavg = squeeze(sum(top_bound_weighting_array(:,:,2:length(depth_ind_inrange),:).*diab_imp_vert_T_flux_bottom(:,:,1:(length(depth_ind_inrange) - 1),:),3));


diff_T_flux_top = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 length(unique_times)]).*diff_T_flux_top_pre_spatavg,2),1));
diab_vert_T_flux_top = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 length(unique_times)]).*diab_vert_T_flux_top_pre_spatavg,2),1));




adv_vol_flux_bottom = squeeze(sum(sum((-repmat(in_box_mask.*tarea,[1 1 1 length(unique_times)]).*sum(bottom_bound_weighting_array(:,:,:,:).*wvel(:,:,:,:),3)),2),1));
adv_T_flux_bottom = squeeze(sum(sum((-repmat(in_box_mask.*tarea,[1 1 1 length(unique_times)]).*sum(bottom_bound_weighting_array(:,:,:,:).*wT_top(:,:,:,:),3)),2),1)) - (adv_vol_flux_bottom.*T_mean_inbox);


adv_wmean_Tmean_tend_bottom = squeeze(sum(sum((-repmat(in_box_mask.*tarea,[1 1 1 length(unique_times)]).*sum(bottom_bound_weighting_array(:,:,:,:).*(wmean_norm_array(:,:,:,:).*Tmean_array_at_w_level(:,:,:,:)),3)),2),1));
adv_wmean_Tanom_tend_bottom = squeeze(sum(sum((-repmat(in_box_mask.*tarea,[1 1 1 length(unique_times)]).*sum(bottom_bound_weighting_array(:,:,:,:).*(wmean_norm_array(:,:,:,:).*Tanom_array_at_w_level(:,:,:,:)),3)),2),1));
adv_wanom_Tmean_tend_bottom = squeeze(sum(sum((-repmat(in_box_mask.*tarea,[1 1 1 length(unique_times)]).*sum(bottom_bound_weighting_array(:,:,:,:).*(wanom_norm_array(:,:,:,:).*Tmean_array_at_w_level(:,:,:,:)),3)),2),1));
adv_wanom_Tanom_tend_bottom = (-adv_T_flux_bottom./vol_integrated_inbox(:)) - adv_wmean_Tmean_tend_bottom - adv_wmean_Tanom_tend_bottom - adv_wanom_Tmean_tend_bottom;


diff_T_flux_bottom_pre_spatavg = squeeze(sum(bottom_bound_weighting_array(:,:,2:length(depth_ind_inrange),:).*hdiff_T_flux_bottom(:,:,1:(length(depth_ind_inrange) - 1),:),3));
diab_vert_T_flux_bottom_pre_spatavg = squeeze(sum(bottom_bound_weighting_array(:,:,2:length(depth_ind_inrange),:).*diab_imp_vert_T_flux_bottom(:,:,1:(length(depth_ind_inrange) - 1),:),3));


diff_T_flux_bottom = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 length(unique_times)]).*diff_T_flux_bottom_pre_spatavg,2),1));
diab_vert_T_flux_bottom = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 length(unique_times)]).*diab_vert_T_flux_bottom_pre_spatavg,2),1));



% correct vertical fluxes for cells adjacent to bathymetry

size_array = [length(lon_ind_inrange) length(lat_ind_inrange) length(depth_ind_inrange) length(unique_time_ind)];

dzt_west_wall = zeros([size_array(1:2) size(dzt,3)]);
dzt_west_wall(2:length(lon_ind_inrange),:,:) = dzt_east_wall(1:(length(lon_ind_inrange) - 1),:,:);
dzt_south_wall = zeros([size_array(1:2) size(dzt,3)]);
dzt_south_wall(:,2:length(lat_ind_inrange),:) = dzt_north_wall(:,1:(length(lat_ind_inrange) - 1),:);

diff_z_w_bot_shallowest_top_bound = repmat(reshape(z_w_bot(depth_ind_inrange),[1 1 length(depth_ind_inrange)]),[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]) - repmat(reshape(top_depth_bound_array,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[1 1 length(depth_ind_inrange) 1]);
diff_z_w_bot_shallowest_top_bound(diff_z_w_bot_shallowest_top_bound < 0) = 0;

repmat_dz_in_range_array = repmat(reshape(dz(depth_ind_inrange),[1 1 length(depth_ind_inrange)]),[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]);
repmat_dzt_in_range_array = repmat(dzt(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]);
min_dzt_depth_integrating_top_only = reshape(min([reshape(repmat_dz_in_range_array,[1 prod(size(diff_z_w_bot_shallowest_top_bound))]); reshape(diff_z_w_bot_shallowest_top_bound,[1 prod(size(diff_z_w_bot_shallowest_top_bound))])],[],1),[length(lon_ind_inrange) length(lat_ind_inrange) length(depth_ind_inrange) length(unique_times)]) - (repmat_dz_in_range_array - repmat_dzt_in_range_array);


% adjustment for top vertical fluxes

supposed_frac = min_dzt_depth_integrating_top_only./repmat_dzt_in_range_array;
% supposed_frac(top_bound_cell_ind) = min_dzt_depth_integrating_top_only(top_bound_cell_ind)./repmat_dzt_in_range_array(top_bound_cell_ind);
supposed_frac(isnan(supposed_frac) | isinf(supposed_frac)) = 0;
actual_frac_east_wall = ((min_dzt_depth_integrating_top_only - repmat_dzt_in_range_array)./repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)])) + 1;
actual_frac_east_wall(isnan(actual_frac_east_wall) | isinf(actual_frac_east_wall)) = 0;
actual_frac_east_wall(actual_frac_east_wall < 0) = 0;
correction_factor_E = actual_frac_east_wall - supposed_frac;
actual_frac_west_wall = ((min_dzt_depth_integrating_top_only - repmat_dzt_in_range_array)./repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)])) + 1;
actual_frac_west_wall(isnan(actual_frac_west_wall) | isinf(actual_frac_west_wall)) = 0;
actual_frac_west_wall(actual_frac_west_wall < 0) = 0;
correction_factor_W = actual_frac_west_wall - supposed_frac;
actual_frac_north_wall = ((min_dzt_depth_integrating_top_only - repmat_dzt_in_range_array)./repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)])) + 1;
actual_frac_north_wall(isnan(actual_frac_north_wall) | isinf(actual_frac_north_wall)) = 0;
actual_frac_north_wall(actual_frac_north_wall < 0) = 0;
correction_factor_N = actual_frac_north_wall - supposed_frac;
actual_frac_south_wall = ((min_dzt_depth_integrating_top_only - repmat_dzt_in_range_array)./repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)])) + 1;
actual_frac_south_wall(isnan(actual_frac_south_wall) | isinf(actual_frac_south_wall)) = 0;
actual_frac_south_wall(actual_frac_south_wall < 0) = 0;
correction_factor_S = actual_frac_south_wall - supposed_frac;

top_cell_mask = zeros(size_array);
top_cell_mask(top_bound_cell_ind) = 1;

adv_vol_flux_top_correction_E = -squeeze(sum(sum(repmat(in_box_mask.*hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_E.*repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_east,3)),2),1));
adv_vol_flux_top_correction_W = squeeze(sum(sum(repmat(in_box_mask.*hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_W.*repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_west,3)),2),1));
adv_vol_flux_top_correction_N = -squeeze(sum(sum(repmat(in_box_mask.*htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_N.*repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_north,3)),2),1));
adv_vol_flux_top_correction_S = squeeze(sum(sum(repmat(in_box_mask.*htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_S.*repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_south,3)),2),1));
adv_vol_flux_top = adv_vol_flux_top + (adv_vol_flux_top_correction_E + adv_vol_flux_top_correction_W + adv_vol_flux_top_correction_N + adv_vol_flux_top_correction_S);

adv_T_flux_top_correction_E = -squeeze(sum(sum(repmat(in_box_mask.*hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_E.*repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uT_east,3)),2),1)) - (adv_vol_flux_top_correction_E.*T_mean_inbox);
adv_T_flux_top_correction_W = squeeze(sum(sum(repmat(in_box_mask.*hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_W.*repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uT_west,3)),2),1)) - (adv_vol_flux_top_correction_W.*T_mean_inbox);
adv_T_flux_top_correction_N = -squeeze(sum(sum(repmat(in_box_mask.*htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_N.*repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vT_north,3)),2),1)) - (adv_vol_flux_top_correction_N.*T_mean_inbox);
adv_T_flux_top_correction_S = squeeze(sum(sum(repmat(in_box_mask.*htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_S.*repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vT_south,3)),2),1)) - (adv_vol_flux_top_correction_S.*T_mean_inbox);
adv_T_flux_top = adv_T_flux_top + (adv_T_flux_top_correction_E + adv_T_flux_top_correction_W + adv_T_flux_top_correction_N + adv_T_flux_top_correction_S);

% adv_T_tend_top = -adv_T_flux_top./vol_integrated_inbox;


% adv_wvel_reg_T_reg_tend_top_correction_E = squeeze(sum(sum(repmat(in_box_mask.*hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_E.*repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_reg_east.*T_reg_east,3)),2),1))./vol_integrated_inbox;
% adv_wvel_reg_T_noreg_tend_top_correction_E = squeeze(sum(sum(repmat(in_box_mask.*hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_E.*repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_reg_east.*T_noreg_east,3)),2),1))./vol_integrated_inbox;
% adv_wvel_noreg_T_reg_tend_top_correction_E = squeeze(sum(sum(repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_E.*repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_noreg_east.*T_reg_east,3)),2),1))./vol_integrated_inbox;
% adv_wvel_noreg_T_noreg_tend_top_correction_E = (-adv_T_flux_top_correction_E./vol_integrated_inbox) - (adv_wvel_reg_T_reg_tend_top_correction_E + adv_wvel_reg_T_noreg_tend_top_correction_E + adv_wvel_noreg_T_reg_tend_top_correction_E);
% adv_wvel_reg_T_reg_tend_top_correction_W = -squeeze(sum(sum(repmat(in_box_mask.*hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_W.*repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_reg_west.*T_reg_west,3)),2),1))./vol_integrated_inbox;
% adv_wvel_reg_T_noreg_tend_top_correction_W = -squeeze(sum(sum(repmat(in_box_mask.*hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_W.*repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_reg_west.*T_noreg_west,3)),2),1))./vol_integrated_inbox;
% adv_wvel_noreg_T_reg_tend_top_correction_W = -squeeze(sum(sum(repmat(in_box_mask.*hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_W.*repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_noreg_west.*T_reg_west,3)),2),1))./vol_integrated_inbox;
% adv_wvel_noreg_T_noreg_tend_top_correction_W = (-adv_T_flux_top_correction_W./vol_integrated_inbox) - (adv_wvel_reg_T_reg_tend_top_correction_W + adv_wvel_reg_T_noreg_tend_top_correction_W + adv_wvel_noreg_T_reg_tend_top_correction_W);
% adv_wvel_reg_T_reg_tend_top_correction_N = squeeze(sum(sum(repmat(in_box_mask.*htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_N.*repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_reg_north.*T_reg_north,3)),2),1))./vol_integrated_inbox;
% adv_wvel_reg_T_noreg_tend_top_correction_N = squeeze(sum(sum(repmat(in_box_mask.*htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_N.*repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_reg_north.*T_noreg_north,3)),2),1))./vol_integrated_inbox;
% adv_wvel_noreg_T_reg_tend_top_correction_N = squeeze(sum(sum(repmat(in_box_mask.*htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_N.*repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_noreg_north.*T_reg_north,3)),2),1))./vol_integrated_inbox;
% adv_wvel_noreg_T_noreg_tend_top_correction_N = (-adv_T_flux_top_correction_N./vol_integrated_inbox) - (adv_wvel_reg_T_reg_tend_top_correction_N + adv_wvel_reg_T_noreg_tend_top_correction_N + adv_wvel_noreg_T_reg_tend_top_correction_N);
% adv_wvel_reg_T_reg_tend_top_correction_S = -squeeze(sum(sum(repmat(in_box_mask.*htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_S.*repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_reg_south.*T_reg_south,3)),2),1))./vol_integrated_inbox;
% adv_wvel_reg_T_noreg_tend_top_correction_S = -squeeze(sum(sum(repmat(in_box_mask.*htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_S.*repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_reg_south.*T_noreg_south,3)),2),1))./vol_integrated_inbox;
% adv_wvel_noreg_T_reg_tend_top_correction_S = -squeeze(sum(sum(repmat(in_box_mask.*htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(top_cell_mask.*correction_factor_S.*repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_noreg_south.*T_reg_south,3)),2),1))./vol_integrated_inbox;
% adv_wvel_noreg_T_noreg_tend_top_correction_S = (-adv_T_flux_top_correction_S./vol_integrated_inbox) - (adv_wvel_reg_T_reg_tend_top_correction_S + adv_wvel_reg_T_noreg_tend_top_correction_S + adv_wvel_noreg_T_reg_tend_top_correction_S);
% 
% 
% adv_wvel_reg_T_reg_tend_top = adv_wvel_reg_T_reg_tend_top + adv_wvel_reg_T_reg_tend_top_correction_E + adv_wvel_reg_T_reg_tend_top_correction_W + adv_wvel_reg_T_reg_tend_top_correction_N + adv_wvel_reg_T_reg_tend_top_correction_S;
% adv_wvel_reg_T_noreg_tend_top = adv_wvel_reg_T_noreg_tend_top + adv_wvel_reg_T_noreg_tend_top_correction_E + adv_wvel_reg_T_noreg_tend_top_correction_W + adv_wvel_reg_T_noreg_tend_top_correction_N + adv_wvel_reg_T_noreg_tend_top_correction_S;
% adv_wvel_noreg_T_reg_tend_top = adv_wvel_noreg_T_reg_tend_top + adv_wvel_noreg_T_reg_tend_top_correction_E + adv_wvel_noreg_T_reg_tend_top_correction_W + adv_wvel_noreg_T_reg_tend_top_correction_N + adv_wvel_noreg_T_reg_tend_top_correction_S;
% adv_wvel_noreg_T_noreg_tend_top = adv_wvel_noreg_T_noreg_tend_top + adv_wvel_noreg_T_noreg_tend_top_correction_E + adv_wvel_noreg_T_noreg_tend_top_correction_W + adv_wvel_noreg_T_noreg_tend_top_correction_N + adv_wvel_noreg_T_noreg_tend_top_correction_S;


% adjustment for bottom vertical fluxes

diff_z_w_top_deepest_bottom_bound = repmat(reshape(bottom_depth_bound_array,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[1 1 length(depth_ind_inrange) 1]) - repmat(reshape(z_w_top(depth_ind_inrange),[1 1 length(depth_ind_inrange)]),[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]);
diff_z_w_top_deepest_bottom_bound(diff_z_w_top_deepest_bottom_bound < 0) = 0;

min_dzt_depth_integrating_bottom_only = reshape(min([reshape(repmat(dzt(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]),[1 prod(size(diff_z_w_top_deepest_bottom_bound))]); reshape(diff_z_w_top_deepest_bottom_bound,[1 prod(size(diff_z_w_top_deepest_bottom_bound))])],[],1),[length(lon_ind_inrange) length(lat_ind_inrange) length(depth_ind_inrange) length(unique_times)]);

supposed_frac = min_dzt_depth_integrating_bottom_only./repmat_dzt_in_range_array;
% supposed_frac(bottom_bound_cell_ind) = min_dzt_depth_integrating_bottom_only(bottom_bound_cell_ind)./repmat_dzt_in_range_array(bottom_bound_cell_ind);
supposed_frac(isnan(supposed_frac) | isinf(supposed_frac)) = 0;
actual_frac_east_wall = min_dzt_depth_integrating_bottom_only./repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]);
actual_frac_east_wall(isnan(actual_frac_east_wall) | isinf(actual_frac_east_wall)) = 0;
actual_frac_east_wall(actual_frac_east_wall > 1) = 1;
correction_factor_E = actual_frac_east_wall - supposed_frac;
actual_frac_west_wall = min_dzt_depth_integrating_bottom_only./repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]);
actual_frac_west_wall(isnan(actual_frac_west_wall) | isinf(actual_frac_west_wall)) = 0;
actual_frac_west_wall(actual_frac_west_wall > 1) = 1;
correction_factor_W = actual_frac_west_wall - supposed_frac;
actual_frac_north_wall = min_dzt_depth_integrating_bottom_only./repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]);
actual_frac_north_wall(isnan(actual_frac_north_wall) | isinf(actual_frac_north_wall)) = 0;
actual_frac_north_wall(actual_frac_north_wall > 1) = 1;
correction_factor_N = actual_frac_north_wall - supposed_frac;
actual_frac_south_wall = min_dzt_depth_integrating_bottom_only./repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]);
actual_frac_south_wall(isnan(actual_frac_south_wall) | isinf(actual_frac_south_wall)) = 0;
actual_frac_south_wall(actual_frac_south_wall > 1) = 1;
correction_factor_S = actual_frac_south_wall - supposed_frac;

bottom_cell_mask = zeros(size_array);
bottom_cell_mask(bottom_bound_cell_ind) = 1;

adv_vol_flux_bottom_correction_E = squeeze(sum(sum(repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_E.*repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_east,3)),2),1));
adv_vol_flux_bottom_correction_W = -squeeze(sum(sum(repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_W.*repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_west,3)),2),1));
adv_vol_flux_bottom_correction_N = squeeze(sum(sum(repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_N.*repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_north,3)),2),1));
adv_vol_flux_bottom_correction_S = -squeeze(sum(sum(repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_S.*repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_south,3)),2),1));
adv_vol_flux_bottom = adv_vol_flux_bottom + adv_vol_flux_bottom_correction_E + adv_vol_flux_bottom_correction_W + adv_vol_flux_bottom_correction_N + adv_vol_flux_bottom_correction_S;

adv_T_flux_bottom_correction_E = (squeeze(sum(sum(repmat(hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_E.*repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uT_east,3)),2),1))) - (adv_vol_flux_bottom_correction_E.*T_mean_inbox);
adv_T_flux_bottom_correction_W = -(squeeze(sum(sum(repmat(hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_W.*repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uT_west,3)),2),1))) - (adv_vol_flux_bottom_correction_W.*T_mean_inbox);
adv_T_flux_bottom_correction_N = (squeeze(sum(sum(repmat(htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_N.*repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vT_north,3)),2),1))) - (adv_vol_flux_bottom_correction_N.*T_mean_inbox);
adv_T_flux_bottom_correction_S = -(squeeze(sum(sum(repmat(htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_S.*repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vT_south,3)),2),1))) - (adv_vol_flux_bottom_correction_S.*T_mean_inbox);
adv_T_flux_bottom = adv_T_flux_bottom + adv_T_flux_bottom_correction_E + adv_T_flux_bottom_correction_W + adv_T_flux_bottom_correction_N + adv_T_flux_bottom_correction_S;

disp(['NaNs in correction_factor_E = ',num2str(length(find(isnan(correction_factor_E) == 1)))])
disp(['NaNs in adv_T_flux_bottom_correction_E = ',num2str(length(find(isnan(adv_T_flux_bottom_correction_E) == 1)))])
disp(['NaNs in adv_T_flux_bottom = ',num2str(length(find(isnan(adv_T_flux_bottom) == 1)))])

% adv_T_tend_bottom = adv_T_flux_bottom./vol_layer_at_horiz_cell;


% adv_wvel_reg_T_reg_tend_bottom_correction_E = squeeze(sum(sum(repmat(in_box_mask.*hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_E.*repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_reg_east.*T_reg_east,3)),2),1))./vol_integrated_inbox;
% adv_wvel_reg_T_noreg_tend_bottom_correction_E = squeeze(sum(sum(repmat(in_box_mask.*hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_E.*repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_reg_east.*T_noreg_east,3)),2),1))./vol_integrated_inbox;
% adv_wvel_noreg_T_reg_tend_bottom_correction_E = squeeze(sum(sum(repmat(in_box_mask.*hte_east_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_E.*repmat(dzt_east_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_noreg_east.*T_reg_east,3)),2),1))./vol_integrated_inbox;
% adv_wvel_noreg_T_noreg_tend_bottom_correction_E = (adv_T_flux_bottom_correction_E./vol_integrated_inbox) - (adv_wvel_reg_T_reg_tend_bottom_correction_E + adv_wvel_reg_T_noreg_tend_bottom_correction_E + adv_wvel_noreg_T_reg_tend_bottom_correction_E);
% adv_wvel_reg_T_reg_tend_bottom_correction_W = -squeeze(sum(sum(repmat(in_box_mask.*hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_W.*repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_reg_west.*T_reg_west,3)),2),1))./vol_integrated_inbox;
% adv_wvel_reg_T_noreg_tend_bottom_correction_W = -squeeze(sum(sum(repmat(in_box_mask.*hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_W.*repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_reg_west.*T_noreg_west,3)),2),1))./vol_integrated_inbox;
% adv_wvel_noreg_T_reg_tend_bottom_correction_W = -squeeze(sum(sum(repmat(in_box_mask.*hte_west_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_W.*repmat(dzt_west_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*uvel_noreg_west.*T_reg_west,3)),2),1))./vol_integrated_inbox;
% adv_wvel_noreg_T_noreg_tend_bottom_correction_W = (adv_T_flux_bottom_correction_W./vol_integrated_inbox) - (adv_wvel_reg_T_reg_tend_bottom_correction_W + adv_wvel_reg_T_noreg_tend_bottom_correction_W + adv_wvel_noreg_T_reg_tend_bottom_correction_W);
% adv_wvel_reg_T_reg_tend_bottom_correction_N = squeeze(sum(sum(repmat(in_box_mask.*htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_N.*repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_reg_north.*T_reg_north,3)),2),1))./vol_integrated_inbox;
% adv_wvel_reg_T_noreg_tend_bottom_correction_N = squeeze(sum(sum(repmat(in_box_mask.*htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_N.*repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_reg_north.*T_noreg_north,3)),2),1))./vol_integrated_inbox;
% adv_wvel_noreg_T_reg_tend_bottom_correction_N = squeeze(sum(sum(repmat(in_box_mask.*htn_north_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_N.*repmat(dzt_north_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_noreg_north.*T_reg_north,3)),2),1))./vol_integrated_inbox;
% adv_wvel_noreg_T_noreg_tend_bottom_correction_N = (adv_T_flux_bottom_correction_N./vol_integrated_inbox) - (adv_wvel_reg_T_reg_tend_bottom_correction_N + adv_wvel_reg_T_noreg_tend_bottom_correction_N + adv_wvel_noreg_T_reg_tend_bottom_correction_N);
% adv_wvel_reg_T_reg_tend_bottom_correction_S = -squeeze(sum(sum(repmat(in_box_mask.*htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_S.*repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_reg_south.*T_reg_south,3)),2),1))./vol_integrated_inbox;
% adv_wvel_reg_T_noreg_tend_bottom_correction_S = -squeeze(sum(sum(repmat(in_box_mask.*htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_S.*repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_reg_south.*T_noreg_south,3)),2),1))./vol_integrated_inbox;
% adv_wvel_noreg_T_reg_tend_bottom_correction_S = -squeeze(sum(sum(repmat(in_box_mask.*htn_south_side,[1 1 length(unique_times)]).*squeeze(sum(bottom_cell_mask.*correction_factor_S.*repmat(dzt_south_wall(:,:,depth_ind_inrange),[1 1 1 length(unique_times)]).*vvel_noreg_south.*T_reg_south,3)),2),1))./vol_integrated_inbox;
% adv_wvel_noreg_T_noreg_tend_bottom_correction_S = (adv_T_flux_bottom_correction_S./vol_integrated_inbox) - (adv_wvel_reg_T_reg_tend_bottom_correction_S + adv_wvel_reg_T_noreg_tend_bottom_correction_S + adv_wvel_noreg_T_reg_tend_bottom_correction_S);
% 
% 
% adv_wvel_reg_T_reg_tend_bottom = adv_wvel_reg_T_reg_tend_bottom + adv_wvel_reg_T_reg_tend_bottom_correction_E + adv_wvel_reg_T_reg_tend_bottom_correction_W + adv_wvel_reg_T_reg_tend_bottom_correction_N + adv_wvel_reg_T_reg_tend_bottom_correction_S;
% adv_wvel_reg_T_noreg_tend_bottom = adv_wvel_reg_T_noreg_tend_bottom + adv_wvel_reg_T_noreg_tend_bottom_correction_E + adv_wvel_reg_T_noreg_tend_bottom_correction_W + adv_wvel_reg_T_noreg_tend_bottom_correction_N + adv_wvel_reg_T_noreg_tend_bottom_correction_S;
% adv_wvel_noreg_T_reg_tend_bottom = adv_wvel_noreg_T_reg_tend_bottom + adv_wvel_noreg_T_reg_tend_bottom_correction_E + adv_wvel_noreg_T_reg_tend_bottom_correction_W + adv_wvel_noreg_T_reg_tend_bottom_correction_N + adv_wvel_noreg_T_reg_tend_bottom_correction_S;
% adv_wvel_noreg_T_noreg_tend_bottom = adv_wvel_noreg_T_noreg_tend_bottom + adv_wvel_noreg_T_noreg_tend_bottom_correction_E + adv_wvel_noreg_T_noreg_tend_bottom_correction_W + adv_wvel_noreg_T_noreg_tend_bottom_correction_N + adv_wvel_noreg_T_noreg_tend_bottom_correction_S;


disp('Completed computing non-sloping advective terms')

% save('adv_T_tend_from_edge_flux_calc.mat','adv_T_flux*','adv_T_tend*','adv_vol*','hte','htn','in_box_mask','tarea','depth_integrating_array','-v7.3')


% compute horizontal advection/diffusion terms through variable depth top bound


diff_z_w_bot_shallowest_top_bound = repmat(reshape(z_w_bot(depth_ind_inrange),[1 1 length(depth_ind_inrange)]),[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]) - repmat(reshape(top_depth_bound_array,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[1 1 length(depth_ind_inrange) 1]);
diff_z_w_bot_shallowest_top_bound(diff_z_w_bot_shallowest_top_bound < 0) = 0;

min_dz_depth_integrating_top_only = reshape(min([reshape(repmat(reshape(dz(depth_ind_inrange),[1 1 length(depth_ind_inrange)]),[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[1 prod(size(diff_z_w_bot_shallowest_top_bound))]); reshape(diff_z_w_bot_shallowest_top_bound,[1 prod(size(diff_z_w_bot_shallowest_top_bound))])],[],1),[length(lon_ind_inrange) length(lat_ind_inrange) length(depth_ind_inrange) length(unique_times)]);

diff_x_min_dz_depth_integrating_top_only = diff(min_dz_depth_integrating_top_only,1,1);
diff_x_min_dz_depth_integrating_east_facing_top_only = diff_x_min_dz_depth_integrating_top_only;
not_east_facing_ind = find(diff_x_min_dz_depth_integrating_east_facing_top_only >= 0);
diff_x_min_dz_depth_integrating_east_facing_top_only(not_east_facing_ind) = 0;

% adv_vol_flux_E_sloping_top = squeeze(sum(sum(repmat(in_box_mask(1:(length(lon_ind_inrange) - 1),:),[1 1 1 length(unique_times)]).*repmat(hte(1:(length(lon_ind_inrange) - 1),:),[1 1 1 length(unique_times)]).*sum(-diff_x_min_dz_depth_integrating_east_facing_top_only(:,:,:,:).*uvel_east(1:(length(lon_ind_inrange) - 1),:,:,:),3),2),1));
% adv_T_flux_E_sloping_top = squeeze(sum(sum(repmat(in_box_mask(1:(length(lon_ind_inrange) - 1),:),[1 1 1 length(unique_times)]).*repmat(hte(1:(length(lon_ind_inrange) - 1),:),[1 1 1 length(unique_times)]).*sum(-diff_x_min_dz_depth_integrating_east_facing_top_only.*uT_east(1:(length(lon_ind_inrange) - 1),:,:,:),3),2),1));

east_facing_ind = setdiff((1:1:prod(size(diff_x_min_dz_depth_integrating_east_facing_top_only)))',not_east_facing_ind);
size_array = size(diff_x_min_dz_depth_integrating_east_facing_top_only);
east_facing_t_ind = ceil(east_facing_ind/prod(size_array(1:3)));
% in_time_range_east_facing_ind = find(ismember(east_facing_t_ind,time_inrange_from_unique_ind) == 1);
% east_facing_ind = east_facing_ind(in_time_range_east_facing_ind);
% east_facing_t_ind = east_facing_t_ind(in_time_range_east_facing_ind);
t_residual = east_facing_ind - (prod(size_array(1:3))*(east_facing_t_ind - 1));
unique_east_facing_i_j_k_ind = unique(t_residual);

adv_vol_flux_E_sloping_top = zeros(length(unique_times),1);
adv_T_flux_E_sloping_top = zeros(length(unique_times),1);
adv_umean_Tmean_tend_E_sloping_top = zeros(length(unique_times),1);
adv_umean_Tanom_tend_E_sloping_top = zeros(length(unique_times),1);
adv_uanom_Tmean_tend_E_sloping_top = zeros(length(unique_times),1);
adv_uanom_Tanom_tend_E_sloping_top = zeros(length(unique_times),1);
for east_facing_cell_ind = 1:length(unique_east_facing_i_j_k_ind)
    curr_i_j_k_ind = unique_east_facing_i_j_k_ind(east_facing_cell_ind);
    curr_k_ind = ceil(curr_i_j_k_ind/prod(size_array(1:2)));
    k_residual = curr_i_j_k_ind - (prod(size_array(1:2))*(curr_k_ind - 1));
    curr_j_ind = ceil(k_residual/size_array(1));
    curr_i_ind = k_residual - ((size_array(1))*(curr_j_ind - 1));
    
    at_cell_ind = find(t_residual == curr_i_j_k_ind);
    t_ind_to_sum = east_facing_t_ind(at_cell_ind);
    
    curr_adv_vol_flux_E_sloping_top = zeros(length(unique_times),1);
    curr_adv_vol_flux_E_sloping_top(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind)*hte(curr_i_ind,curr_j_ind)*(-diff_x_min_dz_depth_integrating_east_facing_top_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*uvel_east(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum)));
    adv_vol_flux_E_sloping_top = adv_vol_flux_E_sloping_top + curr_adv_vol_flux_E_sloping_top;
    curr_adv_T_flux_E_sloping_top = zeros(length(unique_times),1);
    curr_adv_T_flux_E_sloping_top(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind)*hte(curr_i_ind,curr_j_ind)*(-diff_x_min_dz_depth_integrating_east_facing_top_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*uT_east(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum))) - (curr_adv_vol_flux_E_sloping_top(t_ind_to_sum).*T_mean_inbox(t_ind_to_sum));
    adv_T_flux_E_sloping_top = adv_T_flux_E_sloping_top + curr_adv_T_flux_E_sloping_top;
    
    uvel_east_norm_at_pos = squeeze(-uvel_east(curr_i_ind,curr_j_ind,curr_k_ind,:))./vol_integrated_inbox;
    m_seasonal_uvel_east_norm_at_pos = ((uvel_east_norm_at_pos')*seasonal_reg_operator_T)';
    umean_east_norm_at_pos = G_seasonal*m_seasonal_uvel_east_norm_at_pos;
    uanom_east_norm_at_pos = uvel_east_norm_at_pos - umean_east_norm_at_pos;
        
    T_minus_T_inboxmean_at_pos = squeeze(mean(temp(curr_i_ind:(curr_i_ind + 1),curr_j_ind,curr_k_ind,:),1)) - T_mean_inbox;
    m_seasonal_T_at_pos = ((T_minus_T_inboxmean_at_pos')*seasonal_reg_operator_T)';
    Tmean_at_pos = G_seasonal*m_seasonal_T_at_pos;
    Tanom_at_pos = T_minus_T_inboxmean_at_pos - Tmean_at_pos;
    
    curr_adv_umean_Tmean_tend_E_sloping_top = zeros(length(unique_times),1);
    curr_adv_umean_Tmean_tend_E_sloping_top(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind)*hte(curr_i_ind,curr_j_ind)*(-diff_x_min_dz_depth_integrating_east_facing_top_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*umean_east_norm_at_pos(t_ind_to_sum).*Tmean_at_pos(t_ind_to_sum)));
    adv_umean_Tmean_tend_E_sloping_top = adv_umean_Tmean_tend_E_sloping_top + curr_adv_umean_Tmean_tend_E_sloping_top;
    curr_adv_umean_Tanom_tend_E_sloping_top = zeros(length(unique_times),1);
    curr_adv_umean_Tanom_tend_E_sloping_top(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind)*hte(curr_i_ind,curr_j_ind)*(-diff_x_min_dz_depth_integrating_east_facing_top_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*umean_east_norm_at_pos(t_ind_to_sum).*Tanom_at_pos(t_ind_to_sum)));
    adv_umean_Tanom_tend_E_sloping_top = adv_umean_Tanom_tend_E_sloping_top + curr_adv_umean_Tanom_tend_E_sloping_top;
    curr_adv_uanom_Tmean_tend_E_sloping_top = zeros(length(unique_times),1);
    curr_adv_uanom_Tmean_tend_E_sloping_top(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind)*hte(curr_i_ind,curr_j_ind)*(-diff_x_min_dz_depth_integrating_east_facing_top_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*uanom_east_norm_at_pos(t_ind_to_sum).*Tmean_at_pos(t_ind_to_sum)));
    adv_uanom_Tmean_tend_E_sloping_top = adv_uanom_Tmean_tend_E_sloping_top + curr_adv_uanom_Tmean_tend_E_sloping_top;
    
    adv_uanom_Tanom_tend_E_sloping_top = adv_uanom_Tanom_tend_E_sloping_top + ((-curr_adv_T_flux_E_sloping_top./vol_integrated_inbox(:)) - curr_adv_umean_Tmean_tend_E_sloping_top - curr_adv_umean_Tanom_tend_E_sloping_top - curr_adv_uanom_Tmean_tend_E_sloping_top);

end

diff_T_flux_E_sloping_top = squeeze(sum(sum(repmat(in_box_mask(1:(length(lon_ind_inrange) - 1),:),[1 1 1 length(unique_times)]).*repmat(hte(1:(length(lon_ind_inrange) - 1),:),[1 1 1 length(unique_times)]).*sum(-diff_x_min_dz_depth_integrating_east_facing_top_only.*hdiff_T_flux_east(1:(length(lon_ind_inrange) - 1),:,:,:),3),2),1));


diff_x_min_dz_depth_integrating_west_facing_top_only = diff_x_min_dz_depth_integrating_top_only;
not_west_facing_ind = find(diff_x_min_dz_depth_integrating_west_facing_top_only <= 0);
diff_x_min_dz_depth_integrating_west_facing_top_only(not_west_facing_ind) = 0;

% adv_vol_flux_W_sloping_top = squeeze(sum(sum(repmat(in_box_mask(2:length(lon_ind_inrange),:),[1 1 1 length(unique_times)]).*repmat(hte(1:(length(lon_ind_inrange) - 1),:),[1 1 1 length(unique_times)]).*sum(diff_x_min_dz_depth_integrating_west_facing_top_only.*(-uvel_east(1:(length(lon_ind_inrange) - 1),:,:,:)),3),2),1));
% adv_T_flux_W_sloping_top = squeeze(sum(sum(repmat(in_box_mask(2:length(lon_ind_inrange),:),[1 1 1 length(unique_times)]).*repmat(hte(1:(length(lon_ind_inrange) - 1),:),[1 1 1 length(unique_times)]).*sum(diff_x_min_dz_depth_integrating_west_facing_top_only.*(-uT_east(1:(length(lon_ind_inrange) - 1),:,:,:)),3),2),1));

west_facing_ind = setdiff((1:1:prod(size(diff_x_min_dz_depth_integrating_west_facing_top_only)))',not_west_facing_ind);
size_array = size(diff_x_min_dz_depth_integrating_west_facing_top_only);
west_facing_t_ind = ceil(west_facing_ind/prod(size_array(1:3)));
% in_time_range_west_facing_ind = find(ismember(west_facing_t_ind,time_inrange_from_unique_ind) == 1);
% west_facing_ind = west_facing_ind(in_time_range_west_facing_ind);
% west_facing_t_ind = west_facing_t_ind(in_time_range_west_facing_ind);
t_residual = west_facing_ind - (prod(size_array(1:3))*(west_facing_t_ind - 1));
unique_west_facing_i_j_k_ind = unique(t_residual);

adv_vol_flux_W_sloping_top = zeros(length(unique_times),1);
adv_T_flux_W_sloping_top = zeros(length(unique_times),1);
adv_umean_Tmean_tend_W_sloping_top = zeros(length(unique_times),1);
adv_umean_Tanom_tend_W_sloping_top = zeros(length(unique_times),1);
adv_uanom_Tmean_tend_W_sloping_top = zeros(length(unique_times),1);
adv_uanom_Tanom_tend_W_sloping_top = zeros(length(unique_times),1);
for west_facing_cell_ind = 1:length(unique_west_facing_i_j_k_ind)
    curr_i_j_k_ind = unique_west_facing_i_j_k_ind(west_facing_cell_ind);
    curr_k_ind = ceil(curr_i_j_k_ind/prod(size_array(1:2)));
    k_residual = curr_i_j_k_ind - (prod(size_array(1:2))*(curr_k_ind - 1));
    curr_j_ind = ceil(k_residual/size_array(1));
    curr_i_ind = k_residual - ((size_array(1))*(curr_j_ind - 1));
    
    at_cell_ind = find(t_residual == curr_i_j_k_ind);
    t_ind_to_sum = west_facing_t_ind(at_cell_ind);
    
    curr_adv_vol_flux_W_sloping_top = zeros(length(unique_times),1);
    curr_adv_vol_flux_W_sloping_top(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind + 1,curr_j_ind)*hte(curr_i_ind,curr_j_ind)*(diff_x_min_dz_depth_integrating_east_facing_top_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*(-uvel_east(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum))));
    adv_vol_flux_W_sloping_top = adv_vol_flux_W_sloping_top + curr_adv_vol_flux_W_sloping_top;
    curr_adv_T_flux_W_sloping_top = zeros(length(unique_times),1);
    curr_adv_T_flux_W_sloping_top(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind + 1,curr_j_ind)*hte(curr_i_ind,curr_j_ind)*(diff_x_min_dz_depth_integrating_east_facing_top_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*(-uT_east(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum)))) - (curr_adv_vol_flux_W_sloping_top(t_ind_to_sum).*T_mean_inbox(t_ind_to_sum));
    adv_T_flux_W_sloping_top = adv_T_flux_W_sloping_top + curr_adv_T_flux_W_sloping_top;
    
    uvel_east_norm_at_pos = squeeze(-uvel_east(curr_i_ind,curr_j_ind,curr_k_ind,:))./vol_integrated_inbox;
    m_seasonal_uvel_east_norm_at_pos = ((uvel_east_norm_at_pos')*seasonal_reg_operator_T)';
    umean_east_norm_at_pos = G_seasonal*m_seasonal_uvel_east_norm_at_pos;
    uanom_east_norm_at_pos = uvel_east_norm_at_pos - umean_east_norm_at_pos;
        
    T_minus_T_inboxmean_at_pos = squeeze(mean(temp(curr_i_ind:(curr_i_ind + 1),curr_j_ind,curr_k_ind,:),1)) - T_mean_inbox;
    m_seasonal_T_at_pos = ((T_minus_T_inboxmean_at_pos')*seasonal_reg_operator_T)';
    Tmean_at_pos = G_seasonal*m_seasonal_T_at_pos;
    Tanom_at_pos = T_minus_T_inboxmean_at_pos - Tmean_at_pos;
    
    curr_adv_umean_Tmean_tend_W_sloping_top = zeros(length(unique_times),1);
    curr_adv_umean_Tmean_tend_W_sloping_top(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind + 1,curr_j_ind)*hte(curr_i_ind,curr_j_ind)*(diff_x_min_dz_depth_integrating_east_facing_top_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*(-umean_east_norm_at_pos(t_ind_to_sum)).*Tmean_at_pos(t_ind_to_sum)));
    adv_umean_Tmean_tend_W_sloping_top = adv_umean_Tmean_tend_W_sloping_top + curr_adv_umean_Tmean_tend_W_sloping_top;
    curr_adv_umean_Tanom_tend_W_sloping_top = zeros(length(unique_times),1);
    curr_adv_umean_Tanom_tend_W_sloping_top(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind + 1,curr_j_ind)*hte(curr_i_ind,curr_j_ind)*(diff_x_min_dz_depth_integrating_east_facing_top_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*(-umean_east_norm_at_pos(t_ind_to_sum)).*Tanom_at_pos(t_ind_to_sum)));
    adv_umean_Tanom_tend_W_sloping_top = adv_umean_Tanom_tend_W_sloping_top + curr_adv_umean_Tanom_tend_W_sloping_top;
    curr_adv_uanom_Tmean_tend_W_sloping_top = zeros(length(unique_times),1);
    curr_adv_uanom_Tmean_tend_W_sloping_top(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind + 1,curr_j_ind)*hte(curr_i_ind,curr_j_ind)*(diff_x_min_dz_depth_integrating_east_facing_top_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*(-uanom_east_norm_at_pos(t_ind_to_sum)).*Tmean_at_pos(t_ind_to_sum)));
    adv_uanom_Tmean_tend_W_sloping_top = adv_uanom_Tmean_tend_W_sloping_top + curr_adv_uanom_Tmean_tend_W_sloping_top;
    
    adv_uanom_Tanom_tend_W_sloping_top = adv_uanom_Tanom_tend_W_sloping_top + ((-curr_adv_T_flux_W_sloping_top./vol_integrated_inbox(:)) - curr_adv_umean_Tmean_tend_W_sloping_top - curr_adv_umean_Tanom_tend_W_sloping_top - curr_adv_uanom_Tmean_tend_W_sloping_top);

end

diff_T_flux_W_sloping_top = squeeze(sum(sum(repmat(in_box_mask(2:length(lon_ind_inrange),:),[1 1 1 length(unique_times)]).*repmat(hte(1:(length(lon_ind_inrange) - 1),:),[1 1 1 length(unique_times)]).*sum(diff_x_min_dz_depth_integrating_west_facing_top_only.*(-hdiff_T_flux_east(1:(length(lon_ind_inrange) - 1),:,:,:)),3),2),1));



diff_y_min_dz_depth_integrating_top_only = diff(min_dz_depth_integrating_top_only,1,2);
diff_y_min_dz_depth_integrating_north_facing_top_only = diff_y_min_dz_depth_integrating_top_only;
not_north_facing_ind = find(diff_y_min_dz_depth_integrating_north_facing_top_only >= 0);
diff_y_min_dz_depth_integrating_north_facing_top_only(not_north_facing_ind) = 0;

% adv_vol_flux_N_sloping_top = squeeze(sum(sum(repmat(in_box_mask(:,1:(length(lat_ind_inrange) - 1)),[1 1 1 length(unique_times)]).*repmat(htn(:,1:(length(lat_ind_inrange) - 1)),[1 1 1 length(unique_times)]).*sum(-diff_y_min_dz_depth_integrating_north_facing_top_only.*vvel_north(:,1:(length(lat_ind_inrange) - 1),:,:),3),2),1));
% adv_T_flux_N_sloping_top = squeeze(sum(sum(repmat(in_box_mask(:,1:(length(lat_ind_inrange) - 1)),[1 1 1 length(unique_times)]).*repmat(htn(:,1:(length(lat_ind_inrange) - 1)),[1 1 1 length(unique_times)]).*sum(-diff_y_min_dz_depth_integrating_north_facing_top_only.*vT_north(:,1:(length(lat_ind_inrange) - 1),:,:),3),2),1));

north_facing_ind = setdiff((1:1:prod(size(diff_y_min_dz_depth_integrating_north_facing_top_only)))',not_north_facing_ind);
size_array = size(diff_y_min_dz_depth_integrating_north_facing_top_only);
north_facing_t_ind = ceil(north_facing_ind/prod(size_array(1:3)));
% in_time_range_north_facing_ind = find(ismember(north_facing_t_ind,time_inrange_from_unique_ind) == 1);
% north_facing_ind = north_facing_ind(in_time_range_north_facing_ind);
% north_facing_t_ind = north_facing_t_ind(in_time_range_north_facing_ind);
t_residual = north_facing_ind - (prod(size_array(1:3))*(north_facing_t_ind - 1));
unique_north_facing_i_j_k_ind = unique(t_residual);

adv_vol_flux_N_sloping_top = zeros(length(unique_times),1);
adv_T_flux_N_sloping_top = zeros(length(unique_times),1);
adv_vmean_Tmean_tend_N_sloping_top = zeros(length(unique_times),1);
adv_vmean_Tanom_tend_N_sloping_top = zeros(length(unique_times),1);
adv_vanom_Tmean_tend_N_sloping_top = zeros(length(unique_times),1);
adv_vanom_Tanom_tend_N_sloping_top = zeros(length(unique_times),1);
for north_facing_cell_ind = 1:length(unique_north_facing_i_j_k_ind)
    curr_i_j_k_ind = unique_north_facing_i_j_k_ind(north_facing_cell_ind);
    curr_k_ind = ceil(curr_i_j_k_ind/prod(size_array(1:2)));
    k_residual = curr_i_j_k_ind - (prod(size_array(1:2))*(curr_k_ind - 1));
    curr_j_ind = ceil(k_residual/size_array(1));
    curr_i_ind = k_residual - ((size_array(1))*(curr_j_ind - 1));
    
    at_cell_ind = find(t_residual == curr_i_j_k_ind);
    t_ind_to_sum = north_facing_t_ind(at_cell_ind);
    
    curr_adv_vol_flux_N_sloping_top = zeros(length(unique_times),1);
    curr_adv_vol_flux_N_sloping_top(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind)*htn(curr_i_ind,curr_j_ind)*(-diff_y_min_dz_depth_integrating_north_facing_top_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*vvel_north(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum)));
    adv_vol_flux_N_sloping_top = adv_vol_flux_N_sloping_top + curr_adv_vol_flux_N_sloping_top;
    curr_adv_T_flux_N_sloping_top = zeros(length(unique_times),1);
    curr_adv_T_flux_N_sloping_top(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind)*htn(curr_i_ind,curr_j_ind)*(-diff_y_min_dz_depth_integrating_north_facing_top_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*vT_north(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum))) - (curr_adv_vol_flux_N_sloping_top(t_ind_to_sum).*T_mean_inbox(t_ind_to_sum));
    adv_T_flux_N_sloping_top = adv_T_flux_N_sloping_top + curr_adv_T_flux_N_sloping_top;
    
    vvel_north_norm_at_pos = squeeze(-vvel_north(curr_i_ind,curr_j_ind,curr_k_ind,:))./vol_integrated_inbox;
    m_seasonal_vvel_north_norm_at_pos = ((vvel_north_norm_at_pos')*seasonal_reg_operator_T)';
    vmean_north_norm_at_pos = G_seasonal*m_seasonal_vvel_north_norm_at_pos;
    vanom_north_norm_at_pos = vvel_north_norm_at_pos - vmean_north_norm_at_pos;
        
    T_minus_T_inboxmean_at_pos = squeeze(mean(temp(curr_i_ind,curr_j_ind:(curr_j_ind + 1),curr_k_ind,:),2)) - T_mean_inbox;
    m_seasonal_T_at_pos = ((T_minus_T_inboxmean_at_pos')*seasonal_reg_operator_T)';
    Tmean_at_pos = G_seasonal*m_seasonal_T_at_pos;
    Tanom_at_pos = T_minus_T_inboxmean_at_pos - Tmean_at_pos;
    
    curr_adv_vmean_Tmean_tend_N_sloping_top = zeros(length(unique_times),1);
    curr_adv_vmean_Tmean_tend_N_sloping_top(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind)*htn(curr_i_ind,curr_j_ind)*(-diff_y_min_dz_depth_integrating_north_facing_top_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*vmean_north_norm_at_pos(t_ind_to_sum).*Tmean_at_pos(t_ind_to_sum)));
    adv_vmean_Tmean_tend_N_sloping_top = adv_vmean_Tmean_tend_N_sloping_top + curr_adv_vmean_Tmean_tend_N_sloping_top;
    curr_adv_vmean_Tanom_tend_N_sloping_top = zeros(length(unique_times),1);
    curr_adv_vmean_Tanom_tend_N_sloping_top(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind)*htn(curr_i_ind,curr_j_ind)*(-diff_y_min_dz_depth_integrating_north_facing_top_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*vmean_north_norm_at_pos(t_ind_to_sum).*Tanom_at_pos(t_ind_to_sum)));
    adv_vmean_Tanom_tend_N_sloping_top = adv_vmean_Tanom_tend_N_sloping_top + curr_adv_vmean_Tanom_tend_N_sloping_top;
    curr_adv_vanom_Tmean_tend_N_sloping_top = zeros(length(unique_times),1);
    curr_adv_vanom_Tmean_tend_N_sloping_top(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind)*htn(curr_i_ind,curr_j_ind)*(-diff_y_min_dz_depth_integrating_north_facing_top_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*vanom_north_norm_at_pos(t_ind_to_sum).*Tmean_at_pos(t_ind_to_sum)));
    adv_vanom_Tmean_tend_N_sloping_top = adv_vanom_Tmean_tend_N_sloping_top + curr_adv_vanom_Tmean_tend_N_sloping_top;
    
    adv_vanom_Tanom_tend_N_sloping_top = adv_vanom_Tanom_tend_N_sloping_top + ((-curr_adv_T_flux_N_sloping_top./vol_integrated_inbox(:)) - curr_adv_vmean_Tmean_tend_N_sloping_top - curr_adv_vmean_Tanom_tend_N_sloping_top - curr_adv_vanom_Tmean_tend_N_sloping_top);

end

diff_T_flux_N_sloping_top = squeeze(sum(sum(repmat(in_box_mask(:,1:(length(lat_ind_inrange) - 1)),[1 1 1 length(unique_times)]).*repmat(htn(:,1:(length(lat_ind_inrange) - 1)),[1 1 1 length(unique_times)]).*sum(-diff_y_min_dz_depth_integrating_north_facing_top_only.*hdiff_T_flux_north(:,1:(length(lat_ind_inrange) - 1),:,:),3),2),1));

diff_y_min_dz_depth_integrating_south_facing_top_only = diff_y_min_dz_depth_integrating_top_only;
not_south_facing_ind = find(diff_y_min_dz_depth_integrating_top_only <= 0);
diff_y_min_dz_depth_integrating_top_only(not_south_facing_ind) = 0;

% adv_vol_flux_S_sloping_top = squeeze(sum(sum(repmat(in_box_mask(:,2:length(lat_ind_inrange)),[1 1 1 length(unique_times)]).*repmat(htn(:,1:(length(lat_ind_inrange) - 1)),[1 1 1 length(unique_times)]).*sum(diff_y_min_dz_depth_integrating_south_facing_top_only.*(-vvel_north(:,1:(length(lat_ind_inrange) - 1),:,:)),3),2),1));
% adv_T_flux_S_sloping_top = squeeze(sum(sum(repmat(in_box_mask(:,2:length(lat_ind_inrange)),[1 1 1 length(unique_times)]).*repmat(htn(:,1:(length(lat_ind_inrange) - 1)),[1 1 1 length(unique_times)]).*sum(diff_y_min_dz_depth_integrating_south_facing_top_only.*(-vT_north(:,1:(length(lat_ind_inrange) - 1),:,:)),3),2),1));

south_facing_ind = setdiff((1:1:prod(size(diff_y_min_dz_depth_integrating_south_facing_top_only)))',not_south_facing_ind);
size_array = size(diff_y_min_dz_depth_integrating_south_facing_top_only);
south_facing_t_ind = ceil(south_facing_ind/prod(size_array(1:3)));
% in_time_range_south_facing_ind = find(ismember(south_facing_t_ind,time_inrange_from_unique_ind) == 1);
% south_facing_ind = south_facing_ind(in_time_range_south_facing_ind);
% south_facing_t_ind = south_facing_t_ind(in_time_range_south_facing_ind);
t_residual = south_facing_ind - (prod(size_array(1:3))*(south_facing_t_ind - 1));
unique_south_facing_i_j_k_ind = unique(t_residual);

adv_vol_flux_S_sloping_top = zeros(length(unique_times),1);
adv_T_flux_S_sloping_top = zeros(length(unique_times),1);
adv_vmean_Tmean_tend_S_sloping_top = zeros(length(unique_times),1);
adv_vmean_Tanom_tend_S_sloping_top = zeros(length(unique_times),1);
adv_vanom_Tmean_tend_S_sloping_top = zeros(length(unique_times),1);
adv_vanom_Tanom_tend_S_sloping_top = zeros(length(unique_times),1);
for south_facing_cell_ind = 1:length(unique_south_facing_i_j_k_ind)
    curr_i_j_k_ind = unique_south_facing_i_j_k_ind(south_facing_cell_ind);
    curr_k_ind = ceil(curr_i_j_k_ind/prod(size_array(1:2)));
    k_residual = curr_i_j_k_ind - (prod(size_array(1:2))*(curr_k_ind - 1));
    curr_j_ind = ceil(k_residual/size_array(1));
    curr_i_ind = k_residual - ((size_array(1))*(curr_j_ind - 1));
    
    at_cell_ind = find(t_residual == curr_i_j_k_ind);
    t_ind_to_sum = south_facing_t_ind(at_cell_ind);
    
    curr_adv_vol_flux_S_sloping_top = zeros(length(unique_times),1);
    curr_adv_vol_flux_S_sloping_top(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind + 1)*htn(curr_i_ind,curr_j_ind)*(diff_y_min_dz_depth_integrating_south_facing_top_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*(-vvel_north(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum))));
    adv_vol_flux_S_sloping_top = adv_vol_flux_S_sloping_top + curr_adv_vol_flux_S_sloping_top;
    curr_adv_T_flux_S_sloping_top = zeros(length(unique_times),1);
    curr_adv_T_flux_S_sloping_top(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind + 1)*htn(curr_i_ind,curr_j_ind)*(diff_y_min_dz_depth_integrating_south_facing_top_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*(-vT_north(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum)))) - (curr_adv_vol_flux_S_sloping_top(t_ind_to_sum).*T_mean_inbox(t_ind_to_sum));
    adv_T_flux_S_sloping_top = adv_T_flux_S_sloping_top + curr_adv_T_flux_S_sloping_top;
    
    vvel_north_norm_at_pos = squeeze(-vvel_north(curr_i_ind,curr_j_ind,curr_k_ind,:))./vol_integrated_inbox;
    m_seasonal_uvel_east_at_pos = ((vvel_north_norm_at_pos')*seasonal_reg_operator_T)';
    vmean_north_norm_at_pos = G_seasonal*m_seasonal_vvel_north_norm_at_pos;
    vanom_north_norm_at_pos = vvel_north_norm_at_pos - vmean_north_norm_at_pos;
        
    T_minus_T_inboxmean_at_pos = squeeze(mean(temp(curr_i_ind,curr_j_ind:(curr_j_ind + 1),curr_k_ind,:),2)) - T_mean_inbox;
    m_seasonal_T_at_pos = ((T_minus_T_inboxmean_at_pos')*seasonal_reg_operator_T)';
    Tmean_at_pos = G_seasonal*m_seasonal_T_at_pos;
    Tanom_at_pos = T_minus_T_inboxmean_at_pos - Tmean_at_pos;
    
    curr_adv_vmean_Tmean_tend_S_sloping_top = zeros(length(unique_times),1);
    curr_adv_vmean_Tmean_tend_S_sloping_top(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind + 1)*htn(curr_i_ind,curr_j_ind)*(diff_y_min_dz_depth_integrating_south_facing_top_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*(-vmean_north_norm_at_pos(t_ind_to_sum)).*Tmean_at_pos(t_ind_to_sum)));
    adv_vmean_Tmean_tend_S_sloping_top = adv_vmean_Tmean_tend_S_sloping_top + curr_adv_vmean_Tmean_tend_S_sloping_top;
    curr_adv_vmean_Tanom_tend_S_sloping_top = zeros(length(unique_times),1);
    curr_adv_vmean_Tanom_tend_S_sloping_top(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind + 1)*htn(curr_i_ind,curr_j_ind)*(diff_y_min_dz_depth_integrating_south_facing_top_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*(-vmean_north_norm_at_pos(t_ind_to_sum)).*Tanom_at_pos(t_ind_to_sum)));
    adv_vmean_Tanom_tend_S_sloping_top = adv_vmean_Tanom_tend_S_sloping_top + curr_adv_vmean_Tanom_tend_S_sloping_top;
    curr_adv_vanom_Tmean_tend_S_sloping_top = zeros(length(unique_times),1);
    curr_adv_vanom_Tmean_tend_S_sloping_top(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind + 1)*htn(curr_i_ind,curr_j_ind)*(diff_y_min_dz_depth_integrating_south_facing_top_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*(-vanom_north_norm_at_pos(t_ind_to_sum)).*Tmean_at_pos(t_ind_to_sum)));
    adv_vanom_Tmean_tend_S_sloping_top = adv_vanom_Tmean_tend_S_sloping_top + curr_adv_vanom_Tmean_tend_S_sloping_top;
    
    adv_vanom_Tanom_tend_S_sloping_top = adv_uanom_Tanom_tend_S_sloping_top + ((-curr_adv_T_flux_S_sloping_top./vol_integrated_inbox(:)) - curr_adv_umean_Tmean_tend_S_sloping_top - curr_adv_umean_Tanom_tend_S_sloping_top - curr_adv_uanom_Tmean_tend_S_sloping_top);

end

diff_T_flux_S_sloping_top = squeeze(sum(sum(repmat(in_box_mask(:,2:length(lat_ind_inrange)),[1 1 1 length(unique_times)]).*repmat(htn(:,1:(length(lat_ind_inrange) - 1)),[1 1 1 length(unique_times)]).*sum(diff_y_min_dz_depth_integrating_south_facing_top_only.*(-hdiff_T_flux_north(:,1:(length(lat_ind_inrange) - 1),:,:)),3),2),1));

disp('Completed computing advective terms for variable-depth top bound')



% compute horizontal advection/diffusion terms through variable depth bottom bound

% some of this (e.g., the use of ht_east_wall and ht_north_wall) is different from the computation for the top bound, to account for bathymetry and partial bottom cells
ht_east_wall = squeeze(sum(dzt_east_wall,3));
min_ht_bottom_depth_east_side = NaN(size(bottom_depth_bound_array));
min_ht_bottom_depth_east_side(1:(length(lon_ind_inrange) - 1),:,:) = reshape(min([reshape(repmat(ht_east_wall(1:(size(ht_east_wall,1) - 1),:),[1 1 length(unique_times)]),[1 ((length(lon_ind_inrange) - 1)*length(lat_ind_inrange)*length(unique_times))]); reshape(bottom_depth_bound_array(1:(length(lon_ind_inrange) - 1),:,:),[1 ((length(lon_ind_inrange) - 1)*length(lat_ind_inrange)*length(unique_times))])],[],1),[(length(lon_ind_inrange) - 1) length(lat_ind_inrange) length(unique_times)]);
diff_z_w_top_bottom_bound_east_side = repmat(reshape(min_ht_bottom_depth_east_side,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[1 1 length(depth_ind_inrange) 1]) - repmat(reshape(z_w_top(depth_ind_inrange),[1 1 length(depth_ind_inrange)]),[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]);
min_dzt_depth_integrating_east_side_bottom_only = reshape(min([reshape(min_dzt_depth_integrating_array,[1 prod(size(min_dzt_depth_integrating_array))]); reshape(diff_z_w_top_bottom_bound_east_side,[1 prod(size(diff_z_w_top_bottom_bound_east_side))])],[],1),[length(lon_ind_inrange) length(lat_ind_inrange) length(depth_ind_inrange) length(unique_times)]);
min_dzt_depth_integrating_east_side_bottom_only(min_dzt_depth_integrating_east_side_bottom_only < 0) = 0;

min_ht_bottom_depth_west_side = NaN(size(bottom_depth_bound_array));
min_ht_bottom_depth_west_side(2:length(lon_ind_inrange),:,:) = reshape(min([reshape(repmat(ht_east_wall(1:(size(ht_east_wall,1) - 1),:),[1 1 length(unique_times)]),[1 ((length(lon_ind_inrange) - 1)*length(lat_ind_inrange)*length(unique_times))]); reshape(bottom_depth_bound_array(2:length(lon_ind_inrange),:,:),[1 ((length(lon_ind_inrange) - 1)*length(lat_ind_inrange)*length(unique_times))])],[],1),[(length(lon_ind_inrange) - 1) length(lat_ind_inrange) length(unique_times)]);
diff_z_w_top_bottom_bound_west_side = repmat(reshape(min_ht_bottom_depth_west_side,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[1 1 length(depth_ind_inrange) 1]) - repmat(reshape(z_w_top(depth_ind_inrange),[1 1 length(depth_ind_inrange)]),[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]);
min_dzt_depth_integrating_west_side_bottom_only = reshape(min([reshape(min_dzt_depth_integrating_array,[1 prod(size(min_dzt_depth_integrating_array))]); reshape(diff_z_w_top_bottom_bound_west_side,[1 prod(size(diff_z_w_top_bottom_bound_west_side))])],[],1),[length(lon_ind_inrange) length(lat_ind_inrange) length(depth_ind_inrange) length(unique_times)]);
min_dzt_depth_integrating_west_side_bottom_only(min_dzt_depth_integrating_west_side_bottom_only < 0) = 0;

diff_x_min_dzt_depth_integrating_bottom_only = min_dzt_depth_integrating_west_side_bottom_only(2:length(lon_ind_inrange),:,:,:) - min_dzt_depth_integrating_east_side_bottom_only(1:(length(lon_ind_inrange) - 1),:,:,:);

diff_x_min_dzt_depth_integrating_east_facing_bottom_only = diff_x_min_dzt_depth_integrating_bottom_only;
not_east_facing_ind = find(diff_x_min_dzt_depth_integrating_east_facing_bottom_only >= 0);
diff_x_min_dzt_depth_integrating_east_facing_bottom_only(not_east_facing_ind) = 0;

% adv_vol_flux_E_sloping_bottom = squeeze(sum(sum(repmat(in_box_mask(1:(length(lon_ind_inrange) - 1),:),[1 1 1 length(unique_times)]).*repmat(hte(1:(length(lon_ind_inrange) - 1),:),[1 1 1 length(unique_times)]).*sum(-diff_x_min_dzt_depth_integrating_east_facing_bottom_only.*uvel_east(1:(length(lon_ind_inrange) - 1),:,:,:),3),2),1));
% adv_T_flux_E_sloping_bottom = squeeze(sum(sum(repmat(in_box_mask(1:(length(lon_ind_inrange) - 1),:),[1 1 1 length(unique_times)]).*repmat(hte(1:(length(lon_ind_inrange) - 1),:),[1 1 1 length(unique_times)]).*sum(-diff_x_min_dzt_depth_integrating_east_facing_bottom_only.*uT_east(1:(length(lon_ind_inrange) - 1),:,:,:),3),2),1));

east_facing_ind = setdiff((1:1:prod(size(diff_x_min_dzt_depth_integrating_east_facing_bottom_only)))',not_east_facing_ind);
size_array = size(diff_x_min_dzt_depth_integrating_east_facing_bottom_only);
east_facing_t_ind = ceil(east_facing_ind/prod(size_array(1:3)));
% in_time_range_east_facing_ind = find(ismember(east_facing_t_ind,time_inrange_from_unique_ind) == 1);
% east_facing_ind = east_facing_ind(in_time_range_east_facing_ind);
% east_facing_t_ind = east_facing_t_ind(in_time_range_east_facing_ind);
t_residual = east_facing_ind - (prod(size_array(1:3))*(east_facing_t_ind - 1));
unique_east_facing_i_j_k_ind = unique(t_residual);

adv_vol_flux_E_sloping_bottom = zeros(length(unique_times),1);
adv_T_flux_E_sloping_bottom = zeros(length(unique_times),1);
adv_umean_Tmean_tend_E_sloping_bottom = zeros(length(unique_times),1);
adv_umean_Tanom_tend_E_sloping_bottom = zeros(length(unique_times),1);
adv_uanom_Tmean_tend_E_sloping_bottom = zeros(length(unique_times),1);
adv_uanom_Tanom_tend_E_sloping_bottom = zeros(length(unique_times),1);
for east_facing_cell_ind = 1:length(unique_east_facing_i_j_k_ind)
    curr_i_j_k_ind = unique_east_facing_i_j_k_ind(east_facing_cell_ind);
    curr_k_ind = ceil(curr_i_j_k_ind/prod(size_array(1:2)));
    k_residual = curr_i_j_k_ind - (prod(size_array(1:2))*(curr_k_ind - 1));
    curr_j_ind = ceil(k_residual/size_array(1));
    curr_i_ind = k_residual - ((size_array(1))*(curr_j_ind - 1));
    
    at_cell_ind = find(t_residual == curr_i_j_k_ind);
    t_ind_to_sum = east_facing_t_ind(at_cell_ind);
    
    curr_adv_vol_flux_E_sloping_bottom = zeros(length(unique_times),1);
    curr_adv_vol_flux_E_sloping_bottom(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind)*hte(curr_i_ind,curr_j_ind)*(-diff_x_min_dzt_depth_integrating_east_facing_bottom_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*uvel_east(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum)));
    adv_vol_flux_E_sloping_bottom = adv_vol_flux_E_sloping_bottom + curr_adv_vol_flux_E_sloping_bottom;
    curr_adv_T_flux_E_sloping_bottom = zeros(length(unique_times),1);
    curr_adv_T_flux_E_sloping_bottom(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind)*hte(curr_i_ind,curr_j_ind)*(-diff_x_min_dzt_depth_integrating_east_facing_bottom_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*uT_east(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum))) - (curr_adv_vol_flux_E_sloping_bottom(t_ind_to_sum).*T_mean_inbox(t_ind_to_sum));
    adv_T_flux_E_sloping_bottom = adv_T_flux_E_sloping_bottom + curr_adv_T_flux_E_sloping_bottom;
    
    uvel_east_norm_at_pos = squeeze(-uvel_east(curr_i_ind,curr_j_ind,curr_k_ind,:))./vol_integrated_inbox;
    m_seasonal_uvel_east_norm_at_pos = ((uvel_east_norm_at_pos')*seasonal_reg_operator_T)';
    umean_east_norm_at_pos = G_seasonal*m_seasonal_uvel_east_norm_at_pos;
    uanom_east_norm_at_pos = uvel_east_norm_at_pos - umean_east_norm_at_pos;
        
    T_minus_T_inboxmean_at_pos = squeeze(mean(temp(curr_i_ind:(curr_i_ind + 1),curr_j_ind,curr_k_ind,:),1)) - T_mean_inbox;
    m_seasonal_T_at_pos = ((T_minus_T_inboxmean_at_pos')*seasonal_reg_operator_T)';
    Tmean_at_pos = G_seasonal*m_seasonal_T_at_pos;
    Tanom_at_pos = T_minus_T_inboxmean_at_pos - Tmean_at_pos;
    
    curr_adv_umean_Tmean_tend_E_sloping_bottom = zeros(length(unique_times),1);
    curr_adv_umean_Tmean_tend_E_sloping_bottom(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind)*hte(curr_i_ind,curr_j_ind)*(-squeeze(diff_x_min_dzt_depth_integrating_east_facing_bottom_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum)).*umean_east_norm_at_pos(t_ind_to_sum).*Tmean_at_pos(t_ind_to_sum)));
    adv_umean_Tmean_tend_E_sloping_bottom = adv_umean_Tmean_tend_E_sloping_bottom + curr_adv_umean_Tmean_tend_E_sloping_bottom;
    curr_adv_umean_Tanom_tend_E_sloping_bottom = zeros(length(unique_times),1);
    curr_adv_umean_Tanom_tend_E_sloping_bottom(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind)*hte(curr_i_ind,curr_j_ind)*(-squeeze(diff_x_min_dzt_depth_integrating_east_facing_bottom_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum)).*umean_east_norm_at_pos(t_ind_to_sum).*Tanom_at_pos(t_ind_to_sum)));
    adv_umean_Tanom_tend_E_sloping_bottom = adv_umean_Tanom_tend_E_sloping_bottom + curr_adv_umean_Tanom_tend_E_sloping_bottom;
    curr_adv_uanom_Tmean_tend_E_sloping_bottom = zeros(length(unique_times),1);
    curr_adv_uanom_Tmean_tend_E_sloping_bottom(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind)*hte(curr_i_ind,curr_j_ind)*(-squeeze(diff_x_min_dzt_depth_integrating_east_facing_bottom_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum)).*uanom_east_norm_at_pos(t_ind_to_sum).*Tmean_at_pos(t_ind_to_sum)));
    
    adv_uanom_Tanom_tend_E_sloping_bottom = adv_uanom_Tanom_tend_E_sloping_bottom + ((-curr_adv_T_flux_E_sloping_bottom./vol_integrated_inbox(:)) - curr_adv_umean_Tmean_tend_E_sloping_bottom - curr_adv_umean_Tanom_tend_E_sloping_bottom - curr_adv_uanom_Tmean_tend_E_sloping_bottom);

end

diff_T_flux_E_sloping_bottom = squeeze(sum(sum(repmat(in_box_mask(1:(length(lon_ind_inrange) - 1),:),[1 1 1 length(unique_times)]).*repmat(hte(1:(length(lon_ind_inrange) - 1),:),[1 1 1 length(unique_times)]).*sum(-diff_x_min_dzt_depth_integrating_east_facing_bottom_only.*hdiff_T_flux_east(1:(length(lon_ind_inrange) - 1),:,:,:),3),2),1));


diff_x_min_dzt_depth_integrating_west_facing_bottom_only = diff_x_min_dzt_depth_integrating_bottom_only;
not_west_facing_ind = find(diff_x_min_dzt_depth_integrating_west_facing_bottom_only <= 0);
diff_x_min_dzt_depth_integrating_west_facing_bottom_only(not_west_facing_ind) = 0;

% adv_vol_flux_W_sloping_bottom = squeeze(sum(sum(repmat(in_box_mask(2:length(lon_ind_inrange),:),[1 1 1 length(unique_times)]).*repmat(hte(1:(length(lon_ind_inrange) - 1),:),[1 1 1 length(unique_times)]).*sum(diff_x_min_dzt_depth_integrating_west_facing_bottom_only.*(-uvel_east(1:(length(lon_ind_inrange) - 1),:,:,:)),3),2),1));
% adv_T_flux_W_sloping_bottom = squeeze(sum(sum(repmat(in_box_mask(2:length(lon_ind_inrange),:),[1 1 1 length(unique_times)]).*repmat(hte(1:(length(lon_ind_inrange) - 1),:),[1 1 1 length(unique_times)]).*sum(diff_x_min_dzt_depth_integrating_west_facing_bottom_only.*(-uT_east(1:(length(lon_ind_inrange) - 1),:,:,:)),3),2),1));

west_facing_ind = setdiff((1:1:prod(size(diff_x_min_dzt_depth_integrating_west_facing_bottom_only)))',not_west_facing_ind);
size_array = size(diff_x_min_dzt_depth_integrating_west_facing_bottom_only);
west_facing_t_ind = ceil(west_facing_ind/prod(size_array(1:3)));
% in_time_range_west_facing_ind = find(ismember(west_facing_t_ind,time_inrange_from_unique_ind) == 1);
% west_facing_ind = west_facing_ind(in_time_range_west_facing_ind);
% west_facing_t_ind = west_facing_t_ind(in_time_range_west_facing_ind);
t_residual = west_facing_ind - (prod(size_array(1:3))*(west_facing_t_ind - 1));
unique_west_facing_i_j_k_ind = unique(t_residual);

adv_vol_flux_W_sloping_bottom = zeros(length(unique_times),1);
adv_T_flux_W_sloping_bottom = zeros(length(unique_times),1);
adv_umean_Tmean_tend_W_sloping_bottom = zeros(length(unique_times),1);
adv_umean_Tanom_tend_W_sloping_bottom = zeros(length(unique_times),1);
adv_uanom_Tmean_tend_W_sloping_bottom = zeros(length(unique_times),1);
adv_uanom_Tanom_tend_W_sloping_bottom = zeros(length(unique_times),1);
for west_facing_cell_ind = 1:length(unique_west_facing_i_j_k_ind)
    curr_i_j_k_ind = unique_west_facing_i_j_k_ind(west_facing_cell_ind);
    curr_k_ind = ceil(curr_i_j_k_ind/prod(size_array(1:2)));
    k_residual = curr_i_j_k_ind - (prod(size_array(1:2))*(curr_k_ind - 1));
    curr_j_ind = ceil(k_residual/size_array(1));
    curr_i_ind = k_residual - ((size_array(1))*(curr_j_ind - 1));
    
    at_cell_ind = find(t_residual == curr_i_j_k_ind);
    t_ind_to_sum = west_facing_t_ind(at_cell_ind);
    
    curr_adv_vol_flux_W_sloping_bottom = zeros(length(unique_times),1);
    curr_adv_vol_flux_W_sloping_bottom(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind + 1,curr_j_ind)*hte(curr_i_ind,curr_j_ind)*(diff_x_min_dzt_depth_integrating_west_facing_bottom_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*(-uvel_east(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum))));
    adv_vol_flux_W_sloping_bottom = adv_vol_flux_W_sloping_bottom + curr_adv_vol_flux_W_sloping_bottom;
    curr_adv_T_flux_W_sloping_bottom = zeros(length(unique_times),1);
    curr_adv_T_flux_W_sloping_bottom(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind + 1,curr_j_ind)*hte(curr_i_ind,curr_j_ind)*(diff_x_min_dzt_depth_integrating_west_facing_bottom_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*(-uT_east(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum)))) - (curr_adv_vol_flux_W_sloping_bottom(t_ind_to_sum).*T_mean_inbox(t_ind_to_sum));
    adv_T_flux_W_sloping_bottom = adv_T_flux_W_sloping_bottom + curr_adv_T_flux_W_sloping_bottom;
    
    uvel_east_norm_at_pos = squeeze(-uvel_east(curr_i_ind,curr_j_ind,curr_k_ind,:))./vol_integrated_inbox;
    m_seasonal_uvel_east_norm_at_pos = ((uvel_east_norm_at_pos')*seasonal_reg_operator_T)';
    umean_east_norm_at_pos = G_seasonal*m_seasonal_uvel_east_norm_at_pos;
    uanom_east_norm_at_pos = uvel_east_norm_at_pos - umean_east_norm_at_pos;
        
    T_minus_T_inboxmean_at_pos = squeeze(mean(temp(curr_i_ind:(curr_i_ind + 1),curr_j_ind,curr_k_ind,:),1)) - T_mean_inbox;
    m_seasonal_T_at_pos = ((T_minus_T_inboxmean_at_pos')*seasonal_reg_operator_T)';
    Tmean_at_pos = G_seasonal*m_seasonal_T_at_pos;
    Tanom_at_pos = T_minus_T_inboxmean_at_pos - Tmean_at_pos;
    
    curr_adv_umean_Tmean_tend_W_sloping_bottom = zeros(length(unique_times),1);
    curr_adv_umean_Tmean_tend_W_sloping_bottom(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind + 1,curr_j_ind)*hte(curr_i_ind,curr_j_ind)*(squeeze(diff_x_min_dzt_depth_integrating_west_facing_bottom_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum)).*(-umean_east_norm_at_pos(t_ind_to_sum)).*Tmean_at_pos(t_ind_to_sum)));
    adv_umean_Tmean_tend_W_sloping_bottom = adv_umean_Tmean_tend_W_sloping_bottom + curr_adv_umean_Tmean_tend_W_sloping_bottom;
    curr_adv_umean_Tanom_tend_W_sloping_bottom = zeros(length(unique_times),1);
    curr_adv_umean_Tanom_tend_W_sloping_bottom(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind + 1,curr_j_ind)*hte(curr_i_ind,curr_j_ind)*(squeeze(diff_x_min_dzt_depth_integrating_west_facing_bottom_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum)).*(-umean_east_norm_at_pos(t_ind_to_sum)).*Tanom_at_pos(t_ind_to_sum)));
    adv_umean_Tanom_tend_W_sloping_bottom = adv_umean_Tanom_tend_W_sloping_bottom + curr_adv_umean_Tanom_tend_W_sloping_bottom;
    curr_adv_uanom_Tmean_tend_W_sloping_bottom = zeros(length(unique_times),1);
    curr_adv_uanom_Tmean_tend_W_sloping_bottom(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind + 1,curr_j_ind)*hte(curr_i_ind,curr_j_ind)*(squeeze(diff_x_min_dzt_depth_integrating_west_facing_bottom_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum)).*(-uanom_east_norm_at_pos(t_ind_to_sum)).*Tmean_at_pos(t_ind_to_sum)));
    adv_uanom_Tmean_tend_W_sloping_bottom = adv_uanom_Tmean_tend_W_sloping_bottom + curr_adv_uanom_Tmean_tend_W_sloping_bottom;
    
    adv_uanom_Tanom_tend_W_sloping_bottom = adv_uanom_Tanom_tend_W_sloping_bottom + ((-curr_adv_T_flux_W_sloping_bottom./vol_integrated_inbox(:)) - curr_adv_umean_Tmean_tend_W_sloping_bottom - curr_adv_umean_Tanom_tend_W_sloping_bottom - curr_adv_uanom_Tmean_tend_W_sloping_bottom);
    
end

diff_T_flux_W_sloping_bottom = squeeze(sum(sum(repmat(in_box_mask(2:length(lon_ind_inrange),:),[1 1 1 length(unique_times)]).*repmat(hte(1:(length(lon_ind_inrange) - 1),:),[1 1 1 length(unique_times)]).*sum(diff_x_min_dzt_depth_integrating_west_facing_bottom_only.*(-hdiff_T_flux_east(1:(length(lon_ind_inrange) - 1),:,:,:)),3),2),1));



ht_north_wall = squeeze(sum(dzt_north_wall,3));
min_ht_bottom_depth_north_side = NaN(size(bottom_depth_bound_array));
min_ht_bottom_depth_north_side(:,1:(length(lat_ind_inrange) - 1),:) = reshape(min([reshape(repmat(ht_north_wall(:,1:(size(ht_north_wall,2) - 1)),[1 1 length(unique_times)]),[1 (length(lon_ind_inrange)*(length(lat_ind_inrange) - 1)*length(unique_times))]); reshape(bottom_depth_bound_array(:,1:(length(lat_ind_inrange) - 1),:),[1 (length(lon_ind_inrange)*(length(lat_ind_inrange) - 1)*length(unique_times))])],[],1),[length(lon_ind_inrange) (length(lat_ind_inrange) - 1) length(unique_times)]);
diff_z_w_top_bottom_bound_north_side = repmat(reshape(min_ht_bottom_depth_north_side,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[1 1 length(depth_ind_inrange) 1]) - repmat(reshape(z_w_top(depth_ind_inrange),[1 1 length(depth_ind_inrange)]),[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]);
min_dzt_depth_integrating_north_side_bottom_only = reshape(min([reshape(min_dzt_depth_integrating_array,[1 prod(size(min_dzt_depth_integrating_array))]); reshape(diff_z_w_top_bottom_bound_north_side,[1 prod(size(diff_z_w_top_bottom_bound_north_side))])],[],1),[length(lon_ind_inrange) length(lat_ind_inrange) length(depth_ind_inrange) length(unique_times)]);
min_dzt_depth_integrating_north_side_bottom_only(min_dzt_depth_integrating_north_side_bottom_only < 0) = 0;

min_ht_bottom_depth_south_side = NaN(size(bottom_depth_bound_array));
min_ht_bottom_depth_south_side(:,2:length(lat_ind_inrange),:) = reshape(min([reshape(repmat(ht_north_wall(:,1:(size(ht_north_wall,2) - 1)),[1 1 length(unique_times)]),[1 (length(lon_ind_inrange)*(length(lat_ind_inrange) - 1)*length(unique_times))]); reshape(bottom_depth_bound_array(:,2:length(lat_ind_inrange),:),[1 (length(lon_ind_inrange)*(length(lat_ind_inrange) - 1)*length(unique_times))])],[],1),[length(lon_ind_inrange) (length(lat_ind_inrange) - 1) length(unique_times)]);
diff_z_w_top_bottom_bound_south_side = repmat(reshape(min_ht_bottom_depth_south_side,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[1 1 length(depth_ind_inrange) 1]) - repmat(reshape(z_w_top(depth_ind_inrange),[1 1 length(depth_ind_inrange)]),[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]);
min_dzt_depth_integrating_south_side_bottom_only = reshape(min([reshape(min_dzt_depth_integrating_array,[1 prod(size(min_dzt_depth_integrating_array))]); reshape(diff_z_w_top_bottom_bound_south_side,[1 prod(size(diff_z_w_top_bottom_bound_south_side))])],[],1),[length(lon_ind_inrange) length(lat_ind_inrange) length(depth_ind_inrange) length(unique_times)]);
min_dzt_depth_integrating_south_side_bottom_only(min_dzt_depth_integrating_south_side_bottom_only < 0) = 0;

diff_y_min_dzt_depth_integrating_bottom_only = min_dzt_depth_integrating_south_side_bottom_only(:,2:length(lat_ind_inrange),:,:) - min_dzt_depth_integrating_north_side_bottom_only(:,1:(length(lat_ind_inrange) - 1),:,:);

diff_y_min_dzt_depth_integrating_north_facing_bottom_only = diff_y_min_dzt_depth_integrating_bottom_only;
not_north_facing_ind = find(diff_y_min_dzt_depth_integrating_north_facing_bottom_only >= 0);
diff_y_min_dzt_depth_integrating_north_facing_bottom_only(not_north_facing_ind) = 0;

% adv_vol_flux_N_sloping_bottom = squeeze(sum(sum(repmat(in_box_mask(:,1:(length(lat_ind_inrange) - 1)),[1 1 1 length(unique_times)]).*repmat(htn(:,1:(length(lat_ind_inrange) - 1)),[1 1 1 length(unique_times)]).*sum(-diff_y_min_dzt_depth_integrating_north_facing_bottom_only.*vvel_north(:,1:(length(lat_ind_inrange) - 1),:,:),3),2),1));
% adv_T_flux_N_sloping_bottom = squeeze(sum(sum(repmat(in_box_mask(:,1:(length(lat_ind_inrange) - 1)),[1 1 1 length(unique_times)]).*repmat(htn(:,1:(length(lat_ind_inrange) - 1)),[1 1 1 length(unique_times)]).*sum(-diff_y_min_dzt_depth_integrating_north_facing_bottom_only.*vT_north(:,1:(length(lat_ind_inrange) - 1),:,:),3),2),1));

north_facing_ind = setdiff((1:1:prod(size(diff_y_min_dzt_depth_integrating_north_facing_bottom_only)))',not_north_facing_ind);
size_array = size(diff_y_min_dzt_depth_integrating_north_facing_bottom_only);
north_facing_t_ind = ceil(north_facing_ind/prod(size_array(1:3)));
% in_time_range_north_facing_ind = find(ismember(north_facing_t_ind,time_inrange_from_unique_ind) == 1);
% north_facing_ind = north_facing_ind(in_time_range_north_facing_ind);
% north_facing_t_ind = north_facing_t_ind(in_time_range_north_facing_ind);
t_residual = north_facing_ind - (prod(size_array(1:3))*(north_facing_t_ind - 1));
unique_north_facing_i_j_k_ind = unique(t_residual);

adv_vol_flux_N_sloping_bottom = zeros(length(unique_times),1);
adv_T_flux_N_sloping_bottom = zeros(length(unique_times),1);
adv_vmean_Tmean_tend_N_sloping_bottom = zeros(length(unique_times),1);
adv_vmean_Tanom_tend_N_sloping_bottom = zeros(length(unique_times),1);
adv_vanom_Tmean_tend_N_sloping_bottom = zeros(length(unique_times),1);
adv_vanom_Tanom_tend_N_sloping_bottom = zeros(length(unique_times),1);
for north_facing_cell_ind = 1:length(unique_north_facing_i_j_k_ind)
    curr_i_j_k_ind = unique_north_facing_i_j_k_ind(north_facing_cell_ind);
    curr_k_ind = ceil(curr_i_j_k_ind/prod(size_array(1:2)));
    k_residual = curr_i_j_k_ind - (prod(size_array(1:2))*(curr_k_ind - 1));
    curr_j_ind = ceil(k_residual/size_array(1));
    curr_i_ind = k_residual - ((size_array(1))*(curr_j_ind - 1));
    
    at_cell_ind = find(t_residual == curr_i_j_k_ind);
    t_ind_to_sum = north_facing_t_ind(at_cell_ind);
    
    curr_adv_vol_flux_N_sloping_bottom = zeros(length(unique_times),1);
    curr_adv_vol_flux_N_sloping_bottom(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind)*htn(curr_i_ind,curr_j_ind)*(-diff_y_min_dzt_depth_integrating_north_facing_bottom_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*vvel_north(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum)));
    adv_vol_flux_N_sloping_bottom = adv_vol_flux_N_sloping_bottom + curr_adv_vol_flux_N_sloping_bottom;
    curr_adv_T_flux_N_sloping_bottom = zeros(length(unique_times),1);
    curr_adv_T_flux_N_sloping_bottom(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind)*htn(curr_i_ind,curr_j_ind)*(-diff_y_min_dzt_depth_integrating_north_facing_bottom_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*vT_north(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum))) - (curr_adv_vol_flux_N_sloping_bottom(t_ind_to_sum).*T_mean_inbox(t_ind_to_sum));
    adv_T_flux_N_sloping_bottom = adv_T_flux_N_sloping_bottom + curr_adv_T_flux_N_sloping_bottom;
    
    vvel_north_norm_at_pos = squeeze(-vvel_north(curr_i_ind,curr_j_ind,curr_k_ind,:))./vol_integrated_inbox;
    m_seasonal_vvel_north_norm_at_pos = ((vvel_north_norm_at_pos')*seasonal_reg_operator_T)';
    vmean_north_norm_at_pos = G_seasonal*m_seasonal_vvel_north_norm_at_pos;
    vanom_north_norm_at_pos = vvel_north_norm_at_pos - vmean_north_norm_at_pos;
        
    T_minus_T_inboxmean_at_pos = squeeze(mean(temp(curr_i_ind,curr_j_ind:(curr_j_ind + 1),curr_k_ind,:),2)) - T_mean_inbox;
    m_seasonal_T_at_pos = ((T_minus_T_inboxmean_at_pos')*seasonal_reg_operator_T)';
    Tmean_at_pos = G_seasonal*m_seasonal_T_at_pos;
    Tanom_at_pos = T_minus_T_inboxmean_at_pos - Tmean_at_pos;
    
    curr_adv_vmean_Tmean_tend_N_sloping_bottom = zeros(length(unique_times),1);
    curr_adv_vmean_Tmean_tend_N_sloping_bottom(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind)*htn(curr_i_ind,curr_j_ind)*(-squeeze(diff_y_min_dzt_depth_integrating_north_facing_bottom_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum)).*vmean_north_norm_at_pos(t_ind_to_sum).*Tmean_at_pos(t_ind_to_sum)));
    adv_vmean_Tmean_tend_N_sloping_bottom = adv_vmean_Tmean_tend_N_sloping_bottom + curr_adv_vmean_Tmean_tend_N_sloping_bottom;
    curr_adv_vmean_Tanom_tend_N_sloping_bottom = zeros(length(unique_times),1);
    curr_adv_vmean_Tanom_tend_N_sloping_bottom(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind)*htn(curr_i_ind,curr_j_ind)*(-squeeze(diff_y_min_dzt_depth_integrating_north_facing_bottom_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum)).*vmean_north_norm_at_pos(t_ind_to_sum).*Tanom_at_pos(t_ind_to_sum)));
    adv_vmean_Tanom_tend_N_sloping_bottom = adv_vmean_Tanom_tend_N_sloping_bottom + curr_adv_vmean_Tanom_tend_N_sloping_bottom;
    curr_adv_vanom_Tmean_tend_N_sloping_bottom = zeros(length(unique_times),1);
    curr_adv_vanom_Tmean_tend_N_sloping_bottom(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind)*htn(curr_i_ind,curr_j_ind)*(-squeeze(diff_y_min_dzt_depth_integrating_north_facing_bottom_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum)).*vanom_north_norm_at_pos(t_ind_to_sum).*Tmean_at_pos(t_ind_to_sum)));
    adv_vanom_Tmean_tend_N_sloping_bottom = adv_vanom_Tmean_tend_N_sloping_bottom + curr_adv_vanom_Tmean_tend_N_sloping_bottom;
    
    adv_vanom_Tanom_tend_N_sloping_bottom = adv_vanom_Tanom_tend_N_sloping_bottom + ((-curr_adv_T_flux_N_sloping_bottom./vol_integrated_inbox(:)) - curr_adv_vmean_Tmean_tend_N_sloping_bottom - curr_adv_vmean_Tanom_tend_N_sloping_bottom - curr_adv_vanom_Tmean_tend_N_sloping_bottom);

end

diff_T_flux_N_sloping_bottom = squeeze(sum(sum(repmat(in_box_mask(:,1:(length(lat_ind_inrange) - 1)),[1 1 1 length(unique_times)]).*repmat(htn(:,1:(length(lat_ind_inrange) - 1)),[1 1 1 length(unique_times)]).*sum(-diff_y_min_dzt_depth_integrating_north_facing_bottom_only.*hdiff_T_flux_north(:,1:(length(lat_ind_inrange) - 1),:,:),3),2),1));


diff_y_min_dzt_depth_integrating_south_facing_bottom_only = diff_y_min_dzt_depth_integrating_bottom_only;
not_south_facing_ind = find(diff_y_min_dzt_depth_integrating_south_facing_bottom_only <= 0);
diff_y_min_dzt_depth_integrating_south_facing_bottom_only(not_south_facing_ind) = 0;

% adv_vol_flux_S_sloping_bottom = squeeze(sum(sum(repmat(in_box_mask(:,2:length(lat_ind_inrange)),[1 1 1 length(unique_times)]).*repmat(htn(:,1:(length(lat_ind_inrange) - 1)),[1 1 1 length(unique_times)]).*sum(diff_y_min_dzt_depth_integrating_south_facing_bottom_only.*(-vvel_north(:,1:(length(lat_ind_inrange) - 1),:,:)),3),2),1));
% adv_T_flux_S_sloping_bottom = squeeze(sum(sum(repmat(in_box_mask(:,2:length(lat_ind_inrange)),[1 1 1 length(unique_times)]).*repmat(htn(:,1:(length(lat_ind_inrange) - 1)),[1 1 1 length(unique_times)]).*sum(diff_y_min_dzt_depth_integrating_south_facing_bottom_only.*(-vT_north(:,1:(length(lat_ind_inrange) - 1),:,:)),3),2),1));

south_facing_ind = setdiff((1:1:prod(size(diff_y_min_dzt_depth_integrating_south_facing_bottom_only)))',not_south_facing_ind);
size_array = size(diff_y_min_dzt_depth_integrating_south_facing_bottom_only);
south_facing_t_ind = ceil(south_facing_ind/prod(size_array(1:3)));
% in_time_range_south_facing_ind = find(ismember(south_facing_t_ind,time_inrange_from_unique_ind) == 1);
% south_facing_ind = south_facing_ind(in_time_range_south_facing_ind);
% south_facing_t_ind = south_facing_t_ind(in_time_range_south_facing_ind);
t_residual = south_facing_ind - (prod(size_array(1:3))*(south_facing_t_ind - 1));
unique_south_facing_i_j_k_ind = unique(t_residual);

adv_vol_flux_S_sloping_bottom = zeros(length(unique_times),1);
adv_T_flux_S_sloping_bottom = zeros(length(unique_times),1);
adv_vmean_Tmean_tend_S_sloping_bottom = zeros(length(unique_times),1);
adv_vmean_Tanom_tend_S_sloping_bottom = zeros(length(unique_times),1);
adv_vanom_Tmean_tend_S_sloping_bottom = zeros(length(unique_times),1);
adv_vanom_Tanom_tend_S_sloping_bottom = zeros(length(unique_times),1);
for south_facing_cell_ind = 1:length(unique_south_facing_i_j_k_ind)
    curr_i_j_k_ind = unique_south_facing_i_j_k_ind(south_facing_cell_ind);
    curr_k_ind = ceil(curr_i_j_k_ind/prod(size_array(1:2)));
    k_residual = curr_i_j_k_ind - (prod(size_array(1:2))*(curr_k_ind - 1));
    curr_j_ind = ceil(k_residual/size_array(1));
    curr_i_ind = k_residual - ((size_array(1))*(curr_j_ind - 1));
    
    at_cell_ind = find(t_residual == curr_i_j_k_ind);
    t_ind_to_sum = south_facing_t_ind(at_cell_ind);
    
    curr_adv_vol_flux_S_sloping_bottom = zeros(length(unique_times),1);
    curr_adv_vol_flux_S_sloping_bottom(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind + 1)*htn(curr_i_ind,curr_j_ind)*(diff_y_min_dzt_depth_integrating_south_facing_bottom_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*(-vvel_north(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum))));
    adv_vol_flux_S_sloping_bottom = adv_vol_flux_S_sloping_bottom + curr_adv_vol_flux_S_sloping_bottom;
    curr_adv_T_flux_S_sloping_bottom = zeros(length(unique_times),1);
    curr_adv_T_flux_S_sloping_bottom(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind + 1)*htn(curr_i_ind,curr_j_ind)*(diff_y_min_dzt_depth_integrating_south_facing_bottom_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum).*(-vT_north(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum)))) - (curr_adv_vol_flux_S_sloping_bottom(t_ind_to_sum).*T_mean_inbox(t_ind_to_sum));
    adv_T_flux_S_sloping_bottom = adv_T_flux_S_sloping_bottom + curr_adv_T_flux_S_sloping_bottom;
    
    vvel_north_norm_at_pos = squeeze(-vvel_north(curr_i_ind,curr_j_ind,curr_k_ind,:))./vol_integrated_inbox;
    m_seasonal_vvel_north_norm_at_pos = ((vvel_north_norm_at_pos')*seasonal_reg_operator_T)';
    vmean_north_norm_at_pos = G_seasonal*m_seasonal_vvel_north_norm_at_pos;
    vanom_north_norm_at_pos = vvel_north_norm_at_pos - vmean_north_norm_at_pos;
        
        
    T_minus_T_inboxmean_at_pos = squeeze(mean(temp(curr_i_ind,curr_j_ind:(curr_j_ind + 1),curr_k_ind,:),2)) - T_mean_inbox;
    m_seasonal_T_at_pos = ((T_minus_T_inboxmean_at_pos')*seasonal_reg_operator_T)';
    Tmean_at_pos = G_seasonal*m_seasonal_T_at_pos;
    Tanom_at_pos = T_minus_T_inboxmean_at_pos - Tmean_at_pos;
    
    curr_adv_vmean_Tmean_tend_S_sloping_bottom = zeros(length(unique_times),1);
    curr_adv_vmean_Tmean_tend_S_sloping_bottom(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind + 1)*htn(curr_i_ind,curr_j_ind)*(squeeze(diff_y_min_dzt_depth_integrating_south_facing_bottom_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum)).*(-vmean_north_norm_at_pos(t_ind_to_sum)).*Tmean_at_pos(t_ind_to_sum)));
    adv_vmean_Tmean_tend_S_sloping_bottom = adv_vmean_Tmean_tend_S_sloping_bottom + curr_adv_vmean_Tmean_tend_S_sloping_bottom;
    curr_adv_vmean_Tanom_tend_S_sloping_bottom = zeros(length(unique_times),1);
    curr_adv_vmean_Tanom_tend_S_sloping_bottom(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind + 1)*htn(curr_i_ind,curr_j_ind)*(squeeze(diff_y_min_dzt_depth_integrating_south_facing_bottom_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum)).*(-vmean_north_norm_at_pos(t_ind_to_sum)).*Tanom_at_pos(t_ind_to_sum)));
    adv_vmean_Tanom_tend_S_sloping_bottom = adv_vmean_Tanom_tend_S_sloping_bottom + curr_adv_vmean_Tanom_tend_S_sloping_bottom;
    curr_adv_vanom_Tmean_tend_S_sloping_bottom = zeros(length(unique_times),1);
    curr_adv_vanom_Tmean_tend_S_sloping_bottom(t_ind_to_sum) = squeeze(in_box_mask(curr_i_ind,curr_j_ind + 1)*htn(curr_i_ind,curr_j_ind)*(squeeze(diff_y_min_dzt_depth_integrating_south_facing_bottom_only(curr_i_ind,curr_j_ind,curr_k_ind,t_ind_to_sum)).*(-vanom_north_norm_at_pos(t_ind_to_sum)).*Tmean_at_pos(t_ind_to_sum)));
    adv_vanom_Tmean_tend_S_sloping_bottom = adv_vanom_Tmean_tend_S_sloping_bottom + curr_adv_vanom_Tmean_tend_S_sloping_bottom;
    
    adv_vanom_Tanom_tend_S_sloping_bottom = adv_vanom_Tanom_tend_S_sloping_bottom + ((-curr_adv_T_flux_S_sloping_bottom./vol_integrated_inbox(:)) - curr_adv_vmean_Tmean_tend_S_sloping_bottom - curr_adv_vmean_Tanom_tend_S_sloping_bottom - curr_adv_vanom_Tmean_tend_S_sloping_bottom);

end

diff_T_flux_S_sloping_bottom = squeeze(sum(sum(repmat(in_box_mask(:,2:length(lat_ind_inrange)),[1 1 1 length(unique_times)]).*repmat(htn(:,1:(length(lat_ind_inrange) - 1)),[1 1 1 length(unique_times)]).*sum(diff_y_min_dzt_depth_integrating_south_facing_bottom_only.*(-hdiff_T_flux_north(:,1:(length(lat_ind_inrange) - 1),:,:)),3),2),1));

disp('Completed computing advective terms for variable-depth bottom bound')





% compute advective temperature tendency contributions

adv_T_tend_N_edge = -adv_T_flux_N./vol_integrated_inbox(:);
adv_T_tend_W_edge = -adv_T_flux_W./vol_integrated_inbox(:);
adv_T_tend_S_edge = -adv_T_flux_S./vol_integrated_inbox(:);
adv_T_tend_E_edge = -adv_T_flux_E./vol_integrated_inbox(:);
adv_T_tend_top_edge = -adv_T_flux_top./vol_integrated_inbox(:);
adv_T_tend_bottom_edge = -adv_T_flux_bottom./vol_integrated_inbox(:);

adv_T_tend_N_sloping_top = -adv_T_flux_N_sloping_top./vol_integrated_inbox(:);
adv_T_tend_W_sloping_top = -adv_T_flux_W_sloping_top./vol_integrated_inbox(:);
adv_T_tend_S_sloping_top = -adv_T_flux_S_sloping_top./vol_integrated_inbox(:);
adv_T_tend_E_sloping_top = -adv_T_flux_E_sloping_top./vol_integrated_inbox(:);

adv_T_tend_N_sloping_bottom = -adv_T_flux_N_sloping_bottom./vol_integrated_inbox(:);
adv_T_tend_W_sloping_bottom = -adv_T_flux_W_sloping_bottom./vol_integrated_inbox(:);
adv_T_tend_S_sloping_bottom = -adv_T_flux_S_sloping_bottom./vol_integrated_inbox(:);
adv_T_tend_E_sloping_bottom = -adv_T_flux_E_sloping_bottom./vol_integrated_inbox(:);






% adjustment to shift the top advective and entrainment term balance at the surface

top_at_sfc_mask = zeros(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_times));
top_cell_top_level_ind = find(top_depth_bound_array < z_w_bot(1));
min_dzt_depth_integrating_array_top_layer = squeeze(min_dzt_depth_integrating_array(:,:,1,:));
repmat_dzt_inrange = repmat(dzt(:,:,1),[1 1 length(unique_times)]);
if isempty(top_cell_top_level_ind) == 0
    top_at_sfc_mask(top_cell_top_level_ind) = min_dzt_depth_integrating_array_top_layer(top_cell_top_level_ind)./repmat_dzt_inrange(top_cell_top_level_ind);
end
top_at_sfc_mask(isnan(top_at_sfc_mask) == 1) = 0;
top_at_sfc_mask(isinf(top_at_sfc_mask) == 1) = 0;

adv_vol_flux_top_at_sfc = squeeze(sum(sum((repmat(in_box_mask.*tarea,[1 1 length(unique_times)]).*top_at_sfc_mask.*squeeze(wvel(:,:,1,:))),2),1));
adv_T_flux_top_at_sfc = squeeze(sum(sum((repmat(in_box_mask.*tarea,[1 1 length(unique_times)]).*top_at_sfc_mask.*squeeze(wvel(:,:,1,:).*temp(:,:,1,:))),2),1));

sfc_ent_T_tend_adj = (adv_T_flux_top_at_sfc - (adv_vol_flux_top_at_sfc.*T_mean_inbox))./vol_integrated_inbox;
sfc_total_T_tend_adj = adv_T_flux_top_at_sfc(:)./vol_integrated_inbox(:);   % may need to be solved for based on entrainment instead





% compute diffusive temp. tendency contributions

% % seasonal decomposition
% 
% m_seasonal_diff_T_flux_N = diff_T_flux_N*seasonal_reg_operator_T;
% diff_T_mean_flux_N = G_seasonal*m_seasonal_diff_T_flux_N;
% diff_T_anom_flux_N = diff_T_flux_N - diff_T_mean_flux_N;
% m_seasonal_diff_T_flux_W = diff_T_flux_W*seasonal_reg_operator_T;
% diff_T_mean_flux_W = G_seasonal*m_seasonal_diff_T_flux_W;
% diff_T_anom_flux_W = diff_T_flux_W - diff_T_mean_flux_W;
% m_seasonal_diff_T_flux_S = diff_T_flux_S*seasonal_reg_operator_T;
% diff_T_mean_flux_S = G_seasonal*m_seasonal_diff_T_flux_S;
% diff_T_anom_flux_S = diff_T_flux_S - diff_T_mean_flux_S;
% m_seasonal_diff_T_flux_E = diff_T_flux_E*seasonal_reg_operator_T;
% diff_T_mean_flux_E = G_seasonal*m_seasonal_diff_T_flux_E;
% diff_T_anom_flux_E = diff_T_flux_E - diff_T_mean_flux_E;
% m_seasonal_diff_T_flux_top = diff_T_flux_top*seasonal_reg_operator_T;
% diff_T_mean_flux_top = G_seasonal*m_seasonal_diff_T_flux_top;
% diff_T_anom_flux_top = diff_T_flux_top - diff_T_mean_flux_top;
% m_seasonal_diff_T_flux_bottom = diff_T_flux_bottom*seasonal_reg_operator_T;
% diff_T_mean_flux_bottom = G_seasonal*m_seasonal_diff_T_flux_bottom;
% diff_T_anom_flux_bottom = diff_T_flux_bottom - diff_T_mean_flux_bottom;
% 
% m_seasonal_diff_T_flux_N_sloping_top = diff_T_flux_N_sloping_top*seasonal_reg_operator_T;
% diff_T_mean_flux_N_sloping_top = G_seasonal*m_seasonal_diff_T_flux_N_sloping_top;
% diff_T_anom_flux_N_sloping_top = diff_T_flux_N_sloping_top - diff_T_mean_flux_N_sloping_top;
% m_seasonal_diff_T_flux_W_sloping_top = diff_T_flux_W_sloping_top*seasonal_reg_operator_T;
% diff_T_mean_flux_W_sloping_top = G_seasonal*m_seasonal_diff_T_flux_W_sloping_top;
% diff_T_anom_flux_W_sloping_top = diff_T_flux_W_sloping_top - diff_T_mean_flux_W_sloping_top;
% m_seasonal_diff_T_flux_S_sloping_top = diff_T_flux_S_sloping_top*seasonal_reg_operator_T;
% diff_T_mean_flux_S_sloping_top = G_seasonal*m_seasonal_diff_T_flux_S_sloping_top;
% diff_T_anom_flux_S_sloping_top = diff_T_flux_S_sloping_top - diff_T_mean_flux_S_sloping_top;
% m_seasonal_diff_T_flux_sloping_top = diff_T_flux_sloping_top*seasonal_reg_operator_T;
% diff_T_mean_flux_sloping_top = G_seasonal*m_seasonal_diff_T_flux_sloping_top;
% diff_T_anom_flux_sloping_top = diff_T_flux_sloping_top - diff_T_mean_flux_sloping_top;
% 
% m_seasonal_diff_T_flux_N_sloping_bottom = diff_T_flux_N_sloping_bottom*seasonal_reg_operator_T;
% diff_T_mean_flux_N_sloping_bottom = G_seasonal*m_seasonal_diff_T_flux_N_sloping_bottom;
% diff_T_anom_flux_N_sloping_bottom = diff_T_flux_N_sloping_bottom - diff_T_mean_flux_N_sloping_bottom;
% m_seasonal_diff_T_flux_W_sloping_bottom = diff_T_flux_W_sloping_bottom*seasonal_reg_operator_T;
% diff_T_mean_flux_W_sloping_bottom = G_seasonal*m_seasonal_diff_T_flux_W_sloping_bottom;
% diff_T_anom_flux_W_sloping_bottom = diff_T_flux_W_sloping_bottom - diff_T_mean_flux_W_sloping_bottom;
% m_seasonal_diff_T_flux_S_sloping_bottom = diff_T_flux_S_sloping_bottom*seasonal_reg_operator_T;
% diff_T_mean_flux_S_sloping_bottom = G_seasonal*m_seasonal_diff_T_flux_S_sloping_bottom;
% diff_T_anom_flux_S_sloping_bottom = diff_T_flux_S_sloping_bottom - diff_T_mean_flux_S_sloping_bottom;
% m_seasonal_diff_T_flux_sloping_bottom = diff_T_flux_sloping_bottom*seasonal_reg_operator_T;
% diff_T_mean_flux_sloping_bottom = G_seasonal*m_seasonal_diff_T_flux_sloping_bottom;
% diff_T_anom_flux_sloping_bottom = diff_T_flux_sloping_bottom - diff_T_mean_flux_sloping_bottom;



hdiff_T_tend_N_edge = -diff_T_flux_N./vol_integrated_inbox(:);
hdiff_T_tend_W_edge = -diff_T_flux_W./vol_integrated_inbox(:);
hdiff_T_tend_S_edge = -diff_T_flux_S./vol_integrated_inbox(:);
hdiff_T_tend_E_edge = -diff_T_flux_E./vol_integrated_inbox(:);
hdiff_T_tend_top_edge = -diff_T_flux_top./vol_integrated_inbox(:);
hdiff_T_tend_bottom_edge = -diff_T_flux_bottom./vol_integrated_inbox(:);

hdiff_T_tend_N_sloping_top = -diff_T_flux_N_sloping_top./vol_integrated_inbox(:);
hdiff_T_tend_W_sloping_top = -diff_T_flux_W_sloping_top./vol_integrated_inbox(:);
hdiff_T_tend_S_sloping_top = -diff_T_flux_S_sloping_top./vol_integrated_inbox(:);
hdiff_T_tend_E_sloping_top = -diff_T_flux_E_sloping_top./vol_integrated_inbox(:);

hdiff_T_tend_N_sloping_bottom = -diff_T_flux_N_sloping_bottom./vol_integrated_inbox(:);
hdiff_T_tend_W_sloping_bottom = -diff_T_flux_W_sloping_bottom./vol_integrated_inbox(:);
hdiff_T_tend_S_sloping_bottom = -diff_T_flux_S_sloping_bottom./vol_integrated_inbox(:);
hdiff_T_tend_E_sloping_bottom = -diff_T_flux_E_sloping_bottom./vol_integrated_inbox(:);

% hdiff_T_mean_tend_N_edge = -diff_T_mean_flux_N./vol_integrated_inbox(:);
% hdiff_T_mean_tend_W_edge = -diff_T_mean_flux_W./vol_integrated_inbox(:);
% hdiff_T_mean_tend_S_edge = -diff_T_mean_flux_S./vol_integrated_inbox(:);
% hdiff_T_mean_tend_E_edge = -diff_T_mean_flux_E./vol_integrated_inbox(:);
% hdiff_T_mean_tend_top_edge = -diff_T_mean_flux_top./vol_integrated_inbox(:);
% hdiff_T_mean_tend_bottom_edge = -diff_T_mean_flux_bottom./vol_integrated_inbox(:);
% 
% hdiff_T_mean_tend_N_sloping_top = -diff_T_mean_flux_N_sloping_top./vol_integrated_inbox(:);
% hdiff_T_mean_tend_W_sloping_top = -diff_T_mean_flux_W_sloping_top./vol_integrated_inbox(:);
% hdiff_T_mean_tend_S_sloping_top = -diff_T_mean_flux_S_sloping_top./vol_integrated_inbox(:);
% hdiff_T_mean_tend_E_sloping_top = -diff_T_mean_flux_E_sloping_top./vol_integrated_inbox(:);
% 
% hdiff_T_mean_tend_N_sloping_bottom = -diff_T_mean_flux_N_sloping_bottom./vol_integrated_inbox(:);
% hdiff_T_mean_tend_W_sloping_bottom = -diff_T_mean_flux_W_sloping_bottom./vol_integrated_inbox(:);
% hdiff_T_mean_tend_S_sloping_bottom = -diff_T_mean_flux_S_sloping_bottom./vol_integrated_inbox(:);
% hdiff_T_mean_tend_E_sloping_bottom = -diff_T_mean_flux_E_sloping_bottom./vol_integrated_inbox(:);
% 
% hdiff_T_anom_tend_N_edge = -diff_T_anom_flux_N./vol_integrated_inbox(:);
% hdiff_T_anom_tend_W_edge = -diff_T_anom_flux_W./vol_integrated_inbox(:);
% hdiff_T_anom_tend_S_edge = -diff_T_anom_flux_S./vol_integrated_inbox(:);
% hdiff_T_anom_tend_E_edge = -diff_T_anom_flux_E./vol_integrated_inbox(:);
% hdiff_T_anom_tend_top_edge = -diff_T_anom_flux_top./vol_integrated_inbox(:);
% hdiff_T_anom_tend_bottom_edge = -diff_T_anom_flux_bottom./vol_integrated_inbox(:);
% 
% hdiff_T_anom_tend_N_sloping_top = -diff_T_anom_flux_N_sloping_top./vol_integrated_inbox(:);
% hdiff_T_anom_tend_W_sloping_top = -diff_T_anom_flux_W_sloping_top./vol_integrated_inbox(:);
% hdiff_T_anom_tend_S_sloping_top = -diff_T_anom_flux_S_sloping_top./vol_integrated_inbox(:);
% hdiff_T_anom_tend_E_sloping_top = -diff_T_anom_flux_E_sloping_top./vol_integrated_inbox(:);
% 
% hdiff_T_anom_tend_N_sloping_bottom = -diff_T_anom_flux_N_sloping_bottom./vol_integrated_inbox(:);
% hdiff_T_anom_tend_W_sloping_bottom = -diff_T_anom_flux_W_sloping_bottom./vol_integrated_inbox(:);
% hdiff_T_anom_tend_S_sloping_bottom = -diff_T_anom_flux_S_sloping_bottom./vol_integrated_inbox(:);
% hdiff_T_anom_tend_E_sloping_bottom = -diff_T_anom_flux_E_sloping_bottom./vol_integrated_inbox(:);




% compute contributions from diabatic implicit vertical mixing

diab_vert_T_tend_top = diab_vert_T_flux_top./vol_integrated_inbox;
diab_vert_T_tend_bottom = -diab_vert_T_flux_bottom./vol_integrated_inbox;

diab_vert_T_tend = diab_vert_T_tend_top + diab_vert_T_tend_bottom;



% compute contributions from the non-local mixing term

kpp_src_T_tend_integrated_inbox = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 1 length(unique_times)]).*sum(min_dzt_depth_integrating_array.*kpp_src_temp,3),2),1));

kpp_src_T_tend = kpp_src_T_tend_integrated_inbox./vol_integrated_inbox;




% compute contributions from the surface heat flux and the shortwave energy input

sfc_flux_T_tend_vol_integrated_inbox = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 length(unique_times)]).*top_at_sfc_mask.*sfc_heat_flux*hflux_factor,2),1));

% compute contributions from constituents of surface heat flux (other than shortwave)
longwave_downward_flux_T_tend_vol_integrated_inbox = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 length(unique_times)]).*top_at_sfc_mask.*longwave_downward_flux*hflux_factor,2),1));
longwave_upward_flux_T_tend_vol_integrated_inbox = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 length(unique_times)]).*top_at_sfc_mask.*longwave_upward_flux*hflux_factor,2),1));
latent_heat_flux_T_tend_vol_integrated_inbox = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 length(unique_times)]).*top_at_sfc_mask.*evap_mass_flux*latent_heat_vapor*hflux_factor,2),1));
sensible_heat_flux_T_tend_vol_integrated_inbox = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 length(unique_times)]).*top_at_sfc_mask.*sensible_heat_flux*hflux_factor,2),1));


sw_flux_top_bound_top_level_mask = ones(size(top_at_sfc_mask));
sw_flux_top_bound_top_level_mask(top_cell_top_level_ind) = 1 - top_at_sfc_mask(top_cell_top_level_ind);
sw_flux_top_bound_weighting_array = top_bound_weighting_array;
sw_flux_top_bound_weighting_array_sfc = top_bound_weighting_array(:,:,1,:);
sw_flux_top_bound_weighting_array_sfc(top_cell_top_level_ind) = 0;
sw_flux_top_bound_weighting_array(:,:,1,:) = sw_flux_top_bound_weighting_array_sfc;
sw_flux_top_bound_weighting_array_just_under_sfc = top_bound_weighting_array(:,:,2,:);
sw_flux_top_bound_weighting_array_just_under_sfc(top_cell_top_level_ind) = 1;
sw_flux_top_bound_weighting_array(:,:,2,:) = sw_flux_top_bound_weighting_array_just_under_sfc;

% shortwave flux + other surface fluxes (if applicable)
sw_inc_sfc_flux_top_bound_vol_integrated_inbox = squeeze(sum(sum((repmat(in_box_mask.*tarea,[1 1 1 length(unique_times)]).*sum(repmat(reshape(sw_flux_top_bound_top_level_mask,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[1 1 length(depth_ind_inrange) 1]).*sw_flux_top_bound_weighting_array.*sw_flux_top*hflux_factor,3)),2),1));

% shortwave flux only
sw_flux_top_bound_only_vol_integrated_inbox = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 length(unique_times)]).*squeeze(sum(top_bound_weighting_array.*sw_flux_top*hflux_factor,3)),2),1));


sw_flux_bottom_bound_top_level_mask = ones(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_times));
bottom_at_sfc_ind = find(bottom_depth_bound_array <= 0);
bottom_cell_top_level_ind = find(bottom_depth_bound_array < z_w_bot(1));
bottom_cell_top_level_not_sfc_ind = setdiff(bottom_cell_top_level_ind,bottom_at_sfc_ind);
sw_flux_bottom_bound_top_level_mask(bottom_at_sfc_ind) = 0;
if isempty(bottom_cell_top_level_not_sfc_ind) == 0
    sw_flux_bottom_bound_top_level_mask(bottom_cell_top_level_not_sfc_ind) = (bottom_depth_bound_array(bottom_cell_top_level_not_sfc_ind) + SSH(bottom_cell_top_level_not_sfc_ind))./(repmat_dzt_inrange(bottom_cell_top_level_not_sfc_ind) + SSH(bottom_cell_top_level_not_sfc_ind));
end
sw_flux_bottom_bound_top_level_mask(isnan(sw_flux_bottom_bound_top_level_mask) == 1) = 0;
sw_flux_bottom_bound_top_level_mask(isinf(sw_flux_bottom_bound_top_level_mask) == 1) = 0;


sw_flux_bottom_bound_weighting_array = bottom_bound_weighting_array;
sw_flux_bottom_bound_weighting_array_sfc = bottom_bound_weighting_array(:,:,1,:);
sw_flux_bottom_bound_weighting_array_sfc(bottom_cell_top_level_ind) = 0;
sw_flux_bottom_bound_weighting_array(:,:,1,:) = sw_flux_bottom_bound_weighting_array_sfc;
sw_flux_bottom_bound_weighting_array_just_under_sfc = bottom_bound_weighting_array(:,:,2,:);
sw_flux_bottom_bound_weighting_array_just_under_sfc(bottom_cell_top_level_ind) = 1;
sw_flux_bottom_bound_weighting_array(:,:,2,:) = sw_flux_bottom_bound_weighting_array_just_under_sfc;

% shortwave flux + other surface fluxes (if applicable)
sw_inc_sfc_flux_bottom_bound_vol_integrated_inbox = squeeze(sum(sum((repmat(in_box_mask.*tarea,[1 1 1 length(unique_times)]).*sum(repmat(reshape(sw_flux_bottom_bound_top_level_mask,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]),[1 1 length(depth_ind_inrange) 1]).*sw_flux_bottom_bound_weighting_array.*sw_flux_top*hflux_factor,3)),2),1));

% shortwave flux only
sw_flux_bottom_bound_only_vol_integrated_inbox = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 length(unique_times)]).*squeeze(sum(bottom_bound_weighting_array.*sw_flux_top*hflux_factor,3)),2),1));


% separate shortwave and other surface tendencies

sw_top_flux_T_tend = sw_flux_top_bound_only_vol_integrated_inbox./vol_integrated_inbox;
sw_bottom_flux_T_tend = -sw_flux_bottom_bound_only_vol_integrated_inbox./vol_integrated_inbox;

sfc_flux_minus_sw_T_tend = (sfc_flux_T_tend_vol_integrated_inbox - (sw_flux_top_bound_only_vol_integrated_inbox - sw_flux_bottom_bound_only_vol_integrated_inbox) + (sw_inc_sfc_flux_top_bound_vol_integrated_inbox - sw_inc_sfc_flux_bottom_bound_vol_integrated_inbox))./vol_integrated_inbox;


% surface component tendencies (not including shortwave)
longwave_downward_flux_T_tend = longwave_downward_flux_T_tend_vol_integrated_inbox./vol_integrated_inbox;
longwave_upward_flux_T_tend = longwave_upward_flux_T_tend_vol_integrated_inbox./vol_integrated_inbox;
latent_heat_flux_T_tend = latent_heat_flux_T_tend_vol_integrated_inbox./vol_integrated_inbox;
sensible_heat_flux_T_tend = sensible_heat_flux_T_tend_vol_integrated_inbox./vol_integrated_inbox;


% total (surface + shortwave) tendency
sfc_sw_flux_T_tend = sfc_flux_minus_sw_T_tend + sw_top_flux_T_tend + sw_bottom_flux_T_tend;


% diabatic vertical mixing tendencies
diab_vert_T_tend_top = diab_vert_T_flux_top./vol_integrated_inbox;
diab_vert_T_tend_bottom = -diab_vert_T_flux_bottom./vol_integrated_inbox;




% collective contribution from variable depth bound-related terms

var_depth_adv_T_tend_top = adv_T_tend_N_sloping_top + adv_T_tend_W_sloping_top + adv_T_tend_S_sloping_top + adv_T_tend_E_sloping_top;
var_depth_hdiff_T_tend_top = hdiff_T_tend_N_sloping_top + hdiff_T_tend_W_sloping_top + hdiff_T_tend_S_sloping_top + hdiff_T_tend_E_sloping_top;
var_depth_T_tend_top = var_depth_adv_T_tend_top + var_depth_hdiff_T_tend_top + sfc_ent_T_tend_adj;
var_depth_adv_T_tend_bottom = adv_T_tend_N_sloping_bottom + adv_T_tend_W_sloping_bottom + adv_T_tend_S_sloping_bottom + adv_T_tend_E_sloping_bottom;
var_depth_hdiff_T_tend_bottom = hdiff_T_tend_N_sloping_bottom + hdiff_T_tend_W_sloping_bottom + hdiff_T_tend_S_sloping_bottom + hdiff_T_tend_E_sloping_bottom;
var_depth_T_tend_bottom = var_depth_adv_T_tend_bottom + var_depth_hdiff_T_tend_bottom;



% sum of the advective/entrainment contributions to temp. tendency

adv_T_tend_total = adv_T_tend_N_edge + adv_T_tend_W_edge + adv_T_tend_S_edge + adv_T_tend_E_edge + adv_T_tend_top_edge + adv_T_tend_bottom_edge + var_depth_adv_T_tend_top + var_depth_adv_T_tend_bottom;

% sum of the diffusive contributions to temp. tendency
hdiff_T_tend_total = hdiff_T_tend_N_edge + hdiff_T_tend_W_edge + hdiff_T_tend_S_edge + hdiff_T_tend_E_edge + hdiff_T_tend_top_edge + hdiff_T_tend_bottom_edge + var_depth_hdiff_T_tend_top + var_depth_hdiff_T_tend_bottom;


% sum of the temperature tendency terms, prior to the entrainment calculation
T_tend_sum_terms = adv_T_tend_total + hdiff_T_tend_total + sfc_ent_T_tend_adj + diab_vert_T_tend + kpp_src_T_tend + sfc_sw_flux_T_tend;





% compute entrainment term (optional), as the residual of the temperature change unexplained by other terms

% ent_compute_option = 1: no flux or tendency computed due to changing volume of the surface layer (except for the part due to changes at the surface)
% ent_compute_option = 2: entrainment tendencies are computed based on the residual between the sum of the already-computed budget terms and the actual temperature change


% compute time midpoints (i.e., endpoints of tavg periods)
time_midpts = unique_times(2:length(unique_times)) - (diff(unique_times)/2);


if ent_compute_option == 1
    diff_t_SSH_array = diff(SSH_depth_integrating_array,1,4);
    ent_vol_flux_top_time_midpt = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 (length(unique_times) - 1)]).*(-squeeze(diff_t_SSH_array(:,:,1,:))),2),1))./(86400*diff(unique_times));
    ent_vol_flux_top = [(0.5*ent_vol_flux_top_time_midpt(1)); (((diff(unique_times(2:length(unique_times))).*ent_vol_flux_top_time_midpt(2:length(ent_vol_flux_top_time_midpt))) - (diff(diff(unique_times).*ent_vol_flux_top_time_midpt)/2))./diff(time_midpts)); (0.5*ent_vol_flux_top_time_midpt(length(ent_vol_flux_top_time_midpt)))];
    ent_vol_flux_bottom = zeros(length(unique_times),1);
    
    ent_T_tend_total = sfc_ent_T_tend_adj;
    ent_T_tend_top = sfc_ent_T_tend_adj;
    ent_T_tend_bottom = zeros(length(unique_times),1);
elseif ent_compute_option == 2
    
    T_mean_inbox_midpts = [((1.5*T_mean_inbox(1)) + ((-0.5)*T_mean_inbox(2))); (T_mean_inbox(2:length(T_mean_inbox)) - (diff(T_mean_inbox)/2)); (((-0.5)*T_mean_inbox(length(T_mean_inbox) - 1)) + (1.5*T_mean_inbox(length(T_mean_inbox))))];
    
    actual_dT_dt_inbox = diff(T_mean_inbox_midpts)./(86400*[diff(time_midpts(1:2)); diff(time_midpts); diff(time_midpts((length(time_midpts) - 1):length(time_midpts)))]);
    
    % total entrainment tendency (computed from residual of temperature change)
    ent_T_tend_total = actual_dT_dt_inbox - T_tend_sum_terms;
    
    
    % divide up the total entrainment-related tendency into parts associated with the top and bottom surfaces
    
    % adjust top entrainment term to include changes in SSH
    SSH_depth_integrating_top_layer = zeros(size(SSH));
    top_at_sfc_ind = find(top_depth_bound_array <= 0);
    SSH_depth_integrating_top_layer(top_at_sfc_ind) = SSH(top_at_sfc_ind);
    SSH_depth_integrating_array = zeros(size(min_dzt_depth_integrating_array));
    SSH_depth_integrating_array(:,:,1,:) = reshape(SSH_depth_integrating_top_layer,[length(lon_ind_inrange) length(lat_ind_inrange) 1 length(unique_times)]);
    
    
    % compute approximation to T*dh/dt for top bound
    
    diff_t_min_dzt_depth_integrating_top_only = diff(min_dzt_depth_integrating_top_only + SSH_depth_integrating_array,1,4);
    
    ent_vol_flux_top_time_midpt = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 1 (length(unique_times) - 1)]).*sum(-diff_t_min_dzt_depth_integrating_top_only,3),2),1))./(86400*diff(unique_times));
    
    temp_time_midpt = temp(:,:,:,2:length(unique_times)) - (diff(temp,1,4)/2);
    
    ent_T_dh_top_time_midpt = diff_t_min_dzt_depth_integrating_top_only.*temp_time_midpt;
    
    temp_time_midpt_no_nans = temp_time_midpt;
    temp_time_midpt_no_nans(isnan(temp_time_midpt) == 1) = 0;
    
    
    % depth integrating arrays for time midpoints
    
    top_depth_bound_array_with_SSH = top_depth_bound_array - squeeze(SSH_depth_integrating_array(:,:,1,:));
    top_depth_bound_array_with_SSH_midpts = top_depth_bound_array_with_SSH(:,:,2:length(unique_times)) - (diff(top_depth_bound_array_with_SSH,1,3)/2);
    
    bottom_depth_bound_array_midpts = bottom_depth_bound_array(:,:,2:length(unique_times)) - squeeze(diff(bottom_depth_bound_array,1,3)/2);
    
    
    depth_integrating_array_midpts = zeros(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_times) - 1);
    for curr_depth_ind = 1:length(depth_ind_inrange)
        curr_k_ind = depth_ind_inrange(curr_depth_ind);
        
        if curr_k_ind == 1
            at_shallowest_level_ind = find(top_depth_bound_array_with_SSH_midpts < z_w_bot(curr_k_ind));
            not_vert_edge_adj_ind = [];
        else
            at_shallowest_level_ind = find((top_depth_bound_array_with_SSH_midpts >= z_w_top(curr_k_ind)) & (top_depth_bound_array_with_SSH_midpts < z_w_bot(curr_k_ind)));
            not_vert_edge_adj_ind = find((top_depth_bound_array_with_SSH_midpts < z_w_top(curr_k_ind)) & (bottom_depth_bound_array_midpts > z_w_bot(curr_k_ind)));
        end
        at_deepest_level_ind = find((bottom_depth_bound_array_midpts > z_w_top(curr_k_ind)) & (bottom_depth_bound_array_midpts <= z_w_bot(curr_k_ind)));
        only_one_in_level_ind = intersect(at_shallowest_level_ind,at_deepest_level_ind);
        
        depth_integrating_curr_level = zeros(length(lon_ind_inrange),length(lat_ind_inrange),length(unique_times) - 1);
        depth_integrating_curr_level(at_shallowest_level_ind) = z_w_bot(curr_k_ind) - top_depth_bound_array_with_SSH_midpts(at_shallowest_level_ind);
        depth_integrating_curr_level(at_deepest_level_ind) = bottom_depth_bound_array_midpts(at_deepest_level_ind) - z_w_top(curr_k_ind);
        depth_integrating_curr_level(only_one_in_level_ind) = bottom_depth_bound_array_midpts(only_one_in_level_ind) - top_depth_bound_array_with_SSH_midpts(only_one_in_level_ind);
        depth_integrating_curr_level(not_vert_edge_adj_ind) = dz(curr_k_ind)*ones(length(not_vert_edge_adj_ind),1);
        
        depth_integrating_array_midpts(:,:,curr_depth_ind,:) = reshape(depth_integrating_curr_level,[length(lon_ind_inrange) length(lat_ind_inrange) 1 (length(unique_times) - 1)]);
    end
    
    min_dzt_depth_integrating_array_with_SSH_midpts_5D = zeros(length(lon_ind_inrange),length(lat_ind_inrange),length(depth_ind_inrange),length(unique_times) - 1,2);
    min_dzt_depth_integrating_array_with_SSH_midpts_5D(:,:,:,:,1) = depth_integrating_array_midpts;
    if depth_ind_inrange(1) == 1
        min_dzt_depth_integrating_array_with_SSH_midpts_5D(:,:,:,:,2) = repmat(dzt(:,:,depth_ind_inrange),[1 1 1 (length(unique_times) - 1)]);
        min_dzt_depth_integrating_array_with_SSH_midpts_5D(:,:,1,:,2) = min_dzt_depth_integrating_array_with_SSH_midpts_5D(:,:,1,:,2) - reshape(top_depth_bound_array_with_SSH_midpts,[length(lon_ind_inrange) length(lat_ind_inrange) 1 (length(unique_times) - 1)]);
    else
        min_dzt_depth_integrating_array_with_SSH_midpts_5D(:,:,:,:,2) = repmat(dzt(:,:,depth_ind_inrange),[1 1 1 (length(unique_times) - 1)]);
    end
    min_dzt_depth_integrating_array_with_SSH_midpts = squeeze(min(min_dzt_depth_integrating_array_with_SSH_midpts_5D,[],5));
    
    
    vol_integrated_inbox = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 1 length(unique_times)]).*sum(min_dzt_depth_integrating_array + SSH_depth_integrating_array,3),2),1));
    vol_integrated_inbox_midpts = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 1 (length(unique_times) - 1)]).*sum(min_dzt_depth_integrating_array_with_SSH_midpts,3),2),1));
    
    
    
    % approximate the temperature change due specifically to entrainment (from top and bottom bounds combined), based on (dh/dt)*T_midpt
    
    % estimate of entrainment contribution from top bound
    
    T_integrated_inbox_midpts = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 1 (length(unique_times) - 1)]).*sum(min_dzt_depth_integrating_array_with_SSH_midpts.*temp_time_midpt_no_nans,3),2),1));
    
    T_time_midpt_mean_inbox = T_integrated_inbox_midpts./vol_integrated_inbox_midpts;
    
    diff_t_min_dzt_depth_integrating_only_top_change = diff_t_min_dzt_depth_integrating_top_only;
    diff_t_min_dzt_depth_integrating_only_top_change(ent_T_dh_top_time_midpt == 0) = 0;
    
    ent_T_minus_Tmean_dh_top_time_midpt = ent_T_dh_top_time_midpt - (diff_t_min_dzt_depth_integrating_only_top_change.*repmat(reshape(T_time_midpt_mean_inbox,[1 1 1 length(T_time_midpt_mean_inbox)]),[size(temp_time_midpt,1) size(temp_time_midpt,2) size(temp_time_midpt,3) 1]));
    
    
    % estimate of entrainment contribution from bottom bound
    
    diff_t_min_dzt_depth_integrating_bottom_only = diff(min_dzt_depth_integrating_array + SSH_depth_integrating_array,1,4) - diff_t_min_dzt_depth_integrating_top_only;
    
    ent_vol_flux_bottom_time_midpt = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 1 (length(unique_times) - 1)]).*sum(-diff_t_min_dzt_depth_integrating_bottom_only,3),2),1))./(86400*diff(unique_times));
    
    ent_T_dh_bottom_time_midpt = diff_t_min_dzt_depth_integrating_bottom_only.*temp_time_midpt;
    
    
    diff_t_min_dzt_depth_integrating_only_bottom_change = diff_t_min_dzt_depth_integrating_bottom_only;
    diff_t_min_dzt_depth_integrating_only_bottom_change(ent_T_dh_bottom_time_midpt == 0) = 0;
    
    ent_T_minus_Tmean_dh_bottom_time_midpt = ent_T_dh_bottom_time_midpt - (diff_t_min_dzt_depth_integrating_only_bottom_change.*repmat(reshape(T_time_midpt_mean_inbox,[1 1 1 length(T_time_midpt_mean_inbox)]),[size(temp_time_midpt,1) size(temp_time_midpt,2) size(temp_time_midpt,3) 1]));
    
    
    
    % separate out entrainment volume fluxes and temperature tendencies from top and bottom surfaces
    
    ent_T_minus_Tmean_dh_top_time_midpt_integrated = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 1 (length(unique_times) - 1)]).*sum(ent_T_minus_Tmean_dh_top_time_midpt,3),2),1));
    ent_T_minus_Tmean_dh_bottom_time_midpt_integrated = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 1 (length(unique_times) - 1)]).*sum(ent_T_minus_Tmean_dh_bottom_time_midpt,3),2),1));
    
    
    % interpolate estimated entrainment fluxes at top and bottom, to the same time points as the other budget terms
    
    ent_vol_flux_top = [(0.5*ent_vol_flux_top_time_midpt(1)); (((diff(unique_times(2:length(unique_times))).*ent_vol_flux_top_time_midpt(2:length(ent_vol_flux_top_time_midpt))) - (diff(diff(unique_times).*ent_vol_flux_top_time_midpt)/2))./diff(time_midpts)); (0.5*ent_vol_flux_top_time_midpt(length(ent_vol_flux_top_time_midpt)))];
    ent_vol_flux_bottom = [(0.5*ent_vol_flux_bottom_time_midpt(1)); (((diff(unique_times(2:length(unique_times))).*ent_vol_flux_bottom_time_midpt(2:length(ent_vol_flux_bottom_time_midpt))) - (diff(diff(unique_times).*ent_vol_flux_bottom_time_midpt)/2))./diff(time_midpts)); (0.5*ent_vol_flux_bottom_time_midpt(length(ent_vol_flux_bottom_time_midpt)))];
    
    ent_T_minus_Tmean_dh_top_integrated = [(0.5*ent_T_minus_Tmean_dh_top_time_midpt_integrated(1)); (((diff(unique_times(2:length(unique_times))).*ent_T_minus_Tmean_dh_top_time_midpt_integrated(2:length(ent_T_minus_Tmean_dh_top_time_midpt_integrated))) - (diff(diff(unique_times).*ent_T_minus_Tmean_dh_top_time_midpt_integrated)/2))./diff(time_midpts)); (0.5*ent_T_minus_Tmean_dh_top_time_midpt_integrated(length(ent_T_minus_Tmean_dh_top_time_midpt_integrated)))];
    ent_T_minus_Tmean_dh_bottom_integrated = [(0.5*ent_T_minus_Tmean_dh_bottom_time_midpt_integrated(1)); (((diff(unique_times(2:length(unique_times))).*ent_T_minus_Tmean_dh_bottom_time_midpt_integrated(2:length(ent_T_minus_Tmean_dh_bottom_time_midpt_integrated))) - (diff(diff(unique_times).*ent_T_minus_Tmean_dh_bottom_time_midpt_integrated)/2))./diff(time_midpts)); (0.5*ent_T_minus_Tmean_dh_bottom_time_midpt_integrated(length(ent_T_minus_Tmean_dh_bottom_time_midpt_integrated)))];
    
    
    % implement scheme for separating top and bottom entrainment tendencies
    ent_T_tend_top = sfc_ent_T_tend_adj + ((ent_T_minus_Tmean_dh_top_integrated./(ent_T_minus_Tmean_dh_top_integrated + ent_T_minus_Tmean_dh_bottom_integrated)).*ent_T_tend_total);
    ent_T_tend_bottom = ent_T_tend_total - ent_T_tend_top;
    
    
    % use different separation for times when the total entrainment tendency is very small
    too_small_total_ind = find((isnan(ent_T_tend_total) == 1) | (abs(ent_T_tend_total) < (1e-8)) | ((abs(ent_T_tend_total))./(abs(ent_T_tend_top) + abs(ent_T_tend_bottom)) < 0.01));
    
    ent_T_minus_Tmean_tend_top_integrated = ent_T_minus_Tmean_dh_top_integrated./(86400*[diff(time_midpts(1:2)); diff(time_midpts); diff(time_midpts((length(time_midpts) - 1):length(time_midpts)))]);
    ent_T_tend_top(too_small_total_ind) = ent_T_minus_Tmean_tend_top_integrated(too_small_total_ind)./vol_integrated_inbox(too_small_total_ind);
    ent_T_tend_bottom(too_small_total_ind) = ent_T_tend_total(too_small_total_ind) - ent_T_tend_top(too_small_total_ind);
    
    
    
    % adjust variable depth-related tendencies computed earlier
    
    var_depth_T_tend_top = var_depth_T_tend_top - sfc_ent_T_tend_adj + ent_T_tend_top;
    var_depth_T_tend_bottom = var_depth_T_tend_bottom + ent_T_tend_bottom;
    
    
end



% compute temperature tendency from archived field

if tend_temp_present == 1
    total_T_tend_integrated_inbox = squeeze(sum(sum(repmat(in_box_mask.*tarea,[1 1 1 length(unique_times)]).*sum(min_dzt_depth_integrating_array.*tot_temp_tend,3),2),1));
    total_T_tend = total_T_tend_integrated_inbox./vol_integrated_inbox;
    
    % add entrainment terms
    total_T_tend = total_T_tend + ent_T_tend_total;
    
    % adjustment of temp. tendency to account for variable-thickness surface layer
    total_T_tend = total_T_tend - sfc_total_T_tend_adj;
end


% assemble output arrays

time_inrange = time(time_ind_inrange);

T_tend_overall_terms_array = [adv_T_tend_total hdiff_T_tend_total ent_T_tend_total diab_vert_T_tend kpp_src_T_tend sfc_sw_flux_T_tend];

T_tend_detailed_terms_array = [adv_T_tend_N_edge adv_T_tend_W_edge adv_T_tend_S_edge adv_T_tend_E_edge adv_T_tend_top_edge adv_T_tend_bottom_edge var_depth_adv_T_tend_top var_depth_adv_T_tend_bottom hdiff_T_tend_N_edge hdiff_T_tend_W_edge hdiff_T_tend_S_edge hdiff_T_tend_E_edge hdiff_T_tend_top_edge hdiff_T_tend_bottom_edge var_depth_hdiff_T_tend_top var_depth_hdiff_T_tend_bottom ent_T_tend_top ent_T_tend_bottom diab_vert_T_tend_top diab_vert_T_tend_bottom kpp_src_T_tend sw_top_flux_T_tend sw_bottom_flux_T_tend longwave_downward_flux_T_tend longwave_upward_flux_T_tend latent_heat_flux_T_tend sensible_heat_flux_T_tend];

vardepth_breakdown_terms_array = [adv_T_tend_N_sloping_top adv_T_tend_W_sloping_top adv_T_tend_S_sloping_top adv_T_tend_E_sloping_top hdiff_T_tend_N_sloping_top hdiff_T_tend_W_sloping_top hdiff_T_tend_S_sloping_top hdiff_T_tend_E_sloping_top ent_T_tend_top adv_T_tend_N_sloping_bottom adv_T_tend_W_sloping_bottom adv_T_tend_S_sloping_bottom adv_T_tend_E_sloping_bottom hdiff_T_tend_N_sloping_bottom hdiff_T_tend_W_sloping_bottom hdiff_T_tend_S_sloping_bottom hdiff_T_tend_E_sloping_bottom ent_T_tend_bottom];

vol_flux_array = [adv_vol_flux_N adv_vol_flux_W adv_vol_flux_S adv_vol_flux_E adv_vol_flux_top adv_vol_flux_bottom adv_vol_flux_N_sloping_top adv_vol_flux_W_sloping_top adv_vol_flux_S_sloping_top adv_vol_flux_E_sloping_top adv_vol_flux_N_sloping_bottom adv_vol_flux_W_sloping_bottom adv_vol_flux_S_sloping_bottom adv_vol_flux_E_sloping_bottom ent_vol_flux_top ent_vol_flux_bottom];


if tend_temp_present == 1
    T_tend_overall_terms_array = [T_tend_overall_terms_array total_T_tend];
    T_tend_detailed_terms_array = [T_tend_detailed_terms_array total_T_tend];
end




% seasonal decomposition of terms

m_T_tend_overall_terms_array = (seasonal_reg_operator_T')*T_tend_overall_terms_array;
T_tend_overall_terms_mean_array = G_seasonal*m_T_tend_overall_terms_array;
T_tend_overall_terms_array = T_tend_overall_terms_array(time_inrange_from_unique_ind,:);
T_tend_overall_terms_mean_array = T_tend_overall_terms_mean_array(time_inrange_from_unique_ind,:);
T_tend_overall_terms_anom_array = T_tend_overall_terms_array - T_tend_overall_terms_mean_array;

m_T_tend_detailed_terms_array = (seasonal_reg_operator_T')*T_tend_detailed_terms_array;
T_tend_detailed_terms_mean_array = G_seasonal*m_T_tend_detailed_terms_array;
T_tend_detailed_terms_array = T_tend_detailed_terms_array(time_inrange_from_unique_ind,:);
T_tend_detailed_terms_mean_array = T_tend_detailed_terms_mean_array(time_inrange_from_unique_ind,:);
T_tend_detailed_terms_anom_array = T_tend_detailed_terms_array - T_tend_detailed_terms_mean_array;

m_vardepth_breakdown_terms_array = (seasonal_reg_operator_T')*vardepth_breakdown_terms_array;
vardepth_breakdown_terms_mean_array = G_seasonal*m_vardepth_breakdown_terms_array;
vardepth_breakdown_terms_array = vardepth_breakdown_terms_array(time_inrange_from_unique_ind,:);
vardepth_breakdown_terms_mean_array = vardepth_breakdown_terms_mean_array(time_inrange_from_unique_ind,:);
vardepth_breakdown_terms_anom_array = vardepth_breakdown_terms_array - vardepth_breakdown_terms_mean_array;

m_T_mean_inbox = (seasonal_reg_operator_T')*T_mean_inbox;
T_mean_inbox_seasonal_mean = G_seasonal*m_T_mean_inbox;
T_mean_inbox = T_mean_inbox(time_inrange_from_unique_ind);
T_mean_inbox_seasonal_mean = T_mean_inbox_seasonal_mean(time_inrange_from_unique_ind);
T_mean_inbox_seasonal_anom = T_mean_inbox - T_mean_inbox_seasonal_mean;

m_vol_flux_array = (seasonal_reg_operator_T')*vol_flux_array;
vol_flux_mean_array = G_seasonal*m_vol_flux_array;
vol_flux_array = vol_flux_array(time_inrange_from_unique_ind,:);
vol_flux_mean_array = vol_flux_mean_array(time_inrange_from_unique_ind,:);
vol_flux_anom_array = vol_flux_array - vol_flux_mean_array;


adv_T_tend_mean_mean_array = [adv_vmean_Tmean_tend_N adv_umean_Tmean_tend_W adv_vmean_Tmean_tend_S adv_umean_Tmean_tend_E adv_wmean_Tmean_tend_top adv_wmean_Tmean_tend_bottom adv_vmean_Tmean_tend_N_sloping_top adv_umean_Tmean_tend_W_sloping_top adv_vmean_Tmean_tend_S_sloping_top adv_umean_Tmean_tend_E_sloping_top adv_vmean_Tmean_tend_N_sloping_bottom adv_umean_Tmean_tend_W_sloping_bottom adv_vmean_Tmean_tend_S_sloping_bottom adv_umean_Tmean_tend_E_sloping_bottom];
adv_T_tend_mean_mean_array = adv_T_tend_mean_mean_array(time_inrange_from_unique_ind,:);

adv_T_tend_mean_anom_array = [adv_vmean_Tanom_tend_N adv_umean_Tanom_tend_W adv_vmean_Tanom_tend_S adv_umean_Tanom_tend_E adv_wmean_Tanom_tend_top adv_wmean_Tanom_tend_bottom adv_vmean_Tanom_tend_N_sloping_top adv_umean_Tanom_tend_W_sloping_top adv_vmean_Tanom_tend_S_sloping_top adv_umean_Tanom_tend_E_sloping_top adv_vmean_Tanom_tend_N_sloping_bottom adv_umean_Tanom_tend_W_sloping_bottom adv_vmean_Tanom_tend_S_sloping_bottom adv_umean_Tanom_tend_E_sloping_bottom];
adv_T_tend_mean_anom_array = adv_T_tend_mean_anom_array(time_inrange_from_unique_ind,:);

adv_T_tend_anom_mean_array = [adv_vanom_Tmean_tend_N adv_uanom_Tmean_tend_W adv_vanom_Tmean_tend_S adv_uanom_Tmean_tend_E adv_wanom_Tmean_tend_top adv_wanom_Tmean_tend_bottom adv_vanom_Tmean_tend_N_sloping_top adv_uanom_Tmean_tend_W_sloping_top adv_vanom_Tmean_tend_S_sloping_top adv_uanom_Tmean_tend_E_sloping_top adv_vanom_Tmean_tend_N_sloping_bottom adv_uanom_Tmean_tend_W_sloping_bottom adv_vanom_Tmean_tend_S_sloping_bottom adv_uanom_Tmean_tend_E_sloping_bottom];
adv_T_tend_anom_mean_array = adv_T_tend_anom_mean_array(time_inrange_from_unique_ind,:);

adv_T_tend_anom_anom_array = [adv_vanom_Tanom_tend_N adv_uanom_Tanom_tend_W adv_vanom_Tanom_tend_S adv_uanom_Tanom_tend_E adv_wanom_Tanom_tend_top adv_wanom_Tanom_tend_bottom adv_vanom_Tanom_tend_N_sloping_top adv_uanom_Tanom_tend_W_sloping_top adv_vanom_Tanom_tend_S_sloping_top adv_uanom_Tanom_tend_E_sloping_top adv_vanom_Tanom_tend_N_sloping_bottom adv_uanom_Tanom_tend_W_sloping_bottom adv_vanom_Tanom_tend_S_sloping_bottom adv_uanom_Tanom_tend_E_sloping_bottom];
adv_T_tend_anom_anom_array = adv_T_tend_anom_anom_array(time_inrange_from_unique_ind,:);

catch err
save('temp_inbox_calc_err.mat','err')
disp(err.message)
disp(err.stack(1))
end

% save('temp_inbox_fcn_ws.mat','-v7.3')
