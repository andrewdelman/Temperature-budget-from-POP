function [output_flux_vec,output_umean_Tmean_vec,output_umean_Tanom_vec,output_uanom_Tmean_vec,output_uanom_Tanom_vec] = flux_edge_vardepth_calc_seasonal_decomp_fcn(input_flux_vec,input_umean_Tmean_vec,input_umean_Tanom_vec,input_uanom_Tmean_vec,input_uanom_Tanom_vec,in_box_ind,curr_ind,hte,htn,dzt,depth_ind_inrange,depth_integrating_array,flux_array_u,flux_array_v,vel_array_u,vel_array_v,tracer_array,tracer_mean_inbox,vol_integrated_inbox,G_seasonal,seasonal_reg_operator_T);


% define a function to calculate fluxes along region edges


curr_i_ind = mod(curr_ind - 1,size(flux_array_u,1)) + 1;
curr_j_ind = ceil(curr_ind/size(flux_array_u,1));

if ismember(curr_ind - 1,in_box_ind) == 0
    curr_depth_integrating = reshape(min([reshape(squeeze(min(depth_integrating_array((curr_i_ind - 1):curr_i_ind,curr_j_ind,:,:),[],1)),[(length(depth_ind_inrange)*length(input_flux_vec)) 1]) repmat(squeeze(min(dzt((curr_i_ind - 1):curr_i_ind,curr_j_ind,depth_ind_inrange),[],1)),[length(input_flux_vec) 1])],[],2),[1 1 length(depth_ind_inrange) length(input_flux_vec)]);
    curr_vel_flux_vec = -squeeze(hte(curr_i_ind - 1,curr_j_ind)*sum(curr_depth_integrating.*vel_array_u(curr_i_ind - 1,curr_j_ind,:,:),3));
    curr_input_flux_vec = squeeze(-hte(curr_i_ind - 1,curr_j_ind)*sum(curr_depth_integrating.*flux_array_u(curr_i_ind - 1,curr_j_ind,:,:),3)) - (curr_vel_flux_vec.*tracer_mean_inbox(:));
    input_flux_vec = input_flux_vec + curr_input_flux_vec;
    
    vel_array_u_norm_at_pos = squeeze(-vel_array_u(curr_i_ind - 1,curr_j_ind,:,:))./repmat(vol_integrated_inbox',[size(vel_array_u,3) 1]);
    m_seasonal_vel_array_u_norm_at_pos = vel_array_u_norm_at_pos*seasonal_reg_operator_T;
    vel_umean_norm_at_pos = m_seasonal_vel_array_u_norm_at_pos*(G_seasonal');
    vel_uanom_norm_at_pos = vel_array_u_norm_at_pos - vel_umean_norm_at_pos;
    
    T_minus_T_inboxmean_at_pos = squeeze(mean(tracer_array((curr_i_ind - 1):curr_i_ind,curr_j_ind,:,:),1)) - repmat(tracer_mean_inbox',[size(tracer_array,3) 1]);
    m_seasonal_T_at_pos = T_minus_T_inboxmean_at_pos*seasonal_reg_operator_T;
    Tmean_at_pos = m_seasonal_T_at_pos*(G_seasonal');
    Tanom_at_pos = T_minus_T_inboxmean_at_pos - Tmean_at_pos;
    
    curr_depth_integrating_squeezed = squeeze(curr_depth_integrating);
    
    curr_input_umean_Tmean_vec = -squeeze(hte(curr_i_ind - 1,curr_j_ind)*sum(curr_depth_integrating_squeezed.*vel_umean_norm_at_pos(:,:).*Tmean_at_pos(:,:),1))';
    input_umean_Tmean_vec = input_umean_Tmean_vec + curr_input_umean_Tmean_vec;
    curr_input_umean_Tanom_vec = -squeeze(hte(curr_i_ind - 1,curr_j_ind)*sum(curr_depth_integrating_squeezed.*vel_umean_norm_at_pos(:,:).*Tanom_at_pos(:,:),1))';
    input_umean_Tanom_vec = input_umean_Tanom_vec + curr_input_umean_Tanom_vec;
    curr_input_uanom_Tmean_vec = -squeeze(hte(curr_i_ind - 1,curr_j_ind)*sum(curr_depth_integrating_squeezed.*vel_uanom_norm_at_pos(:,:).*Tmean_at_pos(:,:),1))';
    input_uanom_Tmean_vec = input_uanom_Tmean_vec + curr_input_uanom_Tmean_vec;
    input_uanom_Tanom_vec = input_uanom_Tanom_vec + ((-curr_input_flux_vec./vol_integrated_inbox(:)) - curr_input_umean_Tmean_vec - curr_input_umean_Tanom_vec - curr_input_uanom_Tmean_vec);
    
end
if ismember(curr_ind + 1,in_box_ind) == 0
    curr_depth_integrating = reshape(min([reshape(squeeze(min(depth_integrating_array(curr_i_ind:(curr_i_ind + 1),curr_j_ind,:,:),[],1)),[(length(depth_ind_inrange)*length(input_flux_vec)) 1]) repmat(squeeze(min(dzt(curr_i_ind:(curr_i_ind + 1),curr_j_ind,depth_ind_inrange),[],1)),[length(input_flux_vec) 1])],[],2),[1 1 length(depth_ind_inrange) length(input_flux_vec)]);
    curr_vel_flux_vec = squeeze(hte(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating.*vel_array_u(curr_i_ind,curr_j_ind,:,:),3));
    curr_input_flux_vec = squeeze(hte(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating.*flux_array_u(curr_i_ind,curr_j_ind,:,:),3)) - (curr_vel_flux_vec.*tracer_mean_inbox(:));
    input_flux_vec = input_flux_vec + curr_input_flux_vec;
    
    vel_array_u_norm_at_pos = squeeze(vel_array_u(curr_i_ind,curr_j_ind,:,:))./repmat(vol_integrated_inbox',[size(vel_array_u,3) 1]);
    m_seasonal_vel_array_u_norm_at_pos = vel_array_u_norm_at_pos*seasonal_reg_operator_T;
    vel_umean_norm_at_pos = m_seasonal_vel_array_u_norm_at_pos*(G_seasonal');
    vel_uanom_norm_at_pos = vel_array_u_norm_at_pos - vel_umean_norm_at_pos;
    
    T_minus_T_inboxmean_at_pos = squeeze(mean(tracer_array(curr_i_ind:(curr_i_ind + 1),curr_j_ind,:,:),1)) - repmat(tracer_mean_inbox',[size(tracer_array,3) 1]);
    m_seasonal_T_at_pos = T_minus_T_inboxmean_at_pos*seasonal_reg_operator_T;
    Tmean_at_pos = m_seasonal_T_at_pos*(G_seasonal');
    Tanom_at_pos = T_minus_T_inboxmean_at_pos - Tmean_at_pos;
    
    curr_depth_integrating_squeezed = squeeze(curr_depth_integrating);
    
    curr_input_umean_Tmean_vec = -squeeze(hte(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating_squeezed.*vel_umean_norm_at_pos(:,:).*Tmean_at_pos(:,:),1))';
    input_umean_Tmean_vec = input_umean_Tmean_vec + curr_input_umean_Tmean_vec;
    curr_input_umean_Tanom_vec = -squeeze(hte(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating_squeezed.*vel_umean_norm_at_pos(:,:).*Tanom_at_pos(:,:),1))';
    input_umean_Tanom_vec = input_umean_Tanom_vec + curr_input_umean_Tanom_vec;
    curr_input_uanom_Tmean_vec = -squeeze(hte(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating_squeezed.*vel_uanom_norm_at_pos(:,:).*Tmean_at_pos(:,:),1))';
    input_uanom_Tmean_vec = input_uanom_Tmean_vec + curr_input_uanom_Tmean_vec;
    input_uanom_Tanom_vec = input_uanom_Tanom_vec + ((-curr_input_flux_vec./vol_integrated_inbox(:)) - curr_input_umean_Tmean_vec - curr_input_umean_Tanom_vec - curr_input_uanom_Tmean_vec);
end
if ismember(curr_ind - size(flux_array_u,1),in_box_ind) == 0
    curr_depth_integrating = reshape(min([reshape(squeeze(min(depth_integrating_array(curr_i_ind,(curr_j_ind - 1):curr_j_ind,:,:),[],2)),[(length(depth_ind_inrange)*length(input_flux_vec)) 1]) repmat(squeeze(min(dzt(curr_i_ind,(curr_j_ind - 1):curr_j_ind,depth_ind_inrange),[],2)),[length(input_flux_vec) 1])],[],2),[1 1 length(depth_ind_inrange) length(input_flux_vec)]);
    curr_vel_flux_vec = -squeeze(htn(curr_i_ind,curr_j_ind - 1)*sum(curr_depth_integrating.*vel_array_v(curr_i_ind,curr_j_ind - 1,:,:),3));
    curr_input_flux_vec = squeeze(-htn(curr_i_ind,curr_j_ind - 1)*sum(curr_depth_integrating.*flux_array_v(curr_i_ind,curr_j_ind - 1,:,:),3)) - (curr_vel_flux_vec.*tracer_mean_inbox(:));
    input_flux_vec = input_flux_vec + curr_input_flux_vec;
    
    vel_array_v_norm_at_pos = squeeze(-vel_array_v(curr_i_ind,curr_j_ind - 1,:,:))./repmat(vol_integrated_inbox',[size(vel_array_v,3) 1]);
    m_seasonal_vel_array_v_norm_at_pos = vel_array_v_norm_at_pos*seasonal_reg_operator_T;
    vel_vmean_norm_at_pos = m_seasonal_vel_array_v_norm_at_pos*(G_seasonal');
    vel_vanom_norm_at_pos = vel_array_v_norm_at_pos - vel_vmean_norm_at_pos;
    
    T_minus_T_inboxmean_at_pos = squeeze(mean(tracer_array(curr_i_ind,(curr_j_ind - 1):curr_j_ind,:,:),2)) - repmat(tracer_mean_inbox',[size(tracer_array,3) 1]);
    m_seasonal_T_at_pos = T_minus_T_inboxmean_at_pos*seasonal_reg_operator_T;
    Tmean_at_pos = m_seasonal_T_at_pos*(G_seasonal');
    Tanom_at_pos = T_minus_T_inboxmean_at_pos - Tmean_at_pos;
    
    curr_depth_integrating_squeezed = squeeze(curr_depth_integrating);
    
    curr_input_umean_Tmean_vec = -squeeze(htn(curr_i_ind,curr_j_ind - 1)*sum(curr_depth_integrating_squeezed.*vel_vmean_norm_at_pos(:,:).*Tmean_at_pos(:,:),1))';
    input_umean_Tmean_vec = input_umean_Tmean_vec + curr_input_umean_Tmean_vec;
    curr_input_umean_Tanom_vec = -squeeze(htn(curr_i_ind,curr_j_ind - 1)*sum(curr_depth_integrating_squeezed.*vel_vmean_norm_at_pos(:,:).*Tanom_at_pos(:,:),1))';
    input_umean_Tanom_vec = input_umean_Tanom_vec + curr_input_umean_Tanom_vec;
    curr_input_uanom_Tmean_vec = -squeeze(htn(curr_i_ind,curr_j_ind - 1)*sum(curr_depth_integrating_squeezed.*vel_vanom_norm_at_pos(:,:).*Tmean_at_pos(:,:),1))';
    input_uanom_Tmean_vec = input_uanom_Tmean_vec + curr_input_uanom_Tmean_vec;
    input_uanom_Tanom_vec = input_uanom_Tanom_vec + ((-curr_input_flux_vec./vol_integrated_inbox(:)) - curr_input_umean_Tmean_vec - curr_input_umean_Tanom_vec - curr_input_uanom_Tmean_vec);
    
end
if ismember(curr_ind + size(flux_array_u,1),in_box_ind) == 0
    curr_depth_integrating = reshape(min([reshape(squeeze(min(depth_integrating_array(curr_i_ind,curr_j_ind:(curr_j_ind + 1),:,:),[],2)),[(length(depth_ind_inrange)*length(input_flux_vec)) 1]) repmat(squeeze(min(dzt(curr_i_ind,curr_j_ind:(curr_j_ind + 1),depth_ind_inrange),[],2)),[length(input_flux_vec) 1])],[],2),[1 1 length(depth_ind_inrange) length(input_flux_vec)]);
    curr_vel_flux_vec = squeeze(htn(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating.*vel_array_v(curr_i_ind,curr_j_ind,:,:),3));
    curr_input_flux_vec = squeeze(htn(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating.*flux_array_v(curr_i_ind,curr_j_ind,:,:),3)) - (curr_vel_flux_vec.*tracer_mean_inbox(:));
    input_flux_vec = input_flux_vec + curr_input_flux_vec;
    
    vel_array_v_norm_at_pos = squeeze(vel_array_v(curr_i_ind,curr_j_ind,:,:))./repmat(vol_integrated_inbox',[size(vel_array_v,3) 1]);
    m_seasonal_vel_array_v_norm_at_pos = vel_array_v_norm_at_pos*seasonal_reg_operator_T;
    vel_vmean_norm_at_pos = m_seasonal_vel_array_v_norm_at_pos*(G_seasonal');
    vel_vanom_norm_at_pos = vel_array_v_norm_at_pos - vel_vmean_norm_at_pos;
    
    T_minus_T_inboxmean_at_pos = squeeze(mean(tracer_array(curr_i_ind,curr_j_ind:(curr_j_ind + 1),:,:),2)) - repmat(tracer_mean_inbox',[size(tracer_array,3) 1]);
    m_seasonal_T_at_pos = T_minus_T_inboxmean_at_pos*seasonal_reg_operator_T;
    Tmean_at_pos = m_seasonal_T_at_pos*(G_seasonal');
    Tanom_at_pos = T_minus_T_inboxmean_at_pos - Tmean_at_pos;
    
    curr_depth_integrating_squeezed = squeeze(curr_depth_integrating);
    
    curr_input_umean_Tmean_vec = -squeeze(htn(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating_squeezed.*vel_vmean_norm_at_pos(:,:).*Tmean_at_pos(:,:),1))';
    input_umean_Tmean_vec = input_umean_Tmean_vec + curr_input_umean_Tmean_vec;
    curr_input_umean_Tanom_vec = -squeeze(htn(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating_squeezed.*vel_vmean_norm_at_pos(:,:).*Tanom_at_pos(:,:),1))';
    input_umean_Tanom_vec = input_umean_Tanom_vec + curr_input_umean_Tanom_vec;
    curr_input_uanom_Tmean_vec = -squeeze(htn(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating_squeezed.*vel_vanom_norm_at_pos(:,:).*Tmean_at_pos(:,:),1))';
    input_uanom_Tmean_vec = input_uanom_Tmean_vec + curr_input_uanom_Tmean_vec;
    input_uanom_Tanom_vec = input_uanom_Tanom_vec + ((-curr_input_flux_vec./vol_integrated_inbox(:)) - curr_input_umean_Tmean_vec - curr_input_umean_Tanom_vec - curr_input_uanom_Tmean_vec);
    
end



output_flux_vec = input_flux_vec;
output_umean_Tmean_vec = input_umean_Tmean_vec;
output_umean_Tanom_vec = input_umean_Tanom_vec;
output_uanom_Tmean_vec = input_uanom_Tmean_vec;
output_uanom_Tanom_vec = input_uanom_Tanom_vec;
