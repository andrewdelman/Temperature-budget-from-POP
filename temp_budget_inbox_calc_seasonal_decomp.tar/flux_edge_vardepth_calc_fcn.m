function [output_flux_vec] = flux_edge_vardepth_calc_fcn(input_flux_vec,in_box_ind,curr_ind,hte,htn,dzt,depth_ind_inrange,depth_integrating_array,flux_array_u,flux_array_v);


% define a function to calculate fluxes along region edges


curr_i_ind = mod(curr_ind - 1,size(flux_array_u,1)) + 1;
curr_j_ind = ceil(curr_ind/size(flux_array_u,1));

if ismember(curr_ind - 1,in_box_ind) == 0
    curr_depth_integrating = reshape(min([reshape(squeeze(min(depth_integrating_array((curr_i_ind - 1):curr_i_ind,curr_j_ind,:,:),[],1)),[(length(depth_ind_inrange)*size(flux_array_u,4)) 1]) repmat(squeeze(min(dzt((curr_i_ind - 1):curr_i_ind,curr_j_ind,depth_ind_inrange),[],1)),[size(flux_array_u,4) 1])],[],2),[1 1 length(depth_ind_inrange) size(flux_array_u,4)]);
    input_flux_vec = input_flux_vec - squeeze(hte(curr_i_ind - 1,curr_j_ind)*sum(curr_depth_integrating.*flux_array_u(curr_i_ind - 1,curr_j_ind,:,:),3));
end
if ismember(curr_ind + 1,in_box_ind) == 0
    curr_depth_integrating = reshape(min([reshape(squeeze(min(depth_integrating_array(curr_i_ind:(curr_i_ind + 1),curr_j_ind,:,:),[],1)),[(length(depth_ind_inrange)*size(flux_array_u,4)) 1]) repmat(squeeze(min(dzt(curr_i_ind:(curr_i_ind + 1),curr_j_ind,depth_ind_inrange),[],1)),[size(flux_array_u,4) 1])],[],2),[1 1 length(depth_ind_inrange) size(flux_array_u,4)]);
    input_flux_vec = input_flux_vec + squeeze(hte(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating.*flux_array_u(curr_i_ind,curr_j_ind,:,:),3));
end
if ismember(curr_ind - size(flux_array_u,1),in_box_ind) == 0
    curr_depth_integrating = reshape(min([reshape(squeeze(min(depth_integrating_array(curr_i_ind,(curr_j_ind - 1):curr_j_ind,:,:),[],2)),[(length(depth_ind_inrange)*size(flux_array_u,4)) 1]) repmat(squeeze(min(dzt(curr_i_ind,(curr_j_ind - 1):curr_j_ind,depth_ind_inrange),[],2)),[size(flux_array_u,4) 1])],[],2),[1 1 length(depth_ind_inrange) size(flux_array_u,4)]);
    input_flux_vec = input_flux_vec - squeeze(htn(curr_i_ind,curr_j_ind - 1)*sum(curr_depth_integrating.*flux_array_v(curr_i_ind,curr_j_ind - 1,:,:),3));
end
if ismember(curr_ind + size(flux_array_u,1),in_box_ind) == 0
    curr_depth_integrating = reshape(min([reshape(squeeze(min(depth_integrating_array(curr_i_ind,curr_j_ind:(curr_j_ind + 1),:,:),[],2)),[(length(depth_ind_inrange)*size(flux_array_u,4)) 1]) repmat(squeeze(min(dzt(curr_i_ind,curr_j_ind:(curr_j_ind + 1),depth_ind_inrange),[],2)),[size(flux_array_u,4) 1])],[],2),[1 1 length(depth_ind_inrange) size(flux_array_u,4)]);
    input_flux_vec = input_flux_vec + squeeze(htn(curr_i_ind,curr_j_ind)*sum(curr_depth_integrating.*flux_array_v(curr_i_ind,curr_j_ind,:,:),3));
end


output_flux_vec = input_flux_vec;
